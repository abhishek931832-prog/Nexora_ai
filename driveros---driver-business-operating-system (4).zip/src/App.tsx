import React, { useState, useEffect } from 'react';
import { Header, MainPillar, PILLARS_CONFIG } from './components/Header';
import { TodayCockpit } from './components/TodayCockpit';
import { PaymentsView } from './components/PaymentsView';
import { ProfitAnalyticsView } from './components/ProfitAnalyticsView';
import { ProfitMap } from './components/ProfitMap';
import { TripLedger } from './components/TripLedger';
import { ExpenseTracker } from './components/ExpenseTracker';
import { AICoachVoice } from './components/AICoachVoice';
import { SafetyFatigue } from './components/SafetyFatigue';
import { CustomerCRM } from './components/CustomerCRM';
import { ReportsTax } from './components/ReportsTax';
import { SecurityEnclave } from './components/SecurityEnclave';
import { NewTripModal } from './components/NewTripModal';
import { ReceiptScanModal } from './components/ReceiptScanModal';
import { DriverAuthModal } from './components/DriverAuthModal';
import { CustomerPaymentReceiptModal } from './components/CustomerPaymentReceiptModal';
import { UltraSecurityShield, UltraSecurityState } from './components/UltraSecurityShield';

// DRIVEROS 12 Major Pillars + Problem Center Views
import { RideWorkView } from './components/views/RideWorkView';
import { DriverIntelligenceView } from './components/views/DriverIntelligenceView';
import { SmartMobilityView } from './components/views/SmartMobilityView';
import { SaathiAIView } from './components/views/SaathiAIView';
import { MoneyView } from './components/views/MoneyView';
import { VehicleView } from './components/views/VehicleView';
import { BusinessView } from './components/views/BusinessView';
import { DocumentBillEngineView } from './components/views/DocumentBillEngineView';
import { TrustIdentityView } from './components/views/TrustIdentityView';
import { RealtimeOperationsView } from './components/views/RealtimeOperationsView';
import { PlatformHubView } from './components/views/PlatformHubView';
import { IncentivesView } from './components/views/IncentivesView';
import { DriverProblemCenter } from './components/views/DriverProblemCenter';
import { DriverOSMasterDashboard } from './components/DriverOSMasterDashboard';
import { CustomerBookingApp } from './components/CustomerBookingApp';
import { DriverOSBookingFlowModal } from './components/DriverOSBookingFlowModal';
import { BottomNavDock } from './components/BottomNavDock';
import { rideBookingService } from './services/rideBookingService';

import { 
  initialDriverProfile, 
  initialDriversList,
  initialTrips, 
  initialExpenses, 
  initialDirectClients, 
  initialDocuments, 
  initialShiftState, 
  initialFatigueState, 
  initialMicroInsuranceState 
} from './data/mockInitialData';

import { 
  DriverProfile, 
  TripRecord, 
  ExpenseRecord, 
  DirectClientRecord, 
  DocumentRecord, 
  ShiftState,
  RideBooking
} from './types';

export default function App() {
  // Global Driver & State
  const [driver, setDriver] = useState<DriverProfile>(initialDriverProfile);
  const [availableDrivers, setAvailableDrivers] = useState<DriverProfile[]>(initialDriversList);
  const [trips, setTrips] = useState<TripRecord[]>(initialTrips);
  const [expenses, setExpenses] = useState<ExpenseRecord[]>(initialExpenses);
  const [clients, setClients] = useState<DirectClientRecord[]>(initialDirectClients);
  const [documents, setDocuments] = useState<DocumentRecord[]>(initialDocuments);
  const [shift, setShift] = useState<ShiftState>(initialShiftState);
  const [fatigue, setFatigue] = useState(initialFatigueState);
  const [insurance, setInsurance] = useState(initialMicroInsuranceState);

  // DRIVESMART 10-Pillar Navigation State (Defaults to HOME / DriverOS Master Dashboard)
  const [activePillar, setActivePillar] = useState<MainPillar>('HOME');
  const [activeSubView, setActiveSubView] = useState<string>('overview');

  // Modals & Popups
  const [isNewTripOpen, setIsNewTripOpen] = useState(false);
  const [isReceiptScanOpen, setIsReceiptScanOpen] = useState(false);
  const [isDriverAuthOpen, setIsDriverAuthOpen] = useState(false);
  const [isCustomerPaymentOpen, setIsCustomerPaymentOpen] = useState(false);
  const [activeReceiptTrip, setActiveReceiptTrip] = useState<TripRecord | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // DriverOS Booking Flow State (Customer App -> Backend -> DriverOS -> PDF)
  const [activeRide, setActiveRide] = useState<RideBooking | null>(null);
  const [isBookingFlowModalOpen, setIsBookingFlowModalOpen] = useState(false);

  // Sync active ride from /api/rides/active
  useEffect(() => {
    let isSubscribed = true;
    const fetchActive = async () => {
      try {
        const ride = await rideBookingService.getActiveRide();
        if (isSubscribed) {
          if (ride && ['pending', 'searching', 'accepted', 'arriving', 'started', 'completed', 'paid'].includes(ride.status)) {
            setActiveRide(ride);
          }
        }
      } catch {
        // ignore network hiccups
      }
    };
    fetchActive();
    const timer = setInterval(fetchActive, 2500);
    return () => {
      isSubscribed = false;
      clearInterval(timer);
    };
  }, []);

  // Military-Grade Security State
  const [securityState, setSecurityState] = useState<UltraSecurityState>({
    isLocked: false,
    privacyBlurActive: false,
    camouflageActive: false,
    autoLockMinutes: 5,
    failedAttempts: 0,
    lockoutUntil: null,
    integrityVerified: true,
    lastAuditHash: 'SHA256:8f43a9b1c2d3e4f50123456789abcdef0123456789abcdef',
  });

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const handleEmergencyWipe = () => {
    setSecurityState(prev => ({
      ...prev,
      isLocked: true,
      failedAttempts: 0,
      lockoutUntil: null,
    }));
    showToast('EMERGENCY ZEROIZATION COMPLETE: All volatile cryptographic session keys purged.');
  };

  const handleToggleDuty = () => {
    setShift(prev => ({
      ...prev,
      isOnDuty: !prev.isOnDuty,
    }));
    showToast(shift.isOnDuty ? 'Shift Paused. Data encrypted.' : 'Shift Active. Live Profit Velocity tracking enabled.');
  };

  const handleLanguageChange = (lang: string) => {
    setDriver(prev => ({ ...prev, preferredLanguage: lang as any }));
    showToast(`Language set to ${lang.toUpperCase()}`);
  };

  const handleSelectDriver = (selectedDriver: DriverProfile) => {
    setDriver(selectedDriver);
    showToast(`Driver profile switched to ${selectedDriver.name} (${selectedDriver.vehiclePlate})`);
  };

  const handleAddNewDriver = (newDriver: DriverProfile) => {
    setAvailableDrivers(prev => [newDriver, ...prev]);
    setDriver(newDriver);
    showToast(`Welcome ${newDriver.name}! New driver profile created and logged in.`);
  };

  const handleOpenCustomerPayment = (trip?: TripRecord | null) => {
    setActiveReceiptTrip(trip || null);
    setIsCustomerPaymentOpen(true);
  };

  const handleSaveTrip = (newTrip: TripRecord) => {
    setTrips(prev => [newTrip, ...prev]);
    showToast(`Trip logged! +₹${newTrip.netProfit.toFixed(0)} added to net in-pocket profit.`);
  };

  const handleSaveExpense = (newExpense: ExpenseRecord) => {
    setExpenses(prev => [newExpense, ...prev]);
    showToast(`Expense logged: ₹${newExpense.amount} (${newExpense.category})`);
  };

  const handleDeleteExpense = (id: string) => {
    setExpenses(prev => prev.filter(e => e.id !== id));
    showToast('Expense record deleted.');
  };

  const handleAddClient = (newClient: DirectClientRecord) => {
    setClients(prev => [newClient, ...prev]);
    showToast(`Direct client ${newClient.name} added with 0% platform commission!`);
  };

  const handleConvertToDirectClient = (passengerName: string, pickup: string, dropoff: string) => {
    const newClient: DirectClientRecord = {
      id: `client_${Date.now()}`,
      name: passengerName || 'Valued Corporate Commuter',
      phone: '9845012345',
      companyOrLocality: 'Self / Corporate',
      notes: `Converted from aggregator ride: ${pickup} to ${dropoff}`,
      totalTripsCompleted: 1,
      totalRevenueGenerated: 850,
      rating: 5,
      preferredRoute: `${pickup} → ${dropoff}`,
      isVip: false,
    };
    handleAddClient(newClient);
    setActivePillar('BUSINESS');
    setActiveSubView('customers');
  };

  const handleVoiceExpenseAdd = (amount: number, category: string, notes: string) => {
    const expense: ExpenseRecord = {
      id: `exp_voice_${Date.now()}`,
      date: new Date().toISOString(),
      category: category as any,
      amount,
      merchantName: 'Voice Quick Log',
      paymentMethod: 'UPI',
      isTaxDeductible: true,
      notes: `Voice logged: ${notes}`,
      isEncrypted: true,
    };
    handleSaveExpense(expense);
  };

  const handlePaymentCollected = (collectedTrip: TripRecord) => {
    setTrips(prev => [collectedTrip, ...prev]);
    showToast(`Payment collected! ₹${collectedTrip.grossFare} received via ${collectedTrip.paymentMode}. PDF receipt generated.`);
  };

  // Switch Pillar Handler
  const handleSelectPillar = (pillar: MainPillar, defaultSubView?: string) => {
    setActivePillar(pillar);
    if (defaultSubView) {
      setActiveSubView(defaultSubView);
      return;
    }
    const found = PILLARS_CONFIG.find(p => p.id === pillar);
    if (found && (found as any).defaultSub) {
      setActiveSubView((found as any).defaultSub);
    } else {
      setActiveSubView('new-ride');
    }
  };

  return (
    <div className={`min-h-screen bg-slate-950 text-slate-100 flex flex-col selection:bg-emerald-500 selection:text-black ${securityState.privacyBlurActive ? 'privacy-blur-active' : ''}`}>
      
      {/* Top Main Navigation */}
      <Header
        driver={driver}
        shift={shift}
        onToggleDuty={handleToggleDuty}
        insurance={insurance}
        fatigue={fatigue}
        activePillar={activePillar}
        activeSubView={activeSubView}
        onSelectPillar={handleSelectPillar}
        onSelectSubView={setActiveSubView}
        onOpenVoice={() => {
          setActivePillar('SAATHI_AI');
          setActiveSubView('voice-assistant');
        }}
        onOpenNewTrip={() => setIsNewTripOpen(true)}
        onOpenScanReceipt={() => setIsReceiptScanOpen(true)}
        onOpenDriverAuth={() => setIsDriverAuthOpen(true)}
        onOpenCustomerPayment={() => handleOpenCustomerPayment()}
        onOpenBookingFlow={() => setIsBookingFlowModalOpen(true)}
        activeBookingRide={activeRide}
        onLockApp={() => setSecurityState(prev => ({ ...prev, isLocked: true }))}
        privacyBlurActive={securityState.privacyBlurActive}
        onTogglePrivacyBlur={() => setSecurityState(prev => ({ ...prev, privacyBlurActive: !prev.privacyBlurActive }))}
        activeLanguage={driver.preferredLanguage}
        onLanguageChange={handleLanguageChange}
      />

      {/* Floating Notification Toast */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-emerald-600 text-white text-xs font-bold px-4 py-3 rounded-2xl shadow-2xl border border-emerald-400/40 flex items-center gap-2 animate-in slide-in-from-bottom-5 duration-200">
          <span className="w-2 h-2 rounded-full bg-white animate-ping" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Main Content Area Displaying Active Pillar and Sub-View */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-6 pb-24 md:pb-20">
        
        {/* ========================================================= */}
        {/* MASTER DASHBOARD: DRIVEROS 10-PILLAR OVERVIEW             */}
        {/* ========================================================= */}
        {activePillar === 'HOME' && (
          <DriverOSMasterDashboard
            driver={driver}
            shift={shift}
            trips={trips}
            expenses={expenses}
            activeRide={activeRide}
            onToggleDuty={handleToggleDuty}
            onNavigatePillar={handleSelectPillar}
            onOpenNewTrip={() => setIsNewTripOpen(true)}
            onOpenScanReceipt={() => setIsReceiptScanOpen(true)}
            onOpenCustomerPayment={() => handleOpenCustomerPayment()}
            onOpenVoice={() => {
              setActivePillar('SAATHI_AI');
              setActiveSubView('ask-anything');
            }}
            onTriggerEmergencySOS={() => {
              setActivePillar('SAFETY');
              setActiveSubView('emergency-sos');
              showToast('🚨 SOS ALERT INITIATED: Live location & vehicle status dispatched.');
            }}
            onOpenBookingFlow={() => setIsBookingFlowModalOpen(true)}
          />
        )}

        {/* ========================================================= */}
        {/* CUSTOMER APP: DIRECT CAB BOOKING FLOW SIMULATOR           */}
        {/* ========================================================= */}
        {activePillar === 'CUSTOMER_BOOKING' && (
          <CustomerBookingApp
            driver={driver}
            activeRide={activeRide}
            onRideUpdated={(ride) => {
              setActiveRide(ride);
              if (ride.status === 'searching' || ride.status === 'pending') {
                setIsBookingFlowModalOpen(true);
                showToast(`New Ride Request: ${ride.pickup} → ${ride.destination} (₹${ride.fareEstimate})`);
              }
            }}
            onSwitchToDriverOS={() => {
              setActivePillar('HOME');
              setIsBookingFlowModalOpen(true);
            }}
          />
        )}

        {/* ========================================================= */}
        {/* PILLAR 1: RIDE COMMAND CENTER (Taxi lifecycle & navigation) */}
        {/* ========================================================= */}
        {activePillar === 'RIDE_WORK' && (
          <RideWorkView
            driver={driver}
            trips={trips}
            activeSubItem={activeSubView}
            onSelectSubItem={setActiveSubView}
            onOpenNewTrip={() => setIsNewTripOpen(true)}
            onOpenCustomerPayment={handleOpenCustomerPayment}
            onSaveTrip={handlePaymentCollected}
            onOpenMap={() => {
              setActivePillar('SMART_MOBILITY');
              setActiveSubView('moving-car');
            }}
          />
        )}

        {/* ========================================================= */}
        {/* PILLAR 2: DRIVER INTELLIGENCE ENGINE                      */}
        {/* ========================================================= */}
        {activePillar === 'DRIVER_INTELLIGENCE' && (
          <DriverIntelligenceView
            driver={driver}
            trips={trips}
            expenses={expenses}
            activeSubItem={activeSubView}
            onSelectSubItem={setActiveSubView}
            onOpenMap={() => {
              setActivePillar('SMART_MOBILITY');
              setActiveSubView('moving-car');
            }}
          />
        )}

        {/* ========================================================= */}
        {/* PILLAR 3: SMART MOBILITY ENGINE                           */}
        {/* ========================================================= */}
        {activePillar === 'SMART_MOBILITY' && (
          <SmartMobilityView
            driver={driver}
            activeSubItem={activeSubView}
            onSelectSubItem={setActiveSubView}
            onOpenBookingFlow={() => setIsBookingFlowModalOpen(true)}
          />
        )}

        {/* ========================================================= */}
        {/* PILLAR 4: SAATHI AI COPILOT                               */}
        {/* ========================================================= */}
        {activePillar === 'SAATHI_AI' && (
          <SaathiAIView
            driver={driver}
            trips={trips}
            expenses={expenses}
            activeSubItem={activeSubView}
            onSelectSubItem={setActiveSubView}
            onQuickAddExpense={handleVoiceExpenseAdd}
          />
        )}

        {/* ========================================================= */}
        {/* PILLAR 5: DRIVER FINANCIAL OS                             */}
        {/* ========================================================= */}
        {activePillar === 'MONEY' && (
          <MoneyView
            driver={driver}
            trips={trips}
            expenses={expenses}
            activeSubItem={activeSubView}
            onSelectSubItem={setActiveSubView}
            onOpenPayoutModal={() => showToast(`IMPS Fast Payout of daily balance initiated to ${driver.bankDetails?.bankName || 'HDFC Bank'}`)}
            onOpenScanReceipt={() => setIsReceiptScanOpen(true)}
          />
        )}

        {/* ========================================================= */}
        {/* PILLAR 6: VEHICLE INTELLIGENCE                            */}
        {/* ========================================================= */}
        {activePillar === 'VEHICLE' && (
          <VehicleView
            driver={driver}
            documents={documents}
            activeSubItem={activeSubView}
            onSelectSubItem={setActiveSubView}
          />
        )}

        {/* ========================================================= */}
        {/* PILLAR 7: DRIVER SAFETY CENTER                            */}
        {/* ========================================================= */}
        {activePillar === 'SAFETY' && (
          <SafetyFatigue
            driver={driver}
            fatigue={fatigue}
            insurance={insurance}
            activeSubSection={activeSubView as any}
            onChangeSubSection={setActiveSubView}
            onTriggerAlertTest={() => showToast('Sensor Alert Test executed: Eye blink cadence normal')}
            onClaimInsurance={() => showToast('Micro-Insurance claim registered: Cashless emergency hospital admit authorized')}
          />
        )}

        {/* ========================================================= */}
        {/* PILLAR 8: BUSINESS INTELLIGENCE                           */}
        {/* ========================================================= */}
        {activePillar === 'BUSINESS' && (
          <BusinessView
            driver={driver}
            trips={trips}
            expenses={expenses}
            clients={clients}
            activeSubItem={activeSubView}
            onSelectSubItem={setActiveSubView}
            onAddClient={handleAddClient}
          />
        )}

        {/* ========================================================= */}
        {/* PILLAR 9: DOCUMENT & BILL ENGINE                          */}
        {/* ========================================================= */}
        {activePillar === 'DOCUMENT_BILL_ENGINE' && (
          <DocumentBillEngineView
            driver={driver}
            trips={trips}
            expenses={expenses}
            onOpenScanReceipt={() => setIsReceiptScanOpen(true)}
            onOpenCustomerPayment={handleOpenCustomerPayment}
            onOpenNewTrip={() => setIsNewTripOpen(true)}
          />
        )}

        {/* ========================================================= */}
        {/* PILLAR 10: TRUST & IDENTITY                               */}
        {/* ========================================================= */}
        {activePillar === 'TRUST_IDENTITY' && (
          <TrustIdentityView
            driver={driver}
            privacyBlurActive={securityState.privacyBlurActive}
            onTogglePrivacyBlur={() => setSecurityState(prev => ({ ...prev, privacyBlurActive: !prev.privacyBlurActive }))}
            onOpenDriverAuth={() => setIsDriverAuthOpen(true)}
          />
        )}

        {/* ========================================================= */}
        {/* PILLAR 11: REAL-TIME OPERATIONS                           */}
        {/* ========================================================= */}
        {activePillar === 'REALTIME_OPERATIONS' && (
          <RealtimeOperationsView
            driver={driver}
            activeRide={activeRide}
            onOpenBookingFlow={() => setIsBookingFlowModalOpen(true)}
            onOpenMap={() => {
              setActivePillar('SMART_MOBILITY');
              setActiveSubView('moving-car');
            }}
          />
        )}

        {/* ========================================================= */}
        {/* PILLAR 12: PLATFORM HUB                                   */}
        {/* ========================================================= */}
        {activePillar === 'PLATFORM_HUB' && (
          <PlatformHubView
            driver={driver}
            trips={trips}
            activeSubItem={activeSubView}
            onSelectSubItem={setActiveSubView}
          />
        )}

        {/* ========================================================= */}
        {/* MAP RADAR & MOVING CAR DIRECT TAB                         */}
        {/* ========================================================= */}
        {activePillar === 'SMART_MAP' && (
          <ProfitMap />
        )}

        {/* ========================================================= */}
        {/* INCENTIVES                                                */}
        {/* ========================================================= */}
        {activePillar === 'INCENTIVES' && (
          <IncentivesView
            driver={driver}
            activeSubItem={activeSubView}
            onSelectSubItem={setActiveSubView}
          />
        )}

        {/* ========================================================= */}
        {/* DRIVER PROBLEM CENTER (Phone 9318320977)                  */}
        {/* ========================================================= */}
        {activePillar === 'PROBLEM_CENTER' && (
          <DriverProblemCenter
            driver={driver}
            initialCategory={activeSubView as any}
          />
        )}

        {/* ========================================================= */}
        {/* COCKPIT / TODAY FALLBACK                                  */}
        {/* ========================================================= */}
        {activePillar === 'TODAY' && (
          <TodayCockpit
            driver={driver}
            trips={trips}
            expenses={expenses}
            shift={shift}
            fatigue={fatigue}
            insurance={insurance}
            activeSubSection={activeSubView as any}
            onChangeSubSection={setActiveSubView}
            onToggleDuty={handleToggleDuty}
            onOpenNewTrip={() => setIsNewTripOpen(true)}
            onOpenCustomerPayment={handleOpenCustomerPayment}
            onOpenVoice={() => {
              setActivePillar('SAATHI_AI');
              setActiveSubView('voice-assistant');
            }}
            onNavigateSubView={(sub) => setActiveSubView(sub)}
          />
        )}

        {/* Legacy WORK & INSIGHTS compatibility mappings */}
        {activePillar === 'WORK' && (
          <div>
            {activeSubView === 'trips' && (
              <TripLedger
                driver={driver}
                trips={trips}
                onOpenNewTrip={() => setIsNewTripOpen(true)}
                onConvertToDirectClient={handleConvertToDirectClient}
                onOpenCustomerPayment={(trip) => handleOpenCustomerPayment(trip)}
              />
            )}
            {activeSubView === 'payments' && (
              <PaymentsView
                driver={driver}
                trips={trips}
                onOpenCustomerPayment={handleOpenCustomerPayment}
              />
            )}
            {activeSubView === 'expenses' && (
              <ExpenseTracker
                driver={driver}
                expenses={expenses}
                onAddExpense={handleSaveExpense}
                onDeleteExpense={handleDeleteExpense}
              />
            )}
          </div>
        )}

        {activePillar === 'INSIGHTS' && (
          <div>
            {activeSubView === 'profit' && (
              <ProfitAnalyticsView
                driver={driver}
                trips={trips}
                expenses={expenses}
                onNavigateSubView={(sub) => setActiveSubView(sub)}
              />
            )}
            {activeSubView === 'map' && (
              <ProfitMap />
            )}
            {activeSubView === 'coach' && (
              <AICoachVoice
                driver={driver}
                trips={trips}
                expenses={expenses}
                onAddExpenseFromVoice={handleVoiceExpenseAdd}
              />
            )}
          </div>
        )}

      </main>

      {/* Global Modals */}
      {isNewTripOpen && (
        <NewTripModal
          driver={driver}
          isOpen={isNewTripOpen}
          onClose={() => setIsNewTripOpen(false)}
          onSaveTrip={handleSaveTrip}
        />
      )}

      {isReceiptScanOpen && (
        <ReceiptScanModal
          isOpen={isReceiptScanOpen}
          onClose={() => setIsReceiptScanOpen(false)}
          onSaveExpense={handleSaveExpense}
        />
      )}

      {isDriverAuthOpen && (
        <DriverAuthModal
          currentDriver={driver}
          availableDrivers={availableDrivers}
          isOpen={isDriverAuthOpen}
          onClose={() => setIsDriverAuthOpen(false)}
          onSelectDriver={handleSelectDriver}
          onAddNewDriver={handleAddNewDriver}
        />
      )}

      {isCustomerPaymentOpen && (
        <CustomerPaymentReceiptModal
          driver={driver}
          isOpen={isCustomerPaymentOpen}
          initialTrip={activeReceiptTrip}
          onClose={() => {
            setIsCustomerPaymentOpen(false);
            setActiveReceiptTrip(null);
          }}
          onPaymentComplete={handlePaymentCollected}
        />
      )}

      {/* DriverOS Booking Flow Modal (Customer App -> Backend -> DriverOS -> PDF) */}
      {(isBookingFlowModalOpen || activeRide) && (
        <DriverOSBookingFlowModal
          driver={driver}
          activeRide={activeRide}
          isOpen={isBookingFlowModalOpen || !!activeRide}
          onClose={() => {
            setIsBookingFlowModalOpen(false);
            setActiveRide(null);
          }}
          onRideUpdated={(ride) => {
            if (ride.status === 'declined') {
              setActiveRide(null);
              setIsBookingFlowModalOpen(false);
              showToast('Ride Request Declined');
            } else {
              setActiveRide(ride);
              showToast(`Ride status updated: ${ride.status.toUpperCase()}`);
            }
          }}
          onAddTripToLedger={(trip) => {
            handleSaveTrip({
              id: `TRIP-DIRECT-${Date.now().toString().slice(-4)}`,
              timestamp: new Date().toISOString(),
              platform: 'DIRECT_CLIENT',
              pickupLocation: trip.pickupLocation,
              dropoffLocation: trip.dropoffLocation,
              distanceKm: trip.distanceKm,
              durationMinutes: trip.durationMinutes,
              grossFare: trip.grossFare,
              platformCommission: 0,
              fuelCost: trip.fuelCost,
              tollCost: trip.tollCost,
              tips: trip.tips || 0,
              netProfit: trip.netProfit,
              deadheadKm: trip.deadheadKm || 0,
              passengerName: trip.passengerName,
              paymentMode: trip.paymentMode || 'UPI',
            });
          }}
        />
      )}

      {/* Ultra-Defense Military Grade Security Shield & Lock Screen */}
      <UltraSecurityShield
        driver={driver}
        securityState={securityState}
        onUpdateSecurityState={setSecurityState}
        onEmergencyWipe={handleEmergencyWipe}
      />

      {/* Persistent Bottom DriverOS Dock (Matching ASCII: 🏠 HOME  🚕 RIDES  🗺️ MAP  💰 MONEY  🤖 SAATHI  🚗 VEHICLE  ⚙️ MORE) */}
      <BottomNavDock
        activePillar={activePillar}
        onSelectPillar={handleSelectPillar}
        onOpenScanReceipt={() => setIsReceiptScanOpen(true)}
        onOpenCustomerPayment={() => handleOpenCustomerPayment()}
        onLockApp={() => setSecurityState(prev => ({ ...prev, isLocked: true }))}
      />

    </div>
  );
}
