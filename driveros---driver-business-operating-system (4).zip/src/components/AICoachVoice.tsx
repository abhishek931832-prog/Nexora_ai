import React, { useState } from 'react';
import { 
  Sparkles, 
  Mic, 
  Send, 
  TrendingUp, 
  AlertTriangle, 
  ShieldAlert, 
  Compass, 
  Volume2, 
  MessageSquare, 
  CheckCircle2, 
  Zap, 
  DollarSign, 
  Car,
  RefreshCw
} from 'lucide-react';
import { DriverProfile, TripRecord, ExpenseRecord } from '../types';
import { fetchAICoachAdvice, processVoiceInput } from '../services/api';

interface AICoachVoiceProps {
  driver: DriverProfile;
  trips: TripRecord[];
  expenses: ExpenseRecord[];
  onAddExpenseFromVoice: (amount: number, category: any, notes?: string) => void;
}

export const AICoachVoice: React.FC<AICoachVoiceProps> = ({
  driver,
  trips,
  expenses,
  onAddExpenseFromVoice,
}) => {
  const [activeTab, setActiveTab] = useState<'COACH' | 'VOICE_CHAT' | 'ANOMALIES'>('COACH');
  const [coachingData, setCoachingData] = useState<string | null>(null);
  const [isLoadingCoach, setIsLoadingCoach] = useState(false);
  const [customQuestion, setCustomQuestion] = useState('');

  // Voice Chat State
  const [chatMessages, setChatMessages] = useState<Array<{ sender: 'user' | 'assistant'; text: string; action?: any }>>([
    {
      sender: 'assistant',
      text: 'Namaste Ramesh bhai! Main aapka Saathi AI assistant hoon. Aap mujhse bol kar kharche log kar sakte hain ya pooch sakte hain ki aaj maximum munafa kahan milega.',
    }
  ]);
  const [inputQuery, setInputQuery] = useState('');
  const [isProcessingVoice, setIsProcessingVoice] = useState(false);
  const [isListening, setIsListening] = useState(false);

  // Anomaly Alerts Detection
  const anomalies = [
    {
      id: 'ANO-01',
      type: 'COMMISSION_LEAK',
      severity: 'HIGH',
      title: 'Ola Commission Bleed on Short Trips',
      description: 'You completed 4 short hops (<8km) on Ola today, giving away 28% (₹260). If taken via Namma Yatri or Direct UPI, your net profit would be ₹260 higher for the exact same diesel/CNG burn.',
      actionText: 'Prioritize Direct / Namma Yatri for trips under 10km',
    },
    {
      id: 'ANO-02',
      type: 'FUEL_EFFICIENCY_DROP',
      severity: 'MEDIUM',
      title: 'CNG Efficiency Variance (-18%) in Whitefield',
      description: 'Vehicle fuel economy dropped to 18.2 km/kg between 4:30 PM - 6:30 PM due to bumper-to-bumper AC idling on ITPL Main Road. Reposition to Outer Ring Road flyover corridors.',
      actionText: 'Enable Eco-Flyover Routing in Profit Map',
    },
    {
      id: 'ANO-03',
      type: 'DEADHEAD_WARNING',
      severity: 'HIGH',
      title: 'Avoid Outstation Drops without Pre-Booked Return',
      description: 'A drop to Hosur or Devanahalli past 10 PM has an 82% probability of a 35km empty return deadhead. Reject unless client offers private return fare.',
      actionText: 'Enable Return Fare Surcharge in Direct Rate Card',
    },
  ];

  const handleFetchCoach = async () => {
    setIsLoadingCoach(true);
    try {
      const gross = trips.reduce((s, t) => s + t.grossFare, 0);
      const net = trips.reduce((s, t) => s + t.netProfit, 0);
      const res = await fetchAICoachAdvice(
        driver,
        {
          grossEarnings: gross,
          netProfit: net,
          totalTrips: trips.length,
          olaShare: '45%',
          uberShare: '25%',
          nammaShare: '20%',
          directShare: '10%',
        },
        customQuestion || undefined
      );
      setCoachingData(res.coachingAdvice || 'Analysis generated successfully.');
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoadingCoach(false);
    }
  };

  const handleSendMessage = async (textToSend?: string) => {
    const message = textToSend || inputQuery;
    if (!message.trim()) return;

    const newMsgs = [...chatMessages, { sender: 'user' as const, text: message }];
    setChatMessages(newMsgs);
    setInputQuery('');
    setIsProcessingVoice(true);

    try {
      const res = await processVoiceInput(message, 'hindi-english', {
        isOnShift: true,
        todayEarnings: 3400,
        location: 'Koramangala 5th Block',
      });

      if (res.extractedData?.amount && res.extractedData?.category) {
        onAddExpenseFromVoice(
          res.extractedData.amount,
          res.extractedData.category,
          res.extractedData.notes || `Voice logged: ${message}`
        );
      }

      setChatMessages([
        ...newMsgs,
        {
          sender: 'assistant',
          text: res.textReply || 'Samajh gaya driver bhai!',
          action: res.actionExecuted,
        }
      ]);
    } catch (err) {
      console.error(err);
    } finally {
      setIsProcessingVoice(false);
    }
  };

  const handleSimulateVoiceInput = (sampleText: string) => {
    setInputQuery(sampleText);
    handleSendMessage(sampleText);
  };

  return (
    <div className="space-y-6 pb-12">
      
      {/* Top Navigation Strip */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-400">
              <Sparkles className="w-5 h-5" />
            </span>
            <h2 className="text-lg sm:text-xl font-bold text-white tracking-tight">
              Saathi AI Strategist & Hindi Voice Assistant
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Personalized profit intelligence, platform commission audit, and in-cab voice commands.
          </p>
        </div>

        {/* Tab Selector */}
        <div className="flex items-center gap-1.5 bg-slate-800 p-1 rounded-xl border border-slate-700">
          <button
            onClick={() => setActiveTab('COACH')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
              activeTab === 'COACH'
                ? 'bg-emerald-600 text-white shadow'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Compass className="w-3.5 h-3.5" />
            <span>AI Coach</span>
          </button>

          <button
            onClick={() => setActiveTab('VOICE_CHAT')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
              activeTab === 'VOICE_CHAT'
                ? 'bg-emerald-600 text-white shadow'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Mic className="w-3.5 h-3.5" />
            <span>Voice Assistant</span>
          </button>

          <button
            onClick={() => setActiveTab('ANOMALIES')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
              activeTab === 'ANOMALIES'
                ? 'bg-amber-500 text-slate-950 font-bold shadow'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>Anomalies (3)</span>
          </button>
        </div>
      </div>

      {/* Tab 1: AI Profit Coach */}
      {activeTab === 'COACH' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-4">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Zap className="w-5 h-5 text-emerald-400" /> Personalized Driver Profit Blueprint
                </h3>
                <p className="text-xs text-slate-400">
                  Trained on your historical trips ({driver.vehicleModel} - {driver.fuelType}) to eliminate Ola commission leakage.
                </p>
              </div>
              <button
                onClick={handleFetchCoach}
                disabled={isLoadingCoach}
                className="py-2 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-lg transition-all active:scale-95 disabled:opacity-50"
              >
                {isLoadingCoach ? (
                  <RefreshCw className="w-4 h-4 animate-spin" />
                ) : (
                  <Sparkles className="w-4 h-4" />
                )}
                <span>{coachingData ? 'Re-Analyze Strategy' : 'Generate Full Profit Blueprint'}</span>
              </button>
            </div>

            {/* Strategy Content */}
            {coachingData ? (
              <div className="p-5 rounded-xl bg-slate-950 border border-slate-800 space-y-4 text-xs text-slate-200 leading-relaxed">
                <div className="prose prose-invert max-w-none text-xs leading-relaxed whitespace-pre-line">
                  {coachingData}
                </div>
              </div>
            ) : (
              <div className="p-6 rounded-xl bg-slate-950 border border-slate-800 text-center space-y-3">
                <Compass className="w-10 h-10 text-emerald-400 mx-auto opacity-70" />
                <div className="text-sm font-bold text-white">Ready to Boost Net Take-Home by 30%?</div>
                <p className="text-xs text-slate-400 max-w-md mx-auto">
                  Click the button above to run Gemini AI analysis on your shift timing, peak surge clusters, and Ola commission savings.
                </p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Tab 2: Hindi/English Voice Assistant & In-Cab Speech */}
      {activeTab === 'VOICE_CHAT' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl flex flex-col h-[520px]">
          
          {/* Chat Header */}
          <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                <Mic className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-bold text-white flex items-center gap-1.5">
                  Saathi In-Cab Voice Assistant <span className="text-[10px] text-emerald-400 font-mono">ONLINE</span>
                </div>
                <div className="text-[10px] text-slate-400">Contextual Hindi & English voice recognition</div>
              </div>
            </div>
            <span className="text-xs text-slate-400 font-mono">Voice Encryption Active</span>
          </div>

          {/* Quick Voice Prompts Strip */}
          <div className="p-2.5 bg-slate-850/60 border-b border-slate-800 flex items-center gap-1.5 overflow-x-auto text-[11px]">
            <span className="text-slate-400 text-[10px] font-semibold whitespace-nowrap pl-2">Quick Commands:</span>
            {[
              'Bhai 500 ka CNG dala aur 80 toll',
              'Calculate my net profit after Ola cut',
              'Show highest surge area in Bangalore right now',
              'Log 40 Rs chai and biscuit',
              'Airport ride rate card banao WhatsApp ke liye',
            ].map((sample, idx) => (
              <button
                key={idx}
                onClick={() => handleSimulateVoiceInput(sample)}
                className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 whitespace-nowrap border border-slate-700/60 text-[11px] transition-colors"
              >
                "{sample}"
              </button>
            ))}
          </div>

          {/* Messages Feed */}
          <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-slate-950/40">
            {chatMessages.map((msg, i) => (
              <div
                key={i}
                className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`max-w-[85%] p-3.5 rounded-2xl text-xs leading-relaxed shadow ${
                    msg.sender === 'user'
                      ? 'bg-emerald-600 text-white rounded-br-none'
                      : 'bg-slate-800 text-slate-200 border border-slate-700/70 rounded-bl-none'
                  }`}
                >
                  {msg.text}

                  {msg.action && (
                    <div className="mt-2 pt-2 border-t border-slate-700/80 text-[11px] text-emerald-300 flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Action Recorded: {msg.action.category} (₹{msg.action.amount})</span>
                    </div>
                  )}
                </div>
              </div>
            ))}

            {isProcessingVoice && (
              <div className="flex items-center gap-2 text-xs text-slate-400 animate-pulse p-2">
                <Sparkles className="w-4 h-4 text-emerald-400 animate-spin" />
                <span>Saathi AI is processing voice context...</span>
              </div>
            )}
          </div>

          {/* Voice & Text Input Bar */}
          <div className="p-3.5 bg-slate-900 border-t border-slate-800 flex items-center gap-2">
            <button
              onClick={() => {
                setIsListening(true);
                setTimeout(() => {
                  setIsListening(false);
                  handleSimulateVoiceInput('Bhai 650 ka CNG aur 115 toll add karo');
                }, 1800);
              }}
              className={`p-2.5 rounded-xl border transition-all ${
                isListening
                  ? 'bg-rose-600 text-white border-rose-400 animate-ping'
                  : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40 hover:bg-emerald-500/30'
              }`}
              title="Hold to Speak"
            >
              <Mic className="w-5 h-5" />
            </button>

            <input
              type="text"
              value={inputQuery}
              onChange={(e) => setInputQuery(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
              placeholder="Speak or type in Hindi/English (e.g. '500 ka CNG dala')..."
              className="flex-1 bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
            />

            <button
              onClick={() => handleSendMessage()}
              disabled={!inputQuery.trim()}
              className="p-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white disabled:opacity-50 transition-all shadow"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>

        </div>
      )}

      {/* Tab 3: Proactive Anomaly Detection */}
      {activeTab === 'ANOMALIES' && (
        <div className="space-y-4">
          <div className="p-4 bg-slate-900 border border-amber-500/30 rounded-2xl flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-400" /> Real-time Anomaly Guardian
              </h3>
              <p className="text-xs text-slate-400">
                Machine-learning detection for fuel drops, excessive platform fees, and deadhead trips.
              </p>
            </div>
            <span className="text-xs font-mono font-bold text-amber-400 bg-amber-500/20 px-2.5 py-1 rounded-lg border border-amber-500/30">
              3 Alerts Detected
            </span>
          </div>

          <div className="grid grid-cols-1 gap-3">
            {anomalies.map((ano) => (
              <div
                key={ano.id}
                className="p-4 sm:p-5 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-amber-500/40 shadow-lg space-y-2.5 transition-all"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                    {ano.title}
                  </span>
                  <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                    {ano.severity} PRIORITY
                  </span>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed">
                  {ano.description}
                </p>

                <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs">
                  <span className="text-slate-400 font-medium">Recommended Action:</span>
                  <span className="text-emerald-400 font-semibold">{ano.actionText}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
};
