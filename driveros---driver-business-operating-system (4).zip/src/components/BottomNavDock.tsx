import React, { useState } from 'react';
import { 
  Home, 
  Car, 
  MapPin, 
  DollarSign, 
  Mic, 
  Wrench, 
  Settings, 
  ShieldCheck, 
  Gift, 
  TrendingUp, 
  LifeBuoy, 
  Receipt, 
  Banknote, 
  X, 
  Lock, 
  Phone, 
  Layers, 
  Sparkles,
  Cpu,
  Radio,
  FileText,
  Smartphone
} from 'lucide-react';
import { MainPillar } from './Header';

interface BottomNavDockProps {
  activePillar: MainPillar;
  onSelectPillar: (pillar: MainPillar, subItem?: string) => void;
  onOpenScanReceipt: () => void;
  onOpenCustomerPayment: () => void;
  onLockApp: () => void;
}

export const BottomNavDock: React.FC<BottomNavDockProps> = ({
  activePillar,
  onSelectPillar,
  onOpenScanReceipt,
  onOpenCustomerPayment,
  onLockApp,
}) => {
  const [isMoreOpen, setIsMoreOpen] = useState(false);

  const navItems = [
    {
      id: 'HOME' as MainPillar,
      label: 'HOME',
      icon: Home,
      subItem: undefined,
      badge: undefined,
    },
    {
      id: 'RIDE_WORK' as MainPillar,
      label: 'RIDES',
      icon: Car,
      subItem: 'new-ride',
      badge: 'Live',
    },
    {
      id: 'SMART_MAP' as MainPillar,
      label: 'MAP',
      icon: MapPin,
      subItem: 'moving-car',
      badge: 'GPS',
    },
    {
      id: 'MONEY' as MainPillar,
      label: 'MONEY',
      icon: DollarSign,
      subItem: 'today-earnings',
      badge: '₹2.8k',
    },
    {
      id: 'SAATHI_AI' as MainPillar,
      label: 'SAATHI',
      icon: Mic,
      subItem: 'ask-anything',
      badge: 'AI',
    },
    {
      id: 'VEHICLE' as MainPillar,
      label: 'VEHICLE',
      icon: Wrench,
      subItem: 'profile',
      badge: undefined,
    },
  ];

  return (
    <>
      {/* "MORE" Action Drawer Modal */}
      {isMoreOpen && (
        <div 
          className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-end sm:items-center justify-center p-3 animate-in fade-in duration-200"
          onClick={() => setIsMoreOpen(false)}
        >
          <div 
            className="bg-slate-900 border border-slate-800 rounded-3xl p-5 w-full max-w-lg shadow-2xl space-y-4 animate-in slide-in-from-bottom-5 duration-200"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-slate-800 text-slate-200 flex items-center justify-center">
                  <Settings className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white uppercase tracking-wider">DriverOS System Services</h3>
                  <p className="text-[11px] text-slate-400">Additional modules & safety utilities</p>
                </div>
              </div>
              <button
                onClick={() => setIsMoreOpen(false)}
                className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Quick Modules Grid (All 12 Pillars Accessible) */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 max-h-[60vh] overflow-y-auto pr-1">
              <button
                onClick={() => {
                  onSelectPillar('DRIVER_INTELLIGENCE', 'earnings-forecast');
                  setIsMoreOpen(false);
                }}
                className="p-3 rounded-2xl bg-slate-950 border border-slate-800 hover:border-emerald-500/40 text-left space-y-1 transition-all group"
              >
                <div className="flex items-center gap-2 text-xs font-bold text-white group-hover:text-emerald-400">
                  <Cpu className="w-4 h-4 text-emerald-400" />
                  <span>🧠 Intelligence</span>
                </div>
                <div className="text-[10px] text-slate-400">Demand & Earnings AI</div>
              </button>

              <button
                onClick={() => {
                  onSelectPillar('SMART_MOBILITY', 'moving-car');
                  setIsMoreOpen(false);
                }}
                className="p-3 rounded-2xl bg-slate-950 border border-slate-800 hover:border-cyan-500/40 text-left space-y-1 transition-all group"
              >
                <div className="flex items-center gap-2 text-xs font-bold text-white group-hover:text-cyan-400">
                  <MapPin className="w-4 h-4 text-cyan-400" />
                  <span>🗺️ Smart Mobility</span>
                </div>
                <div className="text-[10px] text-slate-400">Fleet, Corridors & CNG</div>
              </button>

              <button
                onClick={() => {
                  onSelectPillar('REALTIME_OPERATIONS', 'telemetry');
                  setIsMoreOpen(false);
                }}
                className="p-3 rounded-2xl bg-slate-950 border border-slate-800 hover:border-teal-500/40 text-left space-y-1 transition-all group"
              >
                <div className="flex items-center gap-2 text-xs font-bold text-white group-hover:text-teal-400">
                  <Radio className="w-4 h-4 text-teal-400" />
                  <span>⚡ Real-time Ops</span>
                </div>
                <div className="text-[10px] text-slate-400">Telemetry & Sync</div>
              </button>

              <button
                onClick={() => {
                  onSelectPillar('DOCUMENT_BILL_ENGINE', 'receipts');
                  setIsMoreOpen(false);
                }}
                className="p-3 rounded-2xl bg-slate-950 border border-slate-800 hover:border-amber-500/40 text-left space-y-1 transition-all group"
              >
                <div className="flex items-center gap-2 text-xs font-bold text-white group-hover:text-amber-400">
                  <FileText className="w-4 h-4 text-amber-400" />
                  <span>🧾 Bill & Tax Engine</span>
                </div>
                <div className="text-[10px] text-slate-400">GST Bills, 44AD P&amp;L</div>
              </button>

              <button
                onClick={() => {
                  onSelectPillar('TRUST_IDENTITY', 'digilocker');
                  setIsMoreOpen(false);
                }}
                className="p-3 rounded-2xl bg-slate-950 border border-slate-800 hover:border-indigo-500/40 text-left space-y-1 transition-all group"
              >
                <div className="flex items-center gap-2 text-xs font-bold text-white group-hover:text-indigo-400">
                  <Lock className="w-4 h-4 text-indigo-400" />
                  <span>🔐 Trust &amp; Identity</span>
                </div>
                <div className="text-[10px] text-slate-400">DigiLocker & Parivahan</div>
              </button>

              <button
                onClick={() => {
                  onSelectPillar('PLATFORM_HUB', 'compare-earnings');
                  setIsMoreOpen(false);
                }}
                className="p-3 rounded-2xl bg-slate-950 border border-slate-800 hover:border-blue-500/40 text-left space-y-1 transition-all group"
              >
                <div className="flex items-center gap-2 text-xs font-bold text-white group-hover:text-blue-400">
                  <Smartphone className="w-4 h-4 text-blue-400" />
                  <span>📱 Platform Hub</span>
                </div>
                <div className="text-[10px] text-slate-400">Ola • Uber • Rapido</div>
              </button>

              <button
                onClick={() => {
                  onSelectPillar('SAFETY');
                  setIsMoreOpen(false);
                }}
                className="p-3 rounded-2xl bg-slate-950 border border-slate-800 hover:border-emerald-500/40 text-left space-y-1 transition-all group"
              >
                <div className="flex items-center gap-2 text-xs font-bold text-white group-hover:text-emerald-400">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>🛡️ Safety Center</span>
                </div>
                <div className="text-[10px] text-slate-400">₹5L Cover, Fatigue, SOS</div>
              </button>

              <button
                onClick={() => {
                  onSelectPillar('INCENTIVES', 'daily-target');
                  setIsMoreOpen(false);
                }}
                className="p-3 rounded-2xl bg-slate-950 border border-slate-800 hover:border-amber-500/40 text-left space-y-1 transition-all group"
              >
                <div className="flex items-center gap-2 text-xs font-bold text-white group-hover:text-amber-400">
                  <Gift className="w-4 h-4 text-amber-400" />
                  <span>🎁 Incentives</span>
                </div>
                <div className="text-[10px] text-slate-400">Daily targets, +₹500 bonus</div>
              </button>

              <button
                onClick={() => {
                  onSelectPillar('BUSINESS', 'profit-dashboard');
                  setIsMoreOpen(false);
                }}
                className="p-3 rounded-2xl bg-slate-950 border border-slate-800 hover:border-sky-500/40 text-left space-y-1 transition-all group"
              >
                <div className="flex items-center gap-2 text-xs font-bold text-white group-hover:text-sky-400">
                  <TrendingUp className="w-4 h-4 text-sky-400" />
                  <span>📊 Business P&amp;L</span>
                </div>
                <div className="text-[10px] text-slate-400">Analytics, 44AD Tax reports</div>
              </button>

              <button
                onClick={() => {
                  onSelectPillar('PROBLEM_CENTER', 'PAYMENT');
                  setIsMoreOpen(false);
                }}
                className="p-3 rounded-2xl bg-slate-950 border border-red-500/30 hover:border-red-500/60 text-left space-y-1 transition-all group"
              >
                <div className="flex items-center gap-2 text-xs font-bold text-rose-400">
                  <LifeBuoy className="w-4 h-4 text-rose-400" />
                  <span>🚨 Problem Center</span>
                </div>
                <div className="text-[10px] text-rose-300 font-mono font-bold">Hotline: 9318320977</div>
              </button>

              <button
                onClick={() => {
                  onOpenScanReceipt();
                  setIsMoreOpen(false);
                }}
                className="p-3 rounded-2xl bg-slate-950 border border-slate-800 hover:border-emerald-500/40 text-left space-y-1 transition-all group"
              >
                <div className="flex items-center gap-2 text-xs font-bold text-white group-hover:text-amber-400">
                  <Receipt className="w-4 h-4 text-amber-400" />
                  <span>🧾 Scan Bill OCR</span>
                </div>
                <div className="text-[10px] text-slate-400">Fuel &amp; Toll receipts</div>
              </button>

              <button
                onClick={() => {
                  onOpenCustomerPayment();
                  setIsMoreOpen(false);
                }}
                className="p-3 rounded-2xl bg-slate-950 border border-slate-800 hover:border-emerald-500/40 text-left space-y-1 transition-all group"
              >
                <div className="flex items-center gap-2 text-xs font-bold text-white group-hover:text-emerald-400">
                  <Banknote className="w-4 h-4 text-emerald-400" />
                  <span>💳 Customer Payment</span>
                </div>
                <div className="text-[10px] text-slate-400">Generate PDF Tax Invoice</div>
              </button>
            </div>

            {/* Lock Enclave Action */}
            <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
              <span className="text-[11px] text-slate-400 font-mono flex items-center gap-1.5">
                <Lock className="w-3 h-3 text-emerald-400" />
                Zero-Knowledge AES256
              </span>
              <button
                onClick={() => {
                  onLockApp();
                  setIsMoreOpen(false);
                }}
                className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-white text-xs font-bold flex items-center gap-1.5 transition-colors"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>Lock DriverOS</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Persistent Bottom Navigation Dock (Matching ASCII: 🏠 HOME  🚕 RIDES  🗺️ MAP  💰 MONEY  🤖 SAATHI  🚗 VEHICLE  ⚙️ MORE) */}
      <nav 
        id="driver-os-bottom-dock" 
        className="fixed bottom-0 left-0 right-0 z-40 bg-slate-950/95 backdrop-blur-xl border-t border-slate-800/90 shadow-2xl py-2 px-2 sm:px-6"
      >
        <div className="max-w-4xl mx-auto flex items-center justify-between gap-1 sm:gap-2">
          
          {/* 6 Main Dock Icons */}
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activePillar === item.id;

            return (
              <button
                key={item.id}
                id={`dock-nav-${item.label.toLowerCase()}`}
                onClick={() => onSelectPillar(item.id, item.subItem)}
                className={`flex-1 py-1.5 sm:py-2 px-1 sm:px-3 rounded-2xl flex flex-col items-center justify-center gap-1 transition-all relative group cursor-pointer ${
                  isActive
                    ? 'bg-gradient-to-b from-emerald-500/20 to-teal-500/10 text-emerald-400 font-black border border-emerald-500/40 shadow-lg shadow-emerald-950/40'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60 font-semibold'
                }`}
              >
                <div className="relative">
                  <Icon className={`w-4 h-4 sm:w-5 sm:h-5 transition-transform group-hover:scale-110 ${
                    isActive ? 'text-emerald-400 stroke-[2.5]' : 'text-slate-400'
                  }`} />
                  
                  {item.badge && !isActive && (
                    <span className="absolute -top-1.5 -right-2.5 px-1 py-0.2 rounded-full text-[8px] font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      {item.badge}
                    </span>
                  )}
                  {isActive && (
                    <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                  )}
                </div>

                <span className="text-[9px] sm:text-[11px] tracking-wider uppercase truncate">
                  {item.label}
                </span>
              </button>
            );
          })}

          {/* 7th Item: ⚙️ MORE */}
          <button
            id="dock-nav-more"
            onClick={() => setIsMoreOpen(true)}
            className={`flex-1 py-1.5 sm:py-2 px-1 sm:px-3 rounded-2xl flex flex-col items-center justify-center gap-1 transition-all relative group cursor-pointer ${
              isMoreOpen
                ? 'bg-emerald-500/20 text-emerald-300 font-black border border-emerald-500/40'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60 font-semibold'
            }`}
          >
            <div className="relative">
              <Settings className="w-4 h-4 sm:w-5 sm:h-5 transition-transform group-hover:rotate-45" />
            </div>
            <span className="text-[9px] sm:text-[11px] tracking-wider uppercase truncate">
              MORE
            </span>
          </button>

        </div>
      </nav>
    </>
  );
};
