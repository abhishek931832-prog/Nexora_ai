import React, { useState, useEffect } from 'react';
import { 
  MapPin, 
  Car, 
  Navigation, 
  CheckCircle2, 
  Clock, 
  ShieldCheck, 
  Star, 
  Phone, 
  MessageSquare, 
  Download, 
  RefreshCw, 
  ArrowRight,
  ExternalLink,
  Info,
  QrCode,
  DollarSign,
  AlertCircle
} from 'lucide-react';
import { RideBooking, RideBookingStatus, RideVehicleType, DriverProfile } from '../types';
import { rideBookingService } from '../services/rideBookingService';
import { exportCustomerReceiptPDF, CustomerReceiptData } from '../utils/exportUtils';

interface CustomerBookingAppProps {
  driver: DriverProfile;
  activeRide: RideBooking | null;
  onRideUpdated: (ride: RideBooking) => void;
  onSwitchToDriverOS: () => void;
}

const VEHICLE_OPTIONS: Array<{
  type: RideVehicleType;
  title: string;
  subtitle: string;
  fareMultiplier: number;
  baseFare: number;
  capacity: string;
  iconName: string;
  tag?: string;
}> = [
  {
    type: 'Mini',
    title: 'Mini / Hatchback',
    subtitle: 'Maruti WagonR CNG • Eco Saver',
    fareMultiplier: 1.0, // ₹650 for 28 km
    baseFare: 650,
    capacity: '4 seats',
    iconName: '🚕',
    tag: 'POPULAR & GREEN',
  },
  {
    type: 'Sedan',
    title: 'Prime Sedan',
    subtitle: 'Maruti Dzire • Extra Comfort',
    fareMultiplier: 1.2,
    baseFare: 780,
    capacity: '4 seats',
    iconName: '🚙',
    tag: 'COMFORT',
  },
  {
    type: 'XL',
    title: 'Prime SUV / XL',
    subtitle: 'Maruti Ertiga • Family & Bags',
    fareMultiplier: 1.72,
    baseFare: 1120,
    capacity: '6 seats',
    iconName: '🚐',
  },
  {
    type: 'Auto',
    title: 'Auto Rickshaw',
    subtitle: 'Metered City Transit',
    fareMultiplier: 0.6,
    baseFare: 390,
    capacity: '3 seats',
    iconName: '🛺',
  },
];

const PRESET_ROUTES = [
  { pickup: 'Airport', drop: 'Whitefield', distance: 28, estDuration: 45, fare: 650 },
  { pickup: 'Koramangala 5th Block', drop: 'Kempegowda Airport T2', distance: 42, estDuration: 65, fare: 950 },
  { pickup: 'Indiranagar 100ft Rd', drop: 'Electronic City Phase 1', distance: 24, estDuration: 48, fare: 580 },
  { pickup: 'MG Road Metro', drop: 'Whitefield ITPB', distance: 20, estDuration: 42, fare: 510 },
];

export const CustomerBookingApp: React.FC<CustomerBookingAppProps> = ({
  driver,
  activeRide,
  onRideUpdated,
  onSwitchToDriverOS,
}) => {
  // Input fields matching user prompt:
  // 📍 Pickup: Airport
  // 📍 Destination: Whitefield
  // 🚕 Choose Ride: Mini
  // 💰 Fare Estimate: ₹650 (28 km)
  // 👤 Driver details
  const [pickup, setPickup] = useState('Airport');
  const [destination, setDestination] = useState('Whitefield');
  const [selectedVehicle, setSelectedVehicle] = useState<RideVehicleType>('Mini');
  const [distanceKm, setDistanceKm] = useState(28);
  const [durationMin, setDurationMin] = useState(45);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [feedbackMessage, setFeedbackMessage] = useState<string | null>(null);

  // Sync inputs if active ride exists
  useEffect(() => {
    if (activeRide) {
      setPickup(activeRide.pickup);
      setDestination(activeRide.destination);
      setSelectedVehicle(activeRide.rideType);
      setDistanceKm(activeRide.distanceKm);
      setDurationMin(activeRide.estimatedDurationMin);
    }
  }, [activeRide]);

  // Selected vehicle pricing
  const currentVehicleConfig = VEHICLE_OPTIONS.find(v => v.type === selectedVehicle) || VEHICLE_OPTIONS[0];
  const calculatedFare = Math.round(650 * currentVehicleConfig.fareMultiplier);

  // Handle Book Ride -> POST /api/rides
  const handleBookRide = async () => {
    setIsSubmitting(true);
    setFeedbackMessage('Sending ride request to DriverOS backend...');
    try {
      const result = await rideBookingService.bookRide({
        pickup,
        destination,
        distanceKm,
        estimatedDurationMin: durationMin,
        fareEstimate: calculatedFare,
        rideType: selectedVehicle,
        customerName: 'Ananya Sharma',
        customerPhone: '+91 98450 19283',
      });

      if (result.success && result.ride) {
        onRideUpdated(result.ride);
        setFeedbackMessage('Ride request broadcast to Driver Ramesh Kumar (KA-05-AB-9821)!');
      }
    } catch (err: any) {
      setFeedbackMessage('Failed to book ride: ' + err.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleResetSample = async () => {
    const ride = await rideBookingService.resetSampleRide();
    onRideUpdated(ride);
    setPickup('Airport');
    setDestination('Whitefield');
    setSelectedVehicle('Mini');
    setDistanceKm(28);
    setDurationMin(45);
    setFeedbackMessage('Reset to sample: Airport → Whitefield (28 km, ₹650)');
  };

  const handleDownloadReceipt = () => {
    const receiptData: CustomerReceiptData = {
      receiptNumber: activeRide?.payment?.invoiceNumber || `INV-${new Date().getFullYear()}-4821`,
      date: activeRide?.payment?.paidAt || new Date().toISOString(),
      customerName: activeRide?.customerName || 'Ananya Sharma',
      customerPhone: activeRide?.customerPhone || '+91 98450 19283',
      pickupLocation: pickup,
      dropoffLocation: destination,
      distanceKm,
      durationMinutes: durationMin,
      driver: driver,
      baseFare: 80,
      distanceFare: calculatedFare - 80 - 115 - 25,
      tollCost: 115,
      waitingOrSurgeFare: 0,
      discount: 0,
      totalPaid: calculatedFare,
      paymentMode: activeRide?.payment?.mode || 'UPI',
      paymentReference: activeRide?.payment?.transactionRef || 'TXN-UPI-8492019',
      notes: 'Official Tax Invoice under Section 44AD / GST SAC Code 996412. Passenger Taxi Service.',
    };

    exportCustomerReceiptPDF(receiptData);
  };

  const currentStatus: RideBookingStatus = activeRide?.status || 'pending';

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-in fade-in duration-300">
      
      {/* Top Banner with Cross-App Context */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-1 text-xs font-bold bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 rounded-lg">
              📱 PASSENGER VIEW
            </span>
            <span className="text-xs text-slate-400 font-mono">
              DRIVEROS BOOKING FLOW SIMULATOR
            </span>
          </div>
          <h1 className="text-xl font-black text-white mt-1">
            Customer Cab Booking App
          </h1>
          <p className="text-xs text-slate-400">
            Simulates customer booking a ride, calling <code className="text-emerald-400">POST /api/rides</code>, and dispatching live to DriverOS.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleResetSample}
            className="px-3 py-2 text-xs font-semibold text-slate-300 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl transition flex items-center gap-1.5"
            title="Reset to default Airport -> Whitefield ₹650"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Reset Demo</span>
          </button>
          
          <button
            onClick={onSwitchToDriverOS}
            className="px-4 py-2 text-xs font-bold text-slate-950 bg-emerald-400 hover:bg-emerald-300 rounded-xl transition shadow-md shadow-emerald-500/20 flex items-center gap-2"
          >
            <span>Switch to DriverOS</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {feedbackMessage && (
        <div className="bg-emerald-950/40 border border-emerald-500/30 rounded-xl p-3 text-xs text-emerald-300 flex items-center justify-between">
          <span>{feedbackMessage}</span>
          <button onClick={() => setFeedbackMessage(null)} className="text-emerald-400 hover:underline">
            Dismiss
          </button>
        </div>
      )}

      {/* Booking State Progress Tracker */}
      {activeRide && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4">
          <div className="flex items-center justify-between mb-3 text-xs text-slate-400">
            <span className="font-semibold text-slate-200">Trip Flow Progression:</span>
            <span className="font-mono text-emerald-400 uppercase font-bold">
              Status: {activeRide.status}
            </span>
          </div>
          <div className="grid grid-cols-6 gap-2 text-center text-[10px] font-bold">
            <div className={`p-2 rounded-lg border ${['pending', 'searching', 'accepted', 'arriving', 'started', 'completed', 'paid'].includes(currentStatus) ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' : 'bg-slate-800/50 text-slate-500 border-slate-800'}`}>
              1. Booked
            </div>
            <div className={`p-2 rounded-lg border ${['searching', 'accepted', 'arriving', 'started', 'completed', 'paid'].includes(currentStatus) ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' : 'bg-slate-800/50 text-slate-500 border-slate-800'}`}>
              2. Searching
            </div>
            <div className={`p-2 rounded-lg border ${['accepted', 'arriving', 'started', 'completed', 'paid'].includes(currentStatus) ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' : 'bg-slate-800/50 text-slate-500 border-slate-800'}`}>
              3. Accepted
            </div>
            <div className={`p-2 rounded-lg border ${['arriving', 'started', 'completed', 'paid'].includes(currentStatus) ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' : 'bg-slate-800/50 text-slate-500 border-slate-800'}`}>
              4. Arriving
            </div>
            <div className={`p-2 rounded-lg border ${['started', 'completed', 'paid'].includes(currentStatus) ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' : 'bg-slate-800/50 text-slate-500 border-slate-800'}`}>
              5. Started
            </div>
            <div className={`p-2 rounded-lg border ${['completed', 'paid'].includes(currentStatus) ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' : 'bg-slate-800/50 text-slate-500 border-slate-800'}`}>
              6. Completed/Paid
            </div>
          </div>
        </div>
      )}

      {/* Main Booking Container */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Form: Inputs, Rides, Fare Estimate */}
        <div className="lg:col-span-7 space-y-5">
          
          {/* 📍 Route Input Box */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <MapPin className="w-4 h-4 text-emerald-400" />
                Select Route
              </h2>
              <span className="text-xs text-slate-400 font-mono">
                {distanceKm} km • ~{durationMin} mins
              </span>
            </div>

            {/* Quick Presets */}
            <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
              <span className="text-slate-500 whitespace-nowrap">Presets:</span>
              {PRESET_ROUTES.map((route, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setPickup(route.pickup);
                    setDestination(route.drop);
                    setDistanceKm(route.distance);
                    setDurationMin(route.estDuration);
                  }}
                  className={`px-2.5 py-1 rounded-lg border text-xs whitespace-nowrap transition ${
                    pickup === route.pickup && destination === route.drop
                      ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 font-bold'
                      : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-750'
                  }`}
                >
                  {route.pickup.split(' ')[0]} → {route.drop.split(' ')[0]}
                </button>
              ))}
            </div>

            {/* Pickup */}
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1.5 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 ring-4 ring-emerald-400/20" />
                📍 Pickup Location
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={pickup}
                  onChange={(e) => setPickup(e.target.value)}
                  placeholder="Enter pickup point (e.g. Airport)"
                  className="w-full bg-slate-950 border border-slate-750 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
                />
              </div>
            </div>

            {/* Destination */}
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1.5 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-rose-400 ring-4 ring-rose-400/20" />
                📍 Destination
              </label>
              <div className="relative">
                <input
                  type="text"
                  value={destination}
                  onChange={(e) => setDestination(e.target.value)}
                  placeholder="Enter destination (e.g. Whitefield)"
                  className="w-full bg-slate-950 border border-slate-750 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
                />
              </div>
            </div>
          </div>

          {/* 🚕 Choose Ride */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <Car className="w-4 h-4 text-emerald-400" />
                Choose Ride
              </h2>
              <span className="text-xs text-slate-400">Fixed Transparent Rate</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {VEHICLE_OPTIONS.map((veh) => {
                const fare = Math.round(650 * veh.fareMultiplier);
                const isSelected = selectedVehicle === veh.type;
                return (
                  <div
                    key={veh.type}
                    onClick={() => setSelectedVehicle(veh.type)}
                    className={`cursor-pointer p-3.5 rounded-xl border transition relative flex items-start gap-3 ${
                      isSelected
                        ? 'bg-emerald-500/10 border-emerald-500/50 ring-1 ring-emerald-500/50'
                        : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="text-2xl mt-0.5">{veh.iconName}</div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-bold text-white">{veh.title}</span>
                        <span className="text-sm font-black text-emerald-400 font-mono">
                          ₹{fare}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-0.5 truncate">{veh.subtitle}</p>
                      <div className="flex items-center gap-2 mt-1.5 text-[10px] text-slate-500 font-medium">
                        <span>{veh.capacity}</span>
                        <span>•</span>
                        <span>ETA ~4 mins</span>
                      </div>
                    </div>
                    {veh.tag && (
                      <span className="absolute top-2 right-2 px-1.5 py-0.5 text-[9px] font-bold bg-emerald-500/20 text-emerald-400 rounded">
                        {veh.tag}
                      </span>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* 💰 Fare Estimate & Breakdown */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <DollarSign className="w-4 h-4 text-emerald-400" />
                Fare Estimate
              </h2>
              <span className="text-xs font-semibold text-emerald-400">Zero Surge Gouging</span>
            </div>

            <div className="space-y-2 text-xs">
              <div className="flex justify-between text-slate-300">
                <span>Base Fare (First 4 km)</span>
                <span className="font-mono">₹80</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Distance Rate ({distanceKm} km @ ₹15.3/km)</span>
                <span className="font-mono">₹{calculatedFare - 80 - 115 - 25}</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Airport Express Elevated Toll (Fastag)</span>
                <span className="font-mono">₹115</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Govt GST / Platform Levy (5%)</span>
                <span className="font-mono">₹25</span>
              </div>
              <div className="border-t border-slate-800 pt-2 flex justify-between items-baseline font-bold text-white">
                <span className="text-sm">Total Estimated Fare</span>
                <span className="text-lg text-emerald-400 font-mono">₹{calculatedFare}</span>
              </div>
            </div>

            <p className="text-[11px] text-slate-400 flex items-center gap-1.5 bg-slate-950 p-2.5 rounded-lg border border-slate-800">
              <Info className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
              <span>
                <strong>100% Direct Driver Earnings:</strong> Unlike Ola/Uber who deduct 28%, DriverOS gives 100% of this fare directly to driver partner Ramesh Kumar.
              </span>
            </p>
          </div>
        </div>

        {/* Right Column: Driver Details & Action Status */}
        <div className="lg:col-span-5 space-y-5">
          
          {/* 👤 Driver Details Card */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                Assigned Driver Details
              </h2>
              <span className="px-2 py-0.5 text-[10px] font-bold bg-emerald-500/20 text-emerald-400 rounded-md">
                VERIFIED PARTNER
              </span>
            </div>

            <div className="flex items-center gap-3.5">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-700 flex items-center justify-center text-xl font-bold text-slate-950 shadow-lg shadow-emerald-500/10">
                RK
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <h3 className="text-base font-black text-white">{driver.name}</h3>
                  <div className="flex items-center gap-1 px-1.5 py-0.5 bg-amber-500/20 text-amber-300 text-[10px] font-bold rounded">
                    <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                    <span>{driver.rating}</span>
                  </div>
                </div>
                <p className="text-xs text-slate-300 font-medium mt-0.5">
                  {driver.vehicleModel}
                </p>
                <div className="inline-block mt-1 px-2 py-0.5 bg-slate-950 border border-slate-750 rounded text-xs font-mono font-bold text-emerald-400 tracking-wider">
                  {driver.vehiclePlate}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs pt-2 border-t border-slate-800">
              <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                <div className="text-[10px] text-slate-500 uppercase">Commercial DL</div>
                <div className="font-mono text-slate-300 font-semibold">{driver.commercialDlNumber}</div>
              </div>
              <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                <div className="text-[10px] text-slate-500 uppercase">Experience</div>
                <div className="text-slate-300 font-semibold">{driver.yearsExperience}+ Years (1,480 trips)</div>
              </div>
            </div>

            <div className="flex items-center gap-2 text-xs text-slate-400 pt-1">
              <Phone className="w-3.5 h-3.5 text-slate-400" />
              <span>Contact: {driver.phone}</span>
            </div>
          </div>

          {/* Active Status Display Box */}
          {activeRide && (
            <div className="bg-slate-900 border border-emerald-500/40 rounded-2xl p-5 shadow-lg space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
                  <h3 className="text-sm font-bold text-white">Live Booking Status</h3>
                </div>
                <span className="text-xs font-mono text-emerald-400 font-bold uppercase">
                  {activeRide.status}
                </span>
              </div>

              {/* Status Conditional Content */}
              {activeRide.status === 'searching' && (
                <div className="text-center py-4 space-y-3">
                  <div className="w-12 h-12 rounded-full border-4 border-emerald-500/20 border-t-emerald-400 animate-spin mx-auto" />
                  <h4 className="text-sm font-bold text-white">Connecting with DriverOS...</h4>
                  <p className="text-xs text-slate-400 max-w-xs mx-auto">
                    New ride request dispatched to Driver Ramesh Kumar. Waiting for acceptance.
                  </p>
                  <button
                    onClick={onSwitchToDriverOS}
                    className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-400 hover:underline"
                  >
                    View Alert in DriverOS <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}

              {activeRide.status === 'accepted' && (
                <div className="space-y-3">
                  <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-xl flex items-center gap-3">
                    <CheckCircle2 className="w-6 h-6 text-emerald-400 shrink-0" />
                    <div>
                      <div className="text-xs font-bold text-emerald-300 uppercase">🟢 Driver Accepted</div>
                      <div className="text-xs text-slate-300">Ramesh Kumar has accepted and is heading to Airport!</div>
                    </div>
                  </div>

                  {/* Passenger OTP */}
                  <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl flex items-center justify-between">
                    <div>
                      <div className="text-[10px] text-slate-400 uppercase font-semibold">Start Ride PIN (Share with driver)</div>
                      <div className="text-xs text-slate-300">Verify chauffeur upon boarding</div>
                    </div>
                    <div className="text-xl font-black text-amber-400 font-mono tracking-widest bg-slate-900 px-3 py-1.5 rounded-lg border border-amber-500/30">
                      {activeRide.otp || '4821'}
                    </div>
                  </div>
                </div>
              )}

              {activeRide.status === 'arriving' && (
                <div className="space-y-3">
                  <div className="p-3 bg-indigo-500/10 border border-indigo-500/30 rounded-xl flex items-center gap-3">
                    <Navigation className="w-6 h-6 text-indigo-400 shrink-0 animate-bounce" />
                    <div>
                      <div className="text-xs font-bold text-indigo-300 uppercase">📍 Driver Arrived at Pickup</div>
                      <div className="text-xs text-slate-300">Maruti WagonR (KA-05-AB-9821) is waiting at Bay #3.</div>
                    </div>
                  </div>
                  <div className="p-2.5 bg-slate-950 rounded-xl text-xs text-slate-400 flex justify-between">
                    <span>Boarding OTP:</span>
                    <span className="font-mono font-bold text-amber-400 text-sm">{activeRide.otp || '4821'}</span>
                  </div>
                </div>
              )}

              {activeRide.status === 'started' && (
                <div className="space-y-3">
                  <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-xl flex items-center gap-3">
                    <Car className="w-6 h-6 text-emerald-400 shrink-0" />
                    <div>
                      <div className="text-xs font-bold text-emerald-300 uppercase">🚕 Ride in Progress</div>
                      <div className="text-xs text-slate-300">Cruising on NH 44 Expressway towards Whitefield.</div>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
                      <span className="text-slate-500 text-[10px]">Speed</span>
                      <div className="font-mono font-bold text-white">58 km/h</div>
                    </div>
                    <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
                      <span className="text-slate-500 text-[10px]">ETA Destination</span>
                      <div className="font-mono font-bold text-emerald-400">~34 mins</div>
                    </div>
                  </div>
                </div>
              )}

              {activeRide.status === 'completed' && (
                <div className="space-y-3">
                  <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-xl flex items-center gap-3">
                    <CheckCircle2 className="w-6 h-6 text-emerald-400 shrink-0" />
                    <div>
                      <div className="text-xs font-bold text-emerald-300 uppercase">🏁 Ride Completed!</div>
                      <div className="text-xs text-slate-300">Reached Whitefield ITPB safely. Please settle payment.</div>
                    </div>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-slate-950 rounded-xl border border-slate-800">
                    <span className="text-xs text-slate-400">Total Payable:</span>
                    <span className="text-lg font-black text-emerald-400 font-mono">₹{activeRide.fareEstimate}</span>
                  </div>
                </div>
              )}

              {activeRide.status === 'paid' && (
                <div className="space-y-3">
                  <div className="p-3 bg-emerald-500/20 border border-emerald-500/40 rounded-xl flex items-center gap-3">
                    <CheckCircle2 className="w-6 h-6 text-emerald-400 shrink-0" />
                    <div>
                      <div className="text-xs font-bold text-emerald-300 uppercase">💳 Payment Settled</div>
                      <div className="text-xs text-slate-300">
                        Paid ₹{activeRide.payment?.amount || calculatedFare} via {activeRide.payment?.mode || 'UPI'}.
                      </div>
                    </div>
                  </div>

                  {/* Download PDF Tax Invoice */}
                  <button
                    onClick={handleDownloadReceipt}
                    className="w-full py-2.5 px-4 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 transition"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download Official PDF Tax Invoice</span>
                  </button>
                </div>
              )}

              {activeRide.status === 'declined' && (
                <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-xl text-xs text-rose-300">
                  <div className="font-bold">Ride was declined by driver.</div>
                  <p className="mt-1 text-slate-400">Please click [BOOK RIDE] again to re-dispatch.</p>
                </div>
              )}
            </div>
          )}

          {/* [ BOOK RIDE ] Button */}
          <div className="space-y-2">
            <button
              onClick={handleBookRide}
              disabled={isSubmitting}
              className={`w-full py-4 px-6 rounded-2xl font-black text-sm uppercase tracking-wider transition shadow-xl flex items-center justify-center gap-3 ${
                isSubmitting
                  ? 'bg-slate-700 text-slate-400 cursor-not-allowed'
                  : 'bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 shadow-emerald-500/25 active:scale-[0.99]'
              }`}
            >
              {isSubmitting ? (
                <>
                  <RefreshCw className="w-5 h-5 animate-spin" />
                  <span>Dispatching to DriverOS...</span>
                </>
              ) : (
                <>
                  <Car className="w-5 h-5" />
                  <span>BOOK RIDE • ₹{calculatedFare}</span>
                </>
              )}
            </button>
            <p className="text-[11px] text-center text-slate-500">
              Dispatches directly to DriverOS • Instant driver confirmation
            </p>
          </div>

        </div>
      </div>

    </div>
  );
};
