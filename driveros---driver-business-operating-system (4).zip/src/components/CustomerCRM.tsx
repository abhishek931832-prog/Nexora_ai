import React, { useState } from 'react';
import { 
  Award, 
  Users, 
  Share2, 
  QrCode, 
  PlusCircle, 
  Phone, 
  MessageSquare, 
  DollarSign, 
  Copy, 
  Check, 
  Sparkles, 
  Star, 
  ShieldCheck, 
  TrendingUp,
  CreditCard
} from 'lucide-react';
import { DirectClientRecord, DriverProfile, RateCardItem } from '../types';

interface CustomerCRMProps {
  driver: DriverProfile;
  clients: DirectClientRecord[];
  onAddClient: (client: DirectClientRecord) => void;
}

export const CustomerCRM: React.FC<CustomerCRMProps> = ({
  driver,
  clients,
  onAddClient,
}) => {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [showAddClientModal, setShowAddClientModal] = useState(false);
  const [activeTab, setActiveTab] = useState<'CLIENTS' | 'RATE_CARDS' | 'QR_SHARE'>('CLIENTS');

  // New Client Form
  const [clientName, setClientName] = useState('');
  const [clientPhone, setClientPhone] = useState('');
  const [clientType, setClientType] = useState<'AIRPORT_REGULAR' | 'CORPORATE_EXECUTIVE' | 'OUTSTATION_FAMILY' | 'DAILY_COMMUTER'>('AIRPORT_REGULAR');
  const [preferredRoute, setPreferredRoute] = useState('');
  const [notes, setNotes] = useState('');

  // Default Rate Cards
  const rateCards: RateCardItem[] = [
    {
      title: 'Kempegowda Airport T1/T2 Drop (Direct)',
      fixedPrice: 1100,
      description: 'Fixed flat rate. No surge, no hidden cancellation fees. Toll extra or included.',
      badge: 'Zero Ola Commission (Save ₹350)',
    },
    {
      title: 'Outstation Long Distance (Mysuru / Coorg)',
      pricePerKm: 14,
      minimumFare: 2800,
      description: 'Comfortable AC sedan with experienced highway driver. Driver allowance included.',
      badge: 'Transparent Km Billing',
    },
    {
      title: 'City Full Day Rental (8 Hours / 80 Km)',
      fixedPrice: 2200,
      description: 'Multiple stops for business meetings or family shopping. Extra km @ ₹16/km.',
      badge: 'Corporate Preferred',
    },
    {
      title: 'Daily Tech Park Commute (Monthly Pass)',
      pricePerKm: 16,
      description: 'Guaranteed on-time morning & evening pickup without platform surge.',
      badge: 'VIP Guaranteed Driver',
    },
  ];

  const handleCopyRateCard = (index: number, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const handleSaveClient = () => {
    if (!clientName || !clientPhone) return;

    const newClient: DirectClientRecord = {
      id: `CLI-${Math.floor(1000 + Math.random() * 9000)}`,
      name: clientName,
      phone: clientPhone,
      clientType: clientType,
      preferredRoute: preferredRoute || 'City Wide',
      totalTripsCompleted: 1,
      totalRevenueGenerated: 1200,
      rating: 5.0,
      lastTripDate: new Date().toISOString().split('T')[0],
      notes: notes || 'Converted from platform rider to direct client',
      customRateCard: 'Airport Drop: ₹1,100',
    };

    onAddClient(newClient);
    setShowAddClientModal(false);
    setClientName('');
    setClientPhone('');
    setPreferredRoute('');
    setNotes('');
  };

  const totalDirectRevenue = clients.reduce((sum, c) => sum + c.totalRevenueGenerated, 0);
  const totalCommissionSaved = Math.round(totalDirectRevenue * 0.28); // 28% saved from Ola cut

  return (
    <div className="space-y-6 pb-12">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-purple-500/20 text-purple-400">
              <Award className="w-5 h-5" />
            </span>
            <h2 className="text-lg sm:text-xl font-bold text-white tracking-tight">
              Direct Client CRM & Private Rate Card Engine
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Build your own private client network. 100% fare belongs to you with <strong className="text-purple-400">zero platform commission cuts</strong>.
          </p>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <button
            onClick={() => setActiveTab('QR_SHARE')}
            className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-200 text-xs font-semibold shadow transition-all"
          >
            <QrCode className="w-4 h-4 text-purple-400" />
            <span>Digital Business Card</span>
          </button>
          <button
            onClick={() => setShowAddClientModal(true)}
            className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white text-xs font-bold shadow-lg shadow-purple-950/50 transition-all active:scale-95"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Add Direct Client</span>
          </button>
        </div>
      </div>

      {/* Direct Sovereign Revenue Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-slate-900/90 border border-purple-500/30 rounded-2xl p-4 sm:p-5 shadow-lg">
          <div className="text-xs font-bold uppercase tracking-wider text-purple-400 flex items-center justify-between">
            <span>Direct Client Revenue</span>
            <DollarSign className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-2xl sm:text-3xl font-black text-white font-mono mt-2 privacy-sensitive">
            ₹{totalDirectRevenue.toLocaleString('en-IN')}
          </div>
          <div className="text-xs text-slate-400 mt-1">
            {clients.length} Loyal Private Riders
          </div>
        </div>

        <div className="bg-slate-900/90 border border-emerald-500/30 rounded-2xl p-4 sm:p-5 shadow-lg">
          <div className="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center justify-between">
            <span>Ola Commission Saved</span>
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl sm:text-3xl font-black text-emerald-400 font-mono mt-2 privacy-sensitive">
            +₹{totalCommissionSaved.toLocaleString('en-IN')}
          </div>
          <div className="text-xs text-emerald-300 font-medium mt-1">
            Kept 100% in your pocket
          </div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg">
          <div className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center justify-between">
            <span>Client Retention Score</span>
            <Star className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl sm:text-3xl font-black text-amber-300 font-mono mt-2">
            4.95 / 5.0
          </div>
          <div className="text-xs text-slate-400 mt-1">
            92% Repeat monthly booking rate
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
        <button
          onClick={() => setActiveTab('CLIENTS')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'CLIENTS'
              ? 'bg-purple-600 text-white shadow'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Active Private Clients ({clients.length})
        </button>
        <button
          onClick={() => setActiveTab('RATE_CARDS')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'RATE_CARDS'
              ? 'bg-purple-600 text-white shadow'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          WhatsApp Shareable Rate Cards
        </button>
        <button
          onClick={() => setActiveTab('QR_SHARE')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'QR_SHARE'
              ? 'bg-purple-600 text-white shadow'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          QR Booking Card & Profile
        </button>
      </div>

      {/* Tab 1: Client Records */}
      {activeTab === 'CLIENTS' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {clients.map((client) => {
            const clientTypeLabel = (client.clientType || 'DIRECT_REGULAR').replace(/_/g, ' ');
            const displayRoute = client.preferredRoute || (client.defaultPickup && client.defaultDropoff ? `${client.defaultPickup} ➔ ${client.defaultDropoff}` : 'Bengaluru City Airport Corridor');
            const tripsCount = client.totalTripsCompleted ?? client.totalRidesCompleted ?? 0;
            const cleanPhone = (client.phone || '').replace(/[^0-9]/g, '');

            return (
              <div
                key={client.id}
                className="bg-slate-900 border border-slate-800 hover:border-purple-500/40 rounded-2xl p-5 shadow-lg space-y-3 transition-all"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-bold text-white text-sm">{client.name}</h3>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 border border-purple-500/30">
                        {clientTypeLabel}
                      </span>
                    </div>
                    <div className="text-xs text-slate-400 font-mono mt-0.5">{client.phone}</div>
                  </div>

                  <div className="text-right">
                    <div className="text-base font-black text-emerald-400 font-mono">
                      ₹{(client.totalRevenueGenerated || 0).toLocaleString('en-IN')}
                    </div>
                    <div className="text-[10px] text-slate-400">{tripsCount} rides completed</div>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80 text-xs space-y-1.5">
                  <div className="flex items-center justify-between text-slate-300">
                    <span className="text-slate-400">Regular Route:</span>
                    <span className="font-medium text-white text-right">{displayRoute}</span>
                  </div>
                  <div className="flex items-center justify-between text-slate-300">
                    <span className="text-slate-400">Rate Agreed:</span>
                    <span className="font-medium text-emerald-300">{client.customRateCard || (client.agreedRate ? `Fixed: ₹${client.agreedRate}` : 'Standard Direct Rate')}</span>
                  </div>
                  {client.notes && (
                    <div className="text-slate-400 italic text-[11px] pt-1 border-t border-slate-850">
                      "{client.notes}"
                    </div>
                  )}
                </div>

                <div className="flex items-center justify-between pt-1 text-xs">
                  <a
                    href={`https://wa.me/${cleanPhone || '919845011223'}?text=Namaste%20${encodeURIComponent(client.name)},%20this%20is%20${encodeURIComponent(driver.name)}.%20Let%20me%20know%20when%20you%20need%20your%20next%20airport%20or%20city%20ride!`}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center gap-1.5 text-emerald-400 hover:text-emerald-300 font-semibold"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    <span>WhatsApp Message</span>
                  </a>
                  <a
                    href={`tel:${client.phone || ''}`}
                    className="flex items-center gap-1.5 text-sky-400 hover:text-sky-300 font-semibold"
                  >
                    <Phone className="w-3.5 h-3.5" />
                    <span>Call Rider</span>
                  </a>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Tab 2: WhatsApp Shareable Rate Cards */}
      {activeTab === 'RATE_CARDS' && (
        <div className="space-y-4">
          <div className="p-4 bg-slate-900 border border-purple-500/30 rounded-2xl flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-white">Direct Transparent Rate Cards</h3>
              <p className="text-xs text-slate-400">Share directly with passengers via 1-tap WhatsApp copy to build loyalty.</p>
            </div>
            <span className="text-xs font-mono font-bold text-purple-300 bg-purple-500/20 px-2.5 py-1 rounded-lg">
              0% Platform Fee
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {rateCards.map((card, idx) => {
              const shareMessage = `🚗 *Private Cab Booking with ${driver.name}*\n\n✨ *${card.title}*\n💵 *Price:* ${card.fixedPrice ? `₹${card.fixedPrice} Fixed` : `₹${card.pricePerKm}/km (Min ₹${card.minimumFare})`}\n🚘 *Vehicle:* ${driver.vehicleModel} (${driver.vehicleNumber})\n⭐ *Rating:* ${driver.rating} Stars (Zero Cancellation Record)\n\n📲 *Book directly on WhatsApp / Call:* ${driver.phone}\n_Pay directly via UPI with zero platform surge!_`;

              return (
                <div key={idx} className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-3 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                        {card.badge}
                      </span>
                      <span className="text-lg font-black text-white font-mono">
                        {card.fixedPrice ? `₹${card.fixedPrice}` : `₹${card.pricePerKm}/km`}
                      </span>
                    </div>

                    <h4 className="font-bold text-white text-sm mt-2">{card.title}</h4>
                    <p className="text-xs text-slate-400 mt-1 leading-relaxed">{card.description}</p>
                  </div>

                  <button
                    onClick={() => handleCopyRateCard(idx, shareMessage)}
                    className="mt-3 w-full py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-750 border border-slate-700 text-xs font-semibold text-slate-200 flex items-center justify-center gap-2 transition-all"
                  >
                    {copiedIndex === idx ? (
                      <>
                        <Check className="w-4 h-4 text-emerald-400" />
                        <span className="text-emerald-400">Copied to Clipboard!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-4 h-4 text-purple-400" />
                        <span>Copy WhatsApp Text</span>
                      </>
                    )}
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Tab 3: Digital Business Card & Dynamic QR */}
      {activeTab === 'QR_SHARE' && (
        <div className="max-w-md mx-auto bg-gradient-to-b from-slate-900 to-slate-950 border border-purple-500/40 rounded-3xl p-6 shadow-2xl text-center space-y-5">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-500 text-white font-black text-2xl flex items-center justify-center mx-auto shadow-lg shadow-emerald-950">
            {driver.name.split(' ').map(n => n[0]).join('')}
          </div>

          <div>
            <h3 className="text-xl font-bold text-white">{driver.name}</h3>
            <p className="text-xs text-emerald-400 font-medium">{driver.vehicleModel} • {driver.vehicleNumber}</p>
            <p className="text-xs text-slate-400 mt-1">Professional Independent Chauffeur • {driver.city}</p>
          </div>

          {/* Simulated QR Code Canvas */}
          <div className="p-4 rounded-2xl bg-white text-slate-950 mx-auto w-52 h-52 flex flex-col items-center justify-center shadow-2xl">
            <QrCode className="w-36 h-36 text-slate-950" />
            <span className="text-[10px] font-bold text-slate-700 mt-1">Scan to Book on WhatsApp / UPI</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-300 space-y-1">
            <div className="flex justify-between">
              <span>UPI ID:</span>
              <strong className="text-white font-mono">{driver.upiId}</strong>
            </div>
            <div className="flex justify-between">
              <span>Direct Phone:</span>
              <strong className="text-white font-mono">{driver.phone}</strong>
            </div>
          </div>

          <p className="text-xs text-purple-300 italic">
            "Show this screen or print this card to place on your cab's headrest for direct airport bookings."
          </p>
        </div>
      )}

      {/* Add Client Modal */}
      {showAddClientModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-5 space-y-4 shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Users className="w-4 h-4 text-purple-400" /> Save Direct Client
              </h3>
              <button
                onClick={() => setShowAddClientModal(false)}
                className="text-slate-400 hover:text-white text-xs"
              >
                Cancel
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 font-medium block mb-1">Passenger Full Name</label>
                <input
                  type="text"
                  value={clientName}
                  onChange={(e) => setClientName(e.target.value)}
                  placeholder="e.g. Vikramaditya Sen"
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-purple-500"
                />
              </div>

              <div>
                <label className="text-slate-400 font-medium block mb-1">Phone Number (WhatsApp)</label>
                <input
                  type="text"
                  value={clientPhone}
                  onChange={(e) => setClientPhone(e.target.value)}
                  placeholder="+91 98765 43210"
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono focus:outline-none focus:border-purple-500"
                />
              </div>

              <div>
                <label className="text-slate-400 font-medium block mb-1">Client Category</label>
                <select
                  value={clientType}
                  onChange={(e) => setClientType(e.target.value as any)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-purple-500"
                >
                  <option value="AIRPORT_REGULAR">Airport Regular</option>
                  <option value="CORPORATE_EXECUTIVE">Corporate Executive</option>
                  <option value="OUTSTATION_FAMILY">Outstation Family Trips</option>
                  <option value="DAILY_COMMUTER">Daily Office Commuter</option>
                </select>
              </div>

              <div>
                <label className="text-slate-400 font-medium block mb-1">Regular / Preferred Route</label>
                <input
                  type="text"
                  value={preferredRoute}
                  onChange={(e) => setPreferredRoute(e.target.value)}
                  placeholder="e.g. Indiranagar to Kempegowda Airport T2"
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-purple-500"
                />
              </div>

              <div>
                <label className="text-slate-400 font-medium block mb-1">Notes / Agreed Rate</label>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="e.g. Needs receipt for corporate expense reimbursement"
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-purple-500"
                />
              </div>
            </div>

            <button
              onClick={handleSaveClient}
              disabled={!clientName || !clientPhone}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 text-white text-xs font-bold shadow-lg transition-all disabled:opacity-50"
            >
              Add to Private Client Roster
            </button>
          </div>
        </div>
      )}

    </div>
  );
};
