import React, { useState } from 'react';
import { 
  X, 
  DollarSign, 
  Receipt, 
  Download, 
  Share2, 
  CheckCircle2, 
  QrCode, 
  CreditCard, 
  Banknote, 
  Phone, 
  User, 
  MapPin, 
  Sparkles,
  Copy,
  ExternalLink,
  ShieldCheck,
  Percent,
  MessageSquare
} from 'lucide-react';
import { DriverProfile, TripRecord } from '../types';
import { exportCustomerReceiptPDF, CustomerReceiptData } from '../utils/exportUtils';

interface CustomerPaymentReceiptModalProps {
  driver: DriverProfile;
  isOpen: boolean;
  onClose: () => void;
  initialTrip?: TripRecord | null;
  onPaymentComplete?: (trip: TripRecord) => void;
}

export const CustomerPaymentReceiptModal: React.FC<CustomerPaymentReceiptModalProps> = ({
  driver,
  isOpen,
  onClose,
  initialTrip,
  onPaymentComplete,
}) => {
  // Form State
  const [customerName, setCustomerName] = useState(initialTrip?.passengerName || 'Vikramaditya Sen');
  const [customerPhone, setCustomerPhone] = useState('9845012345');
  const [customerGstin, setCustomerGstin] = useState('');
  const [pickup, setPickup] = useState(initialTrip?.pickupLocation || 'Koramangala 5th Block, Bengaluru');
  const [dropoff, setDropoff] = useState(initialTrip?.dropoffLocation || 'Kempegowda Airport Terminal 2');
  const [distanceKm, setDistanceKm] = useState<number>(initialTrip?.distanceKm || 42);
  const [durationMin, setDurationMin] = useState<number>(initialTrip?.durationMinutes || 65);

  // Financial Breakdown
  const [baseFare, setBaseFare] = useState<number>(100);
  const [distanceFare, setDistanceFare] = useState<number>(1385);
  const [tollCost, setTollCost] = useState<number>(initialTrip?.tollCost || 115);
  const [waitingSurge, setWaitingSurge] = useState<number>(50);
  const [discount, setDiscount] = useState<number>(0);

  // Payment Method: CASH vs UPI vs CARD
  const [paymentMode, setPaymentMode] = useState<'CASH' | 'UPI' | 'CARD'>('UPI');
  const [cashTendered, setCashTendered] = useState<number | ''>(2000);
  const [upiRefId, setUpiRefId] = useState(`UPI-${Math.floor(100000 + Math.random() * 900000)}`);
  const [driverUpiId, setDriverUpiId] = useState(`${driver.phone.replace(/[^0-9]/g, '')}@okaxis`);
  
  const [isCopiedUpi, setIsCopiedUpi] = useState(false);
  const [isGeneratedPdf, setIsGeneratedPdf] = useState(false);
  const [receiptNumber] = useState(`INV-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`);

  const totalCalculated = Math.max(0, baseFare + distanceFare + tollCost + waitingSurge - discount);
  const cashChange = typeof cashTendered === 'number' && cashTendered >= totalCalculated ? cashTendered - totalCalculated : 0;

  const handleCopyUpi = () => {
    navigator.clipboard.writeText(driverUpiId);
    setIsCopiedUpi(true);
    setTimeout(() => setIsCopiedUpi(false), 2000);
  };

  const handleGenerateAndDownloadPDF = () => {
    const receiptData: CustomerReceiptData = {
      receiptNumber,
      date: new Date().toISOString(),
      driver,
      customerName: customerName || 'Passenger',
      customerPhone: customerPhone ? `+91 ${customerPhone}` : undefined,
      customerGstin: customerGstin || undefined,
      pickupLocation: pickup,
      dropoffLocation: dropoff,
      distanceKm,
      durationMinutes: durationMin,
      baseFare,
      distanceFare,
      tollCost,
      waitingOrSurgeFare: waitingSurge,
      discount,
      totalPaid: totalCalculated,
      paymentMode,
      paymentReference: paymentMode === 'UPI' ? upiRefId : `CASH-SETTLED-${receiptNumber}`,
      notes: 'Direct Sovereign Driver Ride. Section 44AD / GST compliant.',
    };

    exportCustomerReceiptPDF(receiptData);
    setIsGeneratedPdf(true);

    if (onPaymentComplete) {
      const recordedTrip: TripRecord = {
        id: `TRIP-${receiptNumber}`,
        timestamp: new Date().toISOString(),
        platform: 'DIRECT_CLIENT',
        pickupLocation: pickup,
        dropoffLocation: dropoff,
        distanceKm,
        durationMinutes: durationMin,
        grossFare: totalCalculated,
        platformCommission: 0,
        platformCommissionRate: 0,
        fuelCost: Math.round(distanceKm * 3.6),
        tollCost,
        tips: 0,
        netProfit: totalCalculated - Math.round(distanceKm * 3.6) - tollCost,
        deadheadKm: 0,
        passengerName: customerName,
        paymentMode,
        isPassengerVerified: true,
        notes: `Official PDF Receipt ${receiptNumber} Issued`,
      };
      onPaymentComplete(recordedTrip);
    }
  };

  const handleShareWhatsApp = () => {
    const msg = `*TAXI RIDE RECEIPT - ${receiptNumber}*\n` +
      `🚗 Driver: ${driver.name} (${driver.vehiclePlate})\n` +
      `📍 Route: ${pickup} ➔ ${dropoff}\n` +
      `📏 Distance: ${distanceKm} km | Duration: ${durationMin} mins\n` +
      `💳 Total Paid: ₹${totalCalculated} (Via ${paymentMode})\n` +
      `🧾 Ref: ${paymentMode === 'UPI' ? upiRefId : 'Cash'}\n` +
      `Thank you for riding with us! Drive Safe.`;

    const phoneSanitized = customerPhone.replace(/[^0-9]/g, '');
    const targetPhone = phoneSanitized.length === 10 ? `91${phoneSanitized}` : phoneSanitized;
    window.open(`https://wa.me/${targetPhone}?text=${encodeURIComponent(msg)}`, '_blank');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-2xl w-full p-5 sm:p-6 space-y-5 shadow-2xl animate-in zoom-in-95 duration-200 my-8">
        
        {/* Modal Top Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <span className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400">
              <Receipt className="w-5 h-5" />
            </span>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base sm:text-lg font-bold text-white">Customer Payment & PDF Bill</h3>
                <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  {receiptNumber}
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Collect payment via UPI QR / Cash & generate official GST/Commercial Ride Invoice
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Payment Method Selector */}
        <div>
          <label className="text-xs text-slate-400 font-semibold block mb-2">Select Customer Payment Method</label>
          <div className="grid grid-cols-3 gap-2">
            <button
              type="button"
              onClick={() => setPaymentMode('UPI')}
              className={`p-3 rounded-2xl border text-center transition-all flex flex-col items-center gap-1.5 ${
                paymentMode === 'UPI'
                  ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300 ring-2 ring-emerald-500/30 shadow-lg'
                  : 'bg-slate-800/80 border-slate-700 text-slate-400 hover:text-white'
              }`}
            >
              <QrCode className="w-5 h-5 text-emerald-400" />
              <span className="text-xs font-bold">UPI / QR Code</span>
              <span className="text-[10px] text-slate-400">GPay, PhonePe, Paytm</span>
            </button>

            <button
              type="button"
              onClick={() => setPaymentMode('CASH')}
              className={`p-3 rounded-2xl border text-center transition-all flex flex-col items-center gap-1.5 ${
                paymentMode === 'CASH'
                  ? 'bg-amber-500/20 border-amber-500 text-amber-300 ring-2 ring-amber-500/30 shadow-lg'
                  : 'bg-slate-800/80 border-slate-700 text-slate-400 hover:text-white'
              }`}
            >
              <Banknote className="w-5 h-5 text-amber-400" />
              <span className="text-xs font-bold">Hard Cash</span>
              <span className="text-[10px] text-slate-400">Direct Handover</span>
            </button>

            <button
              type="button"
              onClick={() => setPaymentMode('CARD')}
              className={`p-3 rounded-2xl border text-center transition-all flex flex-col items-center gap-1.5 ${
                paymentMode === 'CARD'
                  ? 'bg-sky-500/20 border-sky-500 text-sky-300 ring-2 ring-sky-500/30 shadow-lg'
                  : 'bg-slate-800/80 border-slate-700 text-slate-400 hover:text-white'
              }`}
            >
              <CreditCard className="w-5 h-5 text-sky-400" />
              <span className="text-xs font-bold">Card / Corporate</span>
              <span className="text-[10px] text-slate-400">POS / Direct Transfer</span>
            </button>
          </div>
        </div>

        {/* Dynamic Payment Details Section */}
        {paymentMode === 'UPI' && (
          <div className="p-4 rounded-2xl bg-slate-950 border border-emerald-500/40 grid grid-cols-1 sm:grid-cols-12 gap-4 items-center">
            {/* Visual Dynamic UPI QR Code */}
            <div className="sm:col-span-5 flex flex-col items-center justify-center p-3 bg-white rounded-xl shadow-md text-slate-950">
              {/* Styled SVG QR Code */}
              <svg className="w-28 h-28" viewBox="0 0 100 100">
                {/* Corner markers */}
                <rect x="5" y="5" width="25" height="25" fill="#0f172a" rx="2" />
                <rect x="9" y="9" width="17" height="17" fill="#ffffff" rx="1" />
                <rect x="13" y="13" width="9" height="9" fill="#10b981" rx="1" />

                <rect x="70" y="5" width="25" height="25" fill="#0f172a" rx="2" />
                <rect x="74" y="9" width="17" height="17" fill="#ffffff" rx="1" />
                <rect x="78" y="13" width="9" height="9" fill="#10b981" rx="1" />

                <rect x="5" y="70" width="25" height="25" fill="#0f172a" rx="2" />
                <rect x="9" y="74" width="17" height="17" fill="#ffffff" rx="1" />
                <rect x="13" y="78" width="9" height="9" fill="#10b981" rx="1" />

                {/* Data Grid Matrix */}
                <rect x="35" y="10" width="6" height="6" fill="#0f172a" />
                <rect x="45" y="15" width="6" height="6" fill="#0f172a" />
                <rect x="55" y="8" width="6" height="6" fill="#0f172a" />
                <rect x="35" y="25" width="6" height="6" fill="#0f172a" />
                <rect x="45" y="35" width="8" height="8" fill="#10b981" />
                <rect x="10" y="40" width="6" height="6" fill="#0f172a" />
                <rect x="20" y="50" width="6" height="6" fill="#0f172a" />
                <rect x="35" y="48" width="6" height="6" fill="#0f172a" />
                <rect x="48" y="55" width="6" height="6" fill="#0f172a" />
                <rect x="60" y="40" width="6" height="6" fill="#0f172a" />
                <rect x="75" y="38" width="6" height="6" fill="#0f172a" />
                <rect x="85" y="48" width="6" height="6" fill="#0f172a" />
                <rect x="40" y="70" width="6" height="6" fill="#0f172a" />
                <rect x="55" y="75" width="8" height="8" fill="#0f172a" />
                <rect x="70" y="70" width="6" height="6" fill="#0f172a" />
                <rect x="80" y="80" width="8" height="8" fill="#0f172a" />
              </svg>
              <span className="text-[11px] font-mono font-bold mt-1 text-slate-900">
                Scan & Pay ₹{totalCalculated}
              </span>
              <span className="text-[9px] text-slate-500">100% Instant To Driver Account</span>
            </div>

            {/* UPI Details & UTR */}
            <div className="sm:col-span-7 space-y-2.5 text-xs">
              <div>
                <label className="text-slate-400 font-medium block mb-1">Driver UPI Virtual Address</label>
                <div className="flex items-center gap-1.5">
                  <input
                    type="text"
                    value={driverUpiId}
                    onChange={(e) => setDriverUpiId(e.target.value)}
                    className="flex-1 bg-slate-800 border border-slate-700 rounded-xl px-3 py-1.5 text-white font-mono text-xs focus:outline-none focus:border-emerald-500"
                  />
                  <button
                    onClick={handleCopyUpi}
                    className="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 text-xs font-semibold flex items-center gap-1"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    <span>{isCopiedUpi ? 'Copied!' : 'Copy'}</span>
                  </button>
                </div>
              </div>

              <div>
                <label className="text-slate-400 font-medium block mb-1">Bank UTR / Transaction Ref</label>
                <input
                  type="text"
                  value={upiRefId}
                  onChange={(e) => setUpiRefId(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-1.5 text-emerald-300 font-mono text-xs focus:outline-none focus:border-emerald-500"
                  placeholder="e.g. 329188291044"
                />
              </div>
            </div>
          </div>
        )}

        {paymentMode === 'CASH' && (
          <div className="p-4 rounded-2xl bg-slate-950 border border-amber-500/40 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div>
              <label className="text-slate-400 font-medium block mb-1">Cash Received From Passenger (₹)</label>
              <input
                type="number"
                value={cashTendered}
                onChange={(e) => setCashTendered(e.target.value === '' ? '' : Number(e.target.value))}
                placeholder="e.g. 2000"
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono font-bold text-sm focus:outline-none focus:border-amber-500"
              />
            </div>

            <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex flex-col justify-center">
              <span className="text-slate-400 text-[11px] block">Change to return to passenger:</span>
              <span className={`text-lg font-black font-mono mt-0.5 ${cashChange >= 0 ? 'text-amber-400' : 'text-rose-400'}`}>
                {cashChange >= 0 ? `₹${cashChange}` : 'Short by ₹' + Math.abs(cashChange)}
              </span>
            </div>
          </div>
        )}

        {/* Passenger & Transit Route Details */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
          <div>
            <label className="text-slate-400 font-medium block mb-1">Passenger Name</label>
            <div className="relative">
              <User className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-2.5" />
              <input
                type="text"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl pl-8 pr-3 py-2 text-white focus:outline-none focus:border-emerald-500"
                placeholder="Full Name"
              />
            </div>
          </div>

          <div>
            <label className="text-slate-400 font-medium block mb-1">Passenger Phone (WhatsApp)</label>
            <div className="relative">
              <Phone className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-2.5" />
              <input
                type="text"
                value={customerPhone}
                onChange={(e) => setCustomerPhone(e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl pl-8 pr-3 py-2 text-white font-mono focus:outline-none focus:border-emerald-500"
                placeholder="10-digit mobile"
              />
            </div>
          </div>

          <div>
            <label className="text-slate-400 font-medium block mb-1">Company GSTIN (Optional)</label>
            <input
              type="text"
              value={customerGstin}
              onChange={(e) => setCustomerGstin(e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono uppercase focus:outline-none focus:border-emerald-500"
              placeholder="e.g. 29AAAAA0000A1Z5"
            />
          </div>
        </div>

        {/* Route Details */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          <div>
            <label className="text-slate-400 font-medium block mb-1">Pickup Location</label>
            <input
              type="text"
              value={pickup}
              onChange={(e) => setPickup(e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-emerald-500"
            />
          </div>
          <div>
            <label className="text-slate-400 font-medium block mb-1">Dropoff Location</label>
            <input
              type="text"
              value={dropoff}
              onChange={(e) => setDropoff(e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-emerald-500"
            />
          </div>
        </div>

        {/* Itemized Fare Breakdown Fields */}
        <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between text-xs border-b border-slate-850 pb-2">
            <span className="font-bold text-slate-300">Itemized Fare Breakdown</span>
            <span className="text-slate-400 font-mono text-[11px]">{distanceKm} km • {durationMin} mins</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-xs">
            <div>
              <label className="text-slate-400 text-[10px] block mb-1">Base Fare</label>
              <input
                type="number"
                value={baseFare}
                onChange={(e) => setBaseFare(Number(e.target.value))}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2 py-1.5 text-white font-mono"
              />
            </div>
            <div>
              <label className="text-slate-400 text-[10px] block mb-1">Distance Fare</label>
              <input
                type="number"
                value={distanceFare}
                onChange={(e) => setDistanceFare(Number(e.target.value))}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2 py-1.5 text-white font-mono"
              />
            </div>
            <div>
              <label className="text-slate-400 text-[10px] block mb-1">Tolls / FASTag</label>
              <input
                type="number"
                value={tollCost}
                onChange={(e) => setTollCost(Number(e.target.value))}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2 py-1.5 text-white font-mono"
              />
            </div>
            <div>
              <label className="text-slate-400 text-[10px] block mb-1">Peak / Waiting</label>
              <input
                type="number"
                value={waitingSurge}
                onChange={(e) => setWaitingSurge(Number(e.target.value))}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2 py-1.5 text-white font-mono"
              />
            </div>
            <div>
              <label className="text-slate-400 text-[10px] block mb-1">Discount (₹)</label>
              <input
                type="number"
                value={discount}
                onChange={(e) => setDiscount(Number(e.target.value))}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2 py-1.5 text-rose-300 font-mono"
              />
            </div>
          </div>

          <div className="flex items-center justify-between pt-2 border-t border-slate-850">
            <span className="text-xs font-bold text-slate-300">TOTAL FARE TO BE PAID:</span>
            <span className="text-2xl font-black text-emerald-400 font-mono">₹{totalCalculated}</span>
          </div>
        </div>

        {/* Action Buttons: Generate PDF & WhatsApp Share */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
          <button
            type="button"
            onClick={handleGenerateAndDownloadPDF}
            className="py-3 px-4 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold flex items-center justify-center gap-2 shadow-lg shadow-emerald-950 transition-all active:scale-95 cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>Convert & Download Official PDF Bill</span>
          </button>

          <button
            type="button"
            onClick={handleShareWhatsApp}
            className="py-3 px-4 rounded-2xl bg-slate-800 hover:bg-slate-750 border border-emerald-500/40 text-emerald-300 hover:text-white text-xs font-bold flex items-center justify-center gap-2 transition-all active:scale-95 cursor-pointer"
          >
            <MessageSquare className="w-4 h-4 text-emerald-400" />
            <span>Share Bill Receipt via WhatsApp</span>
          </button>
        </div>

        {isGeneratedPdf && (
          <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-xs text-emerald-300 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>PDF Invoice downloaded successfully & synced with driver encrypted records!</span>
          </div>
        )}

      </div>
    </div>
  );
};
