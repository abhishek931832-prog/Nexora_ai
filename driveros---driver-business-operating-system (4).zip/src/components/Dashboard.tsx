import React, { useEffect, useState } from 'react';
import { 
  TrendingUp, 
  DollarSign, 
  Percent, 
  Fuel, 
  Receipt, 
  ArrowUpRight, 
  ShieldAlert, 
  Car, 
  Zap, 
  Award, 
  Compass, 
  Sparkles,
  CheckCircle2,
  Clock,
  Mic,
  FileText,
  Banknote,
  UserCheck,
  QrCode
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  PieChart, 
  Pie, 
  Cell, 
  AreaChart, 
  Area 
} from 'recharts';
import { TripRecord, ExpenseRecord, DriverProfile, ShiftState } from '../types';

interface DashboardProps {
  driver: DriverProfile;
  trips: TripRecord[];
  expenses: ExpenseRecord[];
  shift: ShiftState;
  onOpenVoice: () => void;
  onOpenNewTrip: () => void;
  onOpenScanReceipt: () => void;
  onNavigateTab: (tabId: string) => void;
  onOpenCustomerPayment?: () => void;
  onOpenDriverAuth?: () => void;
}

const PLATFORM_COLORS: Record<string, string> = {
  OLA: '#f59e0b', // Amber/Yellow
  UBER: '#3b82f6', // Blue
  RAPIDO: '#eab308', // Gold
  NAMMA_YATRI: '#10b981', // Emerald
  DIRECT_CLIENT: '#8b5cf6', // Violet
};

export const Dashboard: React.FC<DashboardProps> = ({
  driver,
  trips,
  expenses,
  shift,
  onOpenVoice,
  onOpenNewTrip,
  onOpenScanReceipt,
  onNavigateTab,
  onOpenCustomerPayment,
  onOpenDriverAuth,
}) => {
  // Aggregate metrics
  const todayDateStr = new Date().toISOString().split('T')[0];
  const todayTrips = trips.filter(t => t.timestamp.startsWith(todayDateStr));
  const todayExpenses = expenses.filter(e => e.date === todayDateStr);

  const todayGross = todayTrips.reduce((sum, t) => sum + t.grossFare, 0);
  const todayCommissionBleed = todayTrips.reduce((sum, t) => sum + t.platformCommission, 0);
  const todayFuel = todayTrips.reduce((sum, t) => sum + t.fuelCost, 0);
  const todayToll = todayTrips.reduce((sum, t) => sum + t.tollCost, 0);
  const todayTips = todayTrips.reduce((sum, t) => sum + t.tips, 0);
  const todayOtherExpenses = todayExpenses.reduce((sum, e) => sum + (e.category !== 'CNG_FUEL' && e.category !== 'TOLL' ? e.amount : 0), 0);
  
  // Real In-Pocket Net Profit
  const todayNetProfit = todayGross - todayCommissionBleed - todayFuel - todayToll + todayTips - todayOtherExpenses;
  const todayKm = todayTrips.reduce((sum, t) => sum + t.distanceKm, 0);
  const todayMinutes = todayTrips.reduce((sum, t) => sum + t.durationMinutes, 0);
  const profitPerKm = todayKm > 0 ? (todayNetProfit / todayKm).toFixed(1) : '0';
  const profitPerHour = todayMinutes > 0 ? ((todayNetProfit / todayMinutes) * 60).toFixed(0) : '0';

  // Platform Breakdown for Chart
  const platformData = ['OLA', 'UBER', 'RAPIDO', 'NAMMA_YATRI', 'DIRECT_CLIENT'].map(platform => {
    const pTrips = trips.filter(t => t.platform === platform);
    const gross = pTrips.reduce((sum, t) => sum + t.grossFare, 0);
    const comm = pTrips.reduce((sum, t) => sum + t.platformCommission, 0);
    const net = pTrips.reduce((sum, t) => sum + t.netProfit, 0);
    return {
      name: platform.replace('_', ' '),
      platformKey: platform,
      gross,
      commission: comm,
      net,
      count: pTrips.length,
    };
  }).filter(p => p.count > 0);

  // Hourly profit curve
  const hourlyData = [
    { hour: '6 AM', gross: 600, net: 520, olaLoss: 80 },
    { hour: '8 AM', gross: 1650, net: 1480, olaLoss: 0 },
    { hour: '10 AM', gross: 680, net: 604, olaLoss: 0 },
    { hour: '12 PM', gross: 420, net: 248, olaLoss: 118 },
    { hour: '2 PM', gross: 280, net: 208, olaLoss: 56 },
    { hour: '4 PM', gross: 850, net: 830, olaLoss: 0 },
    { hour: '7 PM (Peak)', gross: 1100, net: 920, olaLoss: 90 },
  ];

  // Goal Progress
  const dailyGoal = shift.dailyGoalAmount || 3500;
  const goalPercent = Math.min(100, Math.round((todayNetProfit / dailyGoal) * 100));
  const [hasCelebrated, setHasCelebrated] = useState(false);

  useEffect(() => {
    if (goalPercent >= 100 && !hasCelebrated) {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#10b981', '#38bdf8', '#fbbf24'],
      });
      setHasCelebrated(true);
    }
  }, [goalPercent, hasCelebrated]);

  return (
    <div className="space-y-6 pb-12">
      
      {/* Top Banner Alert / Value Proposition */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-slate-900 via-slate-850 to-slate-900 border border-slate-800 p-4 sm:p-6 shadow-xl">
        <div className="absolute right-0 top-0 translate-x-8 -translate-y-8 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 relative z-10">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-emerald-400" /> Ola Independence OS
              </span>
              <span className="text-xs text-slate-400 font-mono">Real-time Zero-Leakage Engine</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              Welcome back, {driver.name.split(' ')[0]}!
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl">
              Ola owns passenger data. <strong className="text-emerald-400 font-semibold">You own your business, profit ledger, and customer relationships.</strong> Zero commissions, encrypted records, direct client booking cards.
            </p>
          </div>

          <div className="flex items-center flex-wrap gap-2.5 w-full lg:w-auto">
            {onOpenCustomerPayment && (
              <button
                onClick={onOpenCustomerPayment}
                className="flex-1 lg:flex-none flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-300 text-xs font-bold shadow-lg shadow-emerald-950/40 transition-all hover:scale-[1.02] cursor-pointer"
              >
                <Banknote className="w-4 h-4 text-emerald-400" />
                <span>Collect Fare & PDF Bill</span>
              </button>
            )}
            {onOpenDriverAuth && (
              <button
                onClick={onOpenDriverAuth}
                className="flex-1 lg:flex-none flex items-center justify-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-300 text-xs font-semibold shadow transition-all hover:scale-[1.02] cursor-pointer"
              >
                <UserCheck className="w-4 h-4 text-sky-400" />
                <span>Switch Driver</span>
              </button>
            )}
            <button
              onClick={() => onNavigateTab('coach')}
              className="flex-1 lg:flex-none flex items-center justify-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-200 text-xs font-semibold shadow transition-all hover:scale-[1.02]"
            >
              <Compass className="w-4 h-4 text-emerald-400" />
              <span>AI Coach</span>
            </button>
            <button
              onClick={onOpenScanReceipt}
              className="flex-1 lg:flex-none flex items-center justify-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-semibold shadow-lg shadow-emerald-950/60 transition-all hover:scale-[1.02]"
            >
              <Receipt className="w-4 h-4" />
              <span>Scan Bill</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main KPI Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Real In-Pocket Net Profit */}
        <div className="bg-slate-900/90 border border-emerald-500/30 rounded-2xl p-4 sm:p-5 shadow-lg relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/10 rounded-full blur-xl group-hover:bg-emerald-500/20 transition-all" />
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" /> Real Net In-Pocket
            </span>
            <span className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400">
              <DollarSign className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-3">
            <div className="text-2xl sm:text-3xl font-black text-white font-mono tracking-tight privacy-sensitive">
              ₹{todayNetProfit.toLocaleString('en-IN')}
            </div>
            <div className="flex items-center gap-2 mt-1 text-xs text-slate-400">
              <span className="text-emerald-400 font-semibold flex items-center">
                <ArrowUpRight className="w-3 h-3" /> +18.4%
              </span>
              <span>vs Ola-only baseline</span>
            </div>
          </div>
        </div>

        {/* The Ola Commission Bleed Metric */}
        <div className="bg-slate-900/90 border border-amber-500/30 rounded-2xl p-4 sm:p-5 shadow-lg relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-24 h-24 bg-amber-500/10 rounded-full blur-xl group-hover:bg-amber-500/20 transition-all" />
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1">
              <ShieldAlert className="w-3.5 h-3.5" /> Ola Commission Cut
            </span>
            <span className="p-2 rounded-xl bg-amber-500/20 text-amber-400">
              <Percent className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-3">
            <div className="text-2xl sm:text-3xl font-black text-amber-300 font-mono tracking-tight privacy-sensitive">
              -₹{todayCommissionBleed.toLocaleString('en-IN')}
            </div>
            <div className="flex items-center gap-1.5 mt-1 text-xs text-slate-400">
              <span className="text-amber-400/90 font-medium">Avg 28% Platform cut</span>
              <span>•</span>
              <button 
                onClick={() => onNavigateTab('ledger')}
                className="text-amber-300 underline hover:text-amber-200"
              >
                Recover via Direct
              </button>
            </div>
          </div>
        </div>

        {/* Gross Business Fares */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Gross Fares (All Apps)
            </span>
            <span className="p-2 rounded-xl bg-slate-800 text-sky-400">
              <TrendingUp className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-3">
            <div className="text-2xl sm:text-3xl font-black text-slate-100 font-mono tracking-tight privacy-sensitive">
              ₹{todayGross.toLocaleString('en-IN')}
            </div>
            <div className="flex items-center gap-2 mt-1 text-xs text-slate-400">
              <span>{todayTrips.length} Trips completed today</span>
              <span>•</span>
              <span>{todayKm.toFixed(0)} km</span>
            </div>
          </div>
        </div>

        {/* Operating Costs (Fuel + Toll + Maint) */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Fuel & Toll Expenses
            </span>
            <span className="p-2 rounded-xl bg-slate-800 text-rose-400">
              <Fuel className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-3">
            <div className="text-2xl sm:text-3xl font-black text-rose-300 font-mono tracking-tight privacy-sensitive">
              ₹{(todayFuel + todayToll + todayOtherExpenses).toLocaleString('en-IN')}
            </div>
            <div className="flex items-center gap-2 mt-1 text-xs text-slate-400">
              <span>CNG: ₹{todayFuel}</span>
              <span>•</span>
              <span>Toll FASTag: ₹{todayToll}</span>
            </div>
          </div>
        </div>

      </div>

      {/* Secondary Metrics Bar: Velocity & Target Goal */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        
        {/* Daily Target Progress Card */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                <Award className="w-4 h-4 text-amber-400" /> Daily Net Profit Target
              </span>
              <span className="text-xs font-mono font-bold text-emerald-400">
                {goalPercent}%
              </span>
            </div>
            <div className="w-full bg-slate-800 h-3 rounded-full overflow-hidden p-0.5 border border-slate-700">
              <div 
                className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 rounded-full transition-all duration-700"
                style={{ width: `${Math.min(100, goalPercent)}%` }}
              />
            </div>
            <div className="flex items-center justify-between text-xs text-slate-400 mt-2">
              <span>Current: <strong className="text-white font-mono">₹{todayNetProfit}</strong></span>
              <span>Goal: <strong className="text-slate-300 font-mono">₹{dailyGoal}</strong></span>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs">
            <span className="text-slate-400">Remaining to target:</span>
            <span className="font-bold text-amber-300 font-mono">
              {todayNetProfit >= dailyGoal ? '🎯 Target Achieved!' : `₹${dailyGoal - todayNetProfit} left`}
            </span>
          </div>
        </div>

        {/* Profit Velocity (₹/km and ₹/hour) */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg flex flex-col justify-between">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5 mb-3">
              <Zap className="w-4 h-4 text-sky-400" /> Real-time Profit Velocity
            </span>

            <div className="grid grid-cols-2 gap-3">
              <div className="p-3 rounded-xl bg-slate-800/70 border border-slate-700/60 text-center">
                <div className="text-[11px] text-slate-400 font-medium">Net Profit / KM</div>
                <div className="text-2xl font-black text-emerald-400 font-mono mt-1">₹{profitPerKm}</div>
                <div className="text-[10px] text-slate-500 mt-0.5">Ola avg: ₹14/km</div>
              </div>
              <div className="p-3 rounded-xl bg-slate-800/70 border border-slate-700/60 text-center">
                <div className="text-[11px] text-slate-400 font-medium">Net Profit / Hour</div>
                <div className="text-2xl font-black text-sky-400 font-mono mt-1">₹{profitPerHour}</div>
                <div className="text-[10px] text-slate-500 mt-0.5">Ola avg: ₹180/hr</div>
              </div>
            </div>
          </div>

          <div className="mt-3 pt-2 text-center text-xs text-slate-400">
            Driving Efficiency: <span className="text-emerald-400 font-medium">Top 5% in Bengaluru</span>
          </div>
        </div>

        {/* Quick Voice & Action Hub */}
        <div className="bg-gradient-to-br from-slate-900 via-slate-850 to-emerald-950/40 border border-slate-800 rounded-2xl p-5 shadow-lg flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
                <Mic className="w-4 h-4 animate-pulse" /> Saathi In-Cab Voice AI
              </span>
              <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded font-mono">
                Hindi & Eng
              </span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Speak naturally while driving: <em>"Bhai 500 ka CNG dala"</em>, <em>"Airport route profit check karo"</em> or <em>"Show top surge area"</em>.
            </p>
          </div>

          <button
            onClick={onOpenVoice}
            className="mt-4 w-full py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 active:scale-98 text-white text-xs font-bold flex items-center justify-center gap-2 shadow-lg shadow-emerald-950 transition-all"
          >
            <Mic className="w-4 h-4 text-white" />
            <span>Tap to Speak Voice Assistant</span>
          </button>
        </div>

      </div>

      {/* Visual Charts: Platform Comparison & Hourly Profit Curve */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Multi-Platform Commission Bleed vs Net Profit */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Car className="w-4 h-4 text-emerald-400" /> Platform Profitability Comparison
              </h3>
              <p className="text-xs text-slate-400">Net Take-Home vs Commission Lost per Platform</p>
            </div>
            <button 
              onClick={() => onNavigateTab('ledger')}
              className="text-xs text-emerald-400 hover:underline flex items-center gap-1"
            >
              View Full Ledger <ArrowUpRight className="w-3 h-3" />
            </button>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={platformData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <XAxis dataKey="name" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={11} tickLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px', fontSize: '12px' }}
                  formatter={(value: any, name: any) => [`₹${value}`, name === 'net' ? 'Net Take-Home' : 'Commission Cut']}
                />
                <Bar dataKey="net" fill="#10b981" name="net" radius={[6, 6, 0, 0]} />
                <Bar dataKey="commission" fill="#f43f5e" name="commission" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-3 border-t border-slate-800 text-xs">
            <div className="text-center p-2 rounded-lg bg-slate-800/40">
              <span className="text-amber-400 block font-semibold">Ola Cut</span>
              <span className="text-slate-300 font-mono font-bold">28% lost</span>
            </div>
            <div className="text-center p-2 rounded-lg bg-slate-800/40">
              <span className="text-sky-400 block font-semibold">Uber Cut</span>
              <span className="text-slate-300 font-mono font-bold">20% lost</span>
            </div>
            <div className="text-center p-2 rounded-lg bg-slate-800/40">
              <span className="text-emerald-400 block font-semibold">Namma Yatri</span>
              <span className="text-emerald-300 font-mono font-bold">0% Cut</span>
            </div>
            <div className="text-center p-2 rounded-lg bg-slate-800/40">
              <span className="text-purple-400 block font-semibold">Direct Client</span>
              <span className="text-purple-300 font-mono font-bold">100% Mine</span>
            </div>
          </div>
        </div>

        {/* Hourly Profit Curve */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Clock className="w-4 h-4 text-sky-400" /> Today's Shift Net Cash Curve
              </h3>
              <p className="text-xs text-slate-400">Peak hour surge vs off-peak hourly earnings</p>
            </div>
            <button 
              onClick={() => onNavigateTab('reports')}
              className="text-xs text-sky-400 hover:underline flex items-center gap-1"
            >
              Export P&L <FileText className="w-3 h-3" />
            </button>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={hourlyData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="profitGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0.0}/>
                  </linearGradient>
                  <linearGradient id="grossGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#38bdf8" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#38bdf8" stopOpacity={0.0}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="hour" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={11} tickLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px', fontSize: '12px' }}
                  formatter={(value: any) => [`₹${value}`, 'Amount']}
                />
                <Area type="monotone" dataKey="gross" stroke="#38bdf8" fillOpacity={1} fill="url(#grossGrad)" name="Gross Fare" />
                <Area type="monotone" dataKey="net" stroke="#10b981" strokeWidth={2} fillOpacity={1} fill="url(#profitGrad)" name="Net Profit" />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          <div className="flex items-center justify-between text-xs text-slate-400 pt-3 border-t border-slate-800">
            <span>Highest Yield Zone: <strong className="text-emerald-400">Airport & Koramangala (₹48/km)</strong></span>
            <span>Fuel Economy: <strong className="text-slate-200">24.5 km/kg</strong></span>
          </div>
        </div>

      </div>

      {/* Quick Launchpad to Sub-Systems */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <button
          onClick={() => onNavigateTab('map')}
          className="p-3.5 rounded-xl bg-slate-900/80 hover:bg-slate-850 border border-slate-800 text-left transition-all hover:border-emerald-500/40 group"
        >
          <Compass className="w-5 h-5 text-emerald-400 mb-2 group-hover:scale-110 transition-transform" />
          <div className="text-xs font-bold text-white">Profit Map</div>
          <div className="text-[10px] text-slate-400">Surge Heatmap & Tolls</div>
        </button>

        <button
          onClick={() => onNavigateTab('ledger')}
          className="p-3.5 rounded-xl bg-slate-900/80 hover:bg-slate-850 border border-slate-800 text-left transition-all hover:border-sky-500/40 group"
        >
          <Car className="w-5 h-5 text-sky-400 mb-2 group-hover:scale-110 transition-transform" />
          <div className="text-xs font-bold text-white">Trip Ledger</div>
          <div className="text-[10px] text-slate-400">Cross-Platform Sync</div>
        </button>

        <button
          onClick={() => onNavigateTab('expenses')}
          className="p-3.5 rounded-xl bg-slate-900/80 hover:bg-slate-850 border border-slate-800 text-left transition-all hover:border-amber-500/40 group"
        >
          <Receipt className="w-5 h-5 text-amber-400 mb-2 group-hover:scale-110 transition-transform" />
          <div className="text-xs font-bold text-white">Expense OCR</div>
          <div className="text-[10px] text-slate-400">Bill & Fuel Scanner</div>
        </button>

        <button
          onClick={() => onNavigateTab('safety')}
          className="p-3.5 rounded-xl bg-slate-900/80 hover:bg-slate-850 border border-slate-800 text-left transition-all hover:border-rose-500/40 group"
        >
          <ShieldAlert className="w-5 h-5 text-rose-400 mb-2 group-hover:scale-110 transition-transform" />
          <div className="text-xs font-bold text-white">Fatigue & Safety</div>
          <div className="text-[10px] text-slate-400">₹5L Micro-Insurance</div>
        </button>

        <button
          onClick={() => onNavigateTab('crm')}
          className="p-3.5 rounded-xl bg-slate-900/80 hover:bg-slate-850 border border-slate-800 text-left transition-all hover:border-purple-500/40 group"
        >
          <Award className="w-5 h-5 text-purple-400 mb-2 group-hover:scale-110 transition-transform" />
          <div className="text-xs font-bold text-white">Direct Clients</div>
          <div className="text-[10px] text-slate-400">Private Rate Cards</div>
        </button>

        <button
          onClick={() => onNavigateTab('security')}
          className="p-3.5 rounded-xl bg-slate-900/80 hover:bg-slate-850 border border-slate-800 text-left transition-all hover:border-teal-500/40 group"
        >
          <Zap className="w-5 h-5 text-teal-400 mb-2 group-hover:scale-110 transition-transform" />
          <div className="text-xs font-bold text-white">Data Enclave</div>
          <div className="text-[10px] text-slate-400">Zero-Knowledge AES</div>
        </button>
      </div>

    </div>
  );
};
