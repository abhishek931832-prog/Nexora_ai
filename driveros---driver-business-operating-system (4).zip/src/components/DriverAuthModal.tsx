import React, { useState } from 'react';
import { 
  X, 
  User, 
  UserPlus, 
  Car, 
  ShieldCheck, 
  CheckCircle2, 
  KeyRound, 
  Phone, 
  Mail, 
  MapPin, 
  Fuel, 
  Award, 
  Sparkles,
  LogIn,
  Layers,
  ArrowRight
} from 'lucide-react';
import { DriverProfile } from '../types';

interface DriverAuthModalProps {
  currentDriver: DriverProfile;
  availableDrivers: DriverProfile[];
  isOpen: boolean;
  onClose: () => void;
  onSelectDriver: (driver: DriverProfile) => void;
  onAddNewDriver: (driver: DriverProfile) => void;
}

export const DriverAuthModal: React.FC<DriverAuthModalProps> = ({
  currentDriver,
  availableDrivers,
  isOpen,
  onClose,
  onSelectDriver,
  onAddNewDriver,
}) => {
  const [activeMode, setActiveMode] = useState<'LOGIN_SWITCH' | 'ADD_NEW'>('LOGIN_SWITCH');

  // Login / Switch State
  const [selectedDriverId, setSelectedDriverId] = useState(currentDriver.id);
  const [loginPin, setLoginPin] = useState('1234');
  const [loginError, setLoginError] = useState<string | null>(null);

  // New Driver Form State
  const [newName, setNewName] = useState('');
  const [newPhone, setNewPhone] = useState('+91 ');
  const [newEmail, setNewEmail] = useState('');
  const [newCity, setNewCity] = useState('Bengaluru, Karnataka');
  const [newVehicleModel, setNewVehicleModel] = useState('Maruti Suzuki Dzire Tour CNG');
  const [newVehiclePlate, setNewVehiclePlate] = useState('KA 04 E 8812');
  const [newFuelType, setNewFuelType] = useState<'CNG' | 'EV' | 'PETROL' | 'DIESEL'>('CNG');
  const [newMileage, setNewMileage] = useState<number>(25.0);
  const [newFuelPrice, setNewFuelPrice] = useState<number>(88.50);
  const [newCommercialDl, setNewCommercialDl] = useState('KA0420210099412');
  const [newRtoBadge, setNewRtoBadge] = useState('KA-04-BDG-2021-9988');
  const [newPin, setNewPin] = useState('1234');
  const [newExperience, setNewExperience] = useState<number>(5);

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const target = availableDrivers.find(d => d.id === selectedDriverId);
    if (!target) {
      setLoginError('Please select a driver account.');
      return;
    }

    if (loginPin.length < 4) {
      setLoginError('Enter valid 4-digit driver security PIN.');
      return;
    }

    onSelectDriver(target);
    onClose();
  };

  const handleCreateDriverSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName || !newPhone || !newVehiclePlate) {
      setLoginError('Please fill in driver name, phone and vehicle registration number.');
      return;
    }

    const createdDriver: DriverProfile = {
      id: `DRV-IN-${Math.floor(10000 + Math.random() * 90000)}`,
      name: newName,
      phone: newPhone,
      email: newEmail || `${newName.toLowerCase().replace(/\s+/g, '.')}.cab@gmail.com`,
      city: newCity,
      vehicleModel: newVehicleModel,
      vehiclePlate: newVehiclePlate.toUpperCase(),
      fuelType: newFuelType,
      fuelMileageKmPerUnit: Number(newMileage) || 24,
      fuelPricePerUnit: Number(newFuelPrice) || 88.5,
      rtoBadgeNumber: newRtoBadge || `KA-BDG-${Math.floor(1000 + Math.random() * 9000)}`,
      commercialDlNumber: newCommercialDl || `KA-DL-${Math.floor(100000 + Math.random() * 900000)}`,
      yearsExperience: Number(newExperience) || 3,
      biometricKeyFingerprint: `SHA256:${Math.random().toString(36).substring(2, 14)}`,
      encryptionKeyHash: `AES256:${Math.random().toString(36).substring(2, 18)}`,
      rating: 5.0,
      totalTripsCount: 1,
      isIdentityVerified: true,
      activeLanguage: 'en',
    };

    onAddNewDriver(createdDriver);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-xl w-full p-5 sm:p-6 space-y-5 shadow-2xl animate-in zoom-in-95 duration-200 my-8">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <span className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400">
              <User className="w-5 h-5" />
            </span>
            <div>
              <h3 className="text-base sm:text-lg font-bold text-white">Driver Login & Fleet Profile Access</h3>
              <p className="text-xs text-slate-400">Switch driver profiles or onboard new commercial cab drivers</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Mode Selector Tabs */}
        <div className="grid grid-cols-2 gap-2 bg-slate-950 p-1 rounded-2xl border border-slate-800">
          <button
            type="button"
            onClick={() => { setActiveMode('LOGIN_SWITCH'); setLoginError(null); }}
            className={`py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all ${
              activeMode === 'LOGIN_SWITCH'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <LogIn className="w-3.5 h-3.5" />
            <span>Driver Login / Switch</span>
          </button>

          <button
            type="button"
            onClick={() => { setActiveMode('ADD_NEW'); setLoginError(null); }}
            className={`py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all ${
              activeMode === 'ADD_NEW'
                ? 'bg-emerald-600 text-white shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <UserPlus className="w-3.5 h-3.5" />
            <span>+ Add New Driver</span>
          </button>
        </div>

        {loginError && (
          <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-xs text-rose-300">
            {loginError}
          </div>
        )}

        {/* TAB 1: LOGIN & SWITCH DRIVER */}
        {activeMode === 'LOGIN_SWITCH' && (
          <form onSubmit={handleLoginSubmit} className="space-y-4">
            <div>
              <label className="text-xs text-slate-400 font-semibold block mb-2">Select Active Driver Account</label>
              <div className="space-y-2.5 max-h-60 overflow-y-auto pr-1">
                {availableDrivers.map(d => {
                  const isSelected = selectedDriverId === d.id;
                  const isCurrent = currentDriver.id === d.id;

                  return (
                    <div
                      key={d.id}
                      onClick={() => setSelectedDriverId(d.id)}
                      className={`p-3.5 rounded-2xl border cursor-pointer transition-all flex items-center justify-between ${
                        isSelected
                          ? 'bg-emerald-500/15 border-emerald-500 ring-1 ring-emerald-500/40 text-white shadow-lg'
                          : 'bg-slate-800/70 border-slate-700/80 text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-sm ${
                          isSelected ? 'bg-emerald-500 text-slate-950' : 'bg-slate-700 text-slate-200'
                        }`}>
                          {d.name.split(' ').map(n => n[0]).join('').slice(0, 2)}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-sm text-white">{d.name}</span>
                            {isCurrent && (
                              <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-1.5 py-0.2 rounded font-mono font-bold">
                                ACTIVE
                              </span>
                            )}
                          </div>
                          <div className="text-xs text-slate-400 font-mono mt-0.5">
                            {d.vehicleModel} • <strong className="text-slate-200">{d.vehiclePlate}</strong>
                          </div>
                        </div>
                      </div>

                      <div className="text-right">
                        <span className="text-[10px] px-2 py-0.5 rounded bg-slate-900 font-mono text-emerald-400 font-bold block">
                          ★ {d.rating}
                        </span>
                        <span className="text-[10px] text-slate-400 block mt-1">
                          {d.fuelType}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800 space-y-2">
              <label className="text-xs text-slate-400 font-semibold flex items-center justify-between">
                <span className="flex items-center gap-1.5">
                  <KeyRound className="w-3.5 h-3.5 text-emerald-400" /> Driver 4-Digit Access PIN
                </span>
                <span className="text-[10px] text-slate-500 font-mono">Demo: 1234</span>
              </label>
              <input
                type="password"
                maxLength={4}
                value={loginPin}
                onChange={(e) => setLoginPin(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono tracking-widest text-center text-base focus:outline-none focus:border-emerald-500"
                placeholder="••••"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold flex items-center justify-center gap-2 shadow-lg shadow-emerald-950 transition-all active:scale-95 cursor-pointer"
            >
              <ShieldCheck className="w-4 h-4" />
              <span>Log In & Switch Active Driver</span>
            </button>
          </form>
        )}

        {/* TAB 2: ADD NEW DRIVER */}
        {activeMode === 'ADD_NEW' && (
          <form onSubmit={handleCreateDriverSubmit} className="space-y-3.5 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-slate-400 font-medium block mb-1">Driver Full Name *</label>
                <input
                  type="text"
                  required
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="e.g. Suresh Patil"
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="text-slate-400 font-medium block mb-1">Mobile Number *</label>
                <input
                  type="text"
                  required
                  value={newPhone}
                  onChange={(e) => setNewPhone(e.target.value)}
                  placeholder="+91 98450 XXXXX"
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-slate-400 font-medium block mb-1">Vehicle Make & Model *</label>
                <input
                  type="text"
                  required
                  value={newVehicleModel}
                  onChange={(e) => setNewVehicleModel(e.target.value)}
                  placeholder="e.g. Maruti WagonR CNG / Tata Tigor EV"
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="text-slate-400 font-medium block mb-1">Vehicle Plate (RTO Registration) *</label>
                <input
                  type="text"
                  required
                  value={newVehiclePlate}
                  onChange={(e) => setNewVehiclePlate(e.target.value.toUpperCase())}
                  placeholder="KA-05-MQ-8921"
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono uppercase focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <div>
                <label className="text-slate-400 text-[11px] block mb-1">Fuel Type</label>
                <select
                  value={newFuelType}
                  onChange={(e) => setNewFuelType(e.target.value as any)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-2 py-2 text-white text-xs focus:outline-none"
                >
                  <option value="CNG">CNG</option>
                  <option value="EV">EV (Electric)</option>
                  <option value="PETROL">Petrol</option>
                  <option value="DIESEL">Diesel</option>
                </select>
              </div>

              <div>
                <label className="text-slate-400 text-[11px] block mb-1">Mileage (km/unit)</label>
                <input
                  type="number"
                  value={newMileage}
                  onChange={(e) => setNewMileage(Number(e.target.value))}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-2 py-2 text-white font-mono"
                />
              </div>

              <div>
                <label className="text-slate-400 text-[11px] block mb-1">Commercial DL</label>
                <input
                  type="text"
                  value={newCommercialDl}
                  onChange={(e) => setNewCommercialDl(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-2 py-2 text-white font-mono uppercase"
                />
              </div>

              <div>
                <label className="text-slate-400 text-[11px] block mb-1">4-Digit PIN</label>
                <input
                  type="password"
                  maxLength={4}
                  value={newPin}
                  onChange={(e) => setNewPin(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-2 py-2 text-white font-mono text-center"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold flex items-center justify-center gap-2 shadow-lg shadow-emerald-950 transition-all active:scale-95 cursor-pointer mt-2"
            >
              <UserPlus className="w-4 h-4" />
              <span>Register & Log In New Driver</span>
            </button>
          </form>
        )}

      </div>
    </div>
  );
};
