import React, { useState } from 'react';
import { 
  Cpu, 
  Car, 
  DollarSign, 
  Navigation, 
  Sparkles, 
  Brain, 
  Lightbulb, 
  Target, 
  AlertTriangle, 
  ArrowDown, 
  ShieldCheck, 
  TrendingUp, 
  Wrench, 
  Award, 
  CheckCircle2, 
  X, 
  ChevronRight, 
  Radio, 
  Zap, 
  Fuel, 
  MapPin, 
  Layers
} from 'lucide-react';
import { MainPillar } from '../types';

interface DriverOSArchitectureModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigatePillar: (pillar: MainPillar, subView?: string) => void;
  activeRide?: any;
  isOnDuty?: boolean;
}

export const DriverOSArchitectureModal: React.FC<DriverOSArchitectureModalProps> = ({
  isOpen,
  onClose,
  onNavigatePillar,
  activeRide,
  isOnDuty = true,
}) => {
  const [selectedNode, setSelectedNode] = useState<string>('DRIVEROS_CORE');
  const [saathiTab, setSaathiTab] = useState<'INSIGHT' | 'OPPORTUNITY' | 'ALERT'>('OPPORTUNITY');

  if (!isOpen) return null;

  const handleActionClick = (action: 'EARN' | 'PROTECT' | 'OPTIMIZE' | 'MANAGE' | 'GROW') => {
    onClose();
    switch (action) {
      case 'EARN':
        onNavigatePillar('RIDE_WORK', 'new-ride');
        break;
      case 'PROTECT':
        onNavigatePillar('SAFETY_FATIGUE', 'fatigue');
        break;
      case 'OPTIMIZE':
        onNavigatePillar('SMART_MAP', 'traffic');
        break;
      case 'MANAGE':
        onNavigatePillar('VEHICLE_INTEL', 'maintenance');
        break;
      case 'GROW':
        onNavigatePillar('INCENTIVES', 'daily-targets');
        break;
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-md overflow-y-auto animate-fadeIn">
      <div className="relative w-full max-w-5xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col my-auto max-h-[92vh]">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/80">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400 shadow-inner">
              <Cpu className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-black tracking-wider text-white uppercase">DRIVEROS CORE ARCHITECTURE</h2>
                <span className="px-2 py-0.5 text-[10px] font-bold rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                  SYSTEM ENGINE PIPELINE
                </span>
              </div>
              <p className="text-xs text-slate-400">
                End-to-end data flow: 3 Feeder Engines ➔ Opportunity Engine ➔ Saathi Intelligence ➔ Driver Actions
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <span className="hidden sm:inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-800 border border-slate-700 text-xs font-mono text-emerald-400">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              Real-time Pipeline: ACTIVE
            </span>
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 border border-transparent hover:border-slate-700 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Body: The Interactive Flowchart */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-6">

          {/* LEVEL 1: DRIVEROS CORE */}
          <div className="flex flex-col items-center">
            <div 
              onClick={() => setSelectedNode('DRIVEROS_CORE')}
              className={`w-full max-w-md p-4 rounded-xl border text-center transition-all cursor-pointer select-none shadow-lg ${
                selectedNode === 'DRIVEROS_CORE'
                  ? 'bg-gradient-to-r from-emerald-950/70 via-slate-900 to-emerald-950/70 border-emerald-400 ring-2 ring-emerald-500/20 shadow-emerald-950/50'
                  : 'bg-slate-950/80 border-slate-800 hover:border-emerald-500/50'
              }`}
            >
              <div className="flex items-center justify-center gap-2 text-emerald-400 mb-1">
                <Cpu className="w-4 h-4" />
                <span className="text-xs font-mono tracking-widest uppercase font-bold">Orchestration Kernel</span>
              </div>
              <h3 className="text-base font-black text-white tracking-wide">DRIVEROS CORE</h3>
              <p className="text-xs text-slate-400 mt-1">
                Unified dispatch state machine • Edge telemetry bus • Sovereign zero-commission protocol
              </p>
              <div className="flex items-center justify-center gap-2 mt-2 pt-2 border-t border-slate-800/80 text-[11px] font-mono text-slate-400">
                <span>Duty: <strong className={isOnDuty ? 'text-emerald-400' : 'text-amber-400'}>{isOnDuty ? '🟢 ONLINE' : '⏸️ OFF-DUTY'}</strong></span>
                <span>•</span>
                <span>Active Ride: <strong className="text-white">{activeRide ? activeRide.status.toUpperCase() : 'STANDBY'}</strong></span>
                <span>•</span>
                <span>Latency: <strong className="text-emerald-400 font-mono">24ms</strong></span>
              </div>
            </div>

            {/* Central Connector Down */}
            <div className="flex flex-col items-center my-2">
              <div className="w-0.5 h-6 bg-gradient-to-b from-emerald-400 to-slate-700" />
              <div className="w-3 h-3 rotate-45 border-b-2 border-r-2 border-emerald-400 -mt-1.5" />
            </div>
          </div>

          {/* LEVEL 2: THE 3 FOUNDATIONAL FEEDER ENGINES */}
          <div>
            <div className="text-center mb-3">
              <span className="text-[11px] font-mono uppercase tracking-widest text-slate-500">
                THREE FOUNDATIONAL SENSING &amp; CALCULATION ENGINES
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              
              {/* 1. RIDE ENGINE */}
              <div 
                onClick={() => setSelectedNode('RIDE_ENGINE')}
                className={`p-4 rounded-xl border transition-all cursor-pointer flex flex-col justify-between ${
                  selectedNode === 'RIDE_ENGINE'
                    ? 'bg-slate-900 border-emerald-400 ring-2 ring-emerald-500/20 shadow-lg'
                    : 'bg-slate-950/70 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-lg bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                        <Car className="w-4 h-4" />
                      </div>
                      <div>
                        <h4 className="text-sm font-black text-white">RIDE ENGINE</h4>
                        <span className="text-[10px] text-emerald-400 font-mono">Dispatch &amp; Trip State</span>
                      </div>
                    </div>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 font-mono">
                      LIVE
                    </span>
                  </div>
                  
                  <ul className="text-xs text-slate-300 space-y-1.5 my-3">
                    <li className="flex items-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                      <span>Direct Sovereign Customer Dispatch</span>
                    </li>
                    <li className="flex items-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                      <span>15s Accept / Reject Countdown Timer</span>
                    </li>
                    <li className="flex items-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                      <span>Real-time Distance &amp; Meter Lifecycle</span>
                    </li>
                  </ul>
                </div>

                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onClose();
                    onNavigatePillar('RIDE_WORK', 'new-ride');
                  }}
                  className="w-full mt-2 py-1.5 px-3 rounded-lg bg-slate-800 hover:bg-emerald-600 text-slate-200 hover:text-white text-xs font-bold transition-all flex items-center justify-center gap-1.5"
                >
                  <span>Open Ride Command</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* 2. ECONOMICS ENGINE */}
              <div 
                onClick={() => setSelectedNode('ECONOMICS_ENGINE')}
                className={`p-4 rounded-xl border transition-all cursor-pointer flex flex-col justify-between ${
                  selectedNode === 'ECONOMICS_ENGINE'
                    ? 'bg-slate-900 border-emerald-400 ring-2 ring-emerald-500/20 shadow-lg'
                    : 'bg-slate-950/70 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-lg bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                        <DollarSign className="w-4 h-4" />
                      </div>
                      <div>
                        <h4 className="text-sm font-black text-white">ECONOMICS ENGINE</h4>
                        <span className="text-[10px] text-emerald-400 font-mono">Fare / Fuel / Toll / Comm.</span>
                      </div>
                    </div>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 font-mono">
                      ₹ NET PROFIT
                    </span>
                  </div>
                  
                  <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800/80 my-2 text-[11px] font-mono space-y-1">
                    <div className="flex justify-between text-slate-400">
                      <span>Fare Breakdown:</span>
                      <span className="text-white font-bold">Gross Fare</span>
                    </div>
                    <div className="flex justify-between text-red-400">
                      <span>Deductions:</span>
                      <span>-Fuel • -FASTag Tolls</span>
                    </div>
                    <div className="flex justify-between text-teal-400">
                      <span>Commission:</span>
                      <span>0% (Saves ₹710/day)</span>
                    </div>
                    <div className="flex justify-between text-emerald-400 font-bold border-t border-slate-800 pt-1">
                      <span>True Net:</span>
                      <span>₹23.3/KM Velocity</span>
                    </div>
                  </div>
                </div>

                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onClose();
                    onNavigatePillar('MONEY', 'today-earnings');
                  }}
                  className="w-full mt-2 py-1.5 px-3 rounded-lg bg-slate-800 hover:bg-emerald-600 text-slate-200 hover:text-white text-xs font-bold transition-all flex items-center justify-center gap-1.5"
                >
                  <span>Open Financial OS</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* 3. MOBILITY ENGINE */}
              <div 
                onClick={() => setSelectedNode('MOBILITY_ENGINE')}
                className={`p-4 rounded-xl border transition-all cursor-pointer flex flex-col justify-between ${
                  selectedNode === 'MOBILITY_ENGINE'
                    ? 'bg-slate-900 border-emerald-400 ring-2 ring-emerald-500/20 shadow-lg'
                    : 'bg-slate-950/70 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-lg bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                        <Navigation className="w-4 h-4" />
                      </div>
                      <div>
                        <h4 className="text-sm font-black text-white">MOBILITY ENGINE</h4>
                        <span className="text-[10px] text-emerald-400 font-mono">GPS / Traffic / Fleet</span>
                      </div>
                    </div>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 font-mono">
                      TELEMETRY
                    </span>
                  </div>
                  
                  <ul className="text-xs text-slate-300 space-y-1.5 my-3">
                    <li className="flex items-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                      <span>Live Moving Fleet Telemetry (24ms)</span>
                    </li>
                    <li className="flex items-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                      <span>Surge Demand Heatmap (1.8x – 2.3x)</span>
                    </li>
                    <li className="flex items-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                      <span>Verified CNG / EV Charger Availability</span>
                    </li>
                  </ul>
                </div>

                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onClose();
                    onNavigatePillar('SMART_MAP', 'moving-car');
                  }}
                  className="w-full mt-2 py-1.5 px-3 rounded-lg bg-slate-800 hover:bg-emerald-600 text-slate-200 hover:text-white text-xs font-bold transition-all flex items-center justify-center gap-1.5"
                >
                  <span>Open Smart Mobility Map</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>

            </div>

            {/* Downward Funnel Connectors */}
            <div className="flex justify-center items-center my-3">
              <div className="flex flex-col items-center">
                <div className="text-[10px] font-mono text-slate-500 uppercase tracking-widest">
                  SYNTHESIS &amp; RANKING
                </div>
                <div className="w-0.5 h-5 bg-emerald-500" />
                <div className="w-3 h-3 rotate-45 border-b-2 border-r-2 border-emerald-400 -mt-1.5" />
              </div>
            </div>
          </div>

          {/* LEVEL 3: OPPORTUNITY ENGINE */}
          <div className="flex flex-col items-center">
            <div 
              onClick={() => setSelectedNode('OPPORTUNITY_ENGINE')}
              className={`w-full max-w-lg p-4 rounded-xl border text-center transition-all cursor-pointer shadow-lg ${
                selectedNode === 'OPPORTUNITY_ENGINE'
                  ? 'bg-slate-900 border-amber-400 ring-2 ring-amber-500/20'
                  : 'bg-slate-950/80 border-slate-800 hover:border-amber-500/50'
              }`}
            >
              <div className="flex items-center justify-center gap-2 text-amber-400 mb-1">
                <Target className="w-4 h-4" />
                <span className="text-xs font-mono uppercase font-bold tracking-wider">Arbitrage &amp; Matching Engine</span>
              </div>
              <h3 className="text-base font-black text-white tracking-wide">OPPORTUNITY ENGINE</h3>
              <p className="text-xs text-slate-400 mt-1">
                Matches driver location, fuel tank, and shift target against city flight waves &amp; tech corridor surges.
              </p>
              <div className="mt-2.5 inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-xs font-medium text-amber-300">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Current Recommended Corridor: <strong>Airport NH44 (Net +₹540)</strong></span>
              </div>
            </div>

            {/* Central Connector Down */}
            <div className="flex flex-col items-center my-2">
              <div className="w-0.5 h-5 bg-gradient-to-b from-amber-400 to-emerald-400" />
              <div className="w-3 h-3 rotate-45 border-b-2 border-r-2 border-emerald-400 -mt-1.5" />
            </div>
          </div>

          {/* LEVEL 4: 🧠 SAATHI ENGINE (3 VECTORS: INSIGHT / OPPORTUNITY / ALERT) */}
          <div className="bg-slate-950/90 border border-emerald-500/40 rounded-2xl p-5 shadow-xl relative overflow-hidden">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4 pb-3 border-b border-slate-800">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
                  <Brain className="w-5 h-5 animate-pulse" />
                </div>
                <div>
                  <h3 className="text-base font-black text-white flex items-center gap-2">
                    <span>🧠 SAATHI ENGINE</span>
                    <span className="text-xs font-normal text-emerald-400 font-mono">(Intelligence Triad)</span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    Tri-vector driver advisory system: Insight, Opportunity, and Proactive Safety Alerts
                  </p>
                </div>
              </div>

              {/* 3 Vector Selector Tabs */}
              <div className="flex items-center gap-1.5 bg-slate-900 p-1 rounded-xl border border-slate-800">
                <button
                  onClick={() => setSaathiTab('INSIGHT')}
                  className={`px-3 py-1 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                    saathiTab === 'INSIGHT'
                      ? 'bg-blue-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Lightbulb className="w-3.5 h-3.5" />
                  <span>INSIGHT</span>
                </button>
                <button
                  onClick={() => setSaathiTab('OPPORTUNITY')}
                  className={`px-3 py-1 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                    saathiTab === 'OPPORTUNITY'
                      ? 'bg-emerald-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Target className="w-3.5 h-3.5" />
                  <span>OPPORTUNITY</span>
                </button>
                <button
                  onClick={() => setSaathiTab('ALERT')}
                  className={`px-3 py-1 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                    saathiTab === 'ALERT'
                      ? 'bg-amber-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span>ALERT</span>
                </button>
              </div>
            </div>

            {/* Tri-Vector Content Display */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              
              {/* VECTOR 1: INSIGHT */}
              <div className={`p-3.5 rounded-xl border transition-all ${
                saathiTab === 'INSIGHT'
                  ? 'bg-blue-950/40 border-blue-500/50 ring-1 ring-blue-500/30'
                  : 'bg-slate-900/60 border-slate-800'
              }`}>
                <div className="flex items-center gap-2 text-blue-400 text-xs font-bold uppercase mb-1.5">
                  <Lightbulb className="w-4 h-4" />
                  <span>1. INSIGHT (MARKET CONTEXT)</span>
                </div>
                <p className="text-xs text-slate-200 leading-relaxed font-medium">
                  "Bengaluru Airport Terminal 2 is receiving 14 incoming flights between 10:30 AM and 11:45 AM. NH44 Elevated toll ₹115 delivers +₹380 profit vs slow service road."
                </p>
                <div className="mt-2 text-[10px] text-blue-300 font-mono">
                  Confidence: 94% • Source: Flight Wave Radar
                </div>
              </div>

              {/* VECTOR 2: OPPORTUNITY */}
              <div className={`p-3.5 rounded-xl border transition-all ${
                saathiTab === 'OPPORTUNITY'
                  ? 'bg-emerald-950/40 border-emerald-500/50 ring-1 ring-emerald-500/30'
                  : 'bg-slate-900/60 border-slate-800'
              }`}>
                <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold uppercase mb-1.5">
                  <Target className="w-4 h-4" />
                  <span>2. OPPORTUNITY (ARBITRAGE)</span>
                </div>
                <p className="text-xs text-slate-200 leading-relaxed font-medium">
                  "Accept Indiranagar ➔ Whitefield booking. Return corridor tech surge is 1.9x active until 1:00 PM, saving 12 km of deadhead mileage."
                </p>
                <div className="mt-2 text-[10px] text-emerald-300 font-mono">
                  Net Yield: ₹540 • Deadhead: 1.2 KM
                </div>
              </div>

              {/* VECTOR 3: ALERT */}
              <div className={`p-3.5 rounded-xl border transition-all ${
                saathiTab === 'ALERT'
                  ? 'bg-amber-950/40 border-amber-500/50 ring-1 ring-amber-500/30'
                  : 'bg-slate-900/60 border-slate-800'
              }`}>
                <div className="flex items-center gap-2 text-amber-400 text-xs font-bold uppercase mb-1.5">
                  <AlertTriangle className="w-4 h-4" />
                  <span>3. ALERT (SAFETY &amp; ASSET)</span>
                </div>
                <p className="text-xs text-slate-200 leading-relaxed font-medium">
                  "Continuous driving at 3h 48m. Chai break recommended in 12 min at Shell Domlur rest hub. Micro-insurance ₹5 Lakh fully active."
                </p>
                <div className="mt-2 text-[10px] text-amber-300 font-mono">
                  Fatigue Level: Moderate • Rest Hub: 1.4 km
                </div>
              </div>

            </div>

            {/* Central Connector Down to Driver Action */}
            <div className="flex justify-center items-center mt-4">
              <div className="flex flex-col items-center">
                <div className="text-[10px] font-mono text-emerald-400 uppercase tracking-widest font-bold">
                  TRANSLATES DIRECTLY INTO DRIVER ACTION
                </div>
                <div className="w-0.5 h-4 bg-emerald-400" />
                <div className="w-3 h-3 rotate-45 border-b-2 border-r-2 border-emerald-400 -mt-1" />
              </div>
            </div>
          </div>

          {/* LEVEL 5: DRIVER ACTION (5 PILLARS: EARN, PROTECT, OPTIMIZE, MANAGE, GROW) */}
          <div>
            <div className="text-center mb-3">
              <span className="text-[11px] font-mono uppercase tracking-widest text-slate-400 font-bold">
                DRIVER ACTION EXECUTION LAYER (5 STRATEGIC OUTCOMES)
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
              
              {/* 1. EARN */}
              <button
                onClick={() => handleActionClick('EARN')}
                className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 hover:border-emerald-500/80 hover:bg-emerald-950/30 transition-all text-left group flex flex-col justify-between"
              >
                <div>
                  <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
                    <DollarSign className="w-4 h-4" />
                  </div>
                  <div className="text-xs font-black text-white uppercase tracking-wider group-hover:text-emerald-300">
                    EARN
                  </div>
                  <div className="text-[11px] text-slate-400 mt-1">
                    Direct dispatches, instant UPI collection, 0% commission.
                  </div>
                </div>
                <span className="mt-2 text-[10px] font-bold text-emerald-400 flex items-center gap-1">
                  <span>Open Ride</span>
                  <ChevronRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
                </span>
              </button>

              {/* 2. PROTECT */}
              <button
                onClick={() => handleActionClick('PROTECT')}
                className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 hover:border-blue-500/80 hover:bg-blue-950/30 transition-all text-left group flex flex-col justify-between"
              >
                <div>
                  <div className="w-8 h-8 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
                    <ShieldCheck className="w-4 h-4" />
                  </div>
                  <div className="text-xs font-black text-white uppercase tracking-wider group-hover:text-blue-300">
                    PROTECT
                  </div>
                  <div className="text-[11px] text-slate-400 mt-1">
                    1-Tap SOS, fatigue monitor, ₹5 Lakh accident cover.
                  </div>
                </div>
                <span className="mt-2 text-[10px] font-bold text-blue-400 flex items-center gap-1">
                  <span>Safety Hub</span>
                  <ChevronRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
                </span>
              </button>

              {/* 3. OPTIMIZE */}
              <button
                onClick={() => handleActionClick('OPTIMIZE')}
                className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 hover:border-purple-500/80 hover:bg-purple-950/30 transition-all text-left group flex flex-col justify-between"
              >
                <div>
                  <div className="w-8 h-8 rounded-lg bg-purple-500/20 text-purple-400 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
                    <Navigation className="w-4 h-4" />
                  </div>
                  <div className="text-xs font-black text-white uppercase tracking-wider group-hover:text-purple-300">
                    OPTIMIZE
                  </div>
                  <div className="text-[11px] text-slate-400 mt-1">
                    Eliminate deadhead KM, low-toll routing, CNG stations.
                  </div>
                </div>
                <span className="mt-2 text-[10px] font-bold text-purple-400 flex items-center gap-1">
                  <span>Smart Map</span>
                  <ChevronRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
                </span>
              </button>

              {/* 4. MANAGE */}
              <button
                onClick={() => handleActionClick('MANAGE')}
                className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 hover:border-amber-500/80 hover:bg-amber-950/30 transition-all text-left group flex flex-col justify-between"
              >
                <div>
                  <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
                    <Wrench className="w-4 h-4" />
                  </div>
                  <div className="text-xs font-black text-white uppercase tracking-wider group-hover:text-amber-300">
                    MANAGE
                  </div>
                  <div className="text-[11px] text-slate-400 mt-1">
                    Vehicle health 94/100, PUC/Insurance, Section 44AD bills.
                  </div>
                </div>
                <span className="mt-2 text-[10px] font-bold text-amber-400 flex items-center gap-1">
                  <span>Vehicle &amp; Bills</span>
                  <ChevronRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
                </span>
              </button>

              {/* 5. GROW */}
              <button
                onClick={() => handleActionClick('GROW')}
                className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 hover:border-teal-500/80 hover:bg-teal-950/30 transition-all text-left group flex flex-col justify-between col-span-2 sm:col-span-1"
              >
                <div>
                  <div className="w-8 h-8 rounded-lg bg-teal-500/20 text-teal-400 flex items-center justify-center mb-2 group-hover:scale-110 transition-transform">
                    <Award className="w-4 h-4" />
                  </div>
                  <div className="text-xs font-black text-white uppercase tracking-wider group-hover:text-teal-300">
                    GROW
                  </div>
                  <div className="text-[11px] text-slate-400 mt-1">
                    Trip streaks, tier bonuses, driver credit profile.
                  </div>
                </div>
                <span className="mt-2 text-[10px] font-bold text-teal-400 flex items-center gap-1">
                  <span>Incentives</span>
                  <ChevronRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
                </span>
              </button>

            </div>
          </div>

        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-800 bg-slate-950 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <span className="font-mono text-emerald-400 font-bold">DRIVEROS ARCHITECTURE:</span>
            <span>Real-time closed-loop decision system. Every module is live and connected.</span>
          </div>
          <button
            onClick={onClose}
            className="w-full sm:w-auto px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold transition-colors"
          >
            Close Diagram
          </button>
        </div>

      </div>
    </div>
  );
};
