import React, { useState, useEffect } from 'react';
import { 
  AlertTriangle, 
  CheckCircle2, 
  X, 
  Navigation, 
  Car, 
  MapPin, 
  Phone, 
  MessageSquare, 
  DollarSign, 
  Download, 
  Share2, 
  QrCode, 
  Copy, 
  ShieldCheck, 
  ArrowRight,
  Clock,
  Fuel,
  Volume2,
  VolumeX,
  Sparkles,
  ExternalLink,
  ChevronRight,
  TrendingUp,
  RefreshCw
} from 'lucide-react';
import { RideBooking, DriverProfile, RideBookingStatus } from '../types';
import { rideBookingService } from '../services/rideBookingService';
import { exportCustomerReceiptPDF, CustomerReceiptData } from '../utils/exportUtils';

interface DriverOSBookingFlowModalProps {
  driver: DriverProfile;
  activeRide: RideBooking | null;
  isOpen: boolean;
  onClose: () => void;
  onRideUpdated: (ride: RideBooking) => void;
  onAddTripToLedger?: (tripData: any) => void;
}

export const DriverOSBookingFlowModal: React.FC<DriverOSBookingFlowModalProps> = ({
  driver,
  activeRide,
  isOpen,
  onClose,
  onRideUpdated,
  onAddTripToLedger,
}) => {
  // Countdown timer for 🚨 NEW RIDE REQUEST
  const [countdown, setCountdown] = useState<number>(15);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [otpInput, setOtpInput] = useState<string>('');
  const [otpError, setOtpError] = useState<string | null>(null);

  // Meter simulation state for 🚕 RIDE STARTED
  const [meterKm, setMeterKm] = useState<number>(0);
  const [meterMinutes, setMeterMinutes] = useState<number>(0);
  const [meterFare, setMeterFare] = useState<number>(80);

  // Payment state for 💳 PAYMENT / BILL
  const [paymentMode, setPaymentMode] = useState<'UPI' | 'CASH' | 'CARD'>('UPI');
  const [cashTendered, setCashTendered] = useState<number | ''>(1000);
  const [copiedUpi, setCopiedUpi] = useState<boolean>(false);
  const [isProcessingPayment, setIsProcessingPayment] = useState<boolean>(false);
  const [tipAmount, setTipAmount] = useState<number>(0);

  // Default ride fallback if null (Airport to Whitefield, 28 km, ₹650)
  const currentRide: RideBooking = activeRide || {
    id: 'RIDE-BLR-2849',
    createdAt: new Date().toISOString(),
    pickup: 'Airport',
    destination: 'Whitefield',
    distanceKm: 28,
    estimatedDurationMin: 45,
    fareEstimate: 650,
    rideType: 'Mini',
    customerName: 'Ananya Sharma',
    customerPhone: '+91 98450 19283',
    status: 'searching',
    otp: '4821',
    driver: {
      name: driver.name,
      phone: driver.phone,
      vehiclePlate: driver.vehiclePlate,
      vehicleModel: driver.vehicleModel,
      rating: driver.rating,
      currentLocation: { lat: 13.1986, lng: 77.7066 },
    },
    breakdown: {
      baseFare: 80,
      distanceFare: 430,
      tollCost: 115,
      platformTaxGst: 25,
      driverEstimatedEarning: 650,
    },
  };

  const status = currentRide.status;

  // Countdown tick during 'searching' / 'pending'
  useEffect(() => {
    if (status !== 'searching' && status !== 'pending') return;
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          return 15; // Loop for simulator friendliness
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [status]);

  // Live Meter tick during 'started'
  useEffect(() => {
    if (status !== 'started') return;
    const interval = setInterval(() => {
      setMeterKm((prev) => {
        const next = Number((prev + 0.3).toFixed(1));
        return next > currentRide.distanceKm ? currentRide.distanceKm : next;
      });
      setMeterMinutes((prev) => prev + 1);
      setMeterFare((prev) => Math.min(currentRide.fareEstimate, prev + 12));
    }, 1200);
    return () => clearInterval(interval);
  }, [status, currentRide.distanceKm, currentRide.fareEstimate]);

  // Actions
  // 1. [ ACCEPT ]
  const handleAccept = async () => {
    try {
      const res = await rideBookingService.acceptRide(currentRide.id);
      if (res.success && res.ride) {
        onRideUpdated(res.ride);
      }
    } catch (err) {
      console.warn('Accept error:', err);
    }
  };

  // 2. [ DECLINE ]
  const handleDecline = async () => {
    try {
      await rideBookingService.declineRide(currentRide.id);
      onClose();
    } catch (err) {
      onClose();
    }
  };

  // 3. Arrived at pickup
  const handleArrivedAtPickup = async () => {
    const res = await rideBookingService.updateStatus(currentRide.id, 'arriving');
    if (res.success && res.ride) {
      onRideUpdated(res.ride);
    }
  };

  // 4. Verify OTP & Start Ride -> 'started'
  const handleStartRide = async () => {
    if (otpInput && otpInput !== currentRide.otp && otpInput !== '4821') {
      setOtpError('Invalid OTP! Please enter passenger PIN (4821)');
      return;
    }
    setOtpError(null);
    const res = await rideBookingService.updateStatus(currentRide.id, 'started');
    if (res.success && res.ride) {
      onRideUpdated(res.ride);
      setMeterKm(0.1);
      setMeterMinutes(1);
      setMeterFare(80);
    }
  };

  // 5. Complete Ride -> 'completed'
  const handleCompleteRide = async () => {
    const res = await rideBookingService.updateStatus(currentRide.id, 'completed');
    if (res.success && res.ride) {
      onRideUpdated(res.ride);
    }
  };

  // 6. Settle Payment -> 'paid'
  const handleSettlePayment = async () => {
    setIsProcessingPayment(true);
    try {
      const finalAmount = currentRide.fareEstimate + tipAmount;
      const res = await rideBookingService.processPayment(currentRide.id, {
        mode: paymentMode,
        amount: finalAmount,
        tip: tipAmount,
        transactionRef: `UPI-TXN-${Date.now().toString().slice(-6)}`,
      });

      if (res.success && res.ride) {
        onRideUpdated(res.ride);
        if (onAddTripToLedger) {
          onAddTripToLedger({
            platform: 'DIRECT_CLIENT',
            pickupLocation: currentRide.pickup,
            dropoffLocation: currentRide.destination,
            distanceKm: currentRide.distanceKm,
            durationMinutes: currentRide.estimatedDurationMin,
            grossFare: finalAmount,
            platformCommission: 0,
            fuelCost: 110,
            tollCost: 115,
            tips: tipAmount,
            netProfit: finalAmount - 110,
            deadheadKm: 2,
            passengerName: currentRide.customerName,
            paymentMode,
          });
        }
      }
    } catch (err) {
      console.warn('Payment settlement error:', err);
    } finally {
      setIsProcessingPayment(false);
    }
  };

  // 7. Download PDF Receipt
  const handleDownloadPDF = () => {
    const receiptData: CustomerReceiptData = {
      receiptNumber: currentRide.payment?.invoiceNumber || `INV-${new Date().getFullYear()}-4821`,
      date: currentRide.payment?.paidAt || new Date().toISOString(),
      customerName: currentRide.customerName,
      customerPhone: currentRide.customerPhone,
      pickupLocation: currentRide.pickup,
      dropoffLocation: currentRide.destination,
      distanceKm: currentRide.distanceKm,
      durationMinutes: currentRide.estimatedDurationMin,
      driver: driver,
      baseFare: currentRide.breakdown.baseFare,
      distanceFare: currentRide.breakdown.distanceFare,
      tollCost: currentRide.breakdown.tollCost,
      waitingOrSurgeFare: 0,
      discount: 0,
      totalPaid: (currentRide.payment?.amount || currentRide.fareEstimate) + tipAmount,
      paymentMode: currentRide.payment?.mode || paymentMode,
      paymentReference: currentRide.payment?.transactionRef || 'TXN-UPI-8492019',
      notes: 'DriverOS Sovereign Direct Dispatch • 0% Commission • Section 44AD / GST Compliant',
    };

    exportCustomerReceiptPDF(receiptData);
  };

  const handleCopyUpi = () => {
    navigator.clipboard.writeText('9318320977@okaxis');
    setCopiedUpi(true);
    setTimeout(() => setCopiedUpi(false), 2000);
  };

  // Calculations for Financial Card
  const grossFare = currentRide.fareEstimate;
  const estimatedFuel = 110;
  const netEarnings = grossFare - estimatedFuel;
  const profitPerKm = (netEarnings / currentRide.distanceKm).toFixed(1);

  if (!isOpen && !activeRide) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-750 rounded-3xl w-full max-w-xl shadow-2xl overflow-hidden text-white my-auto">
        
        {/* Modal Top Header with Status Pill */}
        <div className="bg-slate-950 px-5 py-3.5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-xs font-black tracking-wider text-white uppercase">
              DRIVEROS • BOOKING FLOW ENGINE
            </span>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-[11px] font-mono px-2.5 py-1 rounded-md bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 uppercase font-bold">
              {status}
            </span>
            <button
              onClick={onClose}
              className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="p-5 sm:p-6 space-y-5">
          
          {/* ================================================================= */}
          {/* STEP 1: 🚨 NEW RIDE REQUEST (Searching / Pending State)            */}
          {/* Matches ASCII:                                                    */}
          {/* Pickup: Airport                                                   */}
          {/* Destination: Whitefield                                           */}
          {/* Distance: 28 km                                                   */}
          {/* Estimated earning: ₹650                                           */}
          {/* [ ACCEPT ]   [ DECLINE ]                                          */}
          {/* ================================================================= */}
          {(status === 'searching' || status === 'pending') && (
            <div className="space-y-5 animate-in zoom-in-95 duration-200">
              
              {/* Alert Banner & Countdown Ring */}
              <div className="bg-gradient-to-r from-amber-500/20 via-rose-500/20 to-amber-500/20 border border-amber-500/40 rounded-2xl p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-2xl animate-bounce">
                    🚨
                  </div>
                  <div>
                    <h2 className="text-base font-black text-amber-300 uppercase tracking-wide">
                      NEW RIDE REQUEST
                    </h2>
                    <p className="text-xs text-slate-300">
                      Customer App Direct Booking • Zero Commission
                    </p>
                  </div>
                </div>

                <div className="flex flex-col items-center">
                  <div className="w-11 h-11 rounded-full border-3 border-amber-400/30 border-t-amber-400 flex items-center justify-center text-sm font-black text-amber-300 font-mono">
                    {countdown}s
                  </div>
                  <span className="text-[9px] text-slate-400 mt-0.5">AUTO-PASS</span>
                </div>
              </div>

              {/* Exact Requested Fields Card */}
              <div className="bg-slate-950 border border-slate-800 rounded-2xl p-5 space-y-4 shadow-inner">
                
                <div className="space-y-3">
                  {/* Pickup */}
                  <div className="flex items-start gap-3">
                    <div className="mt-1 w-3.5 h-3.5 rounded-full bg-emerald-400 ring-4 ring-emerald-400/20 shrink-0" />
                    <div>
                      <div className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">Pickup</div>
                      <div className="text-base font-bold text-white">{currentRide.pickup}</div>
                      <div className="text-[11px] text-slate-400">Terminal 2 • Commercial Departure Bay A-3</div>
                    </div>
                  </div>

                  <div className="w-0.5 h-4 bg-slate-800 ml-1.5" />

                  {/* Destination */}
                  <div className="flex items-start gap-3">
                    <div className="mt-1 w-3.5 h-3.5 rounded-full bg-rose-400 ring-4 ring-rose-400/20 shrink-0" />
                    <div>
                      <div className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">Destination</div>
                      <div className="text-base font-bold text-white">{currentRide.destination}</div>
                      <div className="text-[11px] text-slate-400">ITPB Tech Park • Main Gate Boulevard</div>
                    </div>
                  </div>
                </div>

                {/* Distance & Earning Big Telemetry */}
                <div className="grid grid-cols-2 gap-3 pt-3 border-t border-slate-800">
                  <div className="bg-slate-900 p-3 rounded-xl border border-slate-800">
                    <div className="text-[10px] text-slate-400 uppercase font-bold">Distance</div>
                    <div className="text-xl font-black text-white font-mono mt-0.5">
                      {currentRide.distanceKm} km
                    </div>
                    <div className="text-[10px] text-slate-400">~{currentRide.estimatedDurationMin} mins travel</div>
                  </div>

                  <div className="bg-emerald-950/40 p-3 rounded-xl border border-emerald-500/40">
                    <div className="text-[10px] text-emerald-400 uppercase font-bold">Estimated Earning</div>
                    <div className="text-2xl font-black text-emerald-300 font-mono mt-0.5">
                      ₹{currentRide.fareEstimate}
                    </div>
                    <div className="text-[10px] text-emerald-400/80">100% In-Pocket Direct</div>
                  </div>
                </div>

                {/* Chauffeur Profit Intelligence */}
                <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800 text-xs space-y-1.5">
                  <div className="flex justify-between text-slate-300">
                    <span>CNG Fuel Estimate:</span>
                    <span className="font-mono text-rose-300">-₹{estimatedFuel}</span>
                  </div>
                  <div className="flex justify-between text-slate-300">
                    <span>Platform Commission:</span>
                    <span className="font-mono text-emerald-400 font-bold">₹0 (0% Ola/Uber cut)</span>
                  </div>
                  <div className="flex justify-between text-white font-bold border-t border-slate-800 pt-1">
                    <span>Net Profit Velocity:</span>
                    <span className="font-mono text-emerald-300">₹{netEarnings} (₹{profitPerKm}/km)</span>
                  </div>
                </div>

                {/* Passenger details */}
                <div className="flex items-center justify-between text-xs text-slate-400 pt-1">
                  <span>Passenger: <strong className="text-white">{currentRide.customerName}</strong></span>
                  <span>Direct Customer (4.98 ★)</span>
                </div>
              </div>

              {/* Exact Actions: [ ACCEPT ] [ DECLINE ] */}
              <div className="grid grid-cols-2 gap-3 pt-1">
                <button
                  id="driveros-decline-ride-btn"
                  onClick={handleDecline}
                  className="py-3.5 px-4 bg-slate-800 hover:bg-slate-750 text-rose-300 border border-slate-700 rounded-2xl font-bold text-sm uppercase tracking-wider transition active:scale-[0.98] flex items-center justify-center gap-2"
                >
                  <X className="w-4 h-4" />
                  <span>DECLINE</span>
                </button>

                <button
                  id="driveros-accept-ride-btn"
                  onClick={handleAccept}
                  className="py-3.5 px-4 bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 rounded-2xl font-black text-sm uppercase tracking-wider transition shadow-lg shadow-emerald-500/25 active:scale-[0.98] flex items-center justify-center gap-2"
                >
                  <CheckCircle2 className="w-5 h-5" />
                  <span>ACCEPT</span>
                </button>
              </div>

            </div>
          )}

          {/* ================================================================= */}
          {/* STEP 2: 🟢 DRIVER ACCEPTED (Banner & Transition)                  */}
          {/* ================================================================= */}
          {status === 'accepted' && (
            <div className="space-y-5 animate-in zoom-in-95 duration-200">
              
              <div className="bg-emerald-500/15 border border-emerald-500/40 rounded-2xl p-4 flex items-center gap-3.5">
                <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-500/50 flex items-center justify-center text-2xl text-emerald-400">
                  🟢
                </div>
                <div className="flex-1">
                  <h2 className="text-base font-black text-emerald-300 uppercase tracking-wide">
                    DRIVER ACCEPTED
                  </h2>
                  <p className="text-xs text-slate-300">
                    Ride assigned to Ramesh Kumar (KA-05-AB-9821). Navigating to pickup.
                  </p>
                </div>
              </div>

              {/* Navigation Card */}
              <div className="bg-slate-950 border border-slate-800 rounded-2xl p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Navigation className="w-4 h-4 text-emerald-400 animate-pulse" />
                    <span className="text-xs font-bold text-white uppercase tracking-wider">Pickup Navigation</span>
                  </div>
                  <span className="text-xs font-mono text-emerald-400 font-bold">ETA: 3 mins (1.2 km)</span>
                </div>

                <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 flex items-center gap-3">
                  <div className="text-xl">📍</div>
                  <div>
                    <div className="text-xs font-bold text-white">Airport Terminal 2 • Pickup Bay A-3</div>
                    <div className="text-[11px] text-slate-400">Head straight on Ballari Road Airport Expressway</div>
                  </div>
                </div>

                {/* Passenger Contact & OTP */}
                <div className="grid grid-cols-2 gap-3 pt-1">
                  <div className="bg-slate-900 p-3 rounded-xl border border-slate-800">
                    <div className="text-[10px] text-slate-400 uppercase font-semibold">Passenger</div>
                    <div className="text-sm font-bold text-white">{currentRide.customerName}</div>
                    <div className="text-xs text-emerald-400">{currentRide.customerPhone}</div>
                  </div>

                  <div className="bg-slate-900 p-3 rounded-xl border border-slate-800">
                    <div className="text-[10px] text-slate-400 uppercase font-semibold">Start Ride PIN</div>
                    <div className="text-lg font-black text-amber-400 font-mono tracking-widest">
                      {currentRide.otp || '4821'}
                    </div>
                    <div className="text-[10px] text-slate-400">Ask passenger on arrival</div>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={handleArrivedAtPickup}
                  className="py-3 px-4 bg-slate-800 hover:bg-slate-750 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-2"
                >
                  <MapPin className="w-4 h-4 text-amber-400" />
                  <span>ARRIVED AT PICKUP</span>
                </button>

                <button
                  onClick={() => {
                    const res = rideBookingService.updateStatus(currentRide.id, 'arriving');
                    onRideUpdated({ ...currentRide, status: 'arriving' });
                  }}
                  className="py-3 px-4 bg-emerald-500 hover:bg-emerald-400 text-slate-950 rounded-xl text-xs font-black transition flex items-center justify-center gap-2"
                >
                  <span>PROCEED TO TRACKING</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>

            </div>
          )}

          {/* ================================================================= */}
          {/* STEP 3: 📍 LIVE TRACKING & OTP VERIFICATION                       */}
          {/* ================================================================= */}
          {status === 'arriving' && (
            <div className="space-y-5 animate-in zoom-in-95 duration-200">
              
              <div className="bg-indigo-500/15 border border-indigo-500/40 rounded-2xl p-4 flex items-center gap-3.5">
                <div className="w-12 h-12 rounded-2xl bg-indigo-500/20 border border-indigo-500/50 flex items-center justify-center text-2xl text-indigo-400 animate-pulse">
                  📍
                </div>
                <div className="flex-1">
                  <h2 className="text-base font-black text-indigo-300 uppercase tracking-wide">
                    LIVE TRACKING & BOARDING
                  </h2>
                  <p className="text-xs text-slate-300">
                    At Airport Terminal 2. Verify passenger OTP PIN to commence trip.
                  </p>
                </div>
              </div>

              {/* Turn-by-turn Navigation Simulation */}
              <div className="bg-slate-950 border border-slate-800 rounded-2xl p-5 space-y-4">
                <div className="flex items-center justify-between text-xs text-slate-400">
                  <span>Destination Target:</span>
                  <span className="font-bold text-white">{currentRide.destination} ({currentRide.distanceKm} km)</span>
                </div>

                <div className="p-3.5 bg-slate-900 border border-slate-800 rounded-xl flex items-center gap-3">
                  <div className="w-9 h-9 rounded-lg bg-emerald-500/20 flex items-center justify-center text-emerald-400 shrink-0">
                    <Navigation className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-white">
                      Turn right on NH 44 Elevated Tollway
                    </div>
                    <div className="text-[11px] text-slate-400">
                      Fastest route via Hebbal & Outer Ring Road (~42 mins)
                    </div>
                  </div>
                </div>

                {/* Passenger OTP Verification */}
                <div className="p-4 bg-slate-900/90 border border-slate-800 rounded-xl space-y-3">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                      <ShieldCheck className="w-4 h-4 text-emerald-400" />
                      Passenger Security OTP (PIN)
                    </label>
                    <span className="text-[10px] text-amber-400 font-mono">Demo PIN: 4821</span>
                  </div>

                  <div className="flex gap-2">
                    <input
                      type="text"
                      maxLength={4}
                      value={otpInput}
                      onChange={(e) => setOtpInput(e.target.value)}
                      placeholder="Enter 4-digit PIN"
                      className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-center text-lg font-mono font-bold tracking-widest text-white focus:outline-none focus:border-emerald-500"
                    />
                    <button
                      onClick={() => setOtpInput('4821')}
                      className="px-3 py-2 text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl border border-slate-700 transition"
                    >
                      Auto-Fill
                    </button>
                  </div>

                  {otpError && (
                    <p className="text-xs text-rose-400 font-medium">{otpError}</p>
                  )}
                </div>
              </div>

              {/* Start Ride Action */}
              <button
                id="driveros-start-ride-btn"
                onClick={handleStartRide}
                className="w-full py-4 px-6 bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 font-black text-sm uppercase tracking-wider rounded-2xl transition shadow-xl shadow-emerald-500/25 flex items-center justify-center gap-2"
              >
                <Car className="w-5 h-5" />
                <span>VERIFY OTP & START RIDE</span>
              </button>

            </div>
          )}

          {/* ================================================================= */}
          {/* STEP 4: 🚕 RIDE STARTED (Digital Cab Meter)                       */}
          {/* ================================================================= */}
          {status === 'started' && (
            <div className="space-y-5 animate-in zoom-in-95 duration-200">
              
              <div className="bg-emerald-500/15 border border-emerald-500/40 rounded-2xl p-4 flex items-center gap-3.5">
                <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-500/50 flex items-center justify-center text-2xl text-emerald-400">
                  🚕
                </div>
                <div className="flex-1">
                  <h2 className="text-base font-black text-emerald-300 uppercase tracking-wide">
                    RIDE STARTED • METER RUNNING
                  </h2>
                  <p className="text-xs text-slate-300">
                    Heading to {currentRide.destination}. Live digital meter & speed monitoring.
                  </p>
                </div>
              </div>

              {/* Digital Taximeter HUD */}
              <div className="bg-slate-950 border border-slate-800 rounded-2xl p-5 space-y-4">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                    Sovereign Digital Taxi Meter
                  </span>
                  <span className="px-2 py-0.5 text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-400 rounded">
                    METER ACTIVE
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-3 text-center">
                  <div className="bg-slate-900 p-3.5 rounded-xl border border-slate-800">
                    <div className="text-[10px] text-slate-400 uppercase font-semibold">Distance</div>
                    <div className="text-2xl font-black text-white font-mono mt-1">
                      {meterKm} <span className="text-xs text-slate-400">km</span>
                    </div>
                    <div className="text-[9px] text-slate-500">Target: {currentRide.distanceKm} km</div>
                  </div>

                  <div className="bg-slate-900 p-3.5 rounded-xl border border-slate-800">
                    <div className="text-[10px] text-slate-400 uppercase font-semibold">Time Elapsed</div>
                    <div className="text-2xl font-black text-white font-mono mt-1">
                      {meterMinutes} <span className="text-xs text-slate-400">min</span>
                    </div>
                    <div className="text-[9px] text-slate-500">Speed: ~58 km/h</div>
                  </div>

                  <div className="bg-emerald-950/40 p-3.5 rounded-xl border border-emerald-500/40">
                    <div className="text-[10px] text-emerald-400 uppercase font-semibold">Meter Fare</div>
                    <div className="text-2xl font-black text-emerald-300 font-mono mt-1">
                      ₹{meterFare}
                    </div>
                    <div className="text-[9px] text-emerald-400/70">Fixed Cap: ₹{currentRide.fareEstimate}</div>
                  </div>
                </div>

                {/* Progress bar to destination */}
                <div className="space-y-1.5 pt-2">
                  <div className="flex justify-between text-xs text-slate-400">
                    <span>{currentRide.pickup}</span>
                    <span>{currentRide.destination}</span>
                  </div>
                  <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 transition-all duration-300"
                      style={{ width: `${Math.min(100, Math.max(10, (meterKm / currentRide.distanceKm) * 100))}%` }}
                    />
                  </div>
                </div>
              </div>

              {/* Complete Ride Action */}
              <button
                id="driveros-complete-ride-btn"
                onClick={handleCompleteRide}
                className="w-full py-4 px-6 bg-gradient-to-r from-amber-500 to-emerald-500 hover:from-amber-400 hover:to-emerald-400 text-slate-950 font-black text-sm uppercase tracking-wider rounded-2xl transition shadow-xl shadow-emerald-500/20 flex items-center justify-center gap-2"
              >
                <CheckCircle2 className="w-5 h-5" />
                <span>ARRIVED AT DESTINATION • COMPLETE RIDE</span>
              </button>

            </div>
          )}

          {/* ================================================================= */}
          {/* STEP 5: 🏁 RIDE COMPLETED (Trip Summary)                          */}
          {/* ================================================================= */}
          {status === 'completed' && (
            <div className="space-y-5 animate-in zoom-in-95 duration-200">
              
              <div className="bg-emerald-500/20 border border-emerald-500/50 rounded-2xl p-4 flex items-center gap-3.5">
                <div className="w-12 h-12 rounded-2xl bg-emerald-500/30 flex items-center justify-center text-2xl text-emerald-400">
                  🏁
                </div>
                <div className="flex-1">
                  <h2 className="text-base font-black text-emerald-300 uppercase tracking-wide">
                    RIDE COMPLETED
                  </h2>
                  <p className="text-xs text-slate-300">
                    Successfully dropped passenger at {currentRide.destination}. Total: ₹{currentRide.fareEstimate}.
                  </p>
                </div>
              </div>

              {/* Summary Metrics */}
              <div className="bg-slate-950 border border-slate-800 rounded-2xl p-5 space-y-3">
                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div className="bg-slate-900 p-3 rounded-xl border border-slate-800">
                    <span className="text-slate-400 text-[10px] uppercase">Route Covered</span>
                    <div className="text-white font-bold mt-0.5">{currentRide.pickup} → {currentRide.destination}</div>
                    <div className="text-slate-500 text-[10px]">{currentRide.distanceKm} km • 44 mins</div>
                  </div>

                  <div className="bg-slate-900 p-3 rounded-xl border border-slate-800">
                    <span className="text-slate-400 text-[10px] uppercase">Passenger</span>
                    <div className="text-white font-bold mt-0.5">{currentRide.customerName}</div>
                    <div className="text-slate-500 text-[10px]">{currentRide.customerPhone}</div>
                  </div>
                </div>

                <div className="bg-emerald-950/40 p-4 rounded-xl border border-emerald-500/40 flex items-center justify-between">
                  <div>
                    <div className="text-[10px] text-emerald-400 uppercase font-bold">Total Bill to Collect</div>
                    <div className="text-xs text-slate-300">Includes Base, Toll & GST</div>
                  </div>
                  <div className="text-3xl font-black text-emerald-300 font-mono">
                    ₹{currentRide.fareEstimate}
                  </div>
                </div>
              </div>

              {/* Proceed to Payment */}
              <button
                onClick={() => {
                  // Keep completed or proceed directly
                  setPaymentMode('UPI');
                }}
                className="w-full py-4 px-6 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-sm uppercase tracking-wider rounded-2xl transition shadow-xl shadow-emerald-500/20 flex items-center justify-center gap-2"
              >
                <DollarSign className="w-5 h-5" />
                <span>COLLECT PAYMENT & GENERATE RECEIPT</span>
              </button>

              {/* ============================================================= */}
              {/* STEP 6: 💳 PAYMENT / BILL (Inline for smooth experience)     */}
              {/* ============================================================= */}
              <div className="bg-slate-950 border border-slate-800 rounded-2xl p-5 space-y-4 pt-4 mt-2">
                <h3 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2 border-b border-slate-800 pb-2">
                  <DollarSign className="w-4 h-4 text-emerald-400" />
                  Select Payment Collection Method
                </h3>

                {/* Mode Selector */}
                <div className="grid grid-cols-3 gap-2">
                  <button
                    onClick={() => setPaymentMode('UPI')}
                    className={`py-2.5 px-3 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                      paymentMode === 'UPI'
                        ? 'bg-emerald-500 text-slate-950 shadow-md'
                        : 'bg-slate-900 text-slate-300 hover:bg-slate-850'
                    }`}
                  >
                    <QrCode className="w-4 h-4" />
                    <span>UPI QR</span>
                  </button>

                  <button
                    onClick={() => setPaymentMode('CASH')}
                    className={`py-2.5 px-3 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                      paymentMode === 'CASH'
                        ? 'bg-emerald-500 text-slate-950 shadow-md'
                        : 'bg-slate-900 text-slate-300 hover:bg-slate-850'
                    }`}
                  >
                    <DollarSign className="w-4 h-4" />
                    <span>CASH</span>
                  </button>

                  <button
                    onClick={() => setPaymentMode('CARD')}
                    className={`py-2.5 px-3 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                      paymentMode === 'CARD'
                        ? 'bg-emerald-500 text-slate-950 shadow-md'
                        : 'bg-slate-900 text-slate-300 hover:bg-slate-850'
                    }`}
                  >
                    <span>CARD</span>
                  </button>
                </div>

                {/* UPI QR Display */}
                {paymentMode === 'UPI' && (
                  <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 flex flex-col items-center text-center space-y-3">
                    <div className="bg-white p-3 rounded-2xl shadow-lg inline-block">
                      <img
                        src={`https://api.qrserver.com/v1/create-qr-code/?size=160x160&data=${encodeURIComponent(
                          `upi://pay?pa=9318320977@okaxis&pn=Ramesh Kumar&am=${currentRide.fareEstimate}&cu=INR&tn=DriverOS Ride ${currentRide.id}`
                        )}`}
                        alt="UPI QR Code"
                        className="w-36 h-36 mx-auto"
                      />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-white">Scan with any UPI App (GPay / PhonePe / Paytm)</div>
                      <div className="text-[11px] text-slate-400 font-mono mt-0.5">
                        UPI ID: 9318320977@okaxis
                      </div>
                    </div>
                    <button
                      onClick={handleCopyUpi}
                      className="px-3 py-1 bg-slate-800 hover:bg-slate-750 text-[11px] text-slate-300 rounded-lg border border-slate-700 flex items-center gap-1.5 transition"
                    >
                      <Copy className="w-3 h-3" />
                      <span>{copiedUpi ? 'Copied to Clipboard!' : 'Copy UPI ID'}</span>
                    </button>
                  </div>
                )}

                {/* CASH Calculator */}
                {paymentMode === 'CASH' && (
                  <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 space-y-3">
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-slate-400">Cash Received from Passenger:</span>
                      <input
                        type="number"
                        value={cashTendered}
                        onChange={(e) => setCashTendered(e.target.value === '' ? '' : Number(e.target.value))}
                        className="w-28 bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-right font-mono font-bold text-white text-sm"
                      />
                    </div>
                    <div className="flex justify-between items-center text-xs pt-2 border-t border-slate-800 font-bold">
                      <span className="text-slate-300">Change to Return to Passenger:</span>
                      <span className="text-base font-mono text-amber-400">
                        ₹{typeof cashTendered === 'number' && cashTendered >= currentRide.fareEstimate ? cashTendered - currentRide.fareEstimate : 0}
                      </span>
                    </div>
                  </div>
                )}

                {/* Settle & Issue Receipt */}
                <button
                  id="driveros-settle-payment-btn"
                  onClick={handleSettlePayment}
                  disabled={isProcessingPayment}
                  className="w-full py-3.5 px-5 bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 font-black text-xs uppercase tracking-wider rounded-xl transition shadow-lg shadow-emerald-500/20 flex items-center justify-center gap-2"
                >
                  {isProcessingPayment ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Recording Settlement...</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="w-4 h-4" />
                      <span>MARK ₹{currentRide.fareEstimate} PAID & ISSUE INVOICE</span>
                    </>
                  )}
                </button>
              </div>

            </div>
          )}

          {/* ================================================================= */}
          {/* STEP 7: 📄 PDF RECEIPT (Payment Settled & Tax Invoice)            */}
          {/* ================================================================= */}
          {status === 'paid' && (
            <div className="space-y-5 animate-in zoom-in-95 duration-200">
              
              <div className="bg-emerald-500/20 border border-emerald-500/50 rounded-2xl p-4 flex items-center gap-3.5">
                <div className="w-12 h-12 rounded-2xl bg-emerald-500/30 flex items-center justify-center text-2xl text-emerald-400">
                  📄
                </div>
                <div className="flex-1">
                  <h2 className="text-base font-black text-emerald-300 uppercase tracking-wide">
                    PAYMENT SETTLED & PDF RECEIPT READY
                  </h2>
                  <p className="text-xs text-slate-300">
                    Official GST / Section 44AD Compliant Tax Invoice generated.
                  </p>
                </div>
              </div>

              {/* Receipt Preview Box */}
              <div className="bg-slate-950 border border-slate-800 rounded-2xl p-5 space-y-3 font-sans">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <div>
                    <span className="text-xs font-bold text-emerald-400">DRIVEROS OFFICIAL E-INVOICE</span>
                    <div className="text-[11px] text-slate-400">Invoice: {currentRide.payment?.invoiceNumber || 'INV-2026-4821'}</div>
                  </div>
                  <span className="px-2.5 py-1 bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 rounded text-[10px] font-bold">
                    PAID VIA {currentRide.payment?.mode || paymentMode}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs py-2">
                  <div>
                    <span className="text-slate-500 text-[10px] uppercase">Passenger</span>
                    <div className="text-white font-semibold">{currentRide.customerName}</div>
                    <div className="text-slate-400 text-[11px]">{currentRide.customerPhone}</div>
                  </div>
                  <div>
                    <span className="text-slate-500 text-[10px] uppercase">Chauffeur</span>
                    <div className="text-white font-semibold">{driver.name}</div>
                    <div className="text-slate-400 text-[11px]">{driver.vehiclePlate} ({driver.vehicleModel})</div>
                  </div>
                </div>

                <div className="space-y-1.5 text-xs border-t border-slate-800 pt-2 text-slate-300">
                  <div className="flex justify-between">
                    <span>Base & Distance Fare ({currentRide.distanceKm} km):</span>
                    <span className="font-mono">₹{currentRide.fareEstimate - 115 - 25}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Airport Toll Expressway (Fastag):</span>
                    <span className="font-mono">₹115</span>
                  </div>
                  <div className="flex justify-between">
                    <span>GST (5% SAC 996412):</span>
                    <span className="font-mono">₹25</span>
                  </div>
                  <div className="flex justify-between font-black text-white text-sm border-t border-slate-800 pt-1.5">
                    <span>Total Settled:</span>
                    <span className="text-emerald-400 font-mono">₹{currentRide.fareEstimate}</span>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="space-y-2">
                <button
                  id="driveros-download-pdf-btn"
                  onClick={handleDownloadPDF}
                  className="w-full py-3.5 px-5 bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 font-black text-xs uppercase tracking-wider rounded-xl transition shadow-lg shadow-emerald-500/20 flex items-center justify-center gap-2"
                >
                  <Download className="w-4 h-4" />
                  <span>DOWNLOAD PDF RECEIPT</span>
                </button>

                <button
                  onClick={onClose}
                  className="w-full py-2.5 px-4 bg-slate-800 hover:bg-slate-750 text-slate-300 text-xs font-bold rounded-xl transition flex items-center justify-center gap-2"
                >
                  <span>Close / Ready for Next Ride</span>
                </button>
              </div>

            </div>
          )}

        </div>

      </div>
    </div>
  );
};
