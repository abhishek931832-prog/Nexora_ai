import React, { useState, useEffect, useRef } from 'react';
import { 
  Car, 
  DollarSign, 
  Mic, 
  MapPin, 
  ShieldCheck, 
  Wrench, 
  Gift, 
  TrendingUp, 
  Receipt, 
  LifeBuoy, 
  Radio, 
  Phone, 
  Flame, 
  Zap, 
  Fuel, 
  CheckCircle2, 
  AlertTriangle, 
  ChevronRight, 
  Play, 
  Pause, 
  Navigation, 
  FileText, 
  QrCode, 
  Banknote, 
  ArrowUpRight, 
  Sparkles,
  Shield,
  Clock,
  Compass,
  Layers,
  ParkingCircle,
  ExternalLink
} from 'lucide-react';
import { DriverProfile, ShiftState, TripRecord, ExpenseRecord, MainPillar } from '../types';
import { 
  INITIAL_MAP_CARS, 
  ROUTE_WAYPOINTS,
  interpolateWaypoint,
  MapCarData as MapCar
} from './map/mapData';
import { demandSurgeClusters, verifiedRestAndFuelHubs } from '../data/mockInitialData';
import { LeafletMapView } from './map/LeafletMapView';
import { GoogleMapView } from './map/GoogleMapView';

interface DriverOSMasterDashboardProps {
  driver: DriverProfile;
  shift: ShiftState;
  trips: TripRecord[];
  expenses: ExpenseRecord[];
  onToggleDuty: () => void;
  onNavigatePillar: (pillar: MainPillar, subView?: string) => void;
  onOpenNewTrip: () => void;
  onOpenScanReceipt: () => void;
  onOpenCustomerPayment: () => void;
  onOpenVoice: () => void;
  onTriggerEmergencySOS: () => void;
  activeRide?: any;
  onOpenBookingFlow?: () => void;
}

export const DriverOSMasterDashboard: React.FC<DriverOSMasterDashboardProps> = ({
  driver,
  shift,
  trips,
  expenses,
  onToggleDuty,
  onNavigatePillar,
  onOpenNewTrip,
  onOpenScanReceipt,
  onOpenCustomerPayment,
  onOpenVoice,
  onTriggerEmergencySOS,
  activeRide,
  onOpenBookingFlow,
}) => {
  // Map simulation state
  const [cars, setCars] = useState<MapCar[]>(INITIAL_MAP_CARS);
  const [selectedCar, setSelectedCar] = useState<MapCar | null>(INITIAL_MAP_CARS[0]);
  const [activeMapFilter, setActiveMapFilter] = useState<'ALL' | 'SURGE' | 'CNG' | 'EV' | 'PARKING' | 'CARS'>('ALL');
  const [mapEngine, setMapEngine] = useState<'LEAFLET' | 'GOOGLE'>(() => {
    return import.meta.env.VITE_GOOGLE_MAPS_API_KEY ? 'GOOGLE' : 'LEAFLET';
  });
  const [isSimulatingTraffic, setIsSimulatingTraffic] = useState(true);
  const [activeCorridorIndex, setActiveCorridorIndex] = useState(0);

  // Today's aggregate numbers matching user spec
  const todayGrossEarnings = 2840;
  const todayNetProfit = 2240;
  const todayTripsCount = 8;
  const todayKm = 142;
  const profitPerKm = (todayNetProfit / todayKm).toFixed(1);

  // Vehicle Telemetry
  const fuelPercent = 62;
  const cngKgRemaining = 6.8;
  const nextServiceKm = 1240;
  const incentiveProgress = 72; // 8/11 trips
  const incentiveBonus = 500;
  const tripsToNextBonus = 3;

  // Best Route Corridor Data
  const corridors = [
    {
      name: 'Airport Express (NH44 Elevated)',
      estEarning: '₹850–₹1,100',
      time: '38 mins',
      distance: '34.2 km',
      demand: 'HIGH 2.2x',
      status: 'Fast Flow • Toll ₹115',
    },
    {
      name: 'Outer Ring Road (Silk Board to Bellandur)',
      estEarning: '₹420–₹580',
      time: '24 mins',
      distance: '14.8 km',
      demand: 'SURGE 1.8x',
      status: 'Tech Corridor Surge',
    },
    {
      name: 'Electronic City Flyover',
      estEarning: '₹550–₹720',
      time: '28 mins',
      distance: '21.5 km',
      demand: 'MODERATE 1.5x',
      status: 'Clear Elevated Corridor',
    },
  ];

  const currentCorridor = corridors[activeCorridorIndex];

  // Active Simulated Moving Cars Loop
  useEffect(() => {
    if (!isSimulatingTraffic) return;

    const interval = setInterval(() => {
      setCars((prevCars) =>
        prevCars.map((car) => {
          const waypoints = ROUTE_WAYPOINTS[car.routeKey] || ROUTE_WAYPOINTS.AIRPORT_EXPRESS;
          const step = (car.speedKmH / 3600) * 0.08;
          const nextProgress = (car.progress + step) % 1;
          const { coord, heading } = interpolateWaypoint(waypoints, nextProgress);

          const speedDelta = (Math.random() - 0.5) * 3;
          const updatedSpeed = Math.round(Math.max(35, Math.min(78, car.speedKmH + speedDelta)));

          const updatedCar: MapCar = {
            ...car,
            progress: nextProgress,
            currentCoord: coord,
            headingAngle: heading,
            speedKmH: updatedSpeed,
          };

          if (selectedCar && selectedCar.id === car.id) {
            setSelectedCar(updatedCar);
          }

          return updatedCar;
        })
      );
    }, 200);

    return () => clearInterval(interval);
  }, [isSimulatingTraffic, selectedCar]);

  return (
    <div className="space-y-5 animate-in fade-in duration-300">
      
      {/* ========================================================================= */}
      {/* 🚀 DRIVEROS BOOKING FLOW (Customer App -> Backend -> DriverOS -> PDF)     */}
      {/* ========================================================================= */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-indigo-950/70 border border-slate-800 hover:border-indigo-500/40 rounded-3xl p-5 shadow-2xl relative overflow-hidden">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1.5 max-w-2xl">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 text-[10px] font-mono font-bold bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 rounded-full uppercase">
                ⚡ END-TO-END RIDE LIFECYCLE
              </span>
              <span className="text-xs text-slate-400 font-mono">
                AIRPORT ➔ WHITEFIELD (28 KM • ₹650)
              </span>
            </div>
            <h2 className="text-lg font-black text-white flex items-center gap-2">
              <span>DRIVEROS BOOKING FLOW</span>
              <span className="text-xs px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-bold">
                LIVE STATE MACHINE
              </span>
            </h2>
            <p className="text-xs text-slate-300 leading-relaxed">
              Customer App (<code className="text-indigo-400 font-mono">POST /api/rides</code>) ➔ Backend Assignment ➔ DriverOS (<code className="text-amber-400 font-mono">🚨 15s Request</code>) ➔ 🟢 Accepted ➔ 📍 Live Tracking ➔ 🚕 Ride Started ➔ 🏁 Completed ➔ 💳 Payment ➔ 📄 PDF Receipt.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={() => onNavigatePillar('CUSTOMER_BOOKING', 'book-ride')}
              className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition shadow-lg shadow-indigo-600/20 flex items-center gap-2 cursor-pointer"
            >
              <span>📱 Open Customer App</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>

            {onOpenBookingFlow && (
              <button
                onClick={onOpenBookingFlow}
                className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 text-xs font-black transition shadow-lg shadow-emerald-500/20 flex items-center gap-2 cursor-pointer"
              >
                <span>🚨 Launch DriverOS Alert</span>
                <Sparkles className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Quick Lifecycle Pills */}
        <div className="mt-4 pt-3 border-t border-slate-800/80 grid grid-cols-3 sm:grid-cols-6 gap-2 text-center text-[10px] font-bold">
          <div className="p-2 rounded-lg bg-slate-950/80 border border-slate-800 text-slate-300">
            1. 📍 Book Ride
          </div>
          <div className="p-2 rounded-lg bg-slate-950/80 border border-slate-800 text-amber-400">
            2. 🚨 New Request
          </div>
          <div className="p-2 rounded-lg bg-slate-950/80 border border-slate-800 text-emerald-400">
            3. 🟢 Accepted
          </div>
          <div className="p-2 rounded-lg bg-slate-950/80 border border-slate-800 text-indigo-400">
            4. 📍 Tracking
          </div>
          <div className="p-2 rounded-lg bg-slate-950/80 border border-slate-800 text-teal-400">
            5. 🚕 Started
          </div>
          <div className="p-2 rounded-lg bg-slate-950/80 border border-slate-800 text-emerald-300">
            6. 📄 PDF Receipt
          </div>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 1. TOP TIER: 3 CORE CARDS (RIDE WORK • MONEY • SAATHI AI)                 */}
      {/* ========================================================================= */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        
        {/* CARD 1: 🚕 RIDE WORK */}
        <div 
          onClick={() => onNavigatePillar('RIDE_WORK', 'new-ride')}
          className="bg-slate-900/90 border border-slate-800 hover:border-emerald-500/50 rounded-2xl p-5 shadow-xl transition-all cursor-pointer group relative overflow-hidden flex flex-col justify-between"
        >
          <div className="absolute top-0 right-0 w-28 h-28 bg-emerald-500/5 rounded-full blur-2xl pointer-events-none" />
          
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-emerald-500/15 text-emerald-400 flex items-center justify-center border border-emerald-500/30 group-hover:scale-105 transition-transform">
                  <Car className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-white tracking-wide uppercase flex items-center gap-1.5">
                    <span>🚕 RIDE WORK</span>
                  </h3>
                  <span className="text-[11px] text-slate-400 font-medium">Duty & Taxi Dispatch</span>
                </div>
              </div>

              {/* Duty Toggle Button (Inside Card) */}
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onToggleDuty();
                }}
                className={`px-2.5 py-1 rounded-full text-[10px] font-black tracking-wider uppercase transition-all flex items-center gap-1.5 ${
                  shift.isOnDuty 
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/50 shadow-sm' 
                    : 'bg-slate-800 text-slate-400 border border-slate-700'
                }`}
              >
                <span className={`w-2 h-2 rounded-full ${shift.isOnDuty ? 'bg-emerald-400 animate-ping' : 'bg-slate-500'}`} />
                <span>Duty: {shift.isOnDuty ? 'ACTIVE' : 'PAUSED'}</span>
              </button>
            </div>

            {/* Current Ride Info */}
            <div className="bg-slate-950/70 border border-slate-800 rounded-xl p-3 mb-3 space-y-1">
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-slate-400">Current Status:</span>
                {activeRide ? (
                  <span className="flex items-center gap-1 text-emerald-400 font-bold">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                    {activeRide.status.toUpperCase()}
                  </span>
                ) : (
                  <span className={`flex items-center gap-1 font-bold ${shift.isOnDuty ? 'text-teal-300' : 'text-slate-400'}`}>
                    <span className={`w-2 h-2 rounded-full ${shift.isOnDuty ? 'bg-teal-400 animate-pulse' : 'bg-slate-500'}`} />
                    {shift.isOnDuty ? 'STANDBY (AWAITING RIDES)' : 'SHIFT OFF-DUTY'}
                  </span>
                )}
              </div>
              <div className="text-xs font-bold text-slate-100 truncate">
                {activeRide 
                  ? `Passenger: ${activeRide.customerName} • ${activeRide.pickup}`
                  : (shift.isOnDuty ? 'Ready for Sovereign Direct Dispatch' : 'Driver currently off-duty')}
              </div>
              <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 pt-0.5">
                <span>Fare: <strong className="text-emerald-400">{activeRide ? `₹${activeRide.fareEstimate}` : '₹0/km comm.'}</strong></span>
                <span>Dispatch: <strong className="text-white">{shift.isOnDuty ? '0% Commission' : 'Paused'}</strong></span>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between pt-1 text-xs">
            <span className="text-[11px] text-emerald-400 font-bold flex items-center gap-1">
              <span>Open Ride Workflow</span>
              <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300">
              Meter Engaged
            </span>
          </div>
        </div>

        {/* CARD 2: 💰 MONEY */}
        <div 
          onClick={() => onNavigatePillar('MONEY', 'today-earnings')}
          className="bg-slate-900/90 border border-slate-800 hover:border-emerald-500/50 rounded-2xl p-5 shadow-xl transition-all cursor-pointer group relative overflow-hidden flex flex-col justify-between"
        >
          <div className="absolute top-0 right-0 w-28 h-28 bg-emerald-500/5 rounded-full blur-2xl pointer-events-none" />

          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-emerald-500/15 text-emerald-400 flex items-center justify-center border border-emerald-500/30 group-hover:scale-105 transition-transform">
                  <DollarSign className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-white tracking-wide uppercase flex items-center gap-1.5">
                    <span>💰 MONEY</span>
                  </h3>
                  <span className="text-[11px] text-slate-400 font-medium">Daily Net Cashflow</span>
                </div>
              </div>

              <span className="px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 text-[10px] font-bold border border-emerald-500/30">
                ₹ Net Profit
              </span>
            </div>

            {/* Earnings Statistics Display */}
            <div className="grid grid-cols-2 gap-2 mb-3">
              <div className="bg-slate-950/70 border border-slate-800 rounded-xl p-2.5">
                <div className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">Today Gross</div>
                <div className="text-xl font-black text-white font-mono mt-0.5">₹{todayGrossEarnings.toLocaleString()}</div>
              </div>

              <div className="bg-slate-950/70 border border-emerald-500/30 rounded-xl p-2.5">
                <div className="text-[10px] text-emerald-400 uppercase tracking-wider font-semibold">Net Profit</div>
                <div className="text-xl font-black text-emerald-400 font-mono mt-0.5">₹{todayNetProfit.toLocaleString()}</div>
              </div>
            </div>

            <div className="flex items-center justify-between text-xs text-slate-400 px-1">
              <span>{todayTripsCount} Trips Completed</span>
              <span className="font-mono text-slate-300 font-semibold">₹{profitPerKm}/km Velocity</span>
            </div>
          </div>

          <div className="flex items-center justify-between pt-2 text-xs border-t border-slate-800/80 mt-2">
            <span className="text-[11px] text-emerald-400 font-bold flex items-center gap-1">
              <span>View Full Ledger</span>
              <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </span>
            <span className="text-[10px] text-slate-400 font-mono">Instant Payout Ready</span>
          </div>
        </div>

        {/* CARD 3: 🤖 SAATHI AI */}
        <div 
          onClick={() => onNavigatePillar('SAATHI_AI', 'ask-anything')}
          className="bg-slate-900/90 border border-slate-800 hover:border-emerald-500/50 rounded-2xl p-5 shadow-xl transition-all cursor-pointer group relative overflow-hidden flex flex-col justify-between"
        >
          <div className="absolute top-0 right-0 w-28 h-28 bg-emerald-500/5 rounded-full blur-2xl pointer-events-none" />

          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-500/20 to-teal-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30 group-hover:scale-105 transition-transform">
                  <Mic className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-white tracking-wide uppercase flex items-center gap-1.5">
                    <span>🤖 SAATHI AI</span>
                  </h3>
                  <span className="text-[11px] text-slate-400 font-medium">Driver Co-Pilot</span>
                </div>
              </div>

              <div className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-[10px] font-bold">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                <span>🎙 Voice Ready</span>
              </div>
            </div>

            {/* Saathi Advice Capsule */}
            <div className="bg-slate-950/70 border border-slate-800 rounded-xl p-3 mb-3 space-y-2">
              <p className="text-xs text-slate-200 leading-relaxed font-medium">
                "Bhai, Kempegowda Airport T2 flight arrivals peak in 45 mins. Return fares averaging ₹1,100."
              </p>
              
              <div className="flex items-center gap-1.5">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onOpenVoice();
                  }}
                  className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-md shadow-emerald-950 transition-all active:scale-95"
                >
                  <Mic className="w-3.5 h-3.5 animate-pulse" />
                  <span>Ask Saathi</span>
                </button>

                <span className="text-[10px] text-slate-400 font-mono">
                  Multi-language (EN/HI/KN)
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between pt-1 text-xs">
            <span className="text-[11px] text-emerald-400 font-bold flex items-center gap-1">
              <span>Open AI Earnings Advisor</span>
              <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </span>
            <span className="text-[10px] text-slate-400">Gemini 2.5 Flash</span>
          </div>
        </div>

      </div>

      {/* ========================================================================= */}
      {/* 2. CENTER STAGE: 🗺️ SMART MAP (Full-Width Interactive Map Blueprint)      */}
      {/* ========================================================================= */}
      <div className="bg-slate-900/95 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-2xl relative overflow-hidden space-y-4">
        
        {/* Map Header Strip */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800/80 pb-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-600 to-teal-700 text-white flex items-center justify-center shadow-lg shadow-emerald-950">
              <MapPin className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-black text-white tracking-tight flex items-center gap-2">
                  <span>🗺️ SMART MAP</span>
                </h2>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-slate-800 text-emerald-400 border border-slate-700">
                  NH44 Corridor Active
                </span>
              </div>
              <p className="text-xs text-slate-400">High-Velocity Demand & Fuel Routing</p>
            </div>
          </div>

          {/* Right Status Badge */}
          <div className="flex items-center gap-2 self-start sm:self-auto">
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-emerald-500/15 border border-emerald-500/40 text-xs font-bold text-emerald-300">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
              <span>🟢 GPS LIVE</span>
            </div>

            <button
              onClick={() => onNavigatePillar('SMART_MAP', 'moving-car')}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1 transition-colors"
              title="Expand to Full Map View"
            >
              <span>Full Screen</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Telemetry Row (Matching ASCII Art: DEMAND ZONES • 🚕 YOU 56 km/h • ⛽ FUEL / ⚡ EV) */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          
          {/* DEMAND ZONES: 🔴 HIGH */}
          <div className="bg-slate-950/80 border border-rose-500/30 rounded-xl p-3 flex items-center justify-between">
            <div className="space-y-0.5">
              <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                <Flame className="w-3.5 h-3.5 text-rose-400" />
                <span>DEMAND ZONES</span>
              </div>
              <div className="text-sm font-black text-rose-400 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
                <span>🔴 HIGH (1.8x–2.3x)</span>
              </div>
            </div>
            <span className="text-[10px] px-2 py-1 rounded bg-rose-500/10 text-rose-300 font-mono border border-rose-500/20">
              Airport & Tech Hubs
            </span>
          </div>

          {/* 🚕 YOU 56 km/h • KA-05-AB-9821 */}
          <div className="bg-slate-950/80 border border-emerald-500/40 rounded-xl p-3 flex items-center justify-between">
            <div className="space-y-0.5">
              <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                <Car className="w-3.5 h-3.5 text-emerald-400" />
                <span>ACTIVE VEHICLE</span>
              </div>
              <div className="text-sm font-black text-emerald-300 flex items-center gap-2">
                <span>🚕 YOU {selectedCar?.speedKmH || 56} km/h</span>
                <span className="text-slate-500">•</span>
                <span className="font-mono text-white text-xs">{driver.vehiclePlate}</span>
              </div>
            </div>
            <span className="text-[10px] px-2 py-1 rounded bg-emerald-500/15 text-emerald-400 font-mono font-bold border border-emerald-500/30">
              {Math.round(selectedCar?.headingAngle || 20)}° NNE
            </span>
          </div>

          {/* ⛽ FUEL • ⚡ EV */}
          <div className="bg-slate-950/80 border border-amber-500/30 rounded-xl p-3 flex items-center justify-between">
            <div className="space-y-0.5">
              <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                <Fuel className="w-3.5 h-3.5 text-amber-400" />
                <span>⛽ FUEL • ⚡ EV</span>
              </div>
              <div className="text-xs font-bold text-slate-200">
                GAIL CNG ₹88.50/Kg <span className="text-slate-500">•</span> <span className="text-sky-400">Zeon EV 60kW</span>
              </div>
            </div>
            <span className="text-[10px] px-2 py-1 rounded bg-amber-500/10 text-amber-300 font-mono border border-amber-500/20">
              0 Min Wait
            </span>
          </div>

        </div>

        {/* BEST ROUTE Corridor Banner (Matching ASCII Art: ───── BEST ROUTE ────────> 📍 Airport Express 💰 ₹850–₹1,100) */}
        <div className="bg-gradient-to-r from-emerald-950/80 via-slate-950/90 to-teal-950/80 border border-emerald-500/40 rounded-xl p-3 sm:p-4 shadow-lg">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="space-y-1">
              <div className="text-[11px] font-black text-emerald-400 uppercase tracking-widest flex items-center gap-2">
                <Navigation className="w-3.5 h-3.5" />
                <span>───── BEST ROUTE RECOMMENDATION ────────────────────────────────────────&gt;</span>
              </div>
              <div className="flex items-center flex-wrap gap-2 text-sm">
                <span className="font-black text-white flex items-center gap-1">
                  <MapPin className="w-4 h-4 text-emerald-400" />
                  <span>📍 {currentCorridor.name}</span>
                </span>
                <span className="text-slate-600 hidden sm:inline">•</span>
                <span className="font-bold text-emerald-300 font-mono flex items-center gap-1">
                  <span>💰 {currentCorridor.estEarning}</span>
                  <span className="text-xs text-slate-400 font-normal">estimated earning</span>
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <span className="text-xs font-mono text-slate-300 bg-slate-900 px-2.5 py-1 rounded-lg border border-slate-800">
                {currentCorridor.time} • {currentCorridor.distance}
              </span>
              <button
                onClick={() => setActiveCorridorIndex((idx) => (idx + 1) % corridors.length)}
                className="text-[11px] font-bold px-2.5 py-1 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 transition-colors"
                title="Cycle through high-profit routes"
              >
                Next Route &gt;
              </button>
            </div>
          </div>
        </div>

        {/* Filter Pills Bar: [Demand] [Profit] [Fuel] [Parking] [Fleet] */}
        <div className="flex items-center justify-between flex-wrap gap-2 pt-1">
          <div className="flex items-center flex-wrap gap-1.5">
            {[
              { id: 'ALL', label: 'All Layers', icon: Layers },
              { id: 'SURGE', label: 'Demand', icon: Flame },
              { id: 'PROFIT', label: 'Profit', icon: TrendingUp },
              { id: 'CNG', label: 'Fuel', icon: Fuel },
              { id: 'PARKING', label: 'Parking', icon: ParkingCircle },
              { id: 'CARS', label: 'Fleet', icon: Car },
            ].map((pill) => {
              const Icon = pill.icon;
              const isActive = (pill.id === 'PROFIT' ? activeMapFilter === 'SURGE' : activeMapFilter === pill.id);
              return (
                <button
                  key={pill.id}
                  onClick={() => {
                    if (pill.id === 'PROFIT') setActiveMapFilter('SURGE');
                    else setActiveMapFilter(pill.id as any);
                  }}
                  className={`px-3 py-1 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all ${
                    isActive
                      ? 'bg-emerald-500 text-slate-950 shadow-md font-black ring-1 ring-emerald-300'
                      : 'bg-slate-950 text-slate-300 hover:text-white border border-slate-800 hover:bg-slate-800'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>[{pill.label}]</span>
                </button>
              );
            })}
          </div>

          <div className="flex items-center gap-2 text-xs">
            <button
              onClick={() => setIsSimulatingTraffic(!isSimulatingTraffic)}
              className={`p-1.5 rounded-lg border text-xs flex items-center gap-1 ${
                isSimulatingTraffic 
                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40' 
                  : 'bg-slate-800 text-slate-400 border-slate-700'
              }`}
            >
              {isSimulatingTraffic ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
              <span className="text-[10px] font-mono">{isSimulatingTraffic ? 'Fleet Live' : 'Paused'}</span>
            </button>
          </div>
        </div>

        {/* Embedded Interactive Map Stage */}
        <div className="relative h-[440px] sm:h-[480px] rounded-xl overflow-hidden border border-slate-800 bg-slate-950 shadow-inner">
          <LeafletMapView
            cars={cars}
            selectedCar={selectedCar}
            onSelectCar={(c) => setSelectedCar(c)}
            clusters={demandSurgeClusters}
            selectedCluster={null}
            onSelectCluster={() => {}}
            hubs={verifiedRestAndFuelHubs}
            selectedHub={null}
            onSelectHub={() => {}}
            activeFilter={activeMapFilter === 'CARS' ? 'CARS' : activeMapFilter}
            routePoints={ROUTE_WAYPOINTS[selectedCar?.routeKey || 'AIRPORT_EXPRESS'] || ROUTE_WAYPOINTS['AIRPORT_EXPRESS']}
            mapTheme="DARK"
            onChangeMapTheme={() => {}}
          />
        </div>

      </div>

      {/* ========================================================================= */}
      {/* 3. MIDDLE TIER: 3 CARDS (🛡️ SAFETY • 🚗 VEHICLE • 🎁 INCENTIVES)         */}
      {/* ========================================================================= */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        
        {/* CARD 4: 🛡️ SAFETY */}
        <div 
          onClick={() => onNavigatePillar('SAFETY')}
          className="bg-slate-900/90 border border-slate-800 hover:border-emerald-500/50 rounded-2xl p-5 shadow-xl transition-all cursor-pointer group relative overflow-hidden flex flex-col justify-between"
        >
          <div className="absolute top-0 right-0 w-28 h-28 bg-emerald-500/5 rounded-full blur-2xl pointer-events-none" />

          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-emerald-500/15 text-emerald-400 flex items-center justify-center border border-emerald-500/30 group-hover:scale-105 transition-transform">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-white tracking-wide uppercase flex items-center gap-1.5">
                    <span>🛡️ SAFETY</span>
                  </h3>
                  <span className="text-[11px] text-slate-400 font-medium">Protection & Fatigue Alert</span>
                </div>
              </div>

              <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold border border-emerald-500/40">
                ACTIVE
              </span>
            </div>

            {/* Metrics Matching ASCII: Coverage: ₹5L* • Alerts: 0 • Emergency */}
            <div className="space-y-2 bg-slate-950/70 border border-slate-800 rounded-xl p-3 mb-3 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Coverage:</span>
                <span className="font-bold text-white font-mono">₹5,00,000* Cashless</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Fatigue Alerts:</span>
                <span className="font-bold text-emerald-400">0 (Alert & Fresh)</span>
              </div>
              <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-800/80">
                <span>Chai Break Countdown:</span>
                <span className="font-mono text-amber-300 font-bold">In 65 mins</span>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between gap-2 pt-1">
            <button
              onClick={(e) => {
                e.stopPropagation();
                onTriggerEmergencySOS();
              }}
              className="w-full py-2 px-3 rounded-xl bg-red-950/80 hover:bg-red-900 border border-red-500/60 text-red-300 hover:text-white font-black text-xs flex items-center justify-center gap-1.5 transition-all shadow-md active:scale-95"
            >
              <AlertTriangle className="w-3.5 h-3.5 text-red-400 animate-pulse" />
              <span>EMERGENCY SOS</span>
            </button>
          </div>
        </div>

        {/* CARD 5: 🚗 VEHICLE */}
        <div 
          onClick={() => onNavigatePillar('VEHICLE', 'profile')}
          className="bg-slate-900/90 border border-slate-800 hover:border-emerald-500/50 rounded-2xl p-5 shadow-xl transition-all cursor-pointer group relative overflow-hidden flex flex-col justify-between"
        >
          <div className="absolute top-0 right-0 w-28 h-28 bg-emerald-500/5 rounded-full blur-2xl pointer-events-none" />

          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-emerald-500/15 text-emerald-400 flex items-center justify-center border border-emerald-500/30 group-hover:scale-105 transition-transform">
                  <Wrench className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-white tracking-wide uppercase flex items-center gap-1.5">
                    <span>🚗 VEHICLE</span>
                  </h3>
                  <span className="text-[11px] text-slate-400 font-medium">Health & Maintenance</span>
                </div>
              </div>

              <span className="px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 text-[10px] font-bold border border-emerald-500/30">
                GOOD
              </span>
            </div>

            {/* Metrics Matching ASCII: Fuel: 62% • Service: 1,240 km • Health: GOOD */}
            <div className="space-y-2 bg-slate-950/70 border border-slate-800 rounded-xl p-3 mb-3 text-xs">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-slate-400">Fuel (CNG):</span>
                  <span className="font-mono text-emerald-400 font-bold">{fuelPercent}% ({cngKgRemaining} kg left)</span>
                </div>
                <div className="w-full h-1.5 rounded-full bg-slate-800 overflow-hidden">
                  <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${fuelPercent}%` }} />
                </div>
              </div>

              <div className="flex items-center justify-between pt-1">
                <span className="text-slate-400">Periodic Service:</span>
                <span className="font-mono text-white font-bold">{nextServiceKm.toLocaleString()} km left</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">PUC & Insurance:</span>
                <span className="font-bold text-emerald-400">Valid till Nov 2026</span>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between pt-1 text-xs">
            <span className="text-[11px] text-emerald-400 font-bold flex items-center gap-1">
              <span>View Vehicle Profile</span>
              <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </span>
            <span className="text-[10px] font-mono text-slate-400">{driver.vehicleModel.split(' ')[0]} {driver.vehicleModel.split(' ')[1]}</span>
          </div>
        </div>

        {/* CARD 6: 🎁 INCENTIVES */}
        <div 
          onClick={() => onNavigatePillar('INCENTIVES', 'daily-target')}
          className="bg-slate-900/90 border border-slate-800 hover:border-emerald-500/50 rounded-2xl p-5 shadow-xl transition-all cursor-pointer group relative overflow-hidden flex flex-col justify-between"
        >
          <div className="absolute top-0 right-0 w-28 h-28 bg-emerald-500/5 rounded-full blur-2xl pointer-events-none" />

          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-amber-500/15 text-amber-400 flex items-center justify-center border border-amber-500/30 group-hover:scale-105 transition-transform">
                  <Gift className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-white tracking-wide uppercase flex items-center gap-1.5">
                    <span>🎁 INCENTIVES</span>
                  </h3>
                  <span className="text-[11px] text-slate-400 font-medium">Daily Goals & Rewards</span>
                </div>
              </div>

              <span className="px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-300 text-[10px] font-bold border border-amber-500/30">
                +₹{incentiveBonus} Unlocked
              </span>
            </div>

            {/* Metrics Matching ASCII: Progress: 72% • Bonus: ₹500 • Next: 3 rides */}
            <div className="space-y-2 bg-slate-950/70 border border-slate-800 rounded-xl p-3 mb-3 text-xs">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-slate-400">Progress:</span>
                  <span className="font-mono text-amber-300 font-bold">{incentiveProgress}% (8 of 11 rides)</span>
                </div>
                <div className="w-full h-1.5 rounded-full bg-slate-800 overflow-hidden">
                  <div className="h-full bg-gradient-to-r from-amber-500 to-emerald-400 rounded-full" style={{ width: `${incentiveProgress}%` }} />
                </div>
              </div>

              <div className="flex items-center justify-between pt-1">
                <span className="text-slate-400">Today's Bonus:</span>
                <span className="font-mono text-emerald-400 font-bold">₹{incentiveBonus} Credited</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Next Milestone:</span>
                <span className="font-bold text-white">{tripsToNextBonus} rides for extra ₹300</span>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between pt-1 text-xs">
            <span className="text-[11px] text-amber-400 font-bold flex items-center gap-1">
              <span>View Target Challenges</span>
              <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </span>
            <span className="text-[10px] text-slate-400 font-mono">Ends 11:59 PM</span>
          </div>
        </div>

      </div>

      {/* ========================================================================= */}
      {/* 4. BOTTOM TIER: 3 CARDS (📊 BUSINESS • 🧾 BILL CENTER • 🚨 PROBLEM)      */}
      {/* ========================================================================= */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        
        {/* CARD 7: 📊 BUSINESS */}
        <div 
          onClick={() => onNavigatePillar('BUSINESS', 'profit-dashboard')}
          className="bg-slate-900/90 border border-slate-800 hover:border-emerald-500/50 rounded-2xl p-5 shadow-xl transition-all cursor-pointer group relative overflow-hidden flex flex-col justify-between"
        >
          <div className="absolute top-0 right-0 w-28 h-28 bg-emerald-500/5 rounded-full blur-2xl pointer-events-none" />

          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-emerald-500/15 text-emerald-400 flex items-center justify-center border border-emerald-500/30 group-hover:scale-105 transition-transform">
                  <TrendingUp className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-white tracking-wide uppercase flex items-center gap-1.5">
                    <span>📊 BUSINESS</span>
                  </h3>
                  <span className="text-[11px] text-slate-400 font-medium">Driver Enterprise P&amp;L</span>
                </div>
              </div>

              <span className="px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 text-[10px] font-mono border border-slate-700">
                P&amp;L 44AD
              </span>
            </div>

            {/* Metrics Matching ASCII: Earnings analytics • Trips / KM / Profit */}
            <div className="space-y-2 bg-slate-950/70 border border-slate-800 rounded-xl p-3 mb-3 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Earnings Analytics:</span>
                <span className="font-bold text-white font-mono">₹54,800/mo run-rate</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Trips / KM / Profit:</span>
                <span className="font-mono text-emerald-400 font-bold">₹{profitPerKm} net/km</span>
              </div>
              <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-800/80">
                <span>Fuel Cost Ratio:</span>
                <span className="font-mono text-slate-200">21.4% (Optimal)</span>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between pt-1 text-xs">
            <span className="text-[11px] text-emerald-400 font-bold flex items-center gap-1">
              <span>Open Business Reports</span>
              <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </span>
            <span className="text-[10px] text-slate-400 font-mono">Export PDF</span>
          </div>
        </div>

        {/* CARD 8: 🧾 BILL CENTER */}
        <div 
          onClick={onOpenScanReceipt}
          className="bg-slate-900/90 border border-slate-800 hover:border-emerald-500/50 rounded-2xl p-5 shadow-xl transition-all cursor-pointer group relative overflow-hidden flex flex-col justify-between"
        >
          <div className="absolute top-0 right-0 w-28 h-28 bg-emerald-500/5 rounded-full blur-2xl pointer-events-none" />

          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-emerald-500/15 text-emerald-400 flex items-center justify-center border border-emerald-500/30 group-hover:scale-105 transition-transform">
                  <Receipt className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-white tracking-wide uppercase flex items-center gap-1.5">
                    <span>🧾 BILL CENTER</span>
                  </h3>
                  <span className="text-[11px] text-slate-400 font-medium">Receipts & Invoices</span>
                </div>
              </div>

              <span className="px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 text-[10px] font-bold border border-emerald-500/30">
                OCR Scanner
              </span>
            </div>

            {/* Metrics Matching ASCII: Scan Bill • Generate PDF */}
            <div className="grid grid-cols-2 gap-2 mb-3">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onOpenScanReceipt();
                }}
                className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 hover:border-emerald-500 text-left transition-colors"
              >
                <div className="flex items-center gap-1.5 text-xs font-bold text-white mb-0.5">
                  <Receipt className="w-3.5 h-3.5 text-amber-400" />
                  <span>Scan Bill</span>
                </div>
                <div className="text-[10px] text-slate-400">CNG, Toll & Chai OCR</div>
              </button>

              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onOpenCustomerPayment();
                }}
                className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 hover:border-emerald-500 text-left transition-colors"
              >
                <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-400 mb-0.5">
                  <FileText className="w-3.5 h-3.5" />
                  <span>Generate PDF</span>
                </div>
                <div className="text-[10px] text-slate-400">VIP GST Customer Bill</div>
              </button>
            </div>
          </div>

          <div className="flex items-center justify-between pt-1 text-xs">
            <span className="text-[11px] text-emerald-400 font-bold flex items-center gap-1">
              <span>Instant WhatsApp Invoice</span>
              <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </span>
            <span className="text-[10px] font-mono text-slate-400">100% Tax Compliant</span>
          </div>
        </div>

        {/* CARD 9: 🚨 PROBLEM */}
        <div 
          onClick={() => onNavigatePillar('PROBLEM_CENTER', 'PAYMENT')}
          className="bg-slate-900/90 border border-slate-800 hover:border-rose-500/50 rounded-2xl p-5 shadow-xl transition-all cursor-pointer group relative overflow-hidden flex flex-col justify-between"
        >
          <div className="absolute top-0 right-0 w-28 h-28 bg-rose-500/5 rounded-full blur-2xl pointer-events-none" />

          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-rose-500/15 text-rose-400 flex items-center justify-center border border-rose-500/30 group-hover:scale-105 transition-transform">
                  <LifeBuoy className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-white tracking-wide uppercase flex items-center gap-1.5">
                    <span>🚨 PROBLEM</span>
                  </h3>
                  <span className="text-[11px] text-slate-400 font-medium">Disputes & Direct Support</span>
                </div>
              </div>

              <span className="px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 text-[10px] font-mono font-bold border border-rose-500/40 animate-pulse">
                9318320977
              </span>
            </div>

            {/* Metrics Matching ASCII: Report issue • Support */}
            <div className="space-y-2 bg-slate-950/70 border border-slate-800 rounded-xl p-3 mb-3 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Report Issue:</span>
                <span className="font-bold text-white">Aggregator Fare Mismatch</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Direct Support Hotline:</span>
                <span className="font-mono text-rose-400 font-bold">9318320977 (24x7)</span>
              </div>
              <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-800/80">
                <span>Ola/Uber Cut Disputes:</span>
                <span className="text-emerald-400 font-semibold">1-Click Auto Dispute</span>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between pt-1 text-xs">
            <span className="text-[11px] text-rose-400 font-bold flex items-center gap-1">
              <span>Open Driver Problem Desk</span>
              <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </span>
            <span className="text-[10px] font-mono text-slate-400">Instant Escalation</span>
          </div>
        </div>

      </div>

    </div>
  );
};
