import React, { useState, useRef } from 'react';
import { 
  Receipt, 
  PlusCircle, 
  Camera, 
  Upload, 
  Fuel, 
  Wrench, 
  FileText, 
  Sparkles, 
  CheckCircle2, 
  DollarSign, 
  CreditCard, 
  ShieldCheck, 
  Trash2,
  PieChart as PieChartIcon
} from 'lucide-react';
import { ExpenseRecord, ExpenseCategory, DriverProfile } from '../types';
import { scanReceiptOCR } from '../services/api';

interface ExpenseTrackerProps {
  driver: DriverProfile;
  expenses: ExpenseRecord[];
  onAddExpense: (expense: ExpenseRecord) => void;
  onDeleteExpense: (id: string) => void;
}

export const ExpenseTracker: React.FC<ExpenseTrackerProps> = ({
  driver,
  expenses,
  onAddExpense,
  onDeleteExpense,
}) => {
  const [activeCategoryFilter, setActiveCategoryFilter] = useState<string>('ALL');
  const [isScanning, setIsScanning] = useState(false);
  const [scanResult, setScanResult] = useState<any>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Manual Form State
  const [showManualModal, setShowManualModal] = useState(false);
  const [formCategory, setFormCategory] = useState<ExpenseCategory>('CNG_FUEL');
  const [formAmount, setFormAmount] = useState<number | ''>('');
  const [formMerchant, setFormMerchant] = useState('');
  const [formUnits, setFormUnits] = useState('');
  const [formPaymentMethod, setFormPaymentMethod] = useState<'UPI' | 'FASTAG' | 'CASH' | 'CARD'>('UPI');
  const [formTaxDeductible, setFormTaxDeductible] = useState(true);
  const [formNotes, setFormNotes] = useState('');

  // Vehicle Depreciation calculation
  const originalVehicleValue = 680000; // ₹6.8 Lakh WagonR
  const vehicleAgeYears = 3.5;
  const currentDepreciatedValue = Math.round(originalVehicleValue * Math.pow(0.85, vehicleAgeYears)); // 15% WDV
  const annualDepreciationShield = Math.round(currentDepreciatedValue * 0.15);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsScanning(true);
    setScanResult(null);

    const reader = new FileReader();
    reader.onload = async () => {
      const base64 = reader.result as string;
      try {
        const res = await scanReceiptOCR(base64, file.type || 'image/jpeg');
        if (res.extracted) {
          setScanResult(res.extracted);
          // Pre-fill manual form
          setFormMerchant(res.extracted.merchantName || 'HPCL Auto CNG');
          setFormAmount(res.extracted.totalAmount || 500);
          setFormCategory((res.extracted.category as any) || 'CNG_FUEL');
          setFormUnits(res.extracted.quantity || '');
          setFormTaxDeductible(res.extracted.isTaxDeductible !== false);
          setFormNotes(res.extracted.notes || 'Automated OCR extracted receipt');
        }
      } catch (err) {
        console.error(err);
      } finally {
        setIsScanning(false);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSaveExpense = () => {
    if (!formAmount || !formMerchant) return;

    const newExpense: ExpenseRecord = {
      id: `EXP-${Math.floor(1000 + Math.random() * 9000)}`,
      date: new Date().toISOString().split('T')[0],
      category: formCategory,
      amount: Number(formAmount),
      merchantName: formMerchant,
      litresOrUnits: formUnits || undefined,
      paymentMethod: formPaymentMethod,
      isTaxDeductible: formTaxDeductible,
      ocrConfidence: scanResult?.confidence || undefined,
      notes: formNotes,
      isEncrypted: true,
    };

    onAddExpense(newExpense);
    setShowManualModal(false);
    setScanResult(null);
    setFormAmount('');
    setFormMerchant('');
    setFormNotes('');
  };

  const filteredExpenses = expenses.filter(e => {
    if (activeCategoryFilter === 'ALL') return true;
    return e.category === activeCategoryFilter;
  });

  const totalSpent = filteredExpenses.reduce((sum, e) => sum + e.amount, 0);
  const taxDeductibleTotal = filteredExpenses.filter(e => e.isTaxDeductible).reduce((sum, e) => sum + e.amount, 0);

  return (
    <div className="space-y-6 pb-12">
      
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-amber-500/20 text-amber-400">
              <Receipt className="w-5 h-5" />
            </span>
            <h2 className="text-lg sm:text-xl font-bold text-white tracking-tight">
              Expense Intelligence & Gemini OCR Scanner
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Track fuel, tolls, garage services, EMIs, and unlock Section 44AD tax deductions.
          </p>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileUpload}
            accept="image/*"
            className="hidden"
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-slate-950 text-xs font-bold shadow-lg shadow-amber-950/40 transition-all active:scale-95"
          >
            <Camera className="w-4 h-4" />
            <span>Scan Receipt (OCR)</span>
          </button>
          <button
            onClick={() => setShowManualModal(true)}
            className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-200 text-xs font-semibold shadow transition-all"
          >
            <PlusCircle className="w-4 h-4 text-emerald-400" />
            <span>Manual Entry</span>
          </button>
        </div>
      </div>

      {/* OCR Scanner Live Banner / Dropzone if scanning */}
      {isScanning && (
        <div className="p-6 rounded-2xl bg-slate-900 border border-amber-500/40 text-center space-y-3 animate-pulse">
          <Sparkles className="w-8 h-8 text-amber-400 mx-auto animate-spin" />
          <div className="text-sm font-bold text-white">Gemini Vision OCR Processing Receipt...</div>
          <p className="text-xs text-slate-400">Extracting merchant, litres, GST number, and Section 44AD tax deductibility.</p>
        </div>
      )}

      {/* OCR Verification Banner if scanned */}
      {scanResult && !showManualModal && (
        <div className="p-5 rounded-2xl bg-slate-900 border border-emerald-500/50 shadow-xl space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-emerald-400 flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4" /> Gemini OCR Receipt Successfully Analyzed
            </span>
            <span className="text-xs font-mono bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded">
              {Math.round((scanResult.confidence || 0.95) * 100)}% Confidence
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs bg-slate-950 p-3.5 rounded-xl border border-slate-800">
            <div>
              <span className="text-slate-400 block text-[10px]">MERCHANT</span>
              <strong className="text-white">{scanResult.merchantName}</strong>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px]">AMOUNT</span>
              <strong className="text-xl text-emerald-400 font-mono">₹{scanResult.totalAmount}</strong>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px]">CATEGORY</span>
              <strong className="text-amber-300">{scanResult.category}</strong>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px]">TAX DEDUCTION</span>
              <strong className="text-sky-300">{scanResult.isTaxDeductible ? 'Eligible (44AD)' : 'Non-Deductible'}</strong>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-1">
            <button
              onClick={() => setScanResult(null)}
              className="px-3 py-1.5 text-xs text-slate-400 hover:text-slate-200"
            >
              Discard
            </button>
            <button
              onClick={() => setShowManualModal(true)}
              className="px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow transition-all"
            >
              Verify & Save to Encrypted Ledger
            </button>
          </div>
        </div>
      )}

      {/* Aggregate KPI Strip & Vehicle Depreciation Shield */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg">
          <div className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center justify-between">
            <span>Total Recorded Expenses</span>
            <Receipt className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl sm:text-3xl font-black text-white font-mono mt-2">
            ₹{totalSpent.toLocaleString('en-IN')}
          </div>
          <div className="text-xs text-slate-400 mt-1">
            {filteredExpenses.length} entries tracked
          </div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg">
          <div className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center justify-between">
            <span>Section 44AD Tax Deductible</span>
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl sm:text-3xl font-black text-emerald-400 font-mono mt-2">
            ₹{taxDeductibleTotal.toLocaleString('en-IN')}
          </div>
          <div className="text-xs text-emerald-300 font-medium mt-1">
            Saves ~₹{Math.round(taxDeductibleTotal * 0.15)} in income tax
          </div>
        </div>

        {/* Vehicle Depreciation Shield */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg">
          <div className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center justify-between">
            <span>Vehicle Asset Shield</span>
            <Wrench className="w-4 h-4 text-sky-400" />
          </div>
          <div className="text-2xl sm:text-3xl font-black text-sky-300 font-mono mt-2">
            ₹{currentDepreciatedValue.toLocaleString('en-IN')}
          </div>
          <div className="text-xs text-slate-400 mt-1">
            Annual Depreciation write-off: <strong className="text-sky-300 font-mono">₹{annualDepreciationShield}</strong>
          </div>
        </div>

      </div>

      {/* Category Filter Pills */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-2">
        {[
          { id: 'ALL', label: 'All Expenses' },
          { id: 'CNG_FUEL', label: 'CNG Fuel' },
          { id: 'TOLL', label: 'Tolls & FASTag' },
          { id: 'MAINTENANCE', label: 'Maintenance & Service' },
          { id: 'VEHICLE_LOAN_EMI', label: 'Loan EMIs' },
          { id: 'INSURANCE_EMI', label: 'Insurance' },
          { id: 'CHAI_SNACKS', label: 'Chai & Meals' },
        ].map(cat => (
          <button
            key={cat.id}
            onClick={() => setActiveCategoryFilter(cat.id)}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
              activeCategoryFilter === cat.id
                ? 'bg-amber-500 text-slate-950 font-bold shadow-md'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-750 border border-slate-700'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Expense List Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="p-4 border-b border-slate-800 flex items-center justify-between">
          <h3 className="text-sm font-bold text-white">Expense Ledger Records</h3>
          <span className="text-xs text-slate-400 font-mono">AES-256 Client Encrypted</span>
        </div>

        <div className="divide-y divide-slate-800">
          {filteredExpenses.map((exp) => (
            <div key={exp.id} className="p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 hover:bg-slate-850/50 transition-colors">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-white">{exp.merchantName}</span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-amber-300 border border-slate-700">
                    {exp.category.replace('_', ' ')}
                  </span>
                  {exp.isTaxDeductible && (
                    <span className="text-[10px] font-semibold text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded">
                      44AD Eligible
                    </span>
                  )}
                </div>
                <div className="text-xs text-slate-400 flex items-center gap-2">
                  <span>{exp.date}</span>
                  <span>•</span>
                  <span>Paid via {exp.paymentMethod}</span>
                  {exp.litresOrUnits && (
                    <>
                      <span>•</span>
                      <span className="text-slate-300 font-mono">{exp.litresOrUnits}</span>
                    </>
                  )}
                  {exp.notes && (
                    <>
                      <span>•</span>
                      <span className="italic text-slate-400">{exp.notes}</span>
                    </>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-4 self-end sm:self-auto">
                <div className="text-right">
                  <div className="text-lg font-black text-rose-300 font-mono">
                    ₹{exp.amount.toLocaleString('en-IN')}
                  </div>
                  {exp.ocrConfidence && (
                    <span className="text-[10px] text-emerald-400">OCR Verified</span>
                  )}
                </div>
                <button
                  onClick={() => onDeleteExpense(exp.id)}
                  className="p-2 text-slate-500 hover:text-rose-400 transition-colors"
                  title="Delete Expense"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Manual / Verified Expense Add Modal */}
      {showManualModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-5 space-y-4 shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Receipt className="w-4 h-4 text-amber-400" /> Log Business Expense
              </h3>
              <button
                onClick={() => setShowManualModal(false)}
                className="text-slate-400 hover:text-white text-xs"
              >
                Cancel
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-slate-400 font-medium block mb-1">Category</label>
                <select
                  value={formCategory}
                  onChange={(e) => setFormCategory(e.target.value as any)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                >
                  <option value="CNG_FUEL">CNG Fuel</option>
                  <option value="PETROL_DIESEL">Petrol / Diesel</option>
                  <option value="EV_CHARGE">EV Fast Charging</option>
                  <option value="TOLL">Toll Plaza / FASTag</option>
                  <option value="MAINTENANCE">Vehicle Maintenance & Service</option>
                  <option value="VEHICLE_LOAN_EMI">Vehicle Loan EMI</option>
                  <option value="INSURANCE_EMI">Insurance EMI</option>
                  <option value="CAR_WASH">Car Wash & Detailing</option>
                  <option value="CHAI_SNACKS">Chai & Driver Meals</option>
                  <option value="CHALLAN_RTO">Traffic Challan / RTO Fee</option>
                  <option value="OTHER">Other Expense</option>
                </select>
              </div>

              <div>
                <label className="text-slate-400 font-medium block mb-1">Merchant / Station / Plaza Name</label>
                <input
                  type="text"
                  value={formMerchant}
                  onChange={(e) => setFormMerchant(e.target.value)}
                  placeholder="e.g. GAIL Gas CNG Bellandur"
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-400 font-medium block mb-1">Amount (₹)</label>
                  <input
                    type="number"
                    value={formAmount}
                    onChange={(e) => setFormAmount(Number(e.target.value))}
                    placeholder="e.g. 650"
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono focus:outline-none focus:border-amber-500"
                  />
                </div>
                <div>
                  <label className="text-slate-400 font-medium block mb-1">Units (Kg / Litres / KWh)</label>
                  <input
                    type="text"
                    value={formUnits}
                    onChange={(e) => setFormUnits(e.target.value)}
                    placeholder="e.g. 7.2 Kg"
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-400 font-medium block mb-1">Payment Method</label>
                  <select
                    value={formPaymentMethod}
                    onChange={(e) => setFormPaymentMethod(e.target.value as any)}
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  >
                    <option value="UPI">UPI (GPay / PhonePe)</option>
                    <option value="FASTAG">FASTag Auto-Debit</option>
                    <option value="CASH">Cash</option>
                    <option value="CARD">Debit / Credit Card</option>
                  </select>
                </div>
                <div>
                  <label className="text-slate-400 font-medium block mb-1">Tax Deductible?</label>
                  <label className="flex items-center gap-2 mt-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formTaxDeductible}
                      onChange={(e) => setFormTaxDeductible(e.target.checked)}
                      className="rounded bg-slate-800 border-slate-700 text-emerald-500 focus:ring-0"
                    />
                    <span className="text-slate-200">Yes, Claim Sec 44AD</span>
                  </label>
                </div>
              </div>

              <div>
                <label className="text-slate-400 font-medium block mb-1">Notes / Description</label>
                <input
                  type="text"
                  value={formNotes}
                  onChange={(e) => setFormNotes(e.target.value)}
                  placeholder="e.g. Engine oil replacement at 40,000 km"
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>

            <button
              onClick={handleSaveExpense}
              disabled={!formAmount || !formMerchant}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 text-white text-xs font-bold shadow-lg transition-all disabled:opacity-50"
            >
              Save to Encrypted Business Ledger
            </button>
          </div>
        </div>
      )}

    </div>
  );
};
