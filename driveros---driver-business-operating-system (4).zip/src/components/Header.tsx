import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Mic, 
  PlusCircle, 
  Receipt, 
  Globe, 
  Radio, 
  Lock, 
  Car,
  AlertTriangle,
  Zap,
  LayoutDashboard,
  MapPin,
  FileSpreadsheet,
  Wallet,
  HeartPulse,
  Users,
  FileText,
  Shield,
  UserCheck,
  Banknote,
  QrCode,
  Eye,
  EyeOff,
  Layers,
  TrendingUp,
  Building2,
  DollarSign,
  Award,
  ChevronRight,
  Phone,
  HelpCircle,
  Gift,
  Smartphone,
  Navigation,
  Compass,
  LifeBuoy,
  Fuel,
  Wrench,
  AlertOctagon,
  Moon,
  Gauge,
  Bell,
  Home,
  Brain,
  Key,
  Activity,
  X,
  Clock,
  RefreshCw
} from 'lucide-react';
import { DriverProfile, ShiftState, MicroInsuranceState, FatigueMonitoringState } from '../types';

export type MainPillar = 
  | 'HOME'
  | 'TODAY'
  | 'CUSTOMER_BOOKING'
  | 'RIDE_WORK' 
  | 'DRIVER_INTELLIGENCE'
  | 'SMART_MOBILITY'
  | 'SMART_MAP'
  | 'SAATHI_AI' 
  | 'MONEY' 
  | 'VEHICLE' 
  | 'SAFETY' 
  | 'BUSINESS' 
  | 'DOCUMENT_BILL_ENGINE'
  | 'TRUST_IDENTITY'
  | 'REALTIME_OPERATIONS'
  | 'PLATFORM_HUB' 
  | 'INCENTIVES' 
  | 'PROBLEM_CENTER'
  | 'WORK' 
  | 'INSIGHTS';

export interface HeaderProps {
  driver: DriverProfile;
  shift: ShiftState;
  onToggleDuty: () => void;
  insurance?: MicroInsuranceState;
  fatigue?: FatigueMonitoringState;
  activePillar: MainPillar;
  activeSubView: string;
  onSelectPillar: (pillar: MainPillar, defaultSubView?: string) => void;
  onSelectSubView: (subView: string) => void;
  onOpenVoice: () => void;
  onOpenNewTrip: () => void;
  onOpenScanReceipt: () => void;
  onOpenDriverAuth?: () => void;
  onOpenCustomerPayment?: () => void;
  onOpenBookingFlow?: () => void;
  activeBookingRide?: any;
  onLockApp?: () => void;
  privacyBlurActive?: boolean;
  onTogglePrivacyBlur?: () => void;
  activeLanguage?: string;
  onLanguageChange: (lang: string) => void;
}

export const PILLARS_CONFIG = [
  {
    id: 'HOME' as const,
    label: '🏠 HOME',
    icon: Home,
    badge: 'Master',
    defaultSub: 'overview',
    subItems: [
      { id: 'overview', label: 'Driver OS Dashboard', icon: LayoutDashboard },
    ],
  },
  {
    id: 'RIDE_WORK' as const,
    label: '🚕 1. RIDE COMMAND',
    icon: Car,
    badge: 'Live',
    defaultSub: 'new-ride',
    subItems: [
      { id: 'new-ride', label: 'New Ride Match', icon: PlusCircle },
      { id: 'accept-reject', label: 'Accept / Reject', icon: CheckCircle2Icon },
      { id: 'pickup', label: 'Smart Pickup Verify', icon: MapPin },
      { id: 'drop', label: 'Multi-Stop Drop', icon: Navigation },
      { id: 'meter', label: 'Ride State Meter', icon: Gauge },
      { id: 'route-nav', label: 'Navigation', icon: Compass },
      { id: 'cancel', label: 'Cancellation Intel', icon: AlertOctagon },
    ],
  },
  {
    id: 'DRIVER_INTELLIGENCE' as const,
    label: '🧠 2. DRIVER INTEL',
    icon: Brain,
    badge: 'AI ROI',
    defaultSub: 'earnings-prediction',
    subItems: [
      { id: 'earnings-prediction', label: 'Earnings Prediction', icon: TrendingUp },
      { id: 'demand-forecasting', label: 'Demand Forecasting', icon: Zap },
      { id: 'best-zone', label: 'Best-Zone ROI', icon: MapPin },
      { id: 'dead-mile', label: 'Dead-Mile Detection', icon: Gauge },
      { id: 'profit-per-km', label: 'Profit/KM Analysis', icon: DollarSign },
      { id: 'hourly-prediction', label: 'Hourly Earning Curve', icon: Clock },
    ],
  },
  {
    id: 'SMART_MOBILITY' as const,
    label: '🗺️ 3. SMART MOBILITY',
    icon: Compass,
    badge: 'GPS',
    defaultSub: 'moving-car',
    subItems: [
      { id: 'real-time-traffic', label: 'Real-Time Traffic', icon: Zap },
      { id: 'route-optimization', label: 'Route Optimizer', icon: Navigation },
      { id: 'demand-heatmap', label: 'Demand Heatmap', icon: TrendingUp },
      { id: 'fuel-routing', label: 'Fuel-Aware Routing', icon: Fuel },
      { id: 'toll-routing', label: 'Toll-Aware (FASTag)', icon: Receipt },
      { id: 'ev-charging', label: 'EV Charging Opt', icon: Zap },
      { id: 'parking-intel', label: 'Parking Staging', icon: MapPin },
      { id: 'moving-car', label: 'Live Moving Fleet', icon: Car },
    ],
  },
  {
    id: 'SAATHI_AI' as const,
    label: '🤖 4. SAATHI AI',
    icon: Mic,
    badge: 'Voice',
    defaultSub: 'ask-anything',
    subItems: [
      { id: 'ask-anything', label: 'Ask Anything', icon: Mic },
      { id: 'trip-briefing', label: 'Trip Briefing', icon: Navigation },
      { id: 'earnings-advice', label: 'Earnings QA', icon: TrendingUp },
      { id: 'route-advice', label: 'Route Explanation', icon: Compass },
      { id: 'driver-alerts', label: 'Driver Alerts', icon: AlertTriangle },
      { id: 'daily-summary', label: 'Daily Performance Summary', icon: Award },
    ],
  },
  {
    id: 'MONEY' as const,
    label: '💰 5. FINANCIAL OS',
    icon: DollarSign,
    badge: '₹ Net',
    defaultSub: 'today-earnings',
    subItems: [
      { id: 'today-earnings', label: "Gross & Net Earnings", icon: DollarSign },
      { id: 'fuel-cost', label: 'Fuel Expense (CNG/Petrol)', icon: Fuel },
      { id: 'toll-tax', label: 'Toll Expense (FASTag)', icon: Receipt },
      { id: 'maintenance-cost', label: 'Maintenance Cost', icon: Wrench },
      { id: 'profit-km', label: 'Profit/KM Margin', icon: Gauge },
      { id: 'monthly-pnl', label: 'Daily/Weekly/Monthly P&L', icon: FileSpreadsheet },
      { id: 'tax-reports', label: 'Tax Reports (44AD)', icon: FileText },
    ],
  },
  {
    id: 'VEHICLE' as const,
    label: '🚗 6. VEHICLE INTEL',
    icon: Wrench,
    badge: '94/100',
    defaultSub: 'profile',
    subItems: [
      { id: 'service-prediction', label: 'Service Prediction', icon: Wrench },
      { id: 'maintenance-timeline', label: 'Maintenance Timeline', icon: Clock },
      { id: 'fuel-efficiency', label: 'Fuel Efficiency', icon: Fuel },
      { id: 'battery-health', label: 'Battery Health (EV)', icon: Zap },
      { id: 'reminders', label: 'Tyre & Service Reminders', icon: AlertTriangle },
      { id: 'health-score', label: 'Vehicle Health Score', icon: ShieldCheck },
    ],
  },
  {
    id: 'SAFETY' as const,
    label: '🛡️ 7. SAFETY CENTER',
    icon: ShieldCheck,
    badge: '₹5L',
    defaultSub: 'emergency-sos',
    subItems: [
      { id: 'emergency-sos', label: 'Emergency SOS (1-Tap)', icon: AlertOctagon },
      { id: 'emergency-contacts', label: 'Emergency Contacts', icon: Phone },
      { id: 'trip-sharing', label: 'Live Trip Sharing', icon: Compass },
      { id: 'incident-recording', label: 'Incident Recording', icon: Shield },
      { id: 'risk-zones', label: 'Risk-Zone Alerts', icon: AlertTriangle },
      { id: 'safety-score', label: 'Driver Safety Score', icon: HeartPulse },
    ],
  },
  {
    id: 'BUSINESS' as const,
    label: '📊 8. BUSINESS INTEL',
    icon: Building2,
    badge: 'BI',
    defaultSub: 'profit-dashboard',
    subItems: [
      { id: 'profit-dashboard', label: 'Earnings Dashboard', icon: TrendingUp },
      { id: 'ride-analytics', label: 'Ride Analytics', icon: Car },
      { id: 'acceptance-rate', label: 'Acceptance Rate (91%)', icon: CheckCircle2Icon },
      { id: 'cancellation-rate', label: 'Cancellation Rate (3.2%)', icon: AlertOctagon },
      { id: 'fleet-utilization', label: 'Fleet Utilization (83%)', icon: Gauge },
      { id: 'peak-hour', label: 'Peak-Hour Analysis', icon: Clock },
      { id: 'performance-trends', label: 'Performance Trends', icon: Award },
    ],
  },
  {
    id: 'DOCUMENT_BILL_ENGINE' as const,
    label: '🧾 9. BILL & DOCS',
    icon: Receipt,
    badge: '0% Dup',
    defaultSub: 'digital-receipts',
    subItems: [
      { id: 'digital-receipts', label: 'Digital Receipts', icon: FileText },
      { id: 'pdf-on-demand', label: 'PDF On Demand', icon: Receipt },
      { id: 'cloud-bill-history', label: 'Cloud Bill History', icon: Layers },
      { id: 'invoice-search', label: 'Invoice Search', icon: Receipt },
      { id: 'expense-records', label: 'Expense Records', icon: DollarSign },
      { id: 'no-dup-engine', label: 'Zero PDF Duplication', icon: ShieldCheck },
    ],
  },
  {
    id: 'TRUST_IDENTITY' as const,
    label: '🔐 10. TRUST & IDENTITY',
    icon: Key,
    badge: 'DigiLocker',
    defaultSub: 'driver-verify',
    subItems: [
      { id: 'driver-verify', label: 'Driver Verification', icon: UserCheck },
      { id: 'vehicle-verify', label: 'Vehicle Verification (RC)', icon: Car },
      { id: 'session-manage', label: 'Device / Session Mgmt', icon: Smartphone },
      { id: 'role-access', label: 'Role-Based Access', icon: Lock },
      { id: 'audit-history', label: 'Audit History Logs', icon: FileText },
      { id: 'privacy-controls', label: 'Privacy Blur Controls', icon: EyeOff },
    ],
  },
  {
    id: 'REALTIME_OPERATIONS' as const,
    label: '⚡ 11. REAL-TIME OPS',
    icon: Activity,
    badge: '24ms',
    defaultSub: 'ws-live',
    subItems: [
      { id: 'ws-live', label: 'WebSocket Live Updates', icon: Zap },
      { id: 'driver-location', label: 'Driver Location Telemetry', icon: MapPin },
      { id: 'ride-sync', label: 'Ride Status Sync', icon: Radio },
      { id: 'fleet-monitor', label: 'Fleet Peer Monitoring', icon: Car },
      { id: 'system-health', label: 'System Health Diagnostics', icon: ShieldCheck },
      { id: 'offline-recovery', label: 'Offline / Online Recovery', icon: RefreshCw },
    ],
  },
  {
    id: 'PLATFORM_HUB' as const,
    label: '🔌 12. PLATFORM HUB',
    icon: Smartphone,
    badge: 'Aggregator',
    defaultSub: 'ola-earnings',
    subItems: [
      { id: 'maps-api', label: 'Maps API (Google/OSM)', icon: MapPin },
      { id: 'payment-gateway', label: 'Payment Gateway (UPI/Card)', icon: DollarSign },
      { id: 'notification-service', label: 'Notification Service', icon: Bell },
      { id: 'ai-provider', label: 'AI Provider (Gemini Flash)', icon: Mic },
      { id: 'insurance-provider', label: 'Insurance Provider', icon: ShieldCheck },
      { id: 'ev-fuel-apis', label: 'EV / Fuel APIs', icon: Fuel },
      { id: 'webhook-management', label: 'Webhook Management', icon: Layers },
    ],
  },
  {
    id: 'CUSTOMER_BOOKING' as const,
    label: '📱 CUSTOMER APP',
    icon: Smartphone,
    badge: 'Passenger',
    defaultSub: 'book-ride',
    subItems: [
      { id: 'book-ride', label: 'Book Ride (Passenger App)', icon: Car },
      { id: 'flow-architecture', label: 'Ride Flow State Machine', icon: Compass },
    ],
  },
  {
    id: 'PROBLEM_CENTER' as const,
    label: '🚨 PROBLEM CENTER',
    icon: LifeBuoy,
    badge: '9318320977',
    defaultSub: 'PAYMENT',
    subItems: [
      { id: 'PAYMENT', label: '💳 Payment Issues', icon: DollarSign },
      { id: 'RIDE', label: '🚕 Ride Issues', icon: Car },
      { id: 'SUPPORT', label: '👨💼 Driver Support (24x7)', icon: HelpCircle },
    ],
  },
];

// Helper icons placeholder
function CheckCircle2Icon(props: any) {
  return <ShieldCheck {...props} />;
}
function WindIcon(props: any) {
  return <Zap {...props} />;
}

export const Header: React.FC<HeaderProps> = ({
  driver,
  shift,
  onToggleDuty,
  insurance,
  fatigue,
  activePillar,
  activeSubView,
  onSelectPillar,
  onSelectSubView,
  onOpenVoice,
  onOpenNewTrip,
  onOpenScanReceipt,
  onOpenDriverAuth,
  onOpenCustomerPayment,
  onOpenBookingFlow,
  activeBookingRide,
  onLockApp,
  privacyBlurActive = false,
  onTogglePrivacyBlur,
  activeLanguage = 'en',
  onLanguageChange,
}) => {
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const isFatigued = fatigue?.isWarningTriggered ?? false;
  const breakCountdown = fatigue?.restBreakCountdownMinutes ?? 38;

  const currentPillarConfig = PILLARS_CONFIG.find(p => p.id === activePillar) || PILLARS_CONFIG[0];

  return (
    <header className="sticky top-0 z-40 bg-slate-900/95 backdrop-blur-md border-b border-slate-800 shadow-xl">
      {/* Top Banner Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-2.5">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
          
          {/* Brand & Driver Identity (Matching ASCII: 🚗 DRIVESMART / DRIVEROS • AI Driver Operating System) */}
          <div className="flex items-center gap-3 w-full md:w-auto justify-between md:justify-start">
            <div className="flex items-center gap-2.5">
              <button
                onClick={() => onSelectPillar('HOME')}
                title="DriveSmart Driver OS Home"
                className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-700 flex items-center justify-center shadow-lg shadow-emerald-500/20 ring-1 ring-emerald-400/40 hover:scale-105 transition-transform cursor-pointer"
              >
                <Car className="w-5 h-5 text-white" />
              </button>
              <div>
                <div className="flex items-center gap-1.5">
                  <h1 className="text-lg font-black tracking-tight text-white flex items-center gap-1.5">
                    <span>DRIVESMART</span>
                    <span className="text-slate-500">/</span>
                    <span className="text-[11px] uppercase font-mono px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                      DRIVEROS
                    </span>
                  </h1>
                  <span className="flex h-2 w-2 relative" title="AI Driver Operating System Active">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                  </span>
                </div>

                <div className="text-[11px] text-slate-400 font-medium">
                  AI Driver Operating System
                </div>
              </div>
            </div>

            {/* Mobile Actions Trigger */}
            <div className="flex md:hidden items-center gap-2">
              <button
                onClick={() => onSelectPillar('SMART_MAP', 'moving-car')}
                className={`p-2 rounded-lg border transition-all active:scale-95 ${
                  activePillar === 'SMART_MAP'
                    ? 'bg-emerald-500 text-slate-950 border-emerald-400 shadow-md'
                    : 'bg-emerald-950/40 text-emerald-400 border-emerald-500/40 hover:bg-emerald-900/40'
                }`}
                title="Live Map with Car"
              >
                <Car className="w-4 h-4" />
              </button>
              <button
                onClick={onOpenCustomerPayment}
                className="p-2 rounded-lg bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-500/30 active:scale-95"
                title="Customer Payment & PDF Bill"
              >
                <Banknote className="w-4 h-4" />
              </button>
              <button
                onClick={onOpenVoice}
                className="p-2 rounded-lg bg-slate-800 text-slate-300 border border-slate-700 hover:bg-slate-700 active:scale-95"
                title="Saathi Voice Assistant"
              >
                <Mic className="w-4 h-4" />
              </button>
              <button
                onClick={onToggleDuty}
                className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                  shift.isOnDuty 
                    ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30 ring-1 ring-emerald-400' 
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                <Radio className={`w-3.5 h-3.5 ${shift.isOnDuty ? 'animate-pulse text-emerald-200' : 'text-slate-400'}`} />
                {shift.isOnDuty ? 'ON' : 'OFF'}
              </button>
            </div>
          </div>

          {/* Status Indicators & Control Center */}
          <div className="flex items-center flex-wrap gap-2 w-full md:w-auto justify-end">
            
            {/* Direct Match to ASCII Top Right: 🟢 LIVE or ⏸️ OFF-DUTY */}
            <div className="flex items-center gap-2 sm:gap-3 bg-slate-950/70 border border-slate-800 rounded-xl px-3 py-1.5">
              {/* Duty Live/Offline badge */}
              <div className={`flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold border transition-colors ${
                shift.isOnDuty 
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' 
                  : 'bg-slate-800 text-slate-400 border-slate-700'
              }`}>
                <span className={`w-2 h-2 rounded-full ${shift.isOnDuty ? 'bg-emerald-400 animate-ping' : 'bg-slate-500'}`} />
                <span>{shift.isOnDuty ? '🟢 LIVE' : '⏸️ OFF-DUTY'}</span>
              </div>

              {/* 🔔 Notification Bell */}
              <div className="relative">
                <button
                  onClick={() => setIsNotificationsOpen(!isNotificationsOpen)}
                  className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors relative cursor-pointer"
                  title="Live Driver Alerts"
                >
                  <Bell className="w-4 h-4" />
                  <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-amber-400" />
                </button>

                {/* Notifications Popover */}
                {isNotificationsOpen && (
                  <div 
                    className="absolute right-0 top-10 z-50 w-72 bg-slate-900 border border-slate-700 rounded-2xl p-3 shadow-2xl space-y-2 text-xs animate-in fade-in duration-150"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <div className="flex items-center justify-between pb-1.5 border-b border-slate-800 font-bold text-white">
                      <span>Live Driver Alerts (3)</span>
                      <button onClick={() => setIsNotificationsOpen(false)} className="text-slate-400 hover:text-white">
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <div className="space-y-1.5">
                      <div className="p-2 rounded-xl bg-slate-950 border border-emerald-500/30 text-slate-200">
                        <div className="font-bold text-emerald-400 text-[11px] flex items-center gap-1">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                          High Surge Alert (Indiranagar)
                        </div>
                        <div className="text-[10px] text-slate-400 mt-0.5">Surge +2.2x active. Airport drops earning ₹1,100+.</div>
                      </div>
                      <div className="p-2 rounded-xl bg-slate-950 border border-amber-500/30 text-slate-200">
                        <div className="font-bold text-amber-400 text-[11px] flex items-center gap-1">
                          <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
                          CNG Queue Zero-Wait
                        </div>
                        <div className="text-[10px] text-slate-400 mt-0.5">GAIL Koramangala pump 3 open, ₹88.50/kg.</div>
                      </div>
                      <div className="p-2 rounded-xl bg-slate-950 border border-sky-500/30 text-slate-200">
                        <div className="font-bold text-sky-400 text-[11px] flex items-center gap-1">
                          <span className="w-1.5 h-1.5 rounded-full bg-sky-400" />
                          Incentive Milestone
                        </div>
                        <div className="text-[10px] text-slate-400 mt-0.5">3 more trips to unlock ₹300 evening bonus.</div>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Driver Identity Card: Ramesh Kumar / KA-05-AB-9821 */}
              <button
                onClick={onOpenDriverAuth}
                className="flex flex-col text-right cursor-pointer hover:opacity-80 transition-opacity"
                title="Switch Driver / View Profile"
              >
                <div className="text-xs font-black text-white flex items-center justify-end gap-1">
                  <span>{driver.name}</span>
                </div>
                <div className="text-[10px] font-mono text-amber-400 font-bold">
                  {driver.vehiclePlate}
                </div>
              </button>
            </div>
            
            {/* Driver Switcher Button (Desktop) */}
            <button
              onClick={onOpenDriverAuth}
              className="hidden lg:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-300 hover:text-white text-xs font-medium transition-colors cursor-pointer"
              title="Driver Profile & Login Switcher"
            >
              <UserCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>Switch Driver</span>
            </button>

            {/* Duty Status Button (Desktop) */}
            <button
              onClick={onToggleDuty}
              className={`hidden md:flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                shift.isOnDuty 
                  ? 'bg-emerald-600/90 text-white border border-emerald-400 shadow-md shadow-emerald-900/40 hover:bg-emerald-500' 
                  : 'bg-slate-800 text-slate-300 border border-slate-700 hover:bg-slate-750'
              }`}
            >
              <Radio className={`w-3.5 h-3.5 ${shift.isOnDuty ? 'animate-pulse text-emerald-200' : 'text-slate-400'}`} />
              <span>{shift.isOnDuty ? 'DUTY ACTIVE' : 'START SHIFT'}</span>
              {shift.isOnDuty && (
                <span className="text-[10px] bg-emerald-950/60 px-1.5 py-0.5 rounded text-emerald-200 font-mono">
                  LIVE
                </span>
              )}
            </button>

            {/* Micro Insurance Badge */}
            <div className="hidden xl:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-800/80 border border-slate-700 text-xs text-slate-300">
              <ShieldCheck className="w-4 h-4 text-sky-400" />
              <div className="flex flex-col text-left">
                <span className="text-[10px] text-slate-400 font-medium leading-none">Micro-Insurance</span>
                <span className="text-[11px] font-semibold text-sky-300 leading-tight">
                  {insurance?.activePolicyName ? insurance.activePolicyName.split(' - ')[0] : '₹5L Active Cover'}
                </span>
              </div>
            </div>

            {/* Fatigue / Alertness Indicator */}
            <div className={`hidden xl:flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border text-xs ${
              isFatigued 
                ? 'bg-amber-950/50 border-amber-500/60 text-amber-300 animate-pulse' 
                : 'bg-slate-800/80 border-slate-700 text-slate-300'
            }`}>
              {isFatigued ? (
                <AlertTriangle className="w-4 h-4 text-amber-400" />
              ) : (
                <Zap className="w-4 h-4 text-emerald-400" />
              )}
              <div className="flex flex-col text-left">
                <span className="text-[10px] text-slate-400 font-medium leading-none">Alertness Status</span>
                <span className="text-[11px] font-semibold text-slate-200 leading-tight">
                  {breakCountdown}m till Chai Break
                </span>
              </div>
            </div>

            {/* Language Selector */}
            <div className="relative flex items-center bg-slate-800 border border-slate-700 rounded-lg px-2 py-1">
              <Globe className="w-3.5 h-3.5 text-slate-400 mr-1.5" />
              <select
                value={driver.preferredLanguage || activeLanguage}
                onChange={(e) => onLanguageChange(e.target.value)}
                aria-label="Select Application Language"
                className="bg-transparent text-xs text-slate-200 font-medium focus:outline-none cursor-pointer"
              >
                <option value="en" className="bg-slate-900 text-slate-200">English</option>
                <option value="hi" className="bg-slate-900 text-slate-200">हिंदी (Hindi)</option>
                <option value="kn" className="bg-slate-900 text-slate-200">ಕನ್ನಡ (Kannada)</option>
                <option value="ta" className="bg-slate-900 text-slate-200">தமிழ் (Tamil)</option>
                <option value="mr" className="bg-slate-900 text-slate-200">मराठी (Marathi)</option>
                <option value="te" className="bg-slate-900 text-slate-200">తెలుగు (Telugu)</option>
              </select>
            </div>

            {/* Voice Assistant Trigger */}
            <button
              onClick={onOpenVoice}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500/15 hover:bg-emerald-500/25 border border-emerald-500/30 text-emerald-300 text-xs font-semibold transition-all active:scale-95 shadow-sm"
            >
              <Mic className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
              <span>Saathi Voice</span>
            </button>

            {/* Ultra Defense Quick Lock & Privacy Buttons */}
            <button
              onClick={onTogglePrivacyBlur}
              className={`p-1.5 rounded-lg border text-xs font-semibold transition-all active:scale-95 cursor-pointer ${
                privacyBlurActive 
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/50 ring-1 ring-amber-400/40' 
                  : 'bg-slate-800 text-slate-400 hover:text-slate-200 border-slate-700'
              }`}
              title={privacyBlurActive ? 'Disable Anti-Peep Blur Mask' : 'Enable Anti-Peep Blur Mask (Hides numbers from passenger view)'}
            >
              {privacyBlurActive ? <EyeOff className="w-3.5 h-3.5 text-amber-400" /> : <Eye className="w-3.5 h-3.5" />}
            </button>

            <button
              onClick={onLockApp}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-750 border border-slate-700 text-emerald-400 hover:text-emerald-300 text-xs transition-colors cursor-pointer"
              title="Lock Vault Instantly"
            >
              <Lock className="w-3.5 h-3.5" />
            </button>

            {/* Quick Action: Live Map with Car */}
            <button
              onClick={() => onSelectPillar('SMART_MAP', 'moving-car')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all active:scale-95 shadow-sm cursor-pointer ${
                activePillar === 'SMART_MAP'
                  ? 'bg-emerald-500 text-slate-950 shadow-md ring-2 ring-emerald-300 font-extrabold'
                  : 'bg-emerald-950/60 hover:bg-emerald-900/60 border border-emerald-500/50 text-emerald-300'
              }`}
              title="Open Live Map with Moving Car Fleet"
            >
              <Car className="w-3.5 h-3.5 text-emerald-400" />
              <span className="hidden sm:inline">Map with Car</span>
              <span className="sm:hidden">Map</span>
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            </button>

            {/* Quick Action: Customer Booking App (Direct simulation of user diagram) */}
            <button
              onClick={() => onSelectPillar('CUSTOMER_BOOKING', 'book-ride')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all active:scale-95 shadow-sm cursor-pointer ${
                activePillar === 'CUSTOMER_BOOKING'
                  ? 'bg-indigo-500 text-white ring-2 ring-indigo-300 font-extrabold shadow-md'
                  : 'bg-indigo-500/20 hover:bg-indigo-500/30 border border-indigo-500/40 text-indigo-300'
              }`}
              title="Open Customer App & Booking Flow Simulator"
            >
              <Smartphone className="w-3.5 h-3.5 text-indigo-400" />
              <span className="hidden sm:inline">📱 Customer App</span>
              <span className="sm:hidden">Customer</span>
            </button>

            {/* Quick Action: DriverOS Active Ride Request Flow Modal Trigger */}
            {onOpenBookingFlow && (
              <button
                onClick={onOpenBookingFlow}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-300 text-xs font-black transition-all active:scale-95 shadow-sm cursor-pointer animate-pulse"
                title="Open DriverOS Ride Request Modal (Airport -> Whitefield ₹650)"
              >
                <span>🚨</span>
                <span className="hidden sm:inline">Ride Flow</span>
              </button>
            )}

            {/* Quick Action: Customer Payment & PDF Receipt */}
            <button
              onClick={onOpenCustomerPayment}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-300 text-xs font-bold transition-all active:scale-95 shadow-sm cursor-pointer"
              title="Collect Customer Payment & Generate PDF Bill"
            >
              <Banknote className="w-3.5 h-3.5 text-emerald-400" />
              <span className="hidden sm:inline">Pay & PDF Bill</span>
              <span className="sm:hidden">Pay</span>
            </button>

            {/* DRIVE SMART SUPPORT HOTLINE: 9318320977 */}
            <button
              onClick={() => onSelectPillar('PROBLEM_CENTER', 'PAYMENT')}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-red-950/60 hover:bg-red-900/60 border border-red-500/50 text-red-300 hover:text-white text-xs font-black transition-all active:scale-95 shadow-sm cursor-pointer"
              title="DriveSmart Driver Problem Desk & Support Hotline (9318320977)"
            >
              <Phone className="w-3.5 h-3.5 text-red-400 animate-pulse" />
              <span className="font-mono hidden sm:inline">9318320977</span>
              <span className="sm:hidden font-mono">9318320977</span>
            </button>

            {/* Quick Action: Log Expense */}
            <button
              onClick={onOpenScanReceipt}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-200 text-xs font-medium transition-colors"
            >
              <Receipt className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden sm:inline">Scan Bill</span>
              <span className="sm:hidden">Bill</span>
            </button>

            {/* Quick Action: New Trip */}
            <button
              onClick={onOpenNewTrip}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-semibold shadow-md shadow-emerald-950 transition-all active:scale-95"
            >
              <PlusCircle className="w-3.5 h-3.5" />
              <span>+ Ride</span>
            </button>

          </div>

        </div>
      </div>

      {/* Primary 5 Pillars Navigation Strip */}
      <div className="border-t border-slate-800/90 bg-slate-950/90 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 flex items-center justify-between gap-1 overflow-x-auto py-2 scrollbar-none">
          <div className="flex items-center gap-1 sm:gap-2">
            {PILLARS_CONFIG.map((pillar) => {
              const Icon = pillar.icon;
              const isPillarActive = activePillar === pillar.id;
              return (
                <button
                  key={pillar.id}
                  id={`nav-pillar-${pillar.id}`}
                  onClick={() => onSelectPillar(pillar.id)}
                  className={`flex items-center gap-1.5 px-3 sm:px-4 py-1.5 rounded-xl text-xs font-black tracking-wide whitespace-nowrap transition-all cursor-pointer ${
                    isPillarActive
                      ? 'bg-gradient-to-r from-emerald-500/30 to-teal-500/20 text-emerald-300 border border-emerald-500/50 shadow-md shadow-emerald-950 ring-1 ring-emerald-400/30'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850 border border-transparent'
                  }`}
                >
                  <Icon className={`w-4 h-4 shrink-0 ${isPillarActive ? 'text-emerald-400' : 'text-slate-400'}`} />
                  <span>{pillar.label}</span>
                  {pillar.badge && (
                    <span className={`text-[10px] px-1.5 py-0.2 rounded font-mono font-bold ${
                      isPillarActive ? 'bg-emerald-500/30 text-emerald-200' : 'bg-slate-800 text-slate-400'
                    }`}>
                      {pillar.badge}
                    </span>
                  )}
                  {isPillarActive && (
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse ml-0.5" />
                  )}
                </button>
              );
            })}
          </div>

          <div className="hidden lg:flex items-center gap-1.5 text-[11px] text-slate-500 font-mono pl-4">
            <span>DRIVEROS ARCHITECTURE</span>
          </div>
        </div>
      </div>

      {/* Secondary Contextual Sub-Items Strip */}
      <div className="border-t border-slate-850 bg-slate-900/60 py-1.5 px-3 sm:px-6">
        <div className="max-w-7xl mx-auto flex items-center gap-1.5 overflow-x-auto scrollbar-none">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mr-2 hidden sm:inline flex items-center gap-1">
            <span>{activePillar}</span>
            <ChevronRight className="w-3 h-3 text-slate-600" />
          </span>

          {currentPillarConfig.subItems.map((sub) => {
            const SubIcon = sub.icon;
            const isSubActive = activeSubView === sub.id;
            return (
              <button
                key={sub.id}
                id={`sub-tab-${sub.id}`}
                onClick={() => onSelectSubView(sub.id)}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                  isSubActive
                    ? 'bg-slate-800 text-emerald-300 border border-emerald-500/40 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60 border border-transparent'
                }`}
              >
                <SubIcon className={`w-3.5 h-3.5 ${isSubActive ? 'text-emerald-400' : 'text-slate-400'}`} />
                <span>{sub.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
