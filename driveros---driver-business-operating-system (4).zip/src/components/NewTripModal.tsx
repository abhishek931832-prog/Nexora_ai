import React, { useState } from 'react';
import { 
  Car, 
  X, 
  MapPin, 
  DollarSign, 
  Percent, 
  Fuel, 
  Clock, 
  Navigation, 
  CheckCircle2, 
  ShieldCheck,
  Sparkles
} from 'lucide-react';
import { TripRecord, PlatformType, DriverProfile } from '../types';

interface NewTripModalProps {
  driver: DriverProfile;
  isOpen: boolean;
  onClose: () => void;
  onSaveTrip: (trip: TripRecord) => void;
}

export const NewTripModal: React.FC<NewTripModalProps> = ({
  driver,
  isOpen,
  onClose,
  onSaveTrip,
}) => {
  const [platform, setPlatform] = useState<PlatformType>('OLA');
  const [pickup, setPickup] = useState('Koramangala 5th Block');
  const [dropoff, setDropoff] = useState('Kempegowda Airport T2');
  const [grossFare, setGrossFare] = useState<number | ''>(1650);
  const [distanceKm, setDistanceKm] = useState<number | ''>(42);
  const [durationMin, setDurationMin] = useState<number | ''>(65);
  const [tollCost, setTollCost] = useState<number | ''>(115);
  const [tips, setTips] = useState<number | ''>(50);
  const [passengerName, setPassengerName] = useState('Vikramaditya Sen');
  const [paymentMode, setPaymentMode] = useState<'UPI' | 'CASH' | 'WALLET' | 'CORP_ACCOUNT'>('UPI');
  const [deadheadKm, setDeadheadKm] = useState<number | ''>(4);
  const [passengerSafetyBadge, setPassengerSafetyBadge] = useState<string>('VERIFIED_CORP_EXECUTIVE');

  // Dynamic Commission calculation
  const getCommissionPercent = (p: PlatformType) => {
    switch (p) {
      case 'OLA': return 0.28;
      case 'UBER': return 0.20;
      case 'RAPIDO': return 0.18;
      case 'NAMMA_YATRI': return 0.00;
      case 'DIRECT_CLIENT': return 0.00;
    }
  };

  const currentGross = Number(grossFare) || 0;
  const currentDistance = Number(distanceKm) || 0;
  const currentDuration = Number(durationMin) || 0;
  const currentToll = Number(tollCost) || 0;
  const currentTips = Number(tips) || 0;
  const currentCommission = Math.round(currentGross * getCommissionPercent(platform));
  
  // Fuel cost: ~₹3.6 per km for CNG WagonR
  const currentFuelCost = Math.round(currentDistance * 3.6);
  const currentNetProfit = currentGross - currentCommission - currentFuelCost - currentToll + currentTips;

  const handleSave = () => {
    if (!pickup || !dropoff || !grossFare) return;

    const newTrip: TripRecord = {
      id: `TRIP-${Math.floor(1000 + Math.random() * 9000)}`,
      timestamp: new Date().toISOString(),
      platform,
      pickupLocation: pickup,
      dropoffLocation: dropoff,
      distanceKm: currentDistance,
      durationMinutes: currentDuration,
      grossFare: currentGross,
      platformCommission: currentCommission,
      netProfit: currentNetProfit,
      fuelCost: currentFuelCost,
      tollCost: currentToll,
      tips: currentTips,
      deadheadKm: Number(deadheadKm) || 0,
      paymentMode,
      passengerName: passengerName || undefined,
      passengerSafetyBadge: passengerSafetyBadge ? (passengerSafetyBadge as any) : undefined,
      isEncrypted: true,
      notes: `Recorded on ${platform.replace('_', ' ')}`,
    };

    onSaveTrip(newTrip);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-lg w-full p-5 sm:p-6 space-y-5 shadow-2xl animate-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400">
              <Car className="w-5 h-5" />
            </span>
            <div>
              <h3 className="text-base font-bold text-white">Log Completed Ride</h3>
              <p className="text-xs text-slate-400">Instant Profit Ledger Calculation</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Platform Selector */}
        <div>
          <label className="text-xs text-slate-400 font-medium block mb-1.5">Platform</label>
          <div className="grid grid-cols-3 sm:grid-cols-5 gap-1.5">
            {[
              { id: 'OLA', label: 'Ola (28%)' },
              { id: 'UBER', label: 'Uber (20%)' },
              { id: 'RAPIDO', label: 'Rapido' },
              { id: 'NAMMA_YATRI', label: 'Namma Yatri' },
              { id: 'DIRECT_CLIENT', label: 'Direct (100%)' },
            ].map(p => (
              <button
                key={p.id}
                type="button"
                onClick={() => setPlatform(p.id as any)}
                className={`py-2 px-1 text-[11px] font-bold rounded-xl text-center transition-all ${
                  platform === p.id
                    ? 'bg-emerald-600 text-white shadow-md'
                    : 'bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-700'
                }`}
              >
                {p.label}
              </button>
            ))}
          </div>
        </div>

        {/* Pickup & Dropoff */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          <div>
            <label className="text-slate-400 font-medium block mb-1">Pickup Location</label>
            <input
              type="text"
              value={pickup}
              onChange={(e) => setPickup(e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-emerald-500"
            />
          </div>
          <div>
            <label className="text-slate-400 font-medium block mb-1">Dropoff Location</label>
            <input
              type="text"
              value={dropoff}
              onChange={(e) => setDropoff(e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-emerald-500"
            />
          </div>
        </div>

        {/* Fares & Numbers Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
          <div>
            <label className="text-slate-400 font-medium block mb-1">Gross Fare (₹)</label>
            <input
              type="number"
              value={grossFare}
              onChange={(e) => setGrossFare(Number(e.target.value))}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono focus:outline-none focus:border-emerald-500"
            />
          </div>
          <div>
            <label className="text-slate-400 font-medium block mb-1">Distance (km)</label>
            <input
              type="number"
              value={distanceKm}
              onChange={(e) => setDistanceKm(Number(e.target.value))}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono focus:outline-none focus:border-emerald-500"
            />
          </div>
          <div>
            <label className="text-slate-400 font-medium block mb-1">Duration (min)</label>
            <input
              type="number"
              value={durationMin}
              onChange={(e) => setDurationMin(Number(e.target.value))}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono focus:outline-none focus:border-emerald-500"
            />
          </div>
          <div>
            <label className="text-slate-400 font-medium block mb-1">Toll FASTag (₹)</label>
            <input
              type="number"
              value={tollCost}
              onChange={(e) => setTollCost(Number(e.target.value))}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono focus:outline-none focus:border-emerald-500"
            />
          </div>
        </div>

        {/* Live Calculation Preview Banner */}
        <div className="p-3.5 rounded-2xl bg-slate-950 border border-emerald-500/40 grid grid-cols-3 gap-2 text-center text-xs">
          <div>
            <span className="text-[10px] text-rose-400 block">Commission Cut</span>
            <span className="text-base font-bold text-rose-300 font-mono">-₹{currentCommission}</span>
          </div>
          <div>
            <span className="text-[10px] text-amber-400 block">Fuel Cost (CNG)</span>
            <span className="text-base font-bold text-amber-300 font-mono">-₹{currentFuelCost}</span>
          </div>
          <div>
            <span className="text-[10px] text-emerald-400 font-bold block">Real Net In-Pocket</span>
            <span className="text-xl font-black text-emerald-400 font-mono">₹{currentNetProfit}</span>
          </div>
        </div>

        {/* Action Button */}
        <button
          onClick={handleSave}
          className="w-full py-3 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 text-white text-xs font-bold shadow-lg shadow-emerald-950 transition-all active:scale-95"
        >
          Save to Cryptographic Ledger
        </button>

      </div>
    </div>
  );
};
