import React, { useState } from 'react';
import { 
  Banknote, 
  QrCode, 
  CreditCard, 
  Receipt, 
  CheckCircle2, 
  Share2, 
  Download, 
  Clock, 
  ArrowUpRight, 
  DollarSign, 
  ShieldCheck,
  Percent,
  PlusCircle,
  Copy,
  ExternalLink,
  MessageSquare
} from 'lucide-react';
import { TripRecord, DriverProfile } from '../types';
import { exportCustomerReceiptPDF } from '../utils/exportUtils';

interface PaymentsViewProps {
  driver: DriverProfile;
  trips: TripRecord[];
  onOpenCustomerPayment: (trip?: TripRecord | null) => void;
}

export const PaymentsView: React.FC<PaymentsViewProps> = ({
  driver,
  trips,
  onOpenCustomerPayment,
}) => {
  const [copiedUpi, setCopiedUpi] = useState(false);
  const [selectedPaymentFilter, setSelectedPaymentFilter] = useState<string>('ALL');

  const driverUpiId = `${driver.phone}@upi`;

  // Calculated totals
  const totalBilled = trips.reduce((sum, t) => sum + t.grossFare, 0);
  const upiCollected = trips.filter(t => t.paymentMode === 'UPI').reduce((sum, t) => sum + t.grossFare, 0);
  const cashCollected = trips.filter(t => t.paymentMode === 'CASH').reduce((sum, t) => sum + t.grossFare, 0);
  const platformWithheld = trips.filter(t => t.paymentMode !== 'UPI' && t.paymentMode !== 'CASH').reduce((sum, t) => sum + t.grossFare, 0);
  const totalCommissionLost = trips.reduce((sum, t) => sum + t.platformCommission, 0);

  const filteredTrips = selectedPaymentFilter === 'ALL'
    ? trips
    : trips.filter(t => t.paymentMode === selectedPaymentFilter);

  const handleCopyUpi = () => {
    navigator.clipboard.writeText(driverUpiId);
    setCopiedUpi(true);
    setTimeout(() => setCopiedUpi(false), 2500);
  };

  const handleDownloadReceipt = (trip: TripRecord) => {
    exportCustomerReceiptPDF({
      receiptNumber: `REC-${trip.id.substring(0, 8).toUpperCase()}`,
      date: new Date(trip.timestamp).toISOString(),
      driver,
      customerName: trip.passengerName || 'Direct Commuter',
      customerPhone: '9845012345',
      pickupLocation: trip.pickupLocation,
      dropoffLocation: trip.dropoffLocation,
      distanceKm: trip.distanceKm,
      durationMinutes: trip.durationMinutes,
      baseFare: 100,
      distanceFare: Math.max(0, trip.grossFare - 100 - trip.tollCost),
      tollCost: trip.tollCost,
      waitingOrSurgeFare: 0,
      discount: 0,
      totalPaid: trip.grossFare,
      paymentMode: trip.paymentMode as any,
    });
  };

  return (
    <div className="space-y-6 pb-12">
      
      {/* Top Banner & Quick Collect Action */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400">
              <Banknote className="w-5 h-5" />
            </span>
            <h2 className="text-xl font-bold text-white tracking-tight">
              Customer Payments & Invoicing
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Collect fares directly via zero-commission UPI QR, cash reconciliation, and instant commercial PDF receipts.
          </p>
        </div>

        <button
          onClick={() => onOpenCustomerPayment()}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold shadow-lg shadow-emerald-950 transition-all active:scale-95 cursor-pointer"
        >
          <QrCode className="w-4 h-4" />
          <span>Collect Payment & PDF Bill</span>
        </button>
      </div>

      {/* KPI Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg">
          <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4" /> Instant UPI In Bank
          </span>
          <div className="text-2xl sm:text-3xl font-black text-white font-mono mt-2 privacy-sensitive">
            ₹{upiCollected.toLocaleString('en-IN')}
          </div>
          <div className="text-xs text-slate-400 mt-1">
            0% merchant fee • Immediate credit
          </div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg">
          <span className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
            <Banknote className="w-4 h-4" /> Cash Tendered
          </span>
          <div className="text-2xl sm:text-3xl font-black text-amber-300 font-mono mt-2 privacy-sensitive">
            ₹{cashCollected.toLocaleString('en-IN')}
          </div>
          <div className="text-xs text-slate-400 mt-1">
            Physical cash in glovebox
          </div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg">
          <span className="text-xs font-bold uppercase tracking-wider text-sky-400 flex items-center gap-1.5">
            <Clock className="w-4 h-4" /> Platform Escrow
          </span>
          <div className="text-2xl sm:text-3xl font-black text-sky-300 font-mono mt-2 privacy-sensitive">
            ₹{platformWithheld.toLocaleString('en-IN')}
          </div>
          <div className="text-xs text-slate-400 mt-1">
            Withheld by Ola/Uber till weekly cycle
          </div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg">
          <span className="text-xs font-bold uppercase tracking-wider text-rose-400 flex items-center gap-1.5">
            <Percent className="w-4 h-4" /> Total Commission Deducted
          </span>
          <div className="text-2xl sm:text-3xl font-black text-rose-300 font-mono mt-2 privacy-sensitive">
            -₹{totalCommissionLost.toLocaleString('en-IN')}
          </div>
          <div className="text-xs text-slate-400 mt-1">
            Aggregator cut on non-direct rides
          </div>
        </div>
      </div>

      {/* Driver UPI QR Card & Direct Payment Hub */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* UPI QR Display for Backseat Passengers */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <QrCode className="w-4 h-4 text-emerald-400" /> Driver's Direct UPI QR
            </h3>
            <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
              Zero Merchant Cut
            </span>
          </div>

          {/* Rendered QR Card */}
          <div className="p-4 rounded-xl bg-white text-slate-900 text-center space-y-3 shadow-inner">
            <div className="text-xs font-black uppercase tracking-wider text-slate-700">
              Scan & Pay Any UPI App
            </div>

            {/* Generated QR Placeholder / Code */}
            <div className="w-44 h-44 mx-auto bg-slate-100 p-2 rounded-xl border-2 border-slate-300 flex items-center justify-center">
              <img 
                src={`https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(`upi://pay?pa=${driverUpiId}&pn=${encodeURIComponent(driver.name)}&cu=INR`)}`}
                alt="Driver UPI QR"
                className="w-full h-full rounded"
              />
            </div>

            <div className="space-y-0.5">
              <div className="font-bold text-xs text-slate-900">{driver.name}</div>
              <div className="font-mono text-[11px] text-slate-600">{driverUpiId}</div>
              <div className="text-[10px] text-emerald-700 font-semibold pt-1">
                GPay • PhonePe • Paytm • BHIM
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 pt-1">
            <button
              onClick={handleCopyUpi}
              className="flex-1 py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
            >
              <Copy className="w-3.5 h-3.5" />
              <span>{copiedUpi ? 'Copied UPI!' : 'Copy UPI ID'}</span>
            </button>
            <button
              onClick={() => onOpenCustomerPayment()}
              className="py-2 px-3 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 text-xs font-bold transition-colors"
            >
              Generate Bill
            </button>
          </div>
        </div>

        {/* Payment History & PDF Receipts List */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Receipt className="w-4 h-4 text-sky-400" /> Recent Payment & Tax Invoices
              </h3>
              <p className="text-xs text-slate-400">Download commercial GST bills or share with passenger via WhatsApp.</p>
            </div>

            <div className="flex items-center gap-1.5 text-xs">
              {['ALL', 'UPI', 'CASH'].map((f) => (
                <button
                  key={f}
                  onClick={() => setSelectedPaymentFilter(f)}
                  className={`px-2.5 py-1 rounded-lg font-semibold transition-all ${
                    selectedPaymentFilter === f
                      ? 'bg-slate-750 text-white border border-slate-600'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {f}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-3">
            {filteredTrips.slice(0, 6).map((trip) => (
              <div
                key={trip.id}
                className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/80 hover:border-slate-750 transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-white">{trip.id.substring(0, 10)}</span>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      trip.paymentMode === 'UPI' 
                        ? 'bg-emerald-500/20 text-emerald-300' 
                        : 'bg-amber-500/20 text-amber-300'
                    }`}>
                      {trip.paymentMode}
                    </span>
                    <span className="text-slate-400">{new Date(trip.timestamp).toLocaleDateString()}</span>
                  </div>
                  <div className="text-slate-300">
                    {trip.passengerName || 'Direct Commuter'} • {trip.pickupLocation.split(',')[0]} → {trip.dropoffLocation.split(',')[0]}
                  </div>
                </div>

                <div className="flex items-center gap-3 w-full sm:w-auto justify-between sm:justify-end">
                  <div className="text-right">
                    <span className="text-base font-black text-white font-mono">₹{trip.grossFare}</span>
                    <span className="block text-[10px] text-emerald-400 font-medium">Net: ₹{trip.netProfit}</span>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => handleDownloadReceipt(trip)}
                      className="p-2 rounded-lg bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-white border border-slate-700 transition-colors"
                      title="Download PDF Tax Invoice"
                    >
                      <Download className="w-3.5 h-3.5 text-emerald-400" />
                    </button>
                    <a
                      href={`https://wa.me/?text=${encodeURIComponent(`Namaste! Here is your cab trip receipt for ₹${trip.grossFare} with Driver ${driver.name} (${driver.vehiclePlate}). Thank you for riding!`)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-2 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 transition-colors"
                      title="Share Receipt on WhatsApp"
                    >
                      <Share2 className="w-3.5 h-3.5" />
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

    </div>
  );
};
