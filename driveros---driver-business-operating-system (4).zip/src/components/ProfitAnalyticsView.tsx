import React from 'react';
import { 
  TrendingUp, 
  Car, 
  Clock, 
  Percent, 
  ArrowUpRight, 
  Zap, 
  DollarSign, 
  Award,
  Sparkles,
  PieChart as PieIcon,
  Layers,
  FileSpreadsheet
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  AreaChart, 
  Area 
} from 'recharts';
import { TripRecord, ExpenseRecord, DriverProfile } from '../types';

interface ProfitAnalyticsViewProps {
  driver: DriverProfile;
  trips: TripRecord[];
  expenses: ExpenseRecord[];
  onNavigateSubView: (subView: string) => void;
}

export const ProfitAnalyticsView: React.FC<ProfitAnalyticsViewProps> = ({
  driver,
  trips,
  expenses,
  onNavigateSubView,
}) => {
  const totalGross = trips.reduce((sum, t) => sum + t.grossFare, 0);
  const totalCommissionBleed = trips.reduce((sum, t) => sum + t.platformCommission, 0);
  const totalFuel = trips.reduce((sum, t) => sum + t.fuelCost, 0);
  const totalToll = trips.reduce((sum, t) => sum + t.tollCost, 0);
  const totalNet = trips.reduce((sum, t) => sum + t.netProfit, 0);
  const totalKm = trips.reduce((sum, t) => sum + t.distanceKm, 0);
  const totalMinutes = trips.reduce((sum, t) => sum + t.durationMinutes, 0);

  const profitPerKm = totalKm > 0 ? (totalNet / totalKm).toFixed(1) : '0';
  const profitPerHour = totalMinutes > 0 ? ((totalNet / totalMinutes) * 60).toFixed(0) : '0';

  // Platform breakdown
  const platformData = ['OLA', 'UBER', 'RAPIDO', 'NAMMA_YATRI', 'DIRECT_CLIENT'].map(platform => {
    const pTrips = trips.filter(t => t.platform === platform);
    const gross = pTrips.reduce((sum, t) => sum + t.grossFare, 0);
    const comm = pTrips.reduce((sum, t) => sum + t.platformCommission, 0);
    const net = pTrips.reduce((sum, t) => sum + t.netProfit, 0);
    return {
      name: platform.replace('_', ' '),
      platformKey: platform,
      gross,
      commission: comm,
      net,
      count: pTrips.length,
    };
  }).filter(p => p.count > 0);

  // Hourly profit curve
  const hourlyData = [
    { hour: '6 AM', gross: 600, net: 520, commission: 80 },
    { hour: '8 AM', gross: 1650, net: 1480, commission: 0 },
    { hour: '10 AM', gross: 680, net: 604, commission: 0 },
    { hour: '12 PM', gross: 420, net: 248, commission: 118 },
    { hour: '2 PM', gross: 280, net: 208, commission: 56 },
    { hour: '4 PM', gross: 850, net: 830, commission: 0 },
    { hour: '7 PM (Peak)', gross: 1100, net: 920, commission: 90 },
  ];

  return (
    <div className="space-y-6 pb-12">
      
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400">
              <TrendingUp className="w-5 h-5" />
            </span>
            <h2 className="text-xl font-bold text-white tracking-tight">
              Deep Profit & Platform Analytics
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Compare platform deductions, analyze hourly velocity, and maximize in-pocket retainable income.
          </p>
        </div>

        <button
          onClick={() => onNavigateSubView('map')}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-750 text-emerald-400 text-xs font-semibold border border-slate-700 transition-colors"
        >
          <span>Open Profit Map</span>
          <ArrowUpRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-900/90 border border-emerald-500/30 rounded-2xl p-4 sm:p-5 shadow-lg">
          <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
            <TrendingUp className="w-4 h-4" /> Lifetime Take-Home Net
          </span>
          <div className="text-2xl sm:text-3xl font-black text-white font-mono mt-2 privacy-sensitive">
            ₹{totalNet.toLocaleString('en-IN')}
          </div>
          <div className="text-xs text-slate-400 mt-1">
            Across {trips.length} completed trips
          </div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg">
          <span className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
            <Percent className="w-4 h-4" /> Commission Lost to Aggregators
          </span>
          <div className="text-2xl sm:text-3xl font-black text-amber-300 font-mono mt-2 privacy-sensitive">
            -₹{totalCommissionBleed.toLocaleString('en-IN')}
          </div>
          <div className="text-xs text-slate-400 mt-1">
            Average cut: {totalGross > 0 ? ((totalCommissionBleed / totalGross) * 100).toFixed(1) : 0}%
          </div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg">
          <span className="text-xs font-bold uppercase tracking-wider text-sky-400 flex items-center gap-1.5">
            <Zap className="w-4 h-4" /> Net Margin / KM
          </span>
          <div className="text-2xl sm:text-3xl font-black text-sky-400 font-mono mt-2">
            ₹{profitPerKm}
          </div>
          <div className="text-xs text-slate-400 mt-1">
            Fuel cost factored: ₹{driver.fuelPricePerUnit}/unit
          </div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg">
          <span className="text-xs font-bold uppercase tracking-wider text-purple-400 flex items-center gap-1.5">
            <Clock className="w-4 h-4" /> Net Margin / Hour
          </span>
          <div className="text-2xl sm:text-3xl font-black text-purple-400 font-mono mt-2">
            ₹{profitPerHour}
          </div>
          <div className="text-xs text-slate-400 mt-1">
            Top 5% driver tier efficiency
          </div>
        </div>
      </div>

      {/* Visual Charts: Platform Comparison & Hourly Profit Curve */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Multi-Platform Commission Bleed vs Net Profit */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Car className="w-4 h-4 text-emerald-400" /> Platform Profitability Comparison
              </h3>
              <p className="text-xs text-slate-400">Net Take-Home vs Commission Lost per Platform</p>
            </div>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={platformData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <XAxis dataKey="name" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={11} tickLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px', fontSize: '12px' }}
                  formatter={(value: any, name: any) => [`₹${value}`, name === 'net' ? 'Net Take-Home' : 'Commission Cut']}
                />
                <Bar dataKey="net" fill="#10b981" name="net" radius={[6, 6, 0, 0]} />
                <Bar dataKey="commission" fill="#f43f5e" name="commission" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-3 border-t border-slate-800 text-xs">
            <div className="text-center p-2 rounded-lg bg-slate-800/40">
              <span className="text-amber-400 block font-semibold">Ola Cut</span>
              <span className="text-slate-300 font-mono font-bold">28% lost</span>
            </div>
            <div className="text-center p-2 rounded-lg bg-slate-800/40">
              <span className="text-sky-400 block font-semibold">Uber Cut</span>
              <span className="text-slate-300 font-mono font-bold">20% lost</span>
            </div>
            <div className="text-center p-2 rounded-lg bg-slate-800/40">
              <span className="text-emerald-400 block font-semibold">Namma Yatri</span>
              <span className="text-emerald-300 font-mono font-bold">0% Cut</span>
            </div>
            <div className="text-center p-2 rounded-lg bg-slate-800/40">
              <span className="text-purple-400 block font-semibold">Direct Client</span>
              <span className="text-purple-300 font-mono font-bold">100% Mine</span>
            </div>
          </div>
        </div>

        {/* Hourly Profit Curve */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Clock className="w-4 h-4 text-sky-400" /> Shift Net Cash Flow Curve
              </h3>
              <p className="text-xs text-slate-400">Hourly earnings across morning surge and evening peak</p>
            </div>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={hourlyData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="profitGrad2" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0.0}/>
                  </linearGradient>
                  <linearGradient id="grossGrad2" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#38bdf8" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#38bdf8" stopOpacity={0.0}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="hour" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={11} tickLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px', fontSize: '12px' }}
                  formatter={(value: any) => [`₹${value}`, 'Amount']}
                />
                <Area type="monotone" dataKey="gross" stroke="#38bdf8" fillOpacity={1} fill="url(#grossGrad2)" name="Gross Fare" />
                <Area type="monotone" dataKey="net" stroke="#10b981" strokeWidth={2} fillOpacity={1} fill="url(#profitGrad2)" name="Net Profit" />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          <div className="flex items-center justify-between text-xs text-slate-400 pt-3 border-t border-slate-800">
            <span>Highest Yield Zone: <strong className="text-emerald-400">Airport & Outer Ring Road</strong></span>
            <span>CNG Mileage: <strong className="text-slate-200">{driver.fuelMileageKmPerUnit} km/kg</strong></span>
          </div>
        </div>

      </div>

    </div>
  );
};
