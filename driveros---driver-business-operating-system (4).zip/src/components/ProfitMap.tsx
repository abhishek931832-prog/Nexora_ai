// Source: Google Maps Platform Code Assist
import React, { useState, useEffect } from 'react';
import { 
  Compass, 
  Flame, 
  MapPin, 
  Navigation, 
  ParkingCircle, 
  Fuel, 
  Zap, 
  Layers, 
  Route, 
  TrendingUp, 
  DollarSign, 
  ShieldCheck, 
  Clock, 
  Sparkles,
  Car,
  Play,
  Pause,
  Gauge,
  Radio,
  Info,
  Key,
  Globe,
  CheckCircle2,
  ExternalLink,
  ChevronRight
} from 'lucide-react';
import { demandSurgeClusters, verifiedRestAndFuelHubs } from '../data/mockInitialData';
import { evaluateRouteProfit } from '../services/api';
import { DemandSurgeCluster, VerifiedRestAndFuelHub } from '../types';
import { 
  MapCarData, 
  INITIAL_MAP_CARS, 
  ROUTE_WAYPOINTS, 
  interpolateWaypoint, 
  GeoPoint, 
  BENGALURU_CENTER 
} from './map/mapData';
import { LeafletMapView } from './map/LeafletMapView';
import { GoogleMapView } from './map/GoogleMapView';

export const ProfitMap: React.FC = () => {
  // Map Engine & API Key State
  const envKey = import.meta.env.VITE_GOOGLE_MAPS_API_KEY || '';
  const [apiKey, setApiKey] = useState<string>(() => {
    return localStorage.getItem('driveros_gmp_api_key') || envKey || '';
  });
  const [showKeyModal, setShowKeyModal] = useState(false);
  const [keyInput, setKeyInput] = useState(apiKey);
  const [activeEngine, setActiveEngine] = useState<'GOOGLE_MAPS' | 'LEAFLET'>(() => {
    return (apiKey && apiKey.trim().length > 5) ? 'GOOGLE_MAPS' : 'LEAFLET';
  });

  // Google Maps specific controls
  const [gmpTrafficEnabled, setGmpTrafficEnabled] = useState(true);
  const [gmpMapType, setGmpMapType] = useState<'roadmap' | 'satellite' | 'hybrid' | 'terrain'>('roadmap');

  // Leaflet specific controls
  const [leafletTheme, setLeafletTheme] = useState<'dark' | 'street' | 'satellite'>('dark');

  // Selected Entities & Filters
  const [selectedCluster, setSelectedCluster] = useState<DemandSurgeCluster>(demandSurgeClusters[0]);
  const [selectedHub, setSelectedHub] = useState<VerifiedRestAndFuelHub | null>(null);
  const [activeFilter, setActiveFilter] = useState<'ALL' | 'SURGE' | 'CNG' | 'EV' | 'PARKING' | 'CARS'>('ALL');
  
  // Live Moving Fleet State
  const [cars, setCars] = useState<MapCarData[]>(INITIAL_MAP_CARS);
  const [selectedCar, setSelectedCar] = useState<MapCarData | null>(INITIAL_MAP_CARS[0]);
  const [isSimulatingTraffic, setIsSimulatingTraffic] = useState(true);
  const [simulationSpeed, setSimulationSpeed] = useState(1);

  // Active Route Polyline for Map
  const [activeRoutePoints, setActiveRoutePoints] = useState<GeoPoint[]>(ROUTE_WAYPOINTS.AIRPORT_EXPRESS);

  // Route Profit Optimizer Calculator state
  const [pickupInput, setPickupInput] = useState('Koramangala 5th Block');
  const [dropoffInput, setDropoffInput] = useState('Kempegowda Airport T2');
  const [offeredFare, setOfferedFare] = useState(1650);
  const [distanceKm, setDistanceKm] = useState(42);
  const [durationMin, setDurationMin] = useState(65);
  const [fuelType, setFuelType] = useState('CNG');

  const [evalResult, setEvalResult] = useState<any>(null);
  const [isEvaluating, setIsEvaluating] = useState(false);

  // Synchronize API Key updates
  const handleSaveApiKey = (newKey: string) => {
    setApiKey(newKey);
    localStorage.setItem('driveros_gmp_api_key', newKey);
    setShowKeyModal(false);
    if (newKey && newKey.trim().length > 5) {
      setActiveEngine('GOOGLE_MAPS');
    }
  };

  // Real-time Moving Cab Fleet GPS loop across actual Bangalore highway coordinates
  useEffect(() => {
    if (!isSimulatingTraffic) return;

    const interval = setInterval(() => {
      setCars(prevCars => 
        prevCars.map(car => {
          const step = (car.speedKmH / 3600) * 0.08 * simulationSpeed;
          const nextProgress = (car.progress + step) % 1;

          const waypoints = ROUTE_WAYPOINTS[car.routeKey] || ROUTE_WAYPOINTS.AIRPORT_EXPRESS;
          const { coord, heading } = interpolateWaypoint(waypoints, nextProgress);

          return {
            ...car,
            progress: nextProgress,
            currentCoord: coord,
            headingAngle: heading,
          };
        })
      );
    }, 120);

    return () => clearInterval(interval);
  }, [isSimulatingTraffic, simulationSpeed]);

  // Route evaluation and polyline calculation
  const handleEvaluate = async () => {
    setIsEvaluating(true);
    try {
      // Determine best route waypoints based on inputs
      const p = pickupInput.toLowerCase();
      const d = dropoffInput.toLowerCase();

      if (d.includes('airport') || p.includes('airport')) {
        setActiveRoutePoints(ROUTE_WAYPOINTS.AIRPORT_EXPRESS);
      } else if (d.includes('whitefield') || p.includes('whitefield')) {
        setActiveRoutePoints(ROUTE_WAYPOINTS.WHITEFIELD_CORRIDOR);
      } else if (d.includes('ecity') || d.includes('electronic') || p.includes('ecity')) {
        setActiveRoutePoints(ROUTE_WAYPOINTS.ECITY_ELEVATED);
      } else {
        setActiveRoutePoints(ROUTE_WAYPOINTS.OUTER_RING_ROAD);
      }

      const res = await evaluateRouteProfit({
        pickup: pickupInput,
        dropoff: dropoffInput,
        platformOfferedFare: Number(offeredFare),
        distanceKm: Number(distanceKm),
        estimatedDurationMin: Number(durationMin),
        vehicleFuelType: fuelType,
      });
      setEvalResult(res.calculation);
    } catch (err) {
      console.error(err);
    } finally {
      setIsEvaluating(false);
    }
  };

  const filteredHubs = verifiedRestAndFuelHubs.filter(hub => {
    if (activeFilter === 'ALL' || activeFilter === 'CARS') return true;
    if (activeFilter === 'CNG' && hub.type === 'CNG_PUMP') return true;
    if (activeFilter === 'EV' && hub.type === 'EV_FAST_CHARGER') return true;
    if (activeFilter === 'PARKING' && (hub.type === 'VERIFIED_PARKING' || hub.type === 'CHAI_REST_STOP')) return true;
    return false;
  });

  return (
    <div className="space-y-6 pb-12">
      
      {/* Top Map Banner & Controls */}
      <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg">
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <span className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-400">
              <Compass className="w-5 h-5" />
            </span>
            <h2 className="text-lg sm:text-xl font-bold text-white tracking-tight">
              Driver-Profit Optimization & Professional Map
            </h2>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              Google Maps Platform + High-Precision Vector Engine
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Real-time <strong className="text-emerald-400">Live Moving Cab Fleet</strong>, Bengaluru airport express surge zones, and driver-verified zero-queue fuel hubs.
          </p>
        </div>

        {/* Engine Switcher & API Key Configuration */}
        <div className="flex items-center gap-2 flex-wrap">
          <div className="bg-slate-950 p-1 rounded-xl border border-slate-800 flex items-center gap-1 text-xs">
            <button
              onClick={() => {
                if (!apiKey || apiKey.trim().length < 5) {
                  setShowKeyModal(true);
                } else {
                  setActiveEngine('GOOGLE_MAPS');
                }
              }}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all flex items-center gap-1.5 ${
                activeEngine === 'GOOGLE_MAPS'
                  ? 'bg-emerald-500 text-slate-950 shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Globe className="w-3.5 h-3.5" />
              <span>Google Maps Pro</span>
            </button>

            <button
              onClick={() => setActiveEngine('LEAFLET')}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all flex items-center gap-1.5 ${
                activeEngine === 'LEAFLET'
                  ? 'bg-emerald-500 text-slate-950 shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Tactical Vector (OSM)</span>
            </button>
          </div>

          <button
            onClick={() => setShowKeyModal(true)}
            className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-white text-xs font-semibold border border-slate-700 flex items-center gap-1.5 transition-colors"
            title="Configure Google Maps Platform Key"
          >
            <Key className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">API Key</span>
            {apiKey && apiKey.length > 5 && (
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
            )}
          </button>
        </div>
      </div>

      {/* Layer Filter Pills & Traffic Sim Controls */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-slate-900/60 border border-slate-800/80 rounded-xl p-3">
        {/* Layer Filters */}
        <div className="flex items-center flex-wrap gap-1.5">
          {[
            { id: 'ALL', label: 'All Layers', icon: Layers },
            { id: 'CARS', label: `Fleet (${cars.length} Cabs)`, icon: Car },
            { id: 'SURGE', label: 'Surge Zones', icon: Flame },
            { id: 'CNG', label: 'CNG Pumps', icon: Fuel },
            { id: 'EV', label: 'EV Fast Charge', icon: Zap },
            { id: 'PARKING', label: 'Rest & Chai', icon: ParkingCircle },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveFilter(tab.id as any)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
                activeFilter === tab.id
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-950'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-750 border border-slate-700'
              }`}
            >
              <tab.icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {/* Traffic Simulation Controls */}
        <div className="flex items-center gap-2 bg-slate-950 px-2.5 py-1.5 rounded-xl border border-slate-800 text-xs">
          <button
            onClick={() => setIsSimulatingTraffic(!isSimulatingTraffic)}
            className={`p-1 rounded-lg transition-colors ${
              isSimulatingTraffic ? 'text-emerald-400 bg-emerald-500/20' : 'text-slate-400 hover:text-white'
            }`}
            title={isSimulatingTraffic ? 'Pause Fleet Movement' : 'Resume Fleet Movement'}
          >
            {isSimulatingTraffic ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
          </button>

          <button
            onClick={() => setSimulationSpeed(s => s === 1 ? 2 : 1)}
            className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300 hover:text-white border border-slate-700"
          >
            {simulationSpeed}x Speed
          </button>

          <div className="h-3 w-px bg-slate-700" />

          <span className="text-[11px] text-amber-300 font-mono flex items-center gap-1">
            <Flame className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
            <span>Peak Surge (1.6x-2.3x)</span>
          </span>
        </div>
      </div>

      {/* Real-time Fuel & Toll Alerts Banner */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="bg-slate-900/80 border border-emerald-500/30 rounded-xl p-3 flex items-center gap-3">
          <Fuel className="w-5 h-5 text-emerald-400 shrink-0" />
          <div className="text-xs">
            <div className="font-semibold text-slate-200">GAIL CNG Bellandur</div>
            <div className="text-emerald-400 font-mono font-bold">₹88.50/Kg • 0 Mins Queue</div>
          </div>
        </div>

        <div className="bg-slate-900/80 border border-sky-500/30 rounded-xl p-3 flex items-center gap-3">
          <Zap className="w-5 h-5 text-sky-400 shrink-0" />
          <div className="text-xs">
            <div className="font-semibold text-slate-200">Indiranagar 60kW DC Fast</div>
            <div className="text-sky-300 font-mono font-bold">₹14.50/kWh • 2 Guns Free</div>
          </div>
        </div>

        <div className="bg-slate-900/80 border border-amber-500/30 rounded-xl p-3 flex items-center gap-3">
          <Route className="w-5 h-5 text-amber-400 shrink-0" />
          <div className="text-xs">
            <div className="font-semibold text-slate-200">Airport Toll Plaza (FASTag)</div>
            <div className="text-amber-300 font-mono font-bold">₹115 • NH44 Express Active</div>
          </div>
        </div>
      </div>

      {/* Live Moving Car Fleet Selector Bar */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-3 shadow-lg">
        <div className="flex items-center justify-between mb-2 px-1">
          <div className="flex items-center gap-2">
            <span className="relative flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
            </span>
            <span className="text-xs font-bold text-white uppercase tracking-wider">Live Moving Cars on Map ({cars.length})</span>
            <span className="text-[10px] text-slate-400 hidden sm:inline">— Click any taxi to fly camera & track live GPS</span>
          </div>

          <div className="text-[11px] font-mono text-emerald-400">
            Active: <span className="font-bold text-white">{selectedCar?.driverName || 'You'}</span> ({selectedCar?.speedKmH || 0} km/h)
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2">
          {cars.map((car) => {
            const isSelected = selectedCar?.id === car.id;
            const isUser = car.isUserDriver;

            return (
              <button
                key={car.id}
                onClick={() => {
                  setSelectedCar(car);
                }}
                className={`p-2.5 rounded-xl border text-left transition-all relative overflow-hidden group ${
                  isSelected
                    ? isUser 
                      ? 'bg-emerald-950/70 border-emerald-500 shadow-md ring-1 ring-emerald-400' 
                      : 'bg-sky-950/70 border-sky-500 shadow-md ring-1 ring-sky-400'
                    : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 hover:bg-slate-900/80'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-1.5">
                    <span className="text-base">{isUser ? '🚕' : '🚗'}</span>
                    <span className={`text-xs font-bold truncate max-w-[85px] ${
                      isSelected ? (isUser ? 'text-emerald-300' : 'text-sky-300') : 'text-slate-200'
                    }`}>
                      {isUser ? 'YOU' : car.driverName.split(' ')[0]}
                    </span>
                  </div>
                  <span className={`text-[10px] font-mono font-bold px-1.5 py-0.2 rounded ${
                    isUser ? 'bg-emerald-500/20 text-emerald-300' : 'bg-slate-800 text-slate-300'
                  }`}>
                    {car.speedKmH}k
                  </span>
                </div>

                <div className="text-[10px] font-mono text-slate-400 truncate">{car.vehiclePlate}</div>
                <div className="text-[10px] text-slate-500 truncate mt-0.5">{car.routeKey.replace(/_/g, ' ')}</div>

                {isSelected && (
                  <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-emerald-500 to-sky-500" />
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Professional Map Stage & Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Map Canvas Container */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl relative min-h-[520px] flex flex-col">
          {activeEngine === 'GOOGLE_MAPS' && apiKey && apiKey.trim().length > 5 ? (
            <GoogleMapView
              apiKey={apiKey}
              cars={cars}
              selectedCar={selectedCar}
              onSelectCar={(c) => setSelectedCar(c)}
              clusters={demandSurgeClusters}
              selectedCluster={selectedCluster}
              onSelectCluster={(cl) => setSelectedCluster(cl)}
              hubs={verifiedRestAndFuelHubs}
              selectedHub={selectedHub}
              onSelectHub={(h) => setSelectedHub(h)}
              activeFilter={activeFilter}
              routePoints={activeRoutePoints}
              trafficEnabled={gmpTrafficEnabled}
              onToggleTraffic={() => setGmpTrafficEnabled(!gmpTrafficEnabled)}
              mapType={gmpMapType}
              onChangeMapType={(t) => setGmpMapType(t)}
            />
          ) : (
            <LeafletMapView
              cars={cars}
              selectedCar={selectedCar}
              onSelectCar={(c) => setSelectedCar(c)}
              clusters={demandSurgeClusters}
              selectedCluster={selectedCluster}
              onSelectCluster={(cl) => setSelectedCluster(cl)}
              hubs={verifiedRestAndFuelHubs}
              selectedHub={selectedHub}
              onSelectHub={(h) => setSelectedHub(h)}
              activeFilter={activeFilter}
              routePoints={activeRoutePoints}
              mapTheme={leafletTheme}
              onChangeMapTheme={(th) => setLeafletTheme(th)}
            />
          )}
        </div>

        {/* Right Sidebar: Active Zone & Live Telemetry Inspector */}
        <div className="space-y-4">
          
          {/* Selected Live Vehicle Telemetry Card */}
          {selectedCar && (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-400">
                    <Car className="w-4 h-4" />
                  </span>
                  <div>
                    <h3 className="text-sm font-bold text-white">{selectedCar.driverName}</h3>
                    <p className="text-[11px] text-slate-400 font-mono">{selectedCar.vehiclePlate}</p>
                  </div>
                </div>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                  selectedCar.isUserDriver ? 'bg-emerald-500 text-slate-950' : 'bg-slate-800 text-slate-300'
                }`}>
                  {selectedCar.isUserDriver ? 'YOUR CAB' : selectedCar.platform}
                </span>
              </div>

              <div className="grid grid-cols-3 gap-2 text-center pt-1">
                <div className="bg-slate-950 p-2 rounded-xl border border-slate-800">
                  <div className="text-[10px] text-slate-400">Current Speed</div>
                  <div className="text-sm font-bold text-emerald-400 font-mono mt-0.5">{selectedCar.speedKmH} km/h</div>
                </div>
                <div className="bg-slate-950 p-2 rounded-xl border border-slate-800">
                  <div className="text-[10px] text-slate-400">Trip Fare</div>
                  <div className="text-sm font-bold text-slate-100 font-mono mt-0.5">₹{selectedCar.currentFare}</div>
                </div>
                <div className="bg-slate-950 p-2 rounded-xl border border-slate-800">
                  <div className="text-[10px] text-slate-400">Net Profit</div>
                  <div className="text-sm font-bold text-emerald-300 font-mono mt-0.5">₹{selectedCar.netMargin}</div>
                </div>
              </div>

              <div className="text-xs bg-slate-950/60 p-2.5 rounded-xl border border-slate-800 text-slate-300 space-y-1">
                <div className="text-[11px] text-slate-400">Current Status:</div>
                <div className="font-semibold text-emerald-400">{selectedCar.passengerStatus}</div>
              </div>
            </div>
          )}

          {/* Selected Surge Zone Inspector */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Flame className="w-5 h-5 text-amber-400" />
                <h3 className="text-sm font-bold text-white">Active Surge Inspector</h3>
              </div>
              <span className="text-xs font-mono font-bold bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded-full border border-amber-500/30">
                {selectedCluster.surgeMultiplier}x Surge
              </span>
            </div>

            <div>
              <h4 className="text-sm font-bold text-slate-100">{selectedCluster.zoneName}</h4>
              <p className="text-xs text-slate-400">{selectedCluster.city} • Peak Window: {selectedCluster.peakHourWindow}</p>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-2.5 rounded-xl bg-slate-800/80 border border-slate-700/80">
                <span className="text-slate-400 block text-[10px]">Avg Fare / Trip</span>
                <span className="text-emerald-400 font-bold text-sm font-mono">₹{selectedCluster.avgFarePerTrip}</span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-800/80 border border-slate-700/80">
                <span className="text-slate-400 block text-[10px]">Passenger Wait Time</span>
                <span className="text-amber-400 font-bold text-sm font-mono">{selectedCluster.avgWaitTimeMin} mins</span>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-xs text-emerald-200">
              <div className="font-semibold text-emerald-400 flex items-center gap-1 mb-1">
                <Sparkles className="w-3.5 h-3.5" /> High-Profit Route Target:
              </div>
              <div>{selectedCluster.highValueRouteTarget}</div>
            </div>

            <button
              onClick={() => {
                setPickupInput(selectedCluster.zoneName.split('(')[0].trim());
                setDropoffInput(selectedCluster.highValueRouteTarget.split('->')[1]?.trim() || 'Outer Ring Road');
                setOfferedFare(selectedCluster.avgFarePerTrip);
              }}
              className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold flex items-center justify-center gap-2 shadow-lg transition-all"
            >
              <Navigation className="w-4 h-4" />
              <span>Evaluate Route in Profit Optimizer</span>
            </button>
          </div>

          {/* Driver Verified Fuel & Rest Network */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <ParkingCircle className="w-4 h-4 text-purple-400" /> Driver Verified Hubs
            </h3>

            <div className="space-y-2.5">
              {filteredHubs.slice(0, 2).map((hub) => (
                <div 
                  key={hub.id} 
                  onClick={() => setSelectedHub(hub)}
                  className={`p-3 rounded-xl cursor-pointer transition-all border text-xs space-y-1 ${
                    selectedHub?.id === hub.id 
                      ? 'bg-slate-800 border-emerald-500/80 shadow-md' 
                      : 'bg-slate-800/60 border-slate-700/60 hover:border-slate-600'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-200">{hub.name}</span>
                    <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-1.5 py-0.5 rounded font-mono">
                      ★ {hub.rating}
                    </span>
                  </div>
                  <div className="text-slate-400 text-[11px]">{hub.address}</div>
                  <div className="flex items-center justify-between text-slate-300 pt-1">
                    <span className="text-emerald-400 font-medium">{hub.priceInfo}</span>
                    <span className="text-amber-400 font-mono text-[10px]">{hub.queueStatus}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>

      {/* Driver-Profit Route Optimizer Calculator */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-5">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-slate-800 pb-4">
          <div>
            <h3 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
              <Route className="w-5 h-5 text-emerald-400" /> Live Route Profit Calculator & Deadhead Shield
            </h3>
            <p className="text-xs text-slate-400">
              Calculate exact take-home cash per minute after Ola/Uber commission, fuel, tolls, and empty return risk.
            </p>
          </div>
          <span className="text-xs font-mono text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-lg border border-emerald-500/20">
            Section 44AD Auto-Ready
          </span>
        </div>

        {/* Input Fields */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3">
          <div className="lg:col-span-2">
            <label className="text-xs text-slate-400 font-medium block mb-1">Pickup Location</label>
            <input
              type="text"
              value={pickupInput}
              onChange={(e) => setPickupInput(e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
              placeholder="e.g. Koramangala 5th Block"
            />
          </div>

          <div className="lg:col-span-2">
            <label className="text-xs text-slate-400 font-medium block mb-1">Dropoff Location</label>
            <input
              type="text"
              value={dropoffInput}
              onChange={(e) => setDropoffInput(e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
              placeholder="e.g. Kempegowda Airport T2"
            />
          </div>

          <div>
            <label className="text-xs text-slate-400 font-medium block mb-1">Offered Fare (₹)</label>
            <input
              type="number"
              value={offeredFare}
              onChange={(e) => setOfferedFare(Number(e.target.value))}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-emerald-500"
            />
          </div>

          <div>
            <label className="text-xs text-slate-400 font-medium block mb-1">Est. Distance (km)</label>
            <input
              type="number"
              value={distanceKm}
              onChange={(e) => setDistanceKm(Number(e.target.value))}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-emerald-500"
            />
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
          <div className="flex items-center gap-3 text-xs">
            <span className="text-slate-400">Fuel Type:</span>
            {['CNG', 'PETROL', 'EV'].map(type => (
              <button
                key={type}
                onClick={() => setFuelType(type)}
                className={`px-2.5 py-1 rounded-lg font-bold text-xs ${
                  fuelType === type ? 'bg-emerald-500 text-slate-950' : 'bg-slate-800 text-slate-400'
                }`}
              >
                {type}
              </button>
            ))}
          </div>

          <button
            onClick={handleEvaluate}
            disabled={isEvaluating}
            className="py-2.5 px-6 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold flex items-center gap-2 shadow-lg shadow-emerald-950 transition-all active:scale-95 disabled:opacity-50 cursor-pointer"
          >
            {isEvaluating ? (
              <span>Calculating Net Margin...</span>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Evaluate True Profit Margin</span>
              </>
            )}
          </button>
        </div>

        {/* Evaluation Output Result */}
        {evalResult && (
          <div className="p-4 sm:p-5 rounded-xl bg-slate-950 border border-emerald-500/40 space-y-4 animate-in fade-in duration-300">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-center">
                <div className="text-[11px] text-slate-400">Ola 28% Commission Lost</div>
                <div className="text-lg font-black text-rose-400 font-mono mt-0.5">-₹{evalResult.olaCommission}</div>
              </div>
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-center">
                <div className="text-[11px] text-slate-400">Fuel & Toll Cost</div>
                <div className="text-lg font-black text-amber-400 font-mono mt-0.5">₹{evalResult.fuelCost + evalResult.tollCost}</div>
              </div>
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-center">
                <div className="text-[11px] text-slate-400">Net Ola Take-Home</div>
                <div className="text-xl font-black text-slate-100 font-mono mt-0.5">₹{evalResult.netTakeHomeOla}</div>
                <div className="text-[10px] text-slate-500">₹{evalResult.profitPerMinute}/min</div>
              </div>
              <div className="p-3 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-center">
                <div className="text-[11px] text-emerald-300 font-bold">Direct Client Take-Home</div>
                <div className="text-xl font-black text-emerald-400 font-mono mt-0.5">₹{evalResult.netTakeHomeDirect}</div>
                <div className="text-[10px] text-emerald-300 font-bold">+₹{evalResult.directExtraEarnings} EXTRA in pocket</div>
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-300 space-y-1">
              <div className="font-bold text-white flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-400" /> AI Strategy & Deadhead Analysis:
              </div>
              <div className="text-slate-300 leading-relaxed">{evalResult.aiVerdict}</div>
            </div>
          </div>
        )}

      </div>

      {/* Google Maps Platform API Key Modal */}
      {showKeyModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-white font-bold">
                <Key className="w-5 h-5 text-emerald-400" />
                <span>Google Maps Platform Pro</span>
              </div>
              <button
                onClick={() => setShowKeyModal(false)}
                className="text-slate-400 hover:text-white text-xs px-2 py-1 rounded bg-slate-800"
              >
                Close
              </button>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed">
              Enter your Google Maps API Key to enable official Google Maps 3D satellite imagery, Advanced Markers, and real-time live traffic heatmaps.
            </p>

            <div className="space-y-2">
              <label className="text-xs font-semibold text-slate-300 block">Google Maps API Key</label>
              <input
                type="password"
                value={keyInput}
                onChange={(e) => setKeyInput(e.target.value)}
                placeholder="AIzaSy..."
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-xs text-white font-mono focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs space-y-2">
              <div className="text-slate-300 font-semibold flex items-center gap-1.5">
                <Info className="w-4 h-4 text-sky-400" /> Prototyping Demo Key:
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                For rapid prototyping without billing setup, you can generate a Google Maps Demo Key.
              </p>
              <a
                href="https://mapsplatform.google.com/maps-demo-key?utm_campaign=gmp_mcp_codeassist_v1_aistudio"
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1 text-[11px] text-emerald-400 hover:underline font-semibold"
              >
                <span>Get Google Maps Demo Key</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => {
                  handleSaveApiKey('');
                  setActiveEngine('LEAFLET');
                }}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-slate-800 text-slate-300 hover:text-white"
              >
                Use Vector / OSM
              </button>
              <button
                onClick={() => handleSaveApiKey(keyInput)}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-lg"
              >
                Activate Google Maps
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
