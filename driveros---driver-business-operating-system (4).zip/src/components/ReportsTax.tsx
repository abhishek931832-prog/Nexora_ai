import React, { useState } from 'react';
import { 
  FileText, 
  Download, 
  TrendingUp, 
  DollarSign, 
  ShieldCheck, 
  Percent, 
  Sparkles, 
  Calculator, 
  CheckCircle2, 
  ArrowUpRight,
  Receipt,
  FileSpreadsheet
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  Legend 
} from 'recharts';
import { DriverProfile, TripRecord, ExpenseRecord } from '../types';
import { exportPnLReportPDF, exportTripsAndExpensesExcel } from '../utils/exportUtils';
import { estimateTaxAndGST } from '../services/api';

interface ReportsTaxProps {
  driver: DriverProfile;
  trips: TripRecord[];
  expenses: ExpenseRecord[];
}

export const ReportsTax: React.FC<ReportsTaxProps> = ({
  driver,
  trips,
  expenses,
}) => {
  const [selectedPeriod, setSelectedPeriod] = useState<'DAILY' | 'WEEKLY' | 'MONTHLY'>('MONTHLY');
  const [taxEstimationResult, setTaxEstimationResult] = useState<any>(null);
  const [isEstimatingTax, setIsEstimatingTax] = useState(false);

  // Financial Computations
  const totalGross = trips.reduce((sum, t) => sum + t.grossFare, 0);
  const totalCommission = trips.reduce((sum, t) => sum + t.platformCommission, 0);
  const totalFuel = trips.reduce((sum, t) => sum + t.fuelCost, 0);
  const totalToll = trips.reduce((sum, t) => sum + t.tollCost, 0);
  const totalExpenses = expenses.reduce((sum, e) => sum + e.amount, 0);
  const totalNetTakeHome = totalGross - totalCommission - totalExpenses;

  // Monthly breakdown dataset
  const monthlyData = [
    { month: 'Jun', gross: 58000, commission: 16240, expenses: 14500, net: 27260 },
    { month: 'Jul', gross: 64000, commission: 17920, expenses: 15200, net: 30880 },
    { month: 'Aug (Current)', gross: 72400, commission: 12100, expenses: 16800, net: 43500 },
  ];

  const handleRunTaxEstimation = async () => {
    setIsEstimatingTax(true);
    try {
      const digitalFares = Math.round(totalGross * 0.85); // 85% UPI/Card
      const cashFares = totalGross - digitalFares;
      const res = await estimateTaxAndGST(
        totalGross,
        digitalFares,
        cashFares,
        totalExpenses,
        'INDIVIDUAL'
      );
      setTaxEstimationResult(res.taxComputation);
    } catch (err) {
      console.error(err);
    } finally {
      setIsEstimatingTax(false);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-400">
              <FileText className="w-5 h-5" />
            </span>
            <h2 className="text-lg sm:text-xl font-bold text-white tracking-tight">
              P&L Financial Reports & Section 44AD Tax Assistant
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Dynamic P&L summaries, bank-ready PDF balance sheets, and Indian presumptive income tax computation.
          </p>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <button
            onClick={() => exportTripsAndExpensesExcel(driver, trips, expenses)}
            className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-200 text-xs font-semibold shadow transition-all"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
            <span>Excel Export</span>
          </button>
          <button
            onClick={() => exportPnLReportPDF(driver, trips, expenses, selectedPeriod)}
            className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 text-white text-xs font-bold shadow-lg shadow-emerald-950 transition-all active:scale-95"
          >
            <Download className="w-4 h-4" />
            <span>Download Bank-Ready PDF</span>
          </button>
        </div>
      </div>

      {/* Primary Financial Transparency Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg">
          <div className="text-xs font-bold uppercase tracking-wider text-slate-400">
            Total Gross Revenue
          </div>
          <div className="text-2xl sm:text-3xl font-black text-white font-mono mt-2">
            ₹{totalGross.toLocaleString('en-IN')}
          </div>
          <div className="text-xs text-slate-400 mt-1">Across all platforms & direct rides</div>
        </div>

        <div className="bg-slate-900/90 border border-rose-500/30 rounded-2xl p-4 sm:p-5 shadow-lg">
          <div className="text-xs font-bold uppercase tracking-wider text-rose-400">
            Platform Commissions Paid
          </div>
          <div className="text-2xl sm:text-3xl font-black text-rose-300 font-mono mt-2">
            -₹{totalCommission.toLocaleString('en-IN')}
          </div>
          <div className="text-xs text-slate-400 mt-1">Ola/Uber fee deduction</div>
        </div>

        <div className="bg-slate-900/90 border border-amber-500/30 rounded-2xl p-4 sm:p-5 shadow-lg">
          <div className="text-xs font-bold uppercase tracking-wider text-amber-400">
            Operating Expenses
          </div>
          <div className="text-2xl sm:text-3xl font-black text-amber-300 font-mono mt-2">
            -₹{totalExpenses.toLocaleString('en-IN')}
          </div>
          <div className="text-xs text-slate-400 mt-1">Fuel, Tolls, Service & EMIs</div>
        </div>

        <div className="bg-slate-900/90 border border-emerald-500/30 rounded-2xl p-4 sm:p-5 shadow-lg">
          <div className="text-xs font-bold uppercase tracking-wider text-emerald-400">
            Net In-Pocket Profit
          </div>
          <div className="text-2xl sm:text-3xl font-black text-emerald-400 font-mono mt-2">
            ₹{totalNetTakeHome.toLocaleString('en-IN')}
          </div>
          <div className="text-xs text-emerald-300 font-semibold mt-1">Real unencumbered cash</div>
        </div>
      </div>

      {/* Monthly P&L Trend Chart */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-emerald-400" /> Quarterly Profit & Loss Growth
            </h3>
            <p className="text-xs text-slate-400">
              Notice the surge in Net Profit in August as Direct Client rides replaced Ola commission cuts.
            </p>
          </div>
          <div className="flex items-center gap-1 bg-slate-800 p-1 rounded-xl">
            {['DAILY', 'WEEKLY', 'MONTHLY'].map(period => (
              <button
                key={period}
                onClick={() => setSelectedPeriod(period as any)}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                  selectedPeriod === period
                    ? 'bg-emerald-600 text-white'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {period}
              </button>
            ))}
          </div>
        </div>

        <div className="h-72 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={monthlyData} margin={{ top: 20, right: 10, left: -10, bottom: 0 }}>
              <XAxis dataKey="month" stroke="#64748b" fontSize={12} />
              <YAxis stroke="#64748b" fontSize={12} />
              <Tooltip 
                contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px', fontSize: '12px' }}
                formatter={(value: any) => [`₹${value}`, '']}
              />
              <Legend wrapperStyle={{ fontSize: '12px', paddingTop: '10px' }} />
              <Bar dataKey="gross" name="Gross Revenue" fill="#38bdf8" radius={[4, 4, 0, 0]} />
              <Bar dataKey="commission" name="Ola Cut" fill="#f43f5e" radius={[4, 4, 0, 0]} />
              <Bar dataKey="expenses" name="Fuel/Maint" fill="#fbbf24" radius={[4, 4, 0, 0]} />
              <Bar dataKey="net" name="Net In-Pocket Profit" fill="#10b981" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Section 44AD Presumptive Taxation Calculator */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Calculator className="w-5 h-5 text-emerald-400" /> Section 44AD Presumptive Income Tax Optimizer
            </h3>
            <p className="text-xs text-slate-400">
              For commercial drivers & cab operators under ₹2 Crore turnover. No complex audit books required.
            </p>
          </div>

          <button
            onClick={handleRunTaxEstimation}
            disabled={isEstimatingTax}
            className="py-2 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-lg transition-all active:scale-95 disabled:opacity-50"
          >
            <Sparkles className="w-4 h-4" />
            <span>{taxEstimationResult ? 'Re-calculate Tax' : 'Run Section 44AD Tax Calculation'}</span>
          </button>
        </div>

        {taxEstimationResult ? (
          <div className="p-4 sm:p-5 rounded-xl bg-slate-950 border border-emerald-500/40 space-y-4 animate-in fade-in">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center text-xs">
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                <span className="text-slate-400 block text-[11px]">Gross Annual Turnover</span>
                <span className="text-lg font-black text-white font-mono mt-1 block">
                  ₹{taxEstimationResult.annualizedTurnover?.toLocaleString('en-IN') || '8,68,800'}
                </span>
              </div>
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                <span className="text-slate-400 block text-[11px]">Deemed Profit Rate (6%)</span>
                <span className="text-lg font-black text-emerald-400 font-mono mt-1 block">
                  ₹{taxEstimationResult.deemedProfit44AD?.toLocaleString('en-IN') || '52,128'}
                </span>
              </div>
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                <span className="text-slate-400 block text-[11px]">Standard Deduction</span>
                <span className="text-lg font-black text-sky-300 font-mono mt-1 block">
                  ₹50,000
                </span>
              </div>
              <div className="p-3 rounded-xl bg-emerald-950/60 border border-emerald-500/40">
                <span className="text-emerald-300 font-bold block text-[11px]">Net Income Tax Payable</span>
                <span className="text-2xl font-black text-emerald-400 font-mono mt-1 block">
                  ₹0 (Nil Tax under 87A)
                </span>
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-300 space-y-1.5">
              <div className="font-bold text-white flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" /> Presumptive Tax Benefit Summary:
              </div>
              <p className="text-slate-300 leading-relaxed text-[11px]">
                {taxEstimationResult.taxSummary || 'Under Section 44AD with 85%+ digital receipts via UPI/Card, your deemed taxable profit is only 6% of turnover. With Section 87A rebate for income up to ₹7,00,000 under the New Tax Regime, your total payable income tax is ₹0. You are 100% compliant and ready for home/car loan approvals!'}
              </p>
            </div>
          </div>
        ) : (
          <div className="p-5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-400 flex items-center justify-between">
            <span>Click the button to run the AI engine on Section 44AD 6% digital vs 8% cash deemed profits.</span>
            <span className="text-emerald-400 font-mono font-bold">Zero Tax Filing Strategy</span>
          </div>
        )}
      </div>

    </div>
  );
};
