import React, { useState } from 'react';
import { 
  ShieldAlert, 
  ShieldCheck, 
  AlertTriangle, 
  Coffee, 
  HeartHandshake, 
  CheckCircle2, 
  Bell, 
  Car, 
  Clock, 
  FileText, 
  UserCheck, 
  Volume2, 
  Sparkles,
  PhoneCall
} from 'lucide-react';
import { FatigueMonitoringState, MicroInsuranceState, DriverProfile } from '../types';

interface SafetyFatigueProps {
  driver: DriverProfile;
  fatigue: FatigueMonitoringState;
  insurance: MicroInsuranceState;
  activeSubSection?: 'fatigue' | 'insurance' | 'all';
  onChangeSubSection?: (sub: 'fatigue' | 'insurance') => void;
  onTriggerAlertTest: () => void;
  onClaimInsurance: () => void;
}

export const SafetyFatigue: React.FC<SafetyFatigueProps> = ({
  driver,
  fatigue,
  insurance,
  activeSubSection = 'all',
  onChangeSubSection,
  onTriggerAlertTest,
  onClaimInsurance,
}) => {
  const [internalSub, setInternalSub] = useState<'fatigue' | 'insurance'>(
    activeSubSection === 'insurance' ? 'insurance' : 'fatigue'
  );

  const currentSub = activeSubSection === 'all' ? internalSub : activeSubSection;

  const [passengerSearchQuery, setPassengerSearchQuery] = useState('');
  const [passengerResult, setPassengerResult] = useState<any>(null);
  const [isAlertPlaying, setIsAlertPlaying] = useState(false);
  const [claimSubmitted, setClaimSubmitted] = useState(false);

  const handleSearchPassenger = () => {
    if (!passengerSearchQuery.trim()) return;
    // Simulated passenger lookup
    setPassengerResult({
      name: passengerSearchQuery,
      safetyBadge: 'VERIFIED_CORP_EXECUTIVE',
      trustScore: 98,
      totalCompletedTrips: 142,
      incidentReportCount: 0,
      paymentReliability: '100% Instant UPI',
      notes: 'Verified corporate commuter (Infosys ECity). Zero cancellation record.',
    });
  };

  const handleSimulateAlertBuzzer = () => {
    setIsAlertPlaying(true);
    // Play subtle audio beep using Web Audio API if available
    try {
      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(880, ctx.currentTime); // A5 note
      osc.frequency.exponentialRampToValueAtTime(440, ctx.currentTime + 0.5);
      gain.gain.setValueAtTime(0.3, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.5);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.6);
    } catch (e) {
      console.warn('AudioContext not allowed without gesture', e);
    }

    setTimeout(() => {
      setIsAlertPlaying(false);
    }, 1200);
  };

  return (
    <div className="space-y-6 pb-12">
      
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-rose-500/20 text-rose-400">
              <ShieldAlert className="w-5 h-5" />
            </span>
            <h2 className="text-lg sm:text-xl font-bold text-white tracking-tight">
              Preventive Safety & Driver Protection Shield
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Going beyond reactive SOS: Sensor fatigue monitoring, verified passenger badges, and ₹5 Lakh micro-insurance.
          </p>
        </div>

        <button
          onClick={handleSimulateAlertBuzzer}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-200 text-xs font-semibold shadow transition-all active:scale-95"
        >
          <Volume2 className={`w-4 h-4 text-amber-400 ${isAlertPlaying ? 'animate-bounce' : ''}`} />
          <span>Test In-Cab Alert Buzzer</span>
        </button>
      </div>

      {/* Sub-Tab Navigation for SAFETY */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
        <button
          onClick={() => {
            setInternalSub('fatigue');
            onChangeSubSection?.('fatigue');
          }}
          className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
            currentSub === 'fatigue'
              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
          }`}
        >
          <Clock className="w-3.5 h-3.5 text-emerald-400" />
          <span>Fatigue & Alertness Telemetry</span>
          <span className="text-[10px] bg-slate-800 text-emerald-300 px-1.5 py-0.2 rounded font-mono">
            {fatigue.restBreakCountdownMinutes}m break
          </span>
        </button>

        <button
          onClick={() => {
            setInternalSub('insurance');
            onChangeSubSection?.('insurance');
          }}
          className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
            currentSub === 'insurance'
              ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40 shadow-sm'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
          }`}
        >
          <ShieldCheck className="w-3.5 h-3.5 text-sky-400" />
          <span>Micro-Insurance Cover</span>
          <span className="text-[10px] bg-slate-800 text-sky-300 px-1.5 py-0.2 rounded font-mono">
            ₹5L Cover
          </span>
        </button>
      </div>

      {/* Grid: Fatigue Sensor & Micro Insurance */}
      <div className={`grid gap-6 ${activeSubSection === 'all' ? 'grid-cols-1 lg:grid-cols-2' : 'grid-cols-1'}`}>
        
        {/* Preventive Fatigue Monitoring */}
        {(currentSub === 'fatigue' || activeSubSection === 'all') && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-5">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-emerald-400" />
              <h3 className="text-sm font-bold text-white">Sensor-Based Driver Alertness</h3>
            </div>
            <span className="text-xs font-mono font-bold text-emerald-400 bg-emerald-500/10 px-2.5 py-0.5 rounded border border-emerald-500/20">
              Score: {fatigue.fatigueScore}/100 (Optimal)
            </span>
          </div>

          <div className="grid grid-cols-2 gap-3 text-center text-xs">
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
              <div className="text-[11px] text-slate-400">Continuous Shift Driving</div>
              <div className="text-2xl font-black text-white font-mono mt-1">
                {Math.floor(fatigue.continuousDrivingMinutes / 60)}h {fatigue.continuousDrivingMinutes % 60}m
              </div>
              <div className="text-[10px] text-slate-500 mt-1">Max limit: 4.5 hours</div>
            </div>

            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
              <div className="text-[11px] text-slate-400">Mandatory Chai Break In</div>
              <div className="text-2xl font-black text-amber-400 font-mono mt-1">
                {fatigue.restBreakCountdownMinutes} mins
              </div>
              <div className="text-[10px] text-slate-500 mt-1">Prevents highway drowsy accidents</div>
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-xs space-y-1">
            <div className="font-semibold text-emerald-400 flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5" /> Accelerometer & Gyro Sensor Telemetry
            </div>
            <div className="text-slate-300 text-[11px] leading-relaxed">
              Steering variance: <strong>Normal</strong> • Micro-sleep eye closures: <strong>0</strong> • Phone vibration alert active on sudden deceleration.
            </div>
          </div>

          <div className="flex items-center justify-between text-xs pt-1">
            <span className="text-slate-400">Nearest Verified Rest Hub:</span>
            <span className="font-bold text-emerald-400">HSR BBMP Driver Safe Hub (1.8 km)</span>
          </div>
        </div>
        )}

        {/* Per-Trip Micro-Insurance */}
        {(currentSub === 'insurance' || activeSubSection === 'all') && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-5">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-sky-400" />
              <h3 className="text-sm font-bold text-white">Active Per-Trip Micro-Insurance</h3>
            </div>
            <span className="text-xs font-mono font-bold text-sky-300 bg-sky-500/10 px-2.5 py-0.5 rounded border border-sky-500/20">
              ₹1.50 / Trip Auto-Shield
            </span>
          </div>

          <div className="grid grid-cols-2 gap-3 text-center text-xs">
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
              <div className="text-[11px] text-slate-400">Accidental Death & Disability Cover</div>
              <div className="text-2xl font-black text-sky-300 font-mono mt-1">
                ₹5,00,000
              </div>
              <div className="text-[10px] text-slate-500 mt-1">24x7 On-Duty Protection</div>
            </div>

            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
              <div className="text-[11px] text-slate-400">Daily Hospital Cash</div>
              <div className="text-2xl font-black text-emerald-400 font-mono mt-1">
                ₹1,500 / day
              </div>
              <div className="text-[10px] text-slate-500 mt-1">Up to 30 days recovery</div>
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 text-xs space-y-1.5">
            <div className="flex items-center justify-between text-slate-300">
              <span>Policy Number:</span>
              <span className="font-mono text-white font-bold">{insurance.policyNumber}</span>
            </div>
            <div className="flex items-center justify-between text-slate-300">
              <span>Underwriting Partner:</span>
              <span className="text-sky-400 font-medium">{insurance.provider}</span>
            </div>
            <div className="flex items-center justify-between text-slate-300">
              <span>Total Trips Covered to Date:</span>
              <span className="text-emerald-400 font-mono font-bold">{insurance.totalCoveredTrips} Trips</span>
            </div>
          </div>

          {claimSubmitted ? (
            <div className="p-3 rounded-xl bg-emerald-950 border border-emerald-500 text-xs text-emerald-200 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>Emergency Claim Ticket #CLM-9821 logged. ICICI Lombard adjuster assigned.</span>
            </div>
          ) : (
            <button
              onClick={() => setClaimSubmitted(true)}
              className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-200 text-xs font-bold flex items-center justify-center gap-2 transition-all shadow"
            >
              <HeartHandshake className="w-4 h-4 text-sky-400" />
              <span>Initiate 1-Tap Emergency Cashless Claim</span>
            </button>
          )}
        </div>
        )}

      </div>

      {/* Verified Passenger Safety Badge Lookup */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <UserCheck className="w-4 h-4 text-purple-400" /> Verified Passenger Safety Badge Lookup
            </h3>
            <p className="text-xs text-slate-400">
              Verify customer corporate credentials & trust score prior to accepting high-value or night-time trips.
            </p>
          </div>
          <span className="text-xs text-slate-400 font-mono">Two-Way Safety Rating</span>
        </div>

        <div className="flex items-center gap-2">
          <input
            type="text"
            value={passengerSearchQuery}
            onChange={(e) => setPassengerSearchQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSearchPassenger()}
            placeholder="Enter passenger name or corporate phone number..."
            className="flex-1 bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
          />
          <button
            onClick={handleSearchPassenger}
            className="px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold shadow-lg transition-all"
          >
            Verify Safety Badge
          </button>
        </div>

        {passengerResult && (
          <div className="p-4 rounded-xl bg-slate-950 border border-purple-500/40 space-y-3 animate-in fade-in duration-200">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="font-bold text-white text-sm">{passengerResult.name}</span>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-500/20 text-purple-300 border border-purple-500/30">
                  {passengerResult.safetyBadge}
                </span>
              </div>
              <span className="text-xs font-mono font-bold text-emerald-400">
                Trust Score: {passengerResult.trustScore}/100
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs text-slate-300">
              <div>Completed Rides: <strong className="text-white font-mono">{passengerResult.totalCompletedTrips}</strong></div>
              <div>Safety Incidents: <strong className="text-emerald-400 font-mono">0 (Clean Record)</strong></div>
              <div>Payment Mode: <strong className="text-sky-300">{passengerResult.paymentReliability}</strong></div>
            </div>

            <p className="text-xs text-slate-400 italic">
              "{passengerResult.notes}"
            </p>
          </div>
        )}
      </div>

    </div>
  );
};
