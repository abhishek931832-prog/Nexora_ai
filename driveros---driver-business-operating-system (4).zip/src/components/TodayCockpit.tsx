import React, { useState, useEffect } from 'react';
import { 
  TrendingUp, 
  DollarSign, 
  Percent, 
  Fuel, 
  Receipt, 
  ArrowUpRight, 
  Car, 
  Zap, 
  Award, 
  Sparkles,
  CheckCircle2, 
  Clock, 
  Radio, 
  PlusCircle, 
  Banknote, 
  AlertTriangle, 
  Compass, 
  ChevronRight,
  ShieldCheck,
  Calendar,
  Layers,
  Sliders,
  Filter
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { TripRecord, ExpenseRecord, DriverProfile, ShiftState } from '../types';

export type TodaySubView = 'earnings' | 'target' | 'trips' | 'duty';

interface TodayCockpitProps {
  driver: DriverProfile;
  trips: TripRecord[];
  expenses: ExpenseRecord[];
  shift: ShiftState;
  activeSubView: TodaySubView;
  onChangeSubView: (subView: TodaySubView) => void;
  onToggleDuty: () => void;
  onOpenNewTrip: () => void;
  onOpenScanReceipt: () => void;
  onOpenCustomerPayment: (trip?: TripRecord | null) => void;
  onNavigatePillar: (pillar: string, subView?: string) => void;
}

export const TodayCockpit: React.FC<TodayCockpitProps> = ({
  driver,
  trips,
  expenses,
  shift,
  activeSubView,
  onChangeSubView,
  onToggleDuty,
  onOpenNewTrip,
  onOpenScanReceipt,
  onOpenCustomerPayment,
  onNavigatePillar,
}) => {
  // Aggregate today's metrics
  const todayDateStr = new Date().toISOString().split('T')[0];
  const todayTrips = trips.filter(t => t.timestamp.startsWith(todayDateStr));
  const todayExpenses = expenses.filter(e => e.date === todayDateStr);

  const todayGross = todayTrips.reduce((sum, t) => sum + t.grossFare, 0);
  const todayCommissionBleed = todayTrips.reduce((sum, t) => sum + t.platformCommission, 0);
  const todayFuel = todayTrips.reduce((sum, t) => sum + t.fuelCost, 0);
  const todayToll = todayTrips.reduce((sum, t) => sum + t.tollCost, 0);
  const todayTips = todayTrips.reduce((sum, t) => sum + t.tips, 0);
  const todayOtherExpenses = todayExpenses.reduce((sum, e) => sum + (e.category !== 'CNG_FUEL' && e.category !== 'TOLL' ? e.amount : 0), 0);
  
  // Real In-Pocket Net Profit
  const todayNetProfit = todayGross - todayCommissionBleed - todayFuel - todayToll + todayTips - todayOtherExpenses;
  const todayKm = todayTrips.reduce((sum, t) => sum + t.distanceKm, 0);
  const todayMinutes = todayTrips.reduce((sum, t) => sum + t.durationMinutes, 0);
  const profitPerKm = todayKm > 0 ? (todayNetProfit / todayKm).toFixed(1) : '0';
  const profitPerHour = todayMinutes > 0 ? ((todayNetProfit / todayMinutes) * 60).toFixed(0) : '0';

  // Target Goal
  const [dailyGoal, setDailyGoal] = useState<number>(shift.dailyGoalAmount || 3500);
  const [isEditingGoal, setIsEditingGoal] = useState(false);
  const [tempGoalInput, setTempGoalInput] = useState<string>(String(shift.dailyGoalAmount || 3500));
  const goalPercent = Math.min(100, Math.round((todayNetProfit / dailyGoal) * 100));
  const [hasCelebrated, setHasCelebrated] = useState(false);

  // Filter for today's trips sub-view
  const [tripPlatformFilter, setTripPlatformFilter] = useState<string>('ALL');

  useEffect(() => {
    if (goalPercent >= 100 && !hasCelebrated) {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#10b981', '#38bdf8', '#fbbf24'],
      });
      setHasCelebrated(true);
    }
  }, [goalPercent, hasCelebrated]);

  const filteredTrips = tripPlatformFilter === 'ALL' 
    ? todayTrips 
    : todayTrips.filter(t => t.platform === tripPlatformFilter);

  const handleSaveGoal = () => {
    const val = parseInt(tempGoalInput, 10);
    if (!isNaN(val) && val > 0) {
      setDailyGoal(val);
      setIsEditingGoal(false);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      
      {/* Sub-View Navigation Pills (Specific to TODAY pillar) */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 border-b border-slate-800">
        <button
          onClick={() => onChangeSubView('earnings')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
            activeSubView === 'earnings'
              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-sm shadow-emerald-950 ring-1 ring-emerald-500/20'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/70 border border-transparent'
          }`}
        >
          <DollarSign className="w-4 h-4 text-emerald-400" />
          <span>Current Earnings</span>
          <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-slate-300">
            ₹{todayNetProfit.toLocaleString('en-IN')}
          </span>
        </button>

        <button
          onClick={() => onChangeSubView('target')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
            activeSubView === 'target'
              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-sm shadow-emerald-950 ring-1 ring-emerald-500/20'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/70 border border-transparent'
          }`}
        >
          <Award className="w-4 h-4 text-amber-400" />
          <span>Today's Target</span>
          <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-amber-300">
            {goalPercent}%
          </span>
        </button>

        <button
          onClick={() => onChangeSubView('trips')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
            activeSubView === 'trips'
              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-sm shadow-emerald-950 ring-1 ring-emerald-500/20'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/70 border border-transparent'
          }`}
        >
          <Car className="w-4 h-4 text-sky-400" />
          <span>Trips</span>
          <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-sky-300">
            {todayTrips.length} Rides
          </span>
        </button>

        <button
          onClick={() => onChangeSubView('duty')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
            activeSubView === 'duty'
              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-sm shadow-emerald-950 ring-1 ring-emerald-500/20'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/70 border border-transparent'
          }`}
        >
          <Radio className={`w-4 h-4 ${shift.isOnDuty ? 'text-emerald-400 animate-pulse' : 'text-slate-400'}`} />
          <span>Current Duty Status</span>
          <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded ${
            shift.isOnDuty ? 'bg-emerald-500/30 text-emerald-200' : 'bg-slate-800 text-slate-400'
          }`}>
            {shift.isOnDuty ? 'ACTIVE' : 'OFF'}
          </span>
        </button>
      </div>

      {/* =========================================================================
          SUB-VIEW 1: CURRENT EARNINGS
         ========================================================================= */}
      {activeSubView === 'earnings' && (
        <div className="space-y-6">
          {/* Main KPI Stats Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Real In-Pocket Net Profit */}
            <div className="bg-slate-900/90 border border-emerald-500/30 rounded-2xl p-4 sm:p-5 shadow-lg relative overflow-hidden group">
              <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/10 rounded-full blur-xl group-hover:bg-emerald-500/20 transition-all" />
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
                  <TrendingUp className="w-4 h-4" /> Real Take-Home Cash
                </span>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full font-mono font-semibold border border-emerald-500/30">
                  After All Deductions
                </span>
              </div>
              <div className="mt-3">
                <div className="text-2xl sm:text-3xl font-black text-white font-mono tracking-tight privacy-sensitive">
                  ₹{todayNetProfit.toLocaleString('en-IN')}
                </div>
                <div className="flex items-center gap-2 mt-1 text-xs text-slate-400">
                  <span>Net margin: <strong className="text-emerald-400 font-mono">{todayGross > 0 ? Math.round((todayNetProfit / todayGross) * 100) : 0}%</strong></span>
                  <span>•</span>
                  <span>{todayTrips.length} Rides today</span>
                </div>
              </div>
            </div>

            {/* Aggregator Commission Cut */}
            <div className="bg-slate-900/90 border border-slate-800 hover:border-amber-500/30 rounded-2xl p-4 sm:p-5 shadow-lg relative overflow-hidden transition-all">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
                  <Percent className="w-4 h-4" /> Aggregator Commission Cut
                </span>
                <span className="text-[10px] bg-amber-500/10 text-amber-300 px-2 py-0.5 rounded-full font-mono border border-amber-500/20">
                  Ola & Uber Bleed
                </span>
              </div>
              <div className="mt-3">
                <div className="text-2xl sm:text-3xl font-black text-amber-300 font-mono tracking-tight privacy-sensitive">
                  -₹{todayCommissionBleed.toLocaleString('en-IN')}
                </div>
                <div className="flex items-center gap-1.5 mt-1 text-xs text-slate-400">
                  <span>Average cut: <strong className="text-amber-400 font-mono">{todayGross > 0 ? ((todayCommissionBleed / todayGross) * 100).toFixed(1) : 0}%</strong></span>
                  <span className="text-slate-500 text-[10px]">(Lost revenue)</span>
                </div>
              </div>
            </div>

            {/* Gross Fare Billed */}
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                  <DollarSign className="w-4 h-4 text-sky-400" /> Gross Rider Meter
                </span>
                <span className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded font-mono">
                  Customer Paid
                </span>
              </div>
              <div className="mt-3">
                <div className="text-2xl sm:text-3xl font-black text-slate-100 font-mono tracking-tight privacy-sensitive">
                  ₹{todayGross.toLocaleString('en-IN')}
                </div>
                <div className="flex items-center gap-2 mt-1 text-xs text-slate-400">
                  <span>Tips collected: <strong className="text-emerald-400 font-mono">+₹{todayTips}</strong></span>
                </div>
              </div>
            </div>

            {/* Operating Expenses (Fuel & Toll) */}
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-rose-400 flex items-center gap-1.5">
                  <Fuel className="w-4 h-4" /> Shift Operating Costs
                </span>
                <span className="text-[10px] bg-rose-500/10 text-rose-300 px-2 py-0.5 rounded-full font-mono border border-rose-500/20">
                  Fuel & Tolls
                </span>
              </div>
              <div className="mt-3">
                <div className="text-2xl sm:text-3xl font-black text-rose-300 font-mono tracking-tight privacy-sensitive">
                  ₹{(todayFuel + todayToll + todayOtherExpenses).toLocaleString('en-IN')}
                </div>
                <div className="flex items-center gap-2 mt-1 text-xs text-slate-400">
                  <span>Fuel: ₹{todayFuel}</span>
                  <span>•</span>
                  <span>Tolls: ₹{todayToll}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Earnings Velocity & Payout Breakdown */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <Zap className="w-4 h-4 text-sky-400" />
                  <h3 className="text-sm font-bold text-white">Earnings Velocity</h3>
                </div>
                <span className="text-xs text-emerald-400 font-mono">Live Run-Rate</span>
              </div>

              <div className="grid grid-cols-2 gap-3 text-center">
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                  <div className="text-[11px] text-slate-400 font-medium">Net Profit / KM</div>
                  <div className="text-2xl font-black text-emerald-400 font-mono mt-1">₹{profitPerKm}</div>
                  <div className="text-[10px] text-slate-500 mt-0.5">Ola avg: ₹14/km</div>
                </div>
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                  <div className="text-[11px] text-slate-400 font-medium">Net Profit / Hour</div>
                  <div className="text-2xl font-black text-sky-400 font-mono mt-1">₹{profitPerHour}</div>
                  <div className="text-[10px] text-slate-500 mt-0.5">Ola avg: ₹180/hr</div>
                </div>
              </div>

              <div className="text-xs text-slate-400 pt-2 border-t border-slate-800/80 flex items-center justify-between">
                <span>Total Shift Distance:</span>
                <span className="font-mono text-white font-bold">{todayKm} KM</span>
              </div>
              <div className="text-xs text-slate-400 flex items-center justify-between">
                <span>Active Road Minutes:</span>
                <span className="font-mono text-white font-bold">{todayMinutes} mins</span>
              </div>
            </div>

            {/* Payment Collection Channels */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <Banknote className="w-4 h-4 text-emerald-400" />
                  <h3 className="text-sm font-bold text-white">Payment Collections</h3>
                </div>
                <button
                  onClick={() => onOpenCustomerPayment()}
                  className="text-xs text-emerald-400 hover:underline font-semibold"
                >
                  + Collect
                </button>
              </div>

              <div className="space-y-2.5 text-xs">
                <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950 border border-slate-800">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                    <span className="text-slate-300 font-medium">Instant UPI In Bank</span>
                  </div>
                  <span className="font-mono font-bold text-emerald-400">
                    ₹{todayTrips.filter(t => t.paymentMode === 'UPI').reduce((sum, t) => sum + t.netProfit, 0).toLocaleString('en-IN')}
                  </span>
                </div>

                <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950 border border-slate-800">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-amber-400"></span>
                    <span className="text-slate-300 font-medium">Cash in Pocket</span>
                  </div>
                  <span className="font-mono font-bold text-amber-300">
                    ₹{todayTrips.filter(t => t.paymentMode === 'CASH').reduce((sum, t) => sum + t.netProfit, 0).toLocaleString('en-IN')}
                  </span>
                </div>

                <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-950 border border-slate-800">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-sky-400"></span>
                    <span className="text-slate-300 font-medium">Platform Withheld (Ola/Uber)</span>
                  </div>
                  <span className="font-mono font-bold text-sky-400">
                    ₹{todayTrips.filter(t => t.paymentMode !== 'UPI' && t.paymentMode !== 'CASH').reduce((sum, t) => sum + t.netProfit, 0).toLocaleString('en-IN')}
                  </span>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-800">
                <button
                  onClick={() => onNavigatePillar('WORK', 'payments')}
                  className="w-full py-2 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
                >
                  <span>Open Full Payments Hub</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Quick Actions & Short-Cuts */}
            <div className="bg-gradient-to-br from-slate-900 to-emerald-950/30 border border-slate-800 rounded-2xl p-5 shadow-lg flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm mb-2">
                  <Sparkles className="w-4 h-4" /> Zero-Commission Direct Strategy
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Every direct client you convert saves <strong className="text-amber-300 font-semibold">28% platform commission</strong>. Today you have saved:
                </p>
                <div className="text-3xl font-black text-emerald-400 font-mono mt-3">
                  ₹{todayTrips.filter(t => t.platform === 'DIRECT_CLIENT').reduce((sum, t) => sum + (t.grossFare * 0.28), 0).toFixed(0)}
                </div>
                <div className="text-[11px] text-slate-400 mt-1">Saved on direct booking rides today</div>
              </div>

              <div className="space-y-2 mt-4">
                <button
                  onClick={onOpenNewTrip}
                  className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center justify-center gap-2 shadow-lg shadow-emerald-950 transition-all active:scale-95"
                >
                  <PlusCircle className="w-4 h-4" />
                  <span>Log New Ride</span>
                </button>
                <button
                  onClick={onOpenScanReceipt}
                  className="w-full py-2 rounded-xl bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-2 transition-colors"
                >
                  <Receipt className="w-3.5 h-3.5 text-amber-400" />
                  <span>Scan Fuel or Expense Bill</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          SUB-VIEW 2: TODAY'S TARGET
         ========================================================================= */}
      {activeSubView === 'target' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-7 shadow-xl space-y-6">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
              <div>
                <div className="flex items-center gap-2">
                  <Award className="w-5 h-5 text-amber-400" />
                  <h3 className="text-lg font-bold text-white">Today's Daily Target Tracker</h3>
                </div>
                <p className="text-xs text-slate-400 mt-1">
                  Keep your daily earnings focused and celebrate once you achieve your target.
                </p>
              </div>

              <div className="flex items-center gap-2">
                {isEditingGoal ? (
                  <div className="flex items-center gap-1.5">
                    <input
                      type="number"
                      value={tempGoalInput}
                      onChange={(e) => setTempGoalInput(e.target.value)}
                      className="w-24 bg-slate-950 border border-slate-700 rounded-lg px-2 py-1 text-xs font-mono text-white focus:outline-none focus:border-emerald-500"
                    />
                    <button
                      onClick={handleSaveGoal}
                      className="px-2.5 py-1 bg-emerald-600 text-white rounded-lg text-xs font-bold"
                    >
                      Save
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => setIsEditingGoal(true)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-300 text-xs font-semibold transition-colors"
                  >
                    <Sliders className="w-3.5 h-3.5 text-amber-400" />
                    <span>Adjust Goal (₹{dailyGoal})</span>
                  </button>
                )}
              </div>
            </div>

            {/* Target Progress Meter */}
            <div className="p-6 rounded-2xl bg-slate-950 border border-slate-800/80 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-xs text-slate-400">Current Take-Home vs Target</span>
                  <div className="text-3xl sm:text-4xl font-black text-white font-mono mt-1">
                    ₹{todayNetProfit.toLocaleString('en-IN')} <span className="text-base font-normal text-slate-400">/ ₹{dailyGoal.toLocaleString('en-IN')}</span>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-xs text-slate-400">Completion</span>
                  <div className={`text-3xl sm:text-4xl font-black font-mono mt-1 ${
                    goalPercent >= 100 ? 'text-emerald-400' : 'text-amber-400'
                  }`}>
                    {goalPercent}%
                  </div>
                </div>
              </div>

              <div className="w-full bg-slate-800 h-4 rounded-full overflow-hidden p-0.5 border border-slate-700">
                <div 
                  className={`h-full rounded-full transition-all duration-700 ${
                    goalPercent >= 100 
                      ? 'bg-gradient-to-r from-emerald-500 to-teal-400 shadow-md shadow-emerald-500/50' 
                      : 'bg-gradient-to-r from-amber-500 to-emerald-500'
                  }`}
                  style={{ width: `${Math.min(100, goalPercent)}%` }}
                />
              </div>

              <div className="flex items-center justify-between text-xs pt-2">
                <span className="text-slate-400">Status:</span>
                <span className="font-bold text-white font-mono">
                  {todayNetProfit >= dailyGoal 
                    ? '🎉 Target Achieved! Great driving!' 
                    : `₹${(dailyGoal - todayNetProfit).toLocaleString('en-IN')} remaining to goal`}
                </span>
              </div>
            </div>

            {/* Target Planning Breakdown */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                <span className="text-slate-400">Estimated Rides Needed</span>
                <div className="text-2xl font-black text-white font-mono">
                  {todayNetProfit >= dailyGoal ? 0 : Math.ceil((dailyGoal - todayNetProfit) / (todayTrips.length > 0 ? (todayNetProfit / todayTrips.length) : 350))}
                </div>
                <p className="text-[11px] text-slate-500">Based on today's ₹{todayTrips.length > 0 ? Math.round(todayNetProfit / todayTrips.length) : 350}/trip average</p>
              </div>

              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                <span className="text-slate-400">Estimated Driving Hours</span>
                <div className="text-2xl font-black text-amber-300 font-mono">
                  {todayNetProfit >= dailyGoal ? '0h' : `${((dailyGoal - todayNetProfit) / (parseInt(profitPerHour, 10) > 0 ? parseInt(profitPerHour, 10) : 300)).toFixed(1)}h`}
                </div>
                <p className="text-[11px] text-slate-500">At your ₹{profitPerHour}/hr net velocity</p>
              </div>

              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                <span className="text-slate-400">Recommended Route Strategy</span>
                <div className="text-sm font-bold text-emerald-400 mt-1">
                  KIAL Airport Surge Queue
                </div>
                <p className="text-[11px] text-slate-500">High-yield (₹48/km) trip covers the gap fastest</p>
              </div>
            </div>

            {/* Quick Strategy Links */}
            <div className="flex flex-wrap gap-3 pt-2">
              <button
                onClick={() => onNavigatePillar('INSIGHTS', 'map')}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-750 text-emerald-400 text-xs font-semibold border border-slate-700 transition-colors"
              >
                <Compass className="w-3.5 h-3.5" />
                <span>View Profit Hotspots Map</span>
              </button>
              <button
                onClick={() => onNavigatePillar('INSIGHTS', 'coach')}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-750 text-sky-400 text-xs font-semibold border border-slate-700 transition-colors"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Ask Saathi AI Coach</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          SUB-VIEW 3: TRIPS
         ========================================================================= */}
      {activeSubView === 'trips' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-5">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
              <div>
                <div className="flex items-center gap-2">
                  <Car className="w-5 h-5 text-sky-400" />
                  <h3 className="text-lg font-bold text-white">Today's Completed Trips</h3>
                </div>
                <p className="text-xs text-slate-400 mt-1">
                  Live record of rides driven today, deductions audit, and instant customer bills.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={onOpenNewTrip}
                  className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow-md shadow-emerald-950 active:scale-95"
                >
                  <PlusCircle className="w-4 h-4" />
                  <span>+ Add Ride</span>
                </button>
                <button
                  onClick={() => onNavigatePillar('WORK', 'trips')}
                  className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-300 text-xs font-medium"
                >
                  All History
                </button>
              </div>
            </div>

            {/* Platform Filter Buttons */}
            <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
              <span className="text-slate-400 text-[11px] flex items-center gap-1 mr-1">
                <Filter className="w-3 h-3" /> Filter:
              </span>
              {['ALL', 'OLA', 'UBER', 'RAPIDO', 'NAMMA_YATRI', 'DIRECT_CLIENT'].map((p) => (
                <button
                  key={p}
                  onClick={() => setTripPlatformFilter(p)}
                  className={`px-2.5 py-1 rounded-lg font-semibold transition-all ${
                    tripPlatformFilter === p
                      ? 'bg-slate-750 text-white border border-slate-600'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                  }`}
                >
                  {p.replace('_', ' ')}
                </button>
              ))}
            </div>

            {/* Trips List */}
            {filteredTrips.length === 0 ? (
              <div className="text-center py-12 bg-slate-950 rounded-2xl border border-slate-800">
                <Car className="w-10 h-10 text-slate-600 mx-auto mb-2" />
                <div className="text-sm font-semibold text-slate-300">No trips logged yet today</div>
                <p className="text-xs text-slate-500 mt-1">Tap '+ Add Ride' to record your first completed fare.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {filteredTrips.map((trip) => (
                  <div
                    key={trip.id}
                    className="p-4 rounded-xl bg-slate-950 border border-slate-800/80 hover:border-slate-700 transition-all space-y-3"
                  >
                    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase font-mono ${
                          trip.platform === 'DIRECT_CLIENT' 
                            ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                            : trip.platform === 'OLA'
                            ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                            : trip.platform === 'UBER'
                            ? 'bg-sky-500/20 text-sky-300 border border-sky-500/30'
                            : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                        }`}>
                          {trip.platform.replace('_', ' ')}
                        </span>
                        <span className="text-xs text-slate-400 font-mono">{trip.timestamp.split('T')[1]?.substring(0, 5) || 'Today'}</span>
                        {trip.passengerName && (
                          <span className="text-xs text-slate-200 font-semibold">• {trip.passengerName}</span>
                        )}
                      </div>

                      <div className="flex items-center gap-3">
                        <div className="text-right">
                          <span className="text-[10px] text-slate-500 block">Take-Home</span>
                          <span className="text-base font-black text-emerald-400 font-mono">
                            ₹{trip.netProfit}
                          </span>
                        </div>
                        <button
                          onClick={() => onOpenCustomerPayment(trip)}
                          className="px-2.5 py-1 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 text-xs font-semibold flex items-center gap-1 transition-colors"
                          title="Generate Passenger PDF Tax Receipt"
                        >
                          <Receipt className="w-3 h-3" />
                          <span>Bill</span>
                        </button>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-300 pt-1 border-t border-slate-850">
                      <div>
                        <span className="text-slate-500 text-[11px]">From:</span> {trip.pickupLocation}
                      </div>
                      <div>
                        <span className="text-slate-500 text-[11px]">To:</span> {trip.dropoffLocation}
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-900">
                      <span>{trip.distanceKm} km • {trip.durationMinutes} mins</span>
                      <span>Gross: ₹{trip.grossFare} | Comm: -₹{trip.platformCommission} | Fuel: -₹{trip.fuelCost}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* =========================================================================
          SUB-VIEW 4: CURRENT DUTY STATUS
         ========================================================================= */}
      {activeSubView === 'duty' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-7 shadow-xl space-y-6">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
              <div>
                <div className="flex items-center gap-2">
                  <Radio className={`w-5 h-5 ${shift.isOnDuty ? 'text-emerald-400 animate-pulse' : 'text-slate-400'}`} />
                  <h3 className="text-lg font-bold text-white">Current Shift Duty Control Center</h3>
                </div>
                <p className="text-xs text-slate-400 mt-1">
                  Manage active on-road status, driving hours compliance, and cab readiness.
                </p>
              </div>

              {/* Duty Toggle Button */}
              <button
                onClick={onToggleDuty}
                className={`px-5 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer shadow-lg active:scale-95 ${
                  shift.isOnDuty
                    ? 'bg-emerald-600 text-white border border-emerald-400 shadow-emerald-950 hover:bg-emerald-500 ring-2 ring-emerald-400/40'
                    : 'bg-slate-800 text-slate-300 border border-slate-700 hover:bg-slate-700'
                }`}
              >
                <Radio className={`w-4 h-4 ${shift.isOnDuty ? 'animate-pulse text-emerald-200' : 'text-slate-400'}`} />
                <span>{shift.isOnDuty ? 'DUTY ACTIVE (ON ROAD)' : 'START SHIFT (OFF DUTY)'}</span>
              </button>
            </div>

            {/* Shift Dashboard Stats */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="p-5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                <span className="text-xs text-slate-400">Shift Started At</span>
                <div className="text-2xl font-black text-white font-mono">
                  {shift.startTime ? new Date(shift.startTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '06:30 AM'}
                </div>
                <p className="text-[11px] text-emerald-400 font-medium">Auto-synced with GPS start</p>
              </div>

              <div className="p-5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                <span className="text-xs text-slate-400">Cumulative Road Hours</span>
                <div className="text-2xl font-black text-sky-400 font-mono">
                  {Math.floor(todayMinutes / 60)}h {todayMinutes % 60}m
                </div>
                <p className="text-[11px] text-slate-400">Legal driving limit: 8 hours max</p>
              </div>

              <div className="p-5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                <span className="text-xs text-slate-400">Micro-Insurance Active Cover</span>
                <div className="text-2xl font-black text-emerald-400 font-mono">
                  ₹5,00,000
                </div>
                <p className="text-[11px] text-sky-300 font-medium">₹1.50/trip auto-shield active</p>
              </div>
            </div>

            {/* Pre-Trip Vehicle Health & Readiness Checklist */}
            <div className="p-5 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" /> Pre-Shift Cab Readiness
              </h4>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between">
                  <span className="text-slate-300">Fuel Level</span>
                  <span className="text-emerald-400 font-bold">85% CNG</span>
                </div>
                <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between">
                  <span className="text-slate-300">Tire Pressure</span>
                  <span className="text-emerald-400 font-bold">33 PSI Ok</span>
                </div>
                <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between">
                  <span className="text-slate-300">FASTag Balance</span>
                  <span className="text-emerald-400 font-mono font-bold">₹1,420</span>
                </div>
                <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between">
                  <span className="text-slate-300">AC & Sanitizer</span>
                  <span className="text-emerald-400 font-bold">Checked</span>
                </div>
              </div>
            </div>

            {/* Quick Safety Navigation */}
            <div className="pt-2 flex items-center justify-between">
              <button
                onClick={() => onNavigatePillar('SAFETY', 'fatigue')}
                className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-200 text-xs font-semibold border border-slate-700 transition-colors"
              >
                <span>View Full Fatigue & Alertness Telemetry</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
