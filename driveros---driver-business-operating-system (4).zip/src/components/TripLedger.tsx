import React, { useState } from 'react';
import { 
  Car, 
  Search, 
  Filter, 
  ArrowUpRight, 
  ShieldCheck, 
  CheckCircle, 
  PlusCircle, 
  Download, 
  DollarSign, 
  Clock, 
  Fuel, 
  Share2, 
  UserCheck, 
  AlertCircle,
  QrCode,
  FileText,
  Banknote
} from 'lucide-react';
import { TripRecord, PlatformType, DriverProfile } from '../types';
import { exportTripsAndExpensesExcel, exportCustomerReceiptPDF, CustomerReceiptData } from '../utils/exportUtils';

interface TripLedgerProps {
  driver: DriverProfile;
  trips: TripRecord[];
  onOpenNewTrip: () => void;
  onConvertToDirectClient: (trip: TripRecord) => void;
  onOpenCustomerPayment?: (trip?: TripRecord) => void;
}

export const TripLedger: React.FC<TripLedgerProps> = ({
  driver,
  trips,
  onOpenNewTrip,
  onConvertToDirectClient,
  onOpenCustomerPayment,
}) => {
  const [selectedPlatform, setSelectedPlatform] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const handleInstantPDF = (trip: TripRecord) => {
    const receiptData: CustomerReceiptData = {
      receiptNumber: `INV-${trip.id.replace(/[^0-9]/g, '') || Math.floor(1000 + Math.random() * 9000)}`,
      date: trip.timestamp,
      driver,
      customerName: trip.passengerName || 'Direct Passenger',
      customerPhone: '+91 98450 12345',
      pickupLocation: trip.pickupLocation,
      dropoffLocation: trip.dropoffLocation,
      distanceKm: trip.distanceKm,
      durationMinutes: trip.durationMinutes,
      baseFare: 100,
      distanceFare: Math.max(0, trip.grossFare - 100 - trip.tollCost),
      tollCost: trip.tollCost,
      waitingOrSurgeFare: 0,
      discount: 0,
      totalPaid: trip.grossFare,
      paymentMode: trip.paymentMode,
      paymentReference: `SETTLED-${trip.id}`,
      notes: `Verified Ride Ledger entry (${trip.platform})`,
    };
    exportCustomerReceiptPDF(receiptData);
  };

  const filteredTrips = trips.filter(t => {
    const matchesPlatform = selectedPlatform === 'ALL' || t.platform === selectedPlatform;
    const matchesSearch = 
      t.pickupLocation.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.dropoffLocation.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (t.passengerName && t.passengerName.toLowerCase().includes(searchQuery.toLowerCase())) ||
      t.id.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesPlatform && matchesSearch;
  });

  const totalGross = filteredTrips.reduce((acc, t) => acc + t.grossFare, 0);
  const totalCommission = filteredTrips.reduce((acc, t) => acc + t.platformCommission, 0);
  const totalNet = filteredTrips.reduce((acc, t) => acc + t.netProfit, 0);

  const getPlatformBadge = (platform: PlatformType) => {
    switch (platform) {
      case 'OLA':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">OLA (28% Cut)</span>;
      case 'UBER':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-500/20 text-blue-300 border border-blue-500/30">UBER (20% Cut)</span>;
      case 'RAPIDO':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-yellow-500/20 text-yellow-300 border border-yellow-500/30">RAPIDO</span>;
      case 'NAMMA_YATRI':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">NAMMA YATRI (0% Cut)</span>;
      case 'DIRECT_CLIENT':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-500/20 text-purple-300 border border-purple-500/30">DIRECT CLIENT (100% Mine)</span>;
    }
  };

  return (
    <div className="space-y-6 pb-12">
      
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-slate-900/90 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-sky-500/20 text-sky-400">
              <Car className="w-5 h-5" />
            </span>
            <h2 className="text-lg sm:text-xl font-bold text-white tracking-tight">
              Multi-Platform Trip Ledger & Commission Audit
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Aggregated cross-platform records (Ola, Uber, Rapido, Namma Yatri, Direct).
          </p>
        </div>

        <div className="flex items-center flex-wrap gap-2 w-full sm:w-auto">
          {onOpenCustomerPayment && (
            <button
              onClick={() => onOpenCustomerPayment()}
              className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-300 text-xs font-bold shadow transition-all cursor-pointer"
            >
              <Banknote className="w-4 h-4 text-emerald-400" />
              <span>Collect Fare & PDF</span>
            </button>
          )}
          <button
            onClick={() => exportTripsAndExpensesExcel(driver, trips, [])}
            className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-750 border border-slate-700 text-slate-200 text-xs font-semibold shadow transition-all"
          >
            <Download className="w-4 h-4 text-emerald-400" />
            <span>Export Excel</span>
          </button>
          <button
            onClick={onOpenNewTrip}
            className="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold shadow-lg shadow-emerald-950 transition-all active:scale-95"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Add Trip</span>
          </button>
        </div>
      </div>

      {/* Summary Aggregate Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-3.5 flex items-center justify-between">
          <div>
            <div className="text-[11px] text-slate-400 font-medium">Filtered Gross Fares</div>
            <div className="text-xl font-black text-white font-mono mt-0.5">₹{totalGross.toLocaleString('en-IN')}</div>
          </div>
          <span className="text-xs text-slate-400">{filteredTrips.length} Rides</span>
        </div>

        <div className="bg-slate-900/80 border border-amber-500/30 rounded-xl p-3.5 flex items-center justify-between">
          <div>
            <div className="text-[11px] text-amber-400 font-medium">Platform Fee Bleed</div>
            <div className="text-xl font-black text-amber-300 font-mono mt-0.5">-₹{totalCommission.toLocaleString('en-IN')}</div>
          </div>
          <span className="text-xs text-amber-400/90 font-medium">Commission Lost</span>
        </div>

        <div className="bg-slate-900/80 border border-emerald-500/30 rounded-xl p-3.5 flex items-center justify-between">
          <div>
            <div className="text-[11px] text-emerald-400 font-medium">Real Net In-Pocket</div>
            <div className="text-xl font-black text-emerald-400 font-mono mt-0.5">₹{totalNet.toLocaleString('en-IN')}</div>
          </div>
          <span className="text-xs text-emerald-300 font-medium">Take-Home Cash</span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-slate-900/80 border border-slate-800 rounded-xl p-3">
        {/* Search */}
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by pickup, drop, passenger or trip ID..."
            className="w-full bg-slate-800 border border-slate-700 rounded-lg pl-9 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-emerald-500"
          />
        </div>

        {/* Platform Selector Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
          {[
            { id: 'ALL', label: 'All' },
            { id: 'OLA', label: 'Ola' },
            { id: 'UBER', label: 'Uber' },
            { id: 'RAPIDO', label: 'Rapido' },
            { id: 'NAMMA_YATRI', label: 'Namma Yatri' },
            { id: 'DIRECT_CLIENT', label: 'Direct' },
          ].map(p => (
            <button
              key={p.id}
              onClick={() => setSelectedPlatform(p.id)}
              className={`px-3 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                selectedPlatform === p.id
                  ? 'bg-emerald-600 text-white'
                  : 'bg-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              {p.label}
            </button>
          ))}
        </div>
      </div>

      {/* Trip Cards List */}
      <div className="space-y-3">
        {filteredTrips.length === 0 ? (
          <div className="p-8 text-center bg-slate-900/60 border border-slate-800 rounded-2xl text-slate-400 text-xs">
            No trips matching the selected filters.
          </div>
        ) : (
          filteredTrips.map((trip) => (
            <div 
              key={trip.id}
              className="bg-slate-900/90 border border-slate-800 hover:border-slate-700 rounded-2xl p-4 sm:p-5 shadow-lg transition-all space-y-3"
            >
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-slate-800/80 pb-3">
                <div className="flex items-center gap-2">
                  {getPlatformBadge(trip.platform)}
                  <span className="font-mono text-xs text-slate-400">{trip.id}</span>
                  <span className="text-slate-500">•</span>
                  <span className="text-xs text-slate-400">
                    {new Date(trip.timestamp).toLocaleDateString('en-IN', { month: 'short', day: 'numeric' })} at {new Date(trip.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>

                <div className="flex items-center gap-2 self-end sm:self-auto">
                  {trip.passengerSafetyBadge && (
                    <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-sky-500/20 text-sky-300 border border-sky-500/30 flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3" /> {trip.passengerSafetyBadge.replace('_', ' ')}
                    </span>
                  )}
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-800 text-slate-300 font-mono">
                    {trip.paymentMode}
                  </span>
                </div>
              </div>

              {/* Route & Passenger Information */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-center">
                
                {/* Route */}
                <div className="lg:col-span-6 space-y-1.5">
                  <div className="flex items-start gap-2 text-xs">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 mt-1.5 shrink-0" />
                    <div>
                      <span className="text-slate-400 text-[10px] block">PICKUP</span>
                      <span className="text-slate-200 font-medium">{trip.pickupLocation}</span>
                    </div>
                  </div>
                  <div className="flex items-start gap-2 text-xs">
                    <span className="w-2 h-2 rounded-full bg-rose-400 mt-1.5 shrink-0" />
                    <div>
                      <span className="text-slate-400 text-[10px] block">DROPOFF</span>
                      <span className="text-slate-200 font-medium">{trip.dropoffLocation}</span>
                    </div>
                  </div>
                </div>

                {/* Ride Stats */}
                <div className="lg:col-span-3 grid grid-cols-3 gap-2 text-center text-xs p-2.5 rounded-xl bg-slate-800/60 border border-slate-700/60">
                  <div>
                    <span className="text-slate-400 text-[10px] block">DISTANCE</span>
                    <span className="font-mono font-bold text-slate-200">{trip.distanceKm} km</span>
                  </div>
                  <div>
                    <span className="text-slate-400 text-[10px] block">DURATION</span>
                    <span className="font-mono font-bold text-slate-200">{trip.durationMinutes} m</span>
                  </div>
                  <div>
                    <span className="text-slate-400 text-[10px] block">DEADHEAD</span>
                    <span className="font-mono font-bold text-amber-300">{trip.deadheadKm} km</span>
                  </div>
                </div>

                {/* Financial Take-Home Breakdown */}
                <div className="lg:col-span-3 text-right space-y-0.5">
                  <div className="flex items-baseline justify-end gap-2">
                    <span className="text-[10px] text-slate-400">Gross: ₹{trip.grossFare}</span>
                    <span className="text-xl font-black text-emerald-400 font-mono">
                      ₹{trip.netProfit.toFixed(0)}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-400 flex items-center justify-end gap-2">
                    {trip.platformCommission > 0 ? (
                      <span className="text-rose-400">Ola Cut: -₹{trip.platformCommission.toFixed(0)}</span>
                    ) : (
                      <span className="text-emerald-400 font-semibold">0% Commission</span>
                    )}
                    <span>•</span>
                    <span>Fuel: ₹{trip.fuelCost}</span>
                  </div>
                </div>

              </div>

              {/* Action Bar: Convert to Direct Client, PDF Bill, or Payment */}
              <div className="pt-2 border-t border-slate-800/60 flex flex-wrap items-center justify-between gap-2 text-xs">
                <span className="text-slate-400 italic text-[11px]">
                  {trip.notes || (trip.passengerName ? `Passenger: ${trip.passengerName}` : 'Standard passenger ride')}
                </span>

                <div className="flex items-center flex-wrap gap-2">
                  <button
                    onClick={() => handleInstantPDF(trip)}
                    className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border border-emerald-500/30 text-[11px] font-semibold transition-all cursor-pointer"
                    title="Download Official Customer PDF Ride Bill"
                  >
                    <FileText className="w-3 h-3 text-emerald-400" />
                    <span>PDF Bill</span>
                  </button>

                  {onOpenCustomerPayment && (
                    <button
                      onClick={() => onOpenCustomerPayment(trip)}
                      className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-750 text-slate-300 border border-slate-700 text-[11px] font-medium transition-all cursor-pointer"
                      title="Collect / Re-issue Payment with UPI or Cash"
                    >
                      <Banknote className="w-3 h-3 text-amber-400" />
                      <span>Collect / Bill</span>
                    </button>
                  )}

                  {trip.platform === 'OLA' || trip.platform === 'UBER' ? (
                    <button
                      onClick={() => onConvertToDirectClient(trip)}
                      className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-purple-500/20 hover:bg-purple-500/30 text-purple-300 border border-purple-500/40 font-semibold transition-all"
                    >
                      <UserCheck className="w-3.5 h-3.5 text-purple-400" />
                      <span>Save as Direct (Save ₹{trip.platformCommission.toFixed(0)})</span>
                    </button>
                  ) : (
                    <span className="text-emerald-400 font-semibold flex items-center gap-1 text-[11px]">
                      <CheckCircle className="w-3.5 h-3.5" /> 100% Sovereign
                    </span>
                  )}
                </div>
              </div>

            </div>
          ))
        )}
      </div>

    </div>
  );
};
