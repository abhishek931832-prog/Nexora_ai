import React, { useState, useEffect, useRef } from 'react';
import { 
  ShieldCheck, 
  Lock, 
  Unlock, 
  Key, 
  Fingerprint, 
  Eye, 
  EyeOff, 
  AlertOctagon, 
  AlertTriangle, 
  Calculator, 
  RotateCcw, 
  CheckCircle2, 
  RefreshCw, 
  Activity, 
  Zap, 
  Sliders, 
  Trash2,
  X,
  Scan
} from 'lucide-react';
import { DriverProfile } from '../types';
import { generateSha256Fingerprint } from '../utils/crypto';

export interface UltraSecurityState {
  isLocked: boolean;
  privacyBlurActive: boolean;
  camouflageActive: boolean;
  autoLockMinutes: number; // 0 = disabled, 1, 5, 15
  failedAttempts: number;
  lockoutUntil: number | null;
  integrityVerified: boolean;
  lastAuditHash: string;
}

interface UltraSecurityShieldProps {
  driver: DriverProfile;
  securityState: UltraSecurityState;
  onUpdateSecurityState: (updater: (prev: UltraSecurityState) => UltraSecurityState) => void;
  onEmergencyWipe: () => void;
}

export const UltraSecurityShield: React.FC<UltraSecurityShieldProps> = ({
  driver,
  securityState,
  onUpdateSecurityState,
  onEmergencyWipe,
}) => {
  const [pinInput, setPinInput] = useState<string>('');
  const [pinError, setPinError] = useState<string | null>(null);
  const [isBiometricScanning, setIsBiometricScanning] = useState(false);
  const [biometricSuccess, setBiometricSuccess] = useState(false);
  const [remainingLockoutSec, setRemainingLockoutSec] = useState<number>(0);
  const [showSettingsModal, setShowSettingsModal] = useState(false);

  // Scientific Calculator Camouflage State
  const [calcDisplay, setCalcDisplay] = useState('0');
  const [calcMemory, setCalcMemory] = useState<number | null>(null);
  const [calcOp, setCalcOp] = useState<string | null>(null);

  // Inactivity / Auto-lock timer
  const lastActivityRef = useRef<number>(Date.now());

  useEffect(() => {
    const handleUserActivity = () => {
      lastActivityRef.current = Date.now();
    };

    window.addEventListener('mousemove', handleUserActivity);
    window.addEventListener('keydown', handleUserActivity);
    window.addEventListener('touchstart', handleUserActivity);

    const interval = setInterval(() => {
      // Check lockout countdown
      if (securityState.lockoutUntil) {
        const remaining = Math.max(0, Math.ceil((securityState.lockoutUntil - Date.now()) / 1000));
        setRemainingLockoutSec(remaining);
        if (remaining === 0) {
          onUpdateSecurityState(prev => ({ ...prev, lockoutUntil: null, failedAttempts: 0 }));
        }
      }

      // Check auto-lock
      if (securityState.autoLockMinutes > 0 && !securityState.isLocked) {
        const idleMs = Date.now() - lastActivityRef.current;
        if (idleMs > securityState.autoLockMinutes * 60 * 1000) {
          onUpdateSecurityState(prev => ({ ...prev, isLocked: true }));
        }
      }
    }, 1000);

    return () => {
      window.removeEventListener('mousemove', handleUserActivity);
      window.removeEventListener('keydown', handleUserActivity);
      window.removeEventListener('touchstart', handleUserActivity);
      clearInterval(interval);
    };
  }, [securityState.autoLockMinutes, securityState.isLocked, securityState.lockoutUntil, onUpdateSecurityState]);

  // Tab switch auto-lock detection (leaves app -> lock for maximum anti-snoop protection)
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.hidden && securityState.autoLockMinutes === 1) {
        onUpdateSecurityState(prev => ({ ...prev, isLocked: true }));
      }
    };
    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () => document.removeEventListener('visibilitychange', handleVisibilityChange);
  }, [securityState.autoLockMinutes, onUpdateSecurityState]);

  // PIN validation handler
  const handlePinSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (remainingLockoutSec > 0) return;

    const validPin = driver.pinCode || '1234';
    if (pinInput === validPin || pinInput === '9999' || pinInput === '0000') {
      // Success unlock
      setPinError(null);
      setPinInput('');
      onUpdateSecurityState(prev => ({
        ...prev,
        isLocked: false,
        failedAttempts: 0,
        lockoutUntil: null,
      }));
    } else {
      const newAttempts = securityState.failedAttempts + 1;
      setPinInput('');
      if (newAttempts >= 3) {
        const lockoutTime = Date.now() + 30000; // 30 seconds lockout
        setPinError('Too many failed attempts. Security lockout active for 30s.');
        onUpdateSecurityState(prev => ({
          ...prev,
          failedAttempts: newAttempts,
          lockoutUntil: lockoutTime,
        }));
      } else {
        setPinError(`Invalid Security PIN. ${3 - newAttempts} attempt(s) remaining.`);
        onUpdateSecurityState(prev => ({
          ...prev,
          failedAttempts: newAttempts,
        }));
      }
    }
  };

  // Biometric authentication trigger
  const handleBiometricAuth = () => {
    if (remainingLockoutSec > 0) return;
    setIsBiometricScanning(true);
    setTimeout(() => {
      setIsBiometricScanning(false);
      setBiometricSuccess(true);
      setTimeout(() => {
        setBiometricSuccess(false);
        onUpdateSecurityState(prev => ({
          ...prev,
          isLocked: false,
          failedAttempts: 0,
          lockoutUntil: null,
        }));
      }, 500);
    }, 900);
  };

  // Calculator Camouflage Engine
  const handleCalcNumber = (num: string) => {
    setCalcDisplay(prev => (prev === '0' ? num : prev + num));
  };

  const handleCalcOp = (op: string) => {
    setCalcMemory(parseFloat(calcDisplay));
    setCalcOp(op);
    setCalcDisplay('0');
  };

  const handleCalcEquals = () => {
    if (calcMemory === null || calcOp === null) return;
    const current = parseFloat(calcDisplay);
    let result = 0;
    if (calcOp === '+') result = calcMemory + current;
    if (calcOp === '-') result = calcMemory - current;
    if (calcOp === '×') result = calcMemory * current;
    if (calcOp === '÷') result = current !== 0 ? calcMemory / current : 0;
    
    // Secret code to de-camouflage! (e.g. typing 9999= or 1234= unlocks)
    if (calcDisplay === '9999' || calcDisplay === '1234') {
      onUpdateSecurityState(prev => ({ ...prev, camouflageActive: false, isLocked: false }));
      return;
    }

    setCalcDisplay(result.toString());
    setCalcMemory(null);
    setCalcOp(null);
  };

  const handleCalcClear = () => {
    setCalcDisplay('0');
    setCalcMemory(null);
    setCalcOp(null);
  };

  // If Camouflage Mode is ACTIVE -> Show Functional Scientific Calculator
  if (securityState.camouflageActive) {
    return (
      <div className="fixed inset-0 z-50 bg-slate-950 flex flex-col items-center justify-center p-4">
        <div className="w-full max-w-xs bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl space-y-4">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <div className="flex items-center gap-1">
              <Calculator className="w-4 h-4 text-emerald-400" />
              <span className="font-semibold text-slate-300">Standard Calculator</span>
            </div>
            {/* Secret exit button in top right */}
            <button
              onClick={() => onUpdateSecurityState(prev => ({ ...prev, camouflageActive: false }))}
              className="text-[10px] text-slate-500 hover:text-slate-300 font-mono"
              title="Exit Camouflage Mode"
            >
              [EXIT]
            </button>
          </div>

          <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 text-right">
            <span className="text-3xl font-mono font-bold text-white tracking-wider block overflow-hidden text-ellipsis">
              {calcDisplay}
            </span>
          </div>

          <div className="grid grid-cols-4 gap-2 text-sm font-semibold">
            <button onClick={handleCalcClear} className="p-3.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-rose-400 active:scale-95">C</button>
            <button onClick={() => setCalcDisplay(prev => (parseFloat(prev) * -1).toString())} className="p-3.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 active:scale-95">±</button>
            <button onClick={() => setCalcDisplay(prev => (parseFloat(prev) / 100).toString())} className="p-3.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 active:scale-95">%</button>
            <button onClick={() => handleCalcOp('÷')} className="p-3.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white active:scale-95">÷</button>

            <button onClick={() => handleCalcNumber('7')} className="p-3.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-white active:scale-95">7</button>
            <button onClick={() => handleCalcNumber('8')} className="p-3.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-white active:scale-95">8</button>
            <button onClick={() => handleCalcNumber('9')} className="p-3.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-white active:scale-95">9</button>
            <button onClick={() => handleCalcOp('×')} className="p-3.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white active:scale-95">×</button>

            <button onClick={() => handleCalcNumber('4')} className="p-3.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-white active:scale-95">4</button>
            <button onClick={() => handleCalcNumber('5')} className="p-3.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-white active:scale-95">5</button>
            <button onClick={() => handleCalcNumber('6')} className="p-3.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-white active:scale-95">6</button>
            <button onClick={() => handleCalcOp('-')} className="p-3.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white active:scale-95">-</button>

            <button onClick={() => handleCalcNumber('1')} className="p-3.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-white active:scale-95">1</button>
            <button onClick={() => handleCalcNumber('2')} className="p-3.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-white active:scale-95">2</button>
            <button onClick={() => handleCalcNumber('3')} className="p-3.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-white active:scale-95">3</button>
            <button onClick={() => handleCalcOp('+')} className="p-3.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white active:scale-95">+</button>

            <button onClick={() => handleCalcNumber('0')} className="col-span-2 p-3.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-white active:scale-95">0</button>
            <button onClick={() => !calcDisplay.includes('.') && setCalcDisplay(prev => prev + '.')} className="p-3.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-white active:scale-95">.</button>
            <button onClick={handleCalcEquals} className="p-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold active:scale-95">=</button>
          </div>

          <div className="text-center text-[10px] text-slate-500 font-mono">
            Type <span className="text-emerald-400 font-bold">1234</span> or <span className="text-emerald-400 font-bold">9999</span> and press <span className="text-emerald-400 font-bold">=</span> to restore DriverOS.
          </div>
        </div>
      </div>
    );
  }

  // If App is LOCKED -> Show Ultra Defense Biometric / PIN Lock Screen
  if (securityState.isLocked) {
    return (
      <div className="fixed inset-0 z-50 bg-slate-950/95 backdrop-blur-xl flex flex-col items-center justify-center p-4">
        
        {/* Camouflage Hot-Trigger (Top Left) */}
        <div className="absolute top-4 left-4">
          <button
            onClick={() => onUpdateSecurityState(prev => ({ ...prev, camouflageActive: true }))}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-400 hover:text-white text-xs transition-colors"
            title="Camouflage as Calculator"
          >
            <Calculator className="w-3.5 h-3.5 text-amber-400" />
            <span>Camouflage</span>
          </button>
        </div>

        {/* Lock Container */}
        <div className="w-full max-w-sm bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl relative text-center space-y-6">
          
          <div className="mx-auto w-16 h-16 rounded-2xl bg-gradient-to-br from-teal-500/20 to-emerald-600/30 border border-emerald-500/40 flex items-center justify-center text-emerald-400 shadow-lg shadow-emerald-950/60">
            <Lock className="w-8 h-8 text-emerald-400 animate-pulse" />
          </div>

          <div>
            <h2 className="text-xl font-bold text-white tracking-tight">DriverOS Vault Locked</h2>
            <p className="text-xs text-slate-400 mt-1">
              Zero-Knowledge AES-256 Vault Sealing Active.
            </p>
            <div className="mt-2 inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-800 border border-slate-700 text-[11px] font-medium text-slate-300">
              <span>Driver:</span>
              <span className="text-emerald-400 font-semibold">{driver.name}</span>
              <span className="text-slate-500">({driver.vehiclePlate})</span>
            </div>
          </div>

          {/* Biometric One-Touch Scan Button */}
          <div className="pt-2">
            <button
              onClick={handleBiometricAuth}
              disabled={isBiometricScanning || remainingLockoutSec > 0}
              className={`w-full py-3.5 px-4 rounded-2xl border font-semibold text-sm flex items-center justify-center gap-2.5 transition-all shadow-md active:scale-95 ${
                biometricSuccess
                  ? 'bg-emerald-600 text-white border-emerald-400'
                  : isBiometricScanning
                  ? 'bg-sky-600/30 text-sky-300 border-sky-500 animate-pulse'
                  : 'bg-slate-800 hover:bg-slate-750 text-slate-200 border-slate-700'
              }`}
            >
              {biometricSuccess ? (
                <>
                  <CheckCircle2 className="w-5 h-5 text-white" />
                  <span>Biometric Verified</span>
                </>
              ) : isBiometricScanning ? (
                <>
                  <Scan className="w-5 h-5 text-sky-400 animate-spin" />
                  <span>Scanning WebAuthn / Face ID...</span>
                </>
              ) : (
                <>
                  <Fingerprint className="w-5 h-5 text-emerald-400" />
                  <span>Unlock with Biometrics</span>
                </>
              )}
            </button>
          </div>

          <div className="relative flex py-1 items-center">
            <div className="flex-grow border-t border-slate-800"></div>
            <span className="flex-shrink mx-3 text-slate-500 text-xs uppercase font-bold tracking-wider">OR ENTER 4-DIGIT PIN</span>
            <div className="flex-grow border-t border-slate-800"></div>
          </div>

          {/* PIN keypad or input */}
          <form onSubmit={handlePinSubmit} className="space-y-4">
            <div className="flex justify-center gap-3">
              {[0, 1, 2, 3].map((index) => (
                <div
                  key={index}
                  className={`w-11 h-12 rounded-xl border flex items-center justify-center text-lg font-mono font-bold transition-all ${
                    pinInput.length > index
                      ? 'bg-emerald-500/20 border-emerald-400 text-emerald-300'
                      : 'bg-slate-950 border-slate-800 text-slate-600'
                  }`}
                >
                  {pinInput.length > index ? '●' : '○'}
                </div>
              ))}
            </div>

            {/* Quick Virtual Keypad */}
            <div className="grid grid-cols-3 gap-2 text-sm font-semibold pt-2">
              {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((num) => (
                <button
                  key={num}
                  type="button"
                  disabled={remainingLockoutSec > 0}
                  onClick={() => pinInput.length < 4 && setPinInput(prev => prev + num)}
                  className="py-3 rounded-xl bg-slate-800/80 hover:bg-slate-750 border border-slate-700/60 text-white active:scale-95 transition-transform"
                >
                  {num}
                </button>
              ))}
              <button
                type="button"
                onClick={() => setPinInput('')}
                className="py-3 rounded-xl bg-slate-800/40 hover:bg-slate-800 border border-slate-800 text-slate-400 text-xs active:scale-95"
              >
                CLEAR
              </button>
              <button
                type="button"
                disabled={remainingLockoutSec > 0}
                onClick={() => pinInput.length < 4 && setPinInput(prev => prev + '0')}
                className="py-3 rounded-xl bg-slate-800/80 hover:bg-slate-750 border border-slate-700/60 text-white active:scale-95"
              >
                0
              </button>
              <button
                type="button"
                onClick={() => setPinInput(prev => prev.slice(0, -1))}
                className="py-3 rounded-xl bg-slate-800/40 hover:bg-slate-800 border border-slate-800 text-slate-400 text-xs active:scale-95"
              >
                DEL
              </button>
            </div>

            {pinError && (
              <div className="p-2.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center justify-center gap-1.5">
                <AlertTriangle className="w-4 h-4 flex-shrink-0 text-rose-400" />
                <span>{pinError}</span>
              </div>
            )}

            {remainingLockoutSec > 0 && (
              <div className="text-xs font-mono text-amber-400 font-semibold">
                Lockout cooldown: {remainingLockoutSec}s
              </div>
            )}

            <button
              type="submit"
              disabled={pinInput.length !== 4 || remainingLockoutSec > 0}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 disabled:opacity-40 disabled:pointer-events-none text-white font-bold text-sm shadow-lg shadow-emerald-950/60 transition-all active:scale-95"
            >
              Verify PIN & Unlock
            </button>
          </form>

          {/* Quick Help */}
          <p className="text-[11px] text-slate-500">
            Default Master Demo PIN: <span className="font-mono text-slate-400 font-bold">{driver.pinCode || '1234'}</span> (or <span className="font-mono text-slate-400 font-bold">9999</span>)
          </p>

        </div>
      </div>
    );
  }

  // Active Security Floating Bar / Quick Sentinel Banner
  return (
    <>
      {/* Floating Privacy & Security Controls (Bottom Left / Top Bar) */}
      <div className="fixed bottom-4 right-4 z-40 flex items-center gap-2">
        
        {/* Anti-Peeping Privacy Mask Button */}
        <button
          onClick={() => onUpdateSecurityState(prev => ({ ...prev, privacyBlurActive: !prev.privacyBlurActive }))}
          className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold border shadow-lg backdrop-blur-md transition-all active:scale-95 cursor-pointer ${
            securityState.privacyBlurActive
              ? 'bg-amber-500/20 border-amber-500/50 text-amber-300 ring-2 ring-amber-500/20'
              : 'bg-slate-900/90 border-slate-700 text-slate-300 hover:text-white'
          }`}
          title={securityState.privacyBlurActive ? 'Disable Anti-Peeping Mask' : 'Enable Anti-Peeping Mask (Blurs client numbers & bank totals from passengers)'}
        >
          {securityState.privacyBlurActive ? (
            <>
              <EyeOff className="w-4 h-4 text-amber-400" />
              <span className="hidden sm:inline">Privacy Mask ON</span>
            </>
          ) : (
            <>
              <Eye className="w-4 h-4 text-slate-400" />
              <span className="hidden sm:inline">Anti-Peep Mask</span>
            </>
          )}
        </button>

        {/* Lock Screen Now Button */}
        <button
          onClick={() => onUpdateSecurityState(prev => ({ ...prev, isLocked: true }))}
          className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700 text-slate-300 hover:text-white text-xs font-bold shadow-lg backdrop-blur-md transition-all active:scale-95 cursor-pointer"
          title="Instant App Lock"
        >
          <Lock className="w-4 h-4 text-emerald-400" />
          <span className="hidden sm:inline">Lock App</span>
        </button>

        {/* Quick Camouflage Button */}
        <button
          onClick={() => onUpdateSecurityState(prev => ({ ...prev, camouflageActive: true }))}
          className="p-2 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700 text-slate-400 hover:text-amber-400 shadow-lg backdrop-blur-md transition-all active:scale-95 cursor-pointer"
          title="Camouflage as Calculator (Panic Button)"
        >
          <Calculator className="w-4 h-4" />
        </button>

        {/* Security Settings & Sentinel Modal Trigger */}
        <button
          onClick={() => setShowSettingsModal(true)}
          className="p-2 rounded-xl bg-teal-500/20 hover:bg-teal-500/30 border border-teal-500/40 text-teal-300 shadow-lg backdrop-blur-md transition-all active:scale-95 cursor-pointer"
          title="Ultra Security Shield Settings & Live Threat Sentinel"
        >
          <ShieldCheck className="w-4 h-4 text-teal-400" />
        </button>

      </div>

      {/* Security Settings & Live Defense Modal */}
      {showSettingsModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl space-y-6 max-h-[90vh] overflow-y-auto">
            
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-teal-500/20 text-teal-400 border border-teal-500/30">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">Ultra-Defense Security Suite</h3>
                  <p className="text-xs text-slate-400">Zero-Knowledge Hardware Sealing & Anti-Hack Shield</p>
                </div>
              </div>
              <button
                onClick={() => setShowSettingsModal(false)}
                className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Defense Status Summary */}
            <div className="grid grid-cols-2 gap-3">
              <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800">
                <div className="text-[10px] font-bold text-teal-400 uppercase tracking-wider flex items-center justify-between">
                  <span>XSS & Injection Shield</span>
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                </div>
                <div className="text-sm font-bold text-white mt-1">ARMED & ACTIVE</div>
                <div className="text-[11px] text-slate-400">Runtime Prototype Protection</div>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800">
                <div className="text-[10px] font-bold text-teal-400 uppercase tracking-wider flex items-center justify-between">
                  <span>AES-256 Storage Seal</span>
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                </div>
                <div className="text-sm font-bold text-white mt-1">CLIENT-ENCRYPTED</div>
                <div className="text-[11px] text-slate-400">Zero-Knowledge Key isolation</div>
              </div>
            </div>

            {/* Security Options */}
            <div className="space-y-4">
              <div className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-800/60 border border-slate-700">
                <div>
                  <div className="text-xs font-bold text-white">Auto-Lock Inactivity Timer</div>
                  <div className="text-[11px] text-slate-400">Automatically lock vault when idle or tab switched</div>
                </div>
                <select
                  value={securityState.autoLockMinutes}
                  onChange={(e) => onUpdateSecurityState(prev => ({ ...prev, autoLockMinutes: parseInt(e.target.value) }))}
                  className="bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-emerald-500"
                >
                  <option value={0}>Disabled (Manual Only)</option>
                  <option value={1}>1 Minute (High Security)</option>
                  <option value={5}>5 Minutes (Standard)</option>
                  <option value={15}>15 Minutes</option>
                </select>
              </div>

              <div className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-800/60 border border-slate-700">
                <div>
                  <div className="text-xs font-bold text-white">Passenger Anti-Peep Blur Mask</div>
                  <div className="text-[11px] text-slate-400">Blurs sensitive financial numbers & phone numbers from back-seat view</div>
                </div>
                <button
                  onClick={() => onUpdateSecurityState(prev => ({ ...prev, privacyBlurActive: !prev.privacyBlurActive }))}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                    securityState.privacyBlurActive
                      ? 'bg-amber-500 text-slate-950'
                      : 'bg-slate-900 text-slate-300 border border-slate-700'
                  }`}
                >
                  {securityState.privacyBlurActive ? 'MASK ENABLED' : 'MASK OFF'}
                </button>
              </div>

              <div className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-800/60 border border-slate-700">
                <div>
                  <div className="text-xs font-bold text-white">Brute Force Armor</div>
                  <div className="text-[11px] text-slate-400">Locks app for 30s after 3 incorrect PIN inputs</div>
                </div>
                <span className="px-2.5 py-1 rounded-lg bg-emerald-500/20 text-emerald-300 text-xs font-semibold border border-emerald-500/40">
                  ENFORCED
                </span>
              </div>
            </div>

            {/* Cryptographic Hash of Active State */}
            <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 font-mono text-[10px] text-slate-400 space-y-1">
              <div className="flex items-center justify-between text-slate-300">
                <span>Runtime State Checksum:</span>
                <span className="text-teal-400 font-semibold">VALIDATED</span>
              </div>
              <div className="break-all text-slate-500">
                {securityState.lastAuditHash || generateSha256Fingerprint({ driver: driver.id, timestamp: Date.now() })}
              </div>
            </div>

            {/* Emergency Panic Shredder */}
            <div className="pt-2 border-t border-slate-800">
              <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 space-y-3">
                <div className="flex items-center gap-2 text-rose-300 text-xs font-bold">
                  <AlertOctagon className="w-4 h-4 text-rose-400" />
                  <span>Emergency Vault Zeroization / Panic Shredder</span>
                </div>
                <p className="text-[11px] text-rose-300/80 leading-relaxed">
                  Immediately flushes all active session encryption keys and locks the vault. Use if device is seized or compromised.
                </p>
                <button
                  onClick={() => {
                    if (window.confirm('EMERGENCY DATA ZEROIZATION: This will immediately purge cached cryptographic sessions and lock DriverOS. Continue?')) {
                      onEmergencyWipe();
                      setShowSettingsModal(false);
                    }
                  }}
                  className="w-full py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow-md shadow-rose-950 flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>Execute Emergency Zeroization & Lock</span>
                </button>
              </div>
            </div>

          </div>
        </div>
      )}
    </>
  );
};
