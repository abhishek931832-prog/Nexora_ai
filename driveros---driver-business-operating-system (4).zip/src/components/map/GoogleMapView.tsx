// Source: Google Maps Platform Code Assist
import React, { useEffect, useState } from 'react';
import { 
  APIProvider, 
  Map, 
  AdvancedMarker, 
  Pin, 
  InfoWindow, 
  useMap,
  useAdvancedMarkerRef 
} from '@vis.gl/react-google-maps';
import { DemandSurgeCluster, VerifiedRestAndFuelHub } from '../../types';
import { MapCarData, GeoPoint, BENGALURU_CENTER } from './mapData';
import { 
  Flame, 
  Fuel, 
  Zap, 
  ParkingCircle, 
  Coffee, 
  Navigation,
  Crosshair,
  Maximize2,
  Minimize2,
  Layers,
  Car
} from 'lucide-react';

interface GoogleMapViewProps {
  apiKey: string;
  cars: MapCarData[];
  selectedCar: MapCarData | null;
  onSelectCar: (car: MapCarData) => void;
  clusters: DemandSurgeCluster[];
  selectedCluster: DemandSurgeCluster | null;
  onSelectCluster: (cluster: DemandSurgeCluster) => void;
  hubs: VerifiedRestAndFuelHub[];
  selectedHub: VerifiedRestAndFuelHub | null;
  onSelectHub: (hub: VerifiedRestAndFuelHub) => void;
  activeFilter: 'ALL' | 'SURGE' | 'CNG' | 'EV' | 'PARKING' | 'CARS';
  routePoints?: GeoPoint[];
  trafficEnabled: boolean;
  onToggleTraffic: () => void;
  mapType: 'roadmap' | 'satellite' | 'hybrid' | 'terrain';
  onChangeMapType: (type: 'roadmap' | 'satellite' | 'hybrid' | 'terrain') => void;
}

// Sub-component to manage real Google Maps TrafficLayer
const LiveTrafficLayer: React.FC<{ enabled: boolean }> = ({ enabled }) => {
  const map = useMap();

  useEffect(() => {
    if (!map || !window.google?.maps) return;
    const traffic = new google.maps.TrafficLayer();
    if (enabled) {
      traffic.setMap(map);
    } else {
      traffic.setMap(null);
    }
    return () => {
      traffic.setMap(null);
    };
  }, [map, enabled]);

  return null;
};

// Sub-component to render route polyline on Google Map
const RoutePolyline: React.FC<{ points: GeoPoint[] }> = ({ points }) => {
  const map = useMap();

  useEffect(() => {
    if (!map || !window.google?.maps || points.length < 2) return;

    const polyline = new google.maps.Polyline({
      path: points,
      geodesic: true,
      strokeColor: '#10b981',
      strokeOpacity: 0.9,
      strokeWeight: 5,
      map,
    });

    return () => {
      polyline.setMap(null);
    };
  }, [map, points]);

  return null;
};

// Sub-component to render surge aura circles
const SurgeCircle: React.FC<{ cluster: DemandSurgeCluster; isSelected: boolean }> = ({ cluster, isSelected }) => {
  const map = useMap();

  useEffect(() => {
    if (!map || !window.google?.maps || !cluster.lat || !cluster.lng) return;

    const isAirport = cluster.id === 'ZONE-01';
    const circle = new google.maps.Circle({
      strokeColor: isAirport ? '#f59e0b' : '#10b981',
      strokeOpacity: isSelected ? 0.8 : 0.4,
      strokeWeight: isSelected ? 2 : 1,
      fillColor: isAirport ? '#f59e0b' : '#10b981',
      fillOpacity: isSelected ? 0.25 : 0.12,
      map,
      center: { lat: cluster.lat, lng: cluster.lng },
      radius: cluster.surgeMultiplier * 1400,
    });

    return () => {
      circle.setMap(null);
    };
  }, [map, cluster, isSelected]);

  return null;
};

// Sub-component for centering controls
const MapControlsOverlay: React.FC<{
  trafficEnabled: boolean;
  onToggleTraffic: () => void;
  mapType: 'roadmap' | 'satellite' | 'hybrid' | 'terrain';
  onChangeMapType: (t: 'roadmap' | 'satellite' | 'hybrid' | 'terrain') => void;
  onCenterMyCar: () => void;
}> = ({ trafficEnabled, onToggleTraffic, mapType, onChangeMapType, onCenterMyCar }) => {
  return (
    <div className="absolute top-4 right-4 z-10 flex flex-col gap-2">
      <div className="bg-slate-950/90 backdrop-blur-md p-1.5 rounded-xl border border-slate-800 shadow-xl flex flex-col gap-1.5">
        {/* Traffic Layer Toggle */}
        <button
          onClick={onToggleTraffic}
          className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all flex items-center justify-between gap-2 ${
            trafficEnabled ? 'bg-amber-500 text-slate-950 shadow' : 'text-slate-300 hover:bg-slate-800'
          }`}
          title="Toggle Google Maps Live Traffic"
        >
          <span className="flex items-center gap-1.5">
            <span className={`w-2 h-2 rounded-full ${trafficEnabled ? 'bg-slate-950 animate-ping' : 'bg-amber-400'}`} />
            <span>Live Traffic</span>
          </span>
          <span className="text-[10px] font-mono">{trafficEnabled ? 'ON' : 'OFF'}</span>
        </button>

        {/* Map Type Switcher */}
        <div className="grid grid-cols-2 gap-1 pt-1 border-t border-slate-800 text-[10px] font-bold">
          <button
            onClick={() => onChangeMapType('roadmap')}
            className={`px-2 py-1 rounded-md transition-colors ${
              mapType === 'roadmap' ? 'bg-emerald-500 text-slate-950' : 'text-slate-400 hover:text-white'
            }`}
          >
            Roadmap
          </button>
          <button
            onClick={() => onChangeMapType('satellite')}
            className={`px-2 py-1 rounded-md transition-colors ${
              mapType === 'satellite' ? 'bg-emerald-500 text-slate-950' : 'text-slate-400 hover:text-white'
            }`}
          >
            Satellite
          </button>
          <button
            onClick={() => onChangeMapType('hybrid')}
            className={`px-2 py-1 rounded-md transition-colors ${
              mapType === 'hybrid' ? 'bg-emerald-500 text-slate-950' : 'text-slate-400 hover:text-white'
            }`}
          >
            Hybrid
          </button>
          <button
            onClick={() => onChangeMapType('terrain')}
            className={`px-2 py-1 rounded-md transition-colors ${
              mapType === 'terrain' ? 'bg-emerald-500 text-slate-950' : 'text-slate-400 hover:text-white'
            }`}
          >
            Terrain
          </button>
        </div>
      </div>

      <button
        onClick={onCenterMyCar}
        className="bg-slate-950/90 backdrop-blur-md p-2.5 rounded-xl border border-slate-800 text-emerald-400 hover:bg-slate-800 shadow-xl flex items-center justify-center transition-colors"
        title="Center to My Cab"
      >
        <Crosshair className="w-4 h-4" />
      </button>
    </div>
  );
};

export const GoogleMapView: React.FC<GoogleMapViewProps> = ({
  apiKey,
  cars,
  selectedCar,
  onSelectCar,
  clusters,
  selectedCluster,
  onSelectCluster,
  hubs,
  selectedHub,
  onSelectHub,
  activeFilter,
  routePoints = [],
  trafficEnabled,
  onToggleTraffic,
  mapType,
  onChangeMapType,
}) => {
  const [activeInfoWindow, setActiveInfoWindow] = useState<{
    type: 'CAR' | 'CLUSTER' | 'HUB';
    data: any;
    position: GeoPoint;
  } | null>(null);

  const handleCenterMyCar = () => {
    const userCar = cars.find(c => c.isUserDriver);
    if (userCar) {
      setActiveInfoWindow({
        type: 'CAR',
        data: userCar,
        position: userCar.currentCoord,
      });
    }
  };

  return (
    <div className="relative w-full h-full min-h-[500px] flex-1 rounded-2xl overflow-hidden shadow-2xl">
      <APIProvider apiKey={apiKey} solutionChannel="GMP_aistudio">
        <Map
          id="profit-google-map"
          mapId="DEMO_MAP_ID"
          defaultCenter={BENGALURU_CENTER}
          defaultZoom={11}
          mapTypeId={mapType}
          gestureHandling="greedy"
          disableDefaultUI={false}
          style={{ width: '100%', height: '100%', minHeight: '500px' }}
          internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
        >
          {/* Real Google Maps Traffic Layer */}
          <LiveTrafficLayer enabled={trafficEnabled} />

          {/* Route Polyline */}
          {routePoints.length >= 2 && <RoutePolyline points={routePoints} />}

          {/* Surge Clusters and Circles */}
          {(activeFilter === 'ALL' || activeFilter === 'SURGE') && clusters.map((cluster) => {
            if (!cluster.lat || !cluster.lng) return null;
            const isSelected = selectedCluster?.id === cluster.id;
            const isAirport = cluster.id === 'ZONE-01';

            return (
              <React.Fragment key={cluster.id}>
                <SurgeCircle cluster={cluster} isSelected={isSelected} />
                <AdvancedMarker
                  position={{ lat: cluster.lat, lng: cluster.lng }}
                  title={cluster.zoneName}
                  onClick={() => {
                    onSelectCluster(cluster);
                    setActiveInfoWindow({
                      type: 'CLUSTER',
                      data: cluster,
                      position: { lat: cluster.lat!, lng: cluster.lng! },
                    });
                  }}
                >
                  <div className="relative cursor-pointer group transform -translate-x-1/2 -translate-y-1/2 hover:scale-110 transition-transform">
                    <div className={`flex items-center gap-1 px-2 py-1 rounded-full text-xs font-bold shadow-2xl border ${
                      isAirport 
                        ? 'bg-amber-500 text-slate-950 border-amber-300 ring-2 ring-amber-400/50' 
                        : 'bg-slate-900 text-amber-400 border-amber-500/60'
                    }`}>
                      <Flame className="w-3.5 h-3.5" />
                      <span>{cluster.surgeMultiplier}x</span>
                    </div>
                  </div>
                </AdvancedMarker>
              </React.Fragment>
            );
          })}

          {/* Verified Hubs (CNG, EV, Parking, Chai) */}
          {hubs.map((hub) => {
            const isCng = hub.type === 'CNG_PUMP';
            const isEv = hub.type === 'EV_FAST_CHARGER';
            const isParking = hub.type === 'VERIFIED_PARKING';

            if (activeFilter === 'CNG' && !isCng) return null;
            if (activeFilter === 'EV' && !isEv) return null;
            if (activeFilter === 'PARKING' && !isParking) return null;
            if (activeFilter === 'SURGE' || activeFilter === 'CARS') return null;
            if (!hub.lat || !hub.lng) return null;

            const isSelected = selectedHub?.id === hub.id;
            const bgColor = isCng ? '#10b981' : isEv ? '#0ea5e9' : isParking ? '#a855f7' : '#d97706';

            return (
              <AdvancedMarker
                key={hub.id}
                position={{ lat: hub.lat, lng: hub.lng }}
                title={hub.name}
                onClick={() => {
                  onSelectHub(hub);
                  setActiveInfoWindow({
                    type: 'HUB',
                    data: hub,
                    position: { lat: hub.lat!, lng: hub.lng! },
                  });
                }}
              >
                <Pin
                  background={bgColor}
                  borderColor="#ffffff"
                  glyphColor="#ffffff"
                  scale={isSelected ? 1.25 : 1.0}
                />
              </AdvancedMarker>
            );
          })}

          {/* Live Moving Fleet Cars */}
          {(activeFilter === 'ALL' || activeFilter === 'CARS') && cars.map((car) => {
            const isUser = car.isUserDriver;
            const isSelected = selectedCar?.id === car.id;

            return (
              <AdvancedMarker
                key={car.id}
                position={car.currentCoord}
                title={car.driverName}
                onClick={() => {
                  onSelectCar(car);
                  setActiveInfoWindow({
                    type: 'CAR',
                    data: car,
                    position: car.currentCoord,
                  });
                }}
              >
                <div className="relative cursor-pointer group flex flex-col items-center transform -translate-x-1/2 -translate-y-1/2 hover:scale-110 transition-transform">
                  {isUser && (
                    <>
                      <div className="absolute -inset-4 bg-emerald-500/20 rounded-full animate-ping pointer-events-none" />
                      <div className="absolute -inset-2 bg-emerald-500/30 rounded-full pointer-events-none" />
                    </>
                  )}

                  {/* Rotating Top-Down Taxi SVG */}
                  <div 
                    className="relative w-10 h-14 flex items-center justify-center" 
                    style={{ transform: `rotate(${car.headingAngle}deg)`, transition: 'transform 0.15s ease-out' }}
                  >
                    <svg width="22" height="36" viewBox="0 0 26 42" fill="none" className="filter drop-shadow-lg">
                      <rect x="0" y="7" width="2.5" height="7" rx="1.25" fill="#0f172a" />
                      <rect x="23.5" y="7" width="2.5" height="7" rx="1.25" fill="#0f172a" />
                      <rect x="0" y="27" width="2.5" height="7" rx="1.25" fill="#0f172a" />
                      <rect x="23.5" y="27" width="2.5" height="7" rx="1.25" fill="#0f172a" />
                      <rect x="2" y="3" width="22" height="36" rx="6" fill={isUser ? '#064e3b' : isSelected ? '#0369a1' : '#0f172a'} stroke={isUser ? '#34d399' : isSelected ? '#38bdf8' : '#eab308'} strokeWidth="1.8" />
                      <path d="M5 12 C5 9, 21 9, 21 12 L19.5 17 L6.5 17 Z" fill="#38bdf8" opacity="0.9" />
                      <rect x="6" y="17" width="14" height="13" rx="2.5" fill={isUser ? '#10b981' : isSelected ? '#0ea5e9' : '#1e293b'} />
                      <rect x="9" y="20" width="8" height="3.5" rx="1" fill="#facc15" stroke="#ca8a04" strokeWidth="0.5" />
                      <path d="M6.5 30 L19.5 30 L20.5 34 L5.5 34 Z" fill="#38bdf8" opacity="0.75" />
                      <circle cx="5.5" cy="4" r="1.6" fill="#fef08a" />
                      <circle cx="20.5" cy="4" r="1.6" fill="#fef08a" />
                      <rect x="4.5" y="38" width="3" height="1.2" rx="0.5" fill="#ef4444" />
                      <rect x="18.5" y="38" width="3" height="1.2" rx="0.5" fill="#ef4444" />
                    </svg>
                  </div>

                  {/* Telemetry Tag */}
                  <div className={`mt-[-2px] flex items-center gap-1 px-2 py-0.5 rounded-full shadow-2xl border text-[10px] whitespace-nowrap ${
                    isUser 
                      ? 'bg-emerald-500 text-slate-950 border-white ring-2 ring-emerald-400 font-black' 
                      : isSelected
                      ? 'bg-sky-500 text-slate-950 border-white font-black'
                      : 'bg-slate-950/90 text-slate-200 border-slate-700 font-semibold'
                  }`}>
                    <span className="font-mono">{isUser ? 'YOU' : car.vehiclePlate.substring(0, 8)}</span>
                    <span className={`px-1 py-0.2 rounded font-mono font-bold ${
                      isUser ? 'bg-slate-950 text-emerald-300' : 'bg-slate-800 text-amber-300'
                    }`}>{car.speedKmH}k</span>
                  </div>
                </div>
              </AdvancedMarker>
            );
          })}

          {/* InfoWindow for Selected Item */}
          {activeInfoWindow && (
            <InfoWindow
              position={activeInfoWindow.position}
              onCloseClick={() => setActiveInfoWindow(null)}
              maxWidth={300}
            >
              <div className="p-1 text-slate-900 text-xs">
                {activeInfoWindow.type === 'CAR' && (
                  <div className="space-y-1.5">
                    <div className="font-bold text-sm text-emerald-700 flex items-center justify-between">
                      <span>{activeInfoWindow.data.driverName}</span>
                      <span className="text-[10px] bg-slate-200 px-1.5 py-0.5 rounded font-mono">
                        {activeInfoWindow.data.platform}
                      </span>
                    </div>
                    <div className="text-slate-600 font-mono text-[11px]">{activeInfoWindow.data.vehicleModel} • {activeInfoWindow.data.vehiclePlate}</div>
                    <div className="bg-emerald-50 p-2 rounded border border-emerald-200 text-[11px]">
                      <div className="font-semibold text-emerald-900">{activeInfoWindow.data.passengerStatus}</div>
                      <div className="flex justify-between items-center text-emerald-800 font-bold mt-1">
                        <span>Fare: ₹{activeInfoWindow.data.currentFare}</span>
                        <span>Net: ₹{activeInfoWindow.data.netMargin}</span>
                      </div>
                    </div>
                  </div>
                )}

                {activeInfoWindow.type === 'CLUSTER' && (
                  <div className="space-y-1.5">
                    <div className="font-bold text-sm text-amber-700 flex items-center justify-between">
                      <span>{activeInfoWindow.data.zoneName}</span>
                      <span className="text-[10px] bg-amber-100 text-amber-900 px-1.5 py-0.5 rounded font-bold">
                        {activeInfoWindow.data.surgeMultiplier}x Surge
                      </span>
                    </div>
                    <div className="text-slate-600 text-[11px]">Avg Trip: ₹{activeInfoWindow.data.avgFarePerTrip} • Wait: {activeInfoWindow.data.avgWaitTimeMin}m</div>
                    <div className="bg-amber-50 p-2 rounded border border-amber-200 text-[10px] text-amber-900">
                      <strong>Peak Hours:</strong> {activeInfoWindow.data.peakHourWindow}
                    </div>
                  </div>
                )}

                {activeInfoWindow.type === 'HUB' && (
                  <div className="space-y-1.5">
                    <div className="font-bold text-sm text-slate-900 flex items-center justify-between">
                      <span>{activeInfoWindow.data.name}</span>
                      <span className="text-[10px] bg-emerald-100 text-emerald-800 px-1.5 py-0.5 rounded font-bold">
                        ★ {activeInfoWindow.data.rating}
                      </span>
                    </div>
                    <div className="text-slate-600 text-[11px]">{activeInfoWindow.data.address}</div>
                    <div className="font-semibold text-emerald-700">{activeInfoWindow.data.priceInfo}</div>
                    <div className="text-[10px] text-slate-500">Queue: {activeInfoWindow.data.queueStatus}</div>
                  </div>
                )}
              </div>
            </InfoWindow>
          )}

          {/* Map Controls */}
          <MapControlsOverlay
            trafficEnabled={trafficEnabled}
            onToggleTraffic={onToggleTraffic}
            mapType={mapType}
            onChangeMapType={onChangeMapType}
            onCenterMyCar={handleCenterMyCar}
          />
        </Map>
      </APIProvider>
    </div>
  );
};
