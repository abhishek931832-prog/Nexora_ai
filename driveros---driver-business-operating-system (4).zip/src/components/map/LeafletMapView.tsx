import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { DemandSurgeCluster, VerifiedRestAndFuelHub } from '../../types';
import { MapCarData, GeoPoint, BENGALURU_CENTER } from './mapData';
import { 
  Navigation, 
  Car, 
  Flame, 
  Fuel, 
  Zap, 
  ParkingCircle, 
  Coffee,
  Maximize2,
  Minimize2,
  Crosshair,
  Layers,
  Sparkles
} from 'lucide-react';

interface LeafletMapViewProps {
  cars: MapCarData[];
  selectedCar: MapCarData | null;
  onSelectCar: (car: MapCarData) => void;
  clusters: DemandSurgeCluster[];
  selectedCluster: DemandSurgeCluster | null;
  onSelectCluster: (cluster: DemandSurgeCluster) => void;
  hubs: VerifiedRestAndFuelHub[];
  selectedHub: VerifiedRestAndFuelHub | null;
  onSelectHub: (hub: VerifiedRestAndFuelHub) => void;
  activeFilter: 'ALL' | 'SURGE' | 'CNG' | 'EV' | 'PARKING' | 'CARS';
  routePoints?: GeoPoint[];
  mapTheme: 'dark' | 'street' | 'satellite';
  onChangeMapTheme: (theme: 'dark' | 'street' | 'satellite') => void;
}

export const LeafletMapView: React.FC<LeafletMapViewProps> = ({
  cars,
  selectedCar,
  onSelectCar,
  clusters,
  selectedCluster,
  onSelectCluster,
  hubs,
  selectedHub,
  onSelectHub,
  activeFilter,
  routePoints = [],
  mapTheme,
  onChangeMapTheme,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const tileLayerRef = useRef<L.TileLayer | null>(null);
  const markersLayerGroupRef = useRef<L.LayerGroup | null>(null);
  const routePolylineRef = useRef<L.Polyline | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [followCarEnabled, setFollowCarEnabled] = useState(true);

  // Initialize Leaflet Map
  useEffect(() => {
    if (!containerRef.current) return;

    if (!mapInstanceRef.current) {
      const initialCenter = selectedCar?.currentCoord || BENGALURU_CENTER;
      const map = L.map(containerRef.current, {
        center: [initialCenter.lat, initialCenter.lng],
        zoom: 13,
        zoomControl: false,
        attributionControl: false,
      });

      markersLayerGroupRef.current = L.layerGroup().addTo(map);
      mapInstanceRef.current = map;

      // Handle window/container resize
      const resizeObserver = new ResizeObserver(() => {
        map.invalidateSize();
      });
      resizeObserver.observe(containerRef.current);

      return () => {
        resizeObserver.disconnect();
        map.remove();
        mapInstanceRef.current = null;
      };
    }
  }, []);

  // Smooth Follow-Car Camera Tracking
  useEffect(() => {
    if (!followCarEnabled || !mapInstanceRef.current) return;
    const targetCar = selectedCar || cars.find(c => c.isUserDriver);
    if (targetCar) {
      mapInstanceRef.current.panTo([targetCar.currentCoord.lat, targetCar.currentCoord.lng], {
        animate: true,
        duration: 0.6,
      });
    }
  }, [cars, selectedCar, followCarEnabled]);

  // Update Tile Layer when mapTheme changes
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    if (tileLayerRef.current) {
      map.removeLayer(tileLayerRef.current);
    }

    let url = 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png';
    let maxZoom = 19;

    if (mapTheme === 'street') {
      url = 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png';
    } else if (mapTheme === 'satellite') {
      url = 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}';
      maxZoom = 18;
    }

    const tileLayer = L.tileLayer(url, {
      maxZoom,
      subdomains: 'abcd',
    }).addTo(map);

    tileLayerRef.current = tileLayer;
  }, [mapTheme]);

  // Update Markers, Circles, and Overlays
  useEffect(() => {
    const layerGroup = markersLayerGroupRef.current;
    if (!layerGroup) return;

    layerGroup.clearLayers();

    // 1. Render Surge Clusters
    if (activeFilter === 'ALL' || activeFilter === 'SURGE') {
      clusters.forEach((cluster) => {
        const lat = cluster.lat || BENGALURU_CENTER.lat;
        const lng = cluster.lng || BENGALURU_CENTER.lng;
        const isSelected = selectedCluster?.id === cluster.id;
        const isAirport = cluster.id === 'ZONE-01';

        // Glowing circle
        const circle = L.circle([lat, lng], {
          radius: cluster.surgeMultiplier * 1400,
          color: isAirport ? '#f59e0b' : '#10b981',
          fillColor: isAirport ? '#f59e0b' : '#10b981',
          fillOpacity: isSelected ? 0.25 : 0.12,
          weight: isSelected ? 2.5 : 1,
          dashArray: isSelected ? '4, 4' : undefined,
        });
        circle.addTo(layerGroup);

        // Marker icon
        const surgeIcon = L.divIcon({
          className: 'custom-leaflet-surge-icon',
          html: `
            <div class="relative group cursor-pointer transform -translate-x-1/2 -translate-y-1/2">
              <div class="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold shadow-xl border ${
                isAirport 
                  ? 'bg-amber-500 text-slate-950 border-amber-300 ring-2 ring-amber-400/50 animate-pulse' 
                  : 'bg-slate-900 text-amber-400 border-amber-500/60'
              }">
                <span class="text-xs">🔥</span>
                <span>${cluster.surgeMultiplier}x</span>
              </div>
              <div class="absolute -bottom-4 left-1/2 -translate-x-1/2 whitespace-nowrap bg-slate-950/90 text-slate-200 text-[10px] font-semibold px-2 py-0.5 rounded border border-slate-800 shadow-md">
                ${cluster.zoneName.split('(')[0]}
              </div>
            </div>
          `,
          iconSize: [60, 30],
          iconAnchor: [30, 15],
        });

        const marker = L.marker([lat, lng], { icon: surgeIcon });
        marker.on('click', () => onSelectCluster(cluster));
        marker.addTo(layerGroup);
      });
    }

    // 2. Render Verified Hubs (CNG, EV, Parking, Chai)
    hubs.forEach((hub) => {
      const isCng = hub.type === 'CNG_PUMP';
      const isEv = hub.type === 'EV_FAST_CHARGER';
      const isParking = hub.type === 'VERIFIED_PARKING';

      if (activeFilter === 'CNG' && !isCng) return;
      if (activeFilter === 'EV' && !isEv) return;
      if (activeFilter === 'PARKING' && !isParking) return;
      if (activeFilter === 'SURGE' || activeFilter === 'CARS') return;

      const lat = hub.lat || BENGALURU_CENTER.lat;
      const lng = hub.lng || BENGALURU_CENTER.lng;
      const isSelected = selectedHub?.id === hub.id;

      const bgColor = isCng ? 'bg-emerald-500 text-slate-950' : isEv ? 'bg-sky-500 text-slate-950' : isParking ? 'bg-purple-500 text-white' : 'bg-amber-600 text-white';
      const iconSymbol = isCng ? '⛽' : isEv ? '⚡' : isParking ? '🅿️' : '☕';

      const hubIcon = L.divIcon({
        className: 'custom-leaflet-hub-icon',
        html: `
          <div class="relative cursor-pointer transform -translate-x-1/2 -translate-y-1/2 hover:scale-110 transition-transform">
            <div class="w-8 h-8 rounded-xl ${bgColor} flex items-center justify-center text-sm shadow-lg border-2 ${isSelected ? 'border-white ring-4 ring-emerald-400/40' : 'border-slate-900'}">
              <span>${iconSymbol}</span>
            </div>
            <div class="absolute -bottom-4 left-1/2 -translate-x-1/2 whitespace-nowrap bg-slate-900/90 text-slate-300 text-[9px] font-mono px-1.5 py-0.2 rounded border border-slate-700 shadow">
              ${hub.priceInfo.split('(')[0]}
            </div>
          </div>
        `,
        iconSize: [32, 32],
        iconAnchor: [16, 16],
      });

      const marker = L.marker([lat, lng], { icon: hubIcon });
      marker.on('click', () => onSelectHub(hub));
      marker.addTo(layerGroup);
    });

    // 3. Render Live Moving Cars Fleet
    if (activeFilter === 'ALL' || activeFilter === 'CARS') {
      cars.forEach((car) => {
        const isUser = car.isUserDriver;
        const isSelected = selectedCar?.id === car.id;

        const carIcon = L.divIcon({
          className: 'custom-leaflet-car-icon',
          html: `
            <div class="relative cursor-pointer group flex flex-col items-center transform -translate-x-1/2 -translate-y-1/2 transition-transform hover:scale-110">
              ${isUser ? `
                <div class="absolute -inset-4 bg-emerald-500/20 rounded-full animate-ping pointer-events-none"></div>
                <div class="absolute -inset-2 bg-emerald-500/30 rounded-full pointer-events-none"></div>
              ` : ''}

              {/* Rotating Top-Down Taxi SVG with Headlight Beam */}
              <div class="relative w-12 h-16 flex items-center justify-center" style="transform: rotate(${car.headingAngle}deg); transition: transform 0.15s ease-out;">
                <!-- Headlight Projection Beam -->
                <svg class="absolute -top-6 left-1/2 -translate-x-1/2 w-16 h-12 pointer-events-none opacity-50" viewBox="0 0 64 48" fill="none">
                  <polygon points="26,44 6,0 58,0 38,44" fill="url(#headlightGlow-${car.id})" />
                  <defs>
                    <linearGradient id="headlightGlow-${car.id}" x1="32" y1="44" x2="32" y2="0" gradientUnits="userSpaceOnUse">
                      <stop offset="0%" stop-color="#fef08a" stop-opacity="0.8" />
                      <stop offset="100%" stop-color="#fef08a" stop-opacity="0" />
                    </linearGradient>
                  </defs>
                </svg>

                <!-- Detailed Top-Down Vehicle Body -->
                <svg width="26" height="42" viewBox="0 0 26 42" fill="none" class="filter drop-shadow-lg">
                  <!-- Wheels Left & Right -->
                  <rect x="0" y="7" width="2.5" height="7" rx="1.25" fill="#0f172a" />
                  <rect x="23.5" y="7" width="2.5" height="7" rx="1.25" fill="#0f172a" />
                  <rect x="0" y="27" width="2.5" height="7" rx="1.25" fill="#0f172a" />
                  <rect x="23.5" y="27" width="2.5" height="7" rx="1.25" fill="#0f172a" />

                  <!-- Main Car Body Shell -->
                  <rect x="2" y="3" width="22" height="36" rx="6" fill="${isUser ? '#064e3b' : isSelected ? '#0369a1' : '#0f172a'}" stroke="${isUser ? '#34d399' : isSelected ? '#38bdf8' : '#eab308'}" stroke-width="1.8" />

                  <!-- Front Windshield -->
                  <path d="M5 12 C5 9, 21 9, 21 12 L19.5 17 L6.5 17 Z" fill="#38bdf8" opacity="0.9" />

                  <!-- Roof -->
                  <rect x="6" y="17" width="14" height="13" rx="2.5" fill="${isUser ? '#10b981' : isSelected ? '#0ea5e9' : '#1e293b'}" />

                  <!-- Commercial Taxi Roof Board (Yellow Amber Beacon) -->
                  <rect x="9" y="20" width="8" height="3.5" rx="1" fill="#facc15" stroke="#ca8a04" stroke-width="0.5" />

                  <!-- Rear Windshield -->
                  <path d="M6.5 30 L19.5 30 L20.5 34 L5.5 34 Z" fill="#38bdf8" opacity="0.75" />

                  <!-- Dual Front Headlights -->
                  <circle cx="5.5" cy="4" r="1.6" fill="#fef08a" />
                  <circle cx="20.5" cy="4" r="1.6" fill="#fef08a" />

                  <!-- Dual Rear Brake Taillights -->
                  <rect x="4.5" y="38" width="3" height="1.2" rx="0.5" fill="#ef4444" />
                  <rect x="18.5" y="38" width="3" height="1.2" rx="0.5" fill="#ef4444" />
                </svg>
              </div>

              <!-- Floating Car Telemetry Tag (Stays upright regardless of rotation) -->
              <div class="mt-[-2px] flex items-center gap-1 px-2 py-0.5 rounded-full shadow-2xl border text-[10px] whitespace-nowrap ${
                isUser 
                  ? 'bg-emerald-500 text-slate-950 border-white ring-2 ring-emerald-400 font-black' 
                  : isSelected
                  ? 'bg-sky-500 text-slate-950 border-white font-black'
                  : 'bg-slate-950/90 text-slate-200 border-slate-700 font-semibold'
              }">
                <span class="font-mono">${isUser ? 'YOU • WagonR' : car.vehiclePlate.substring(0, 8)}</span>
                <span class="px-1 py-0.2 rounded font-mono font-bold ${
                  isUser ? 'bg-slate-950 text-emerald-300' : 'bg-slate-800 text-amber-300'
                }">${car.speedKmH} km/h</span>
              </div>
            </div>
          `,
          iconSize: [110, 80],
          iconAnchor: [55, 40],
        });

        const marker = L.marker([car.currentCoord.lat, car.currentCoord.lng], { icon: carIcon });
        marker.on('click', () => onSelectCar(car));
        marker.addTo(layerGroup);
      });
    }

    // 4. Render Active Route Polyline
    if (routePoints.length >= 2) {
      if (routePolylineRef.current) {
        mapInstanceRef.current?.removeLayer(routePolylineRef.current);
      }
      const latLngs: [number, number][] = routePoints.map(p => [p.lat, p.lng]);
      const polyline = L.polyline(latLngs, {
        color: '#10b981',
        weight: 5,
        opacity: 0.85,
        lineCap: 'round',
        dashArray: '6, 8',
      }).addTo(mapInstanceRef.current!);
      routePolylineRef.current = polyline;
    }
  }, [cars, clusters, hubs, selectedCar, selectedCluster, selectedHub, activeFilter, routePoints]);

  const handleCenterOnUser = () => {
    const userCar = cars.find(c => c.isUserDriver);
    if (userCar && mapInstanceRef.current) {
      mapInstanceRef.current.flyTo([userCar.currentCoord.lat, userCar.currentCoord.lng], 14, {
        duration: 1.2,
      });
    }
  };

  const handleZoomIn = () => mapInstanceRef.current?.zoomIn();
  const handleZoomOut = () => mapInstanceRef.current?.zoomOut();

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      document.exitFullscreen().catch(() => {});
      setIsFullscreen(false);
    }
  };

  return (
    <div className={`relative w-full h-full min-h-[500px] flex-1 overflow-hidden select-none ${isFullscreen ? 'fixed inset-0 z-50 bg-slate-950' : 'rounded-2xl'}`}>
      {/* Map DOM Canvas */}
      <div ref={containerRef} className="w-full h-full min-h-[500px] bg-slate-950" />

      {/* Floating Tactical Map Controls */}
      <div className="absolute top-4 right-4 z-[400] flex flex-col gap-2">
        {/* Map Theme Toggle */}
        <div className="bg-slate-950/90 backdrop-blur-md p-1 rounded-xl border border-slate-800 shadow-xl flex flex-col gap-1">
          <button
            onClick={() => onChangeMapTheme('dark')}
            className={`px-2.5 py-1 text-[10px] font-bold rounded-lg transition-all flex items-center gap-1.5 ${
              mapTheme === 'dark' ? 'bg-emerald-500 text-slate-950 shadow' : 'text-slate-400 hover:text-white'
            }`}
            title="Tactical Dark Mode (Windshield HUD)"
          >
            <span className="w-2 h-2 rounded-full bg-slate-900 border border-slate-600" />
            <span>Tactical Dark</span>
          </button>
          <button
            onClick={() => onChangeMapTheme('street')}
            className={`px-2.5 py-1 text-[10px] font-bold rounded-lg transition-all flex items-center gap-1.5 ${
              mapTheme === 'street' ? 'bg-emerald-500 text-slate-950 shadow' : 'text-slate-400 hover:text-white'
            }`}
            title="Street Road Map"
          >
            <span className="w-2 h-2 rounded-full bg-amber-400" />
            <span>Street View</span>
          </button>
          <button
            onClick={() => onChangeMapTheme('satellite')}
            className={`px-2.5 py-1 text-[10px] font-bold rounded-lg transition-all flex items-center gap-1.5 ${
              mapTheme === 'satellite' ? 'bg-emerald-500 text-slate-950 shadow' : 'text-slate-400 hover:text-white'
            }`}
            title="Satellite Aerial"
          >
            <span className="w-2 h-2 rounded-full bg-sky-400" />
            <span>Satellite</span>
          </button>
        </div>

        {/* Zoom & Navigation Actions */}
        <div className="bg-slate-950/90 backdrop-blur-md p-1 rounded-xl border border-slate-800 shadow-xl flex flex-col gap-1">
          {/* Follow Car Toggle */}
          <button
            onClick={() => setFollowCarEnabled(!followCarEnabled)}
            className={`p-2 rounded-lg transition-all flex items-center justify-center relative ${
              followCarEnabled 
                ? 'bg-emerald-500 text-slate-950 shadow-md ring-2 ring-emerald-400/50 font-bold' 
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
            title={followCarEnabled ? 'Camera Locked to Moving Car (Click to Unlock)' : 'Click to Lock Camera to Moving Car'}
          >
            <Car className="w-4 h-4" />
            {followCarEnabled && (
              <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-emerald-400 rounded-full animate-ping" />
            )}
          </button>

          <button
            onClick={handleCenterOnUser}
            className="p-2 rounded-lg text-emerald-400 hover:bg-slate-800 transition-colors flex items-center justify-center"
            title="Center GPS to My Vehicle"
          >
            <Crosshair className="w-4 h-4" />
          </button>
          <button
            onClick={handleZoomIn}
            className="p-2 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 transition-colors font-bold text-sm flex items-center justify-center"
            title="Zoom In"
          >
            +
          </button>
          <button
            onClick={handleZoomOut}
            className="p-2 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 transition-colors font-bold text-sm flex items-center justify-center"
            title="Zoom Out"
          >
            −
          </button>
          <button
            onClick={toggleFullscreen}
            className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors flex items-center justify-center"
            title="Toggle Fullscreen"
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Floating Active Car HUD (Top-Left) */}
      {selectedCar && (
        <div className="absolute top-4 left-4 z-[400] bg-slate-950/92 backdrop-blur-md px-3.5 py-2.5 rounded-2xl border border-emerald-500/40 shadow-2xl flex items-center gap-3">
          <div className="relative">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-600 to-teal-700 flex items-center justify-center text-white shadow-lg">
              <Car className="w-5 h-5" />
            </div>
            {selectedCar.isUserDriver && (
              <span className="absolute -top-1 -right-1 w-3 h-3 bg-emerald-400 rounded-full border-2 border-slate-950 animate-pulse" />
            )}
          </div>

          <div className="space-y-0.5">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-white tracking-tight">
                {selectedCar.isUserDriver ? 'Your Taxi' : selectedCar.driverName}
              </span>
              <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-800 text-slate-300 font-mono">
                {selectedCar.vehiclePlate}
              </span>
            </div>
            <div className="flex items-center gap-2 text-[11px]">
              <span className="text-emerald-400 font-mono font-black text-sm">{selectedCar.speedKmH} km/h</span>
              <span className="text-slate-500">•</span>
              <span className="text-slate-300 font-mono text-[10px] flex items-center gap-1">
                <Navigation 
                  className="w-3 h-3 text-sky-400" 
                  style={{ transform: `rotate(${selectedCar.headingAngle}deg)` }} 
                />
                {Math.round(selectedCar.headingAngle)}°
              </span>
              <span className="text-slate-500">•</span>
              <span className="text-amber-400 text-[10px] font-medium truncate max-w-[130px]">
                {selectedCar.routeKey.replace(/_/g, ' ')}
              </span>
            </div>
          </div>

          <button
            onClick={() => setFollowCarEnabled(!followCarEnabled)}
            className={`ml-1 px-2 py-1 rounded-lg text-[10px] font-bold transition-all ${
              followCarEnabled 
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' 
                : 'bg-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            {followCarEnabled ? 'LOCKED' : 'LOCK'}
          </button>
        </div>
      )}

      {/* Floating Bottom Telemetry Badge */}
      <div className="absolute bottom-4 left-4 z-[400] bg-slate-950/90 backdrop-blur-md px-3 py-2 rounded-xl border border-slate-800 shadow-xl flex items-center gap-3 text-xs text-slate-300">
        <div className="flex items-center gap-1.5 font-bold text-emerald-400">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
          <span>Live GPS Fleet Tracking</span>
        </div>
        <div className="h-3 w-px bg-slate-700" />
        <div className="text-[11px] font-mono text-slate-400">
          Bengaluru Highway: NH44 • ORR • E-City Elevated
        </div>
      </div>
    </div>
  );
};
