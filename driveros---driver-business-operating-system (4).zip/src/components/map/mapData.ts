// Source: Google Maps Platform Code Assist
export interface GeoPoint {
  lat: number;
  lng: number;
}

export interface MapCarData {
  id: string;
  driverName: string;
  vehicleModel: string;
  vehiclePlate: string;
  platform: 'NAMMA_YATRI' | 'DIRECT_CLIENT' | 'OLA' | 'UBER' | 'RAPIDO';
  isUserDriver?: boolean;
  routeKey: 'AIRPORT_EXPRESS' | 'OUTER_RING_ROAD' | 'ECITY_ELEVATED' | 'WHITEFIELD_CORRIDOR';
  progress: number; // 0 to 1
  speedKmH: number;
  currentCoord: GeoPoint;
  headingAngle: number;
  currentFare: number;
  commissionCut: number;
  netMargin: number;
  passengerStatus: string;
  fuelType: 'CNG' | 'EV' | 'PETROL' | 'DIESEL';
}

export type MapCar = MapCarData;

export const BENGALURU_CENTER: GeoPoint = { lat: 12.9716, lng: 77.5946 };

export const ROUTE_WAYPOINTS: Record<string, GeoPoint[]> = {
  AIRPORT_EXPRESS: [
    { lat: 12.9352, lng: 77.6245 }, // Koramangala
    { lat: 12.9610, lng: 77.6387 }, // Domlur Flyover
    { lat: 12.9984, lng: 77.6258 }, // Ulsoor / Frazer Town
    { lat: 13.0358, lng: 77.5970 }, // Hebbal Flyover
    { lat: 13.1007, lng: 77.5963 }, // Yelahanka Bypass
    { lat: 13.1704, lng: 77.6368 }, // Chikkajala Toll Plaza
    { lat: 13.1986, lng: 77.7066 }, // Kempegowda Airport T2
  ],
  OUTER_RING_ROAD: [
    { lat: 12.9172, lng: 77.6228 }, // Silk Board
    { lat: 12.9116, lng: 77.6389 }, // HSR Layout
    { lat: 12.9260, lng: 77.6762 }, // Bellandur EcoSpace
    { lat: 12.9591, lng: 77.7011 }, // Marathahalli Bridge
    { lat: 12.9904, lng: 77.6974 }, // Mahadevapura
    { lat: 13.0076, lng: 77.6853 }, // KR Puram Hanging Bridge
    { lat: 13.0358, lng: 77.5970 }, // Hebbal Flyover
  ],
  ECITY_ELEVATED: [
    { lat: 12.9172, lng: 77.6228 }, // Silk Board
    { lat: 12.8872, lng: 77.6433 }, // Kudlu Gate Flyover
    { lat: 12.8689, lng: 77.6521 }, // Singasandra
    { lat: 12.8452, lng: 77.6602 }, // Electronic City Phase 1
  ],
  WHITEFIELD_CORRIDOR: [
    { lat: 12.9784, lng: 77.6408 }, // Indiranagar 100ft Rd
    { lat: 12.9553, lng: 77.6653 }, // HAL Airport Road
    { lat: 12.9591, lng: 77.7011 }, // Marathahalli
    { lat: 12.9648, lng: 77.7289 }, // Kundalahalli Gate
    { lat: 12.9698, lng: 77.7499 }, // ITPL Main Gate
  ],
};

// Interpolate coordinate along waypoints given progress 0..1
export function interpolateWaypoint(waypoints: GeoPoint[], progress: number): { coord: GeoPoint; heading: number } {
  if (waypoints.length === 0) return { coord: BENGALURU_CENTER, heading: 0 };
  if (waypoints.length === 1) return { coord: waypoints[0], heading: 0 };

  const clamped = Math.max(0, Math.min(0.9999, progress));
  const segmentCount = waypoints.length - 1;
  const totalScaled = clamped * segmentCount;
  const segmentIndex = Math.floor(totalScaled);
  const segmentFraction = totalScaled - segmentIndex;

  const p1 = waypoints[segmentIndex];
  const p2 = waypoints[Math.min(segmentCount, segmentIndex + 1)];

  const lat = p1.lat + (p2.lat - p1.lat) * segmentFraction;
  const lng = p1.lng + (p2.lng - p1.lng) * segmentFraction;

  // Approximate heading in degrees
  const dy = (p2.lat - p1.lat);
  const dx = (p2.lng - p1.lng) * Math.cos((p1.lat * Math.PI) / 180);
  const heading = (Math.atan2(dx, dy) * 180) / Math.PI;

  return { coord: { lat, lng }, heading };
}

export const INITIAL_MAP_CARS: MapCarData[] = [
  {
    id: 'CAR-YOU',
    driverName: 'You (Shivaraj Gowda)',
    vehicleModel: 'Maruti WagonR CNG',
    vehiclePlate: 'KA-05-MQ-8921',
    platform: 'DIRECT_CLIENT',
    isUserDriver: true,
    routeKey: 'AIRPORT_EXPRESS',
    progress: 0.45,
    speedKmH: 56,
    currentCoord: { lat: 13.0358, lng: 77.5970 },
    headingAngle: 20,
    currentFare: 1650,
    commissionCut: 0,
    netMargin: 1535,
    passengerStatus: 'En-route to Airport T2 (Direct VIP)',
    fuelType: 'CNG',
  },
  {
    id: 'CAR-01',
    driverName: 'Raghu K.',
    vehicleModel: 'Tata Tigor EV',
    vehiclePlate: 'KA-01-EV-3012',
    platform: 'NAMMA_YATRI',
    routeKey: 'OUTER_RING_ROAD',
    progress: 0.20,
    speedKmH: 44,
    currentCoord: { lat: 12.9260, lng: 77.6762 },
    headingAngle: 45,
    currentFare: 420,
    commissionCut: 0,
    netMargin: 395,
    passengerStatus: 'Koramangala ➔ HSR Sector 2 (0% Commission)',
    fuelType: 'EV',
  },
  {
    id: 'CAR-02',
    driverName: 'Manjunath B.',
    vehicleModel: 'Toyota Etios Platinum',
    vehiclePlate: 'KA-03-AA-9081',
    platform: 'DIRECT_CLIENT',
    routeKey: 'AIRPORT_EXPRESS',
    progress: 0.85,
    speedKmH: 62,
    currentCoord: { lat: 13.1704, lng: 77.6368 },
    headingAngle: 25,
    currentFare: 1800,
    commissionCut: 0,
    netMargin: 1680,
    passengerStatus: 'Indiranagar ➔ Airport T1 (Direct Corporate)',
    fuelType: 'CNG',
  },
  {
    id: 'CAR-03',
    driverName: 'Suresh Patil',
    vehicleModel: 'Swift Dzire Tour CNG',
    vehiclePlate: 'KA-04-E-4521',
    platform: 'OLA',
    routeKey: 'AIRPORT_EXPRESS',
    progress: 0.65,
    speedKmH: 52,
    currentCoord: { lat: 13.1007, lng: 77.5963 },
    headingAngle: 15,
    currentFare: 1400,
    commissionCut: 392,
    netMargin: 890,
    passengerStatus: 'Ola Prime Ride (Losing 28% Commission)',
    fuelType: 'CNG',
  },
  {
    id: 'CAR-04',
    driverName: 'Chetan R.',
    vehicleModel: 'Hyundai Aura CNG',
    vehiclePlate: 'KA-51-M-7733',
    platform: 'UBER',
    routeKey: 'ECITY_ELEVATED',
    progress: 0.55,
    speedKmH: 48,
    currentCoord: { lat: 12.8689, lng: 77.6521 },
    headingAngle: 170,
    currentFare: 680,
    commissionCut: 136,
    netMargin: 460,
    passengerStatus: 'Uber Go Trip to E-City Tollway',
    fuelType: 'CNG',
  },
  {
    id: 'CAR-05',
    driverName: 'Harish Gowda',
    vehicleModel: 'Innova Crysta Diesel',
    vehiclePlate: 'KA-02-MJ-9900',
    platform: 'DIRECT_CLIENT',
    routeKey: 'WHITEFIELD_CORRIDOR',
    progress: 0.70,
    speedKmH: 42,
    currentCoord: { lat: 12.9648, lng: 77.7289 },
    headingAngle: 85,
    currentFare: 2400,
    commissionCut: 0,
    netMargin: 2150,
    passengerStatus: 'Whitefield Tech Park Full-Day Corporate Rental',
    fuelType: 'DIESEL',
  },
];
