import React, { useState } from 'react';
import { 
  Building2, 
  TrendingUp, 
  Award, 
  FileText, 
  Users, 
  UserPlus, 
  Share2, 
  Download, 
  DollarSign, 
  Briefcase, 
  Phone, 
  Calendar,
  CheckCircle2,
  ChevronRight
} from 'lucide-react';
import { DriverProfile, TripRecord, ExpenseRecord, DirectClientRecord } from '../../types';

interface BusinessViewProps {
  driver: DriverProfile;
  trips: TripRecord[];
  expenses: ExpenseRecord[];
  clients: DirectClientRecord[];
  activeSubItem: string;
  onSelectSubItem: (sub: string) => void;
  onAddClient: (client: DirectClientRecord) => void;
}

export const BusinessView: React.FC<BusinessViewProps> = ({
  driver,
  trips,
  expenses,
  clients,
  activeSubItem,
  onSelectSubItem,
  onAddClient,
}) => {
  const [newClientName, setNewClientName] = useState('');
  const [newClientPhone, setNewClientPhone] = useState('');
  const [newClientRoute, setNewClientRoute] = useState('Indiranagar → Kempegowda Airport T2');
  const [newClientRate, setNewClientRate] = useState(1650);

  const handleCreateClient = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newClientName.trim()) return;

    const newRecord: DirectClientRecord = {
      id: `client_${Date.now()}`,
      name: newClientName,
      phone: newClientPhone || '9845000000',
      companyOrLocality: 'Corporate VIP',
      totalRevenueGenerated: newClientRate,
      totalTripsCompleted: 1,
      rating: 5,
      preferredRoute: newClientRoute,
      agreedRate: newClientRate,
      notes: 'Direct booking added from Business Hub',
      isVip: true,
    };

    onAddClient(newRecord);
    setNewClientName('');
    setNewClientPhone('');
    alert(`Direct Client ${newRecord.name} registered with 0% platform commission!`);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header & Sub-items */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 sm:p-4 shadow-lg">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-blue-500/20 text-blue-400">
              <Building2 className="w-5 h-5" />
            </span>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                Commercial Business & Fleet Enterprise
              </h2>
              <p className="text-xs text-slate-400">
                Transition from an aggregator driver into an independent commercial fleet owner. 0% commission direct clients & tax filings.
              </p>
            </div>
          </div>
        </div>

        {/* Sub-item Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pt-3 border-t border-slate-800/80 mt-3 scrollbar-none">
          {[
            { id: 'profit-dashboard', label: 'Profit Dashboard' },
            { id: 'daily-target', label: 'Daily Target' },
            { id: 'monthly-pnl', label: 'Monthly P&L' },
            { id: 'tax-reports', label: 'Tax Reports (44AD)' },
            { id: 'customer-crm', label: 'Customer CRM' },
            { id: 'direct-customers', label: 'Direct Customers' },
            { id: 'business-reports', label: 'Business Reports' },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => onSelectSubItem(tab.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-1.5 ${
                activeSubItem === tab.id
                  ? 'bg-blue-500 text-slate-950 font-bold shadow'
                  : 'bg-slate-800/60 text-slate-300 hover:bg-slate-800 hover:text-white border border-slate-700/50'
              }`}
            >
              <span>{tab.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* SUB-VIEW 1: PROFIT DASHBOARD */}
      {activeSubItem === 'profit-dashboard' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-1">
              <div className="text-xs text-slate-400">This Month's Gross Revenue</div>
              <div className="text-3xl font-black text-white font-mono">₹78,450</div>
              <div className="text-[11px] text-emerald-400">+18% vs last month</div>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-1">
              <div className="text-xs text-slate-400">Direct Client Revenue (0% Cut)</div>
              <div className="text-3xl font-black text-emerald-400 font-mono">₹38,200</div>
              <div className="text-[11px] text-emerald-300">Saved ₹10,696 in platform cuts!</div>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-1">
              <div className="text-xs text-slate-400">Operating Expenses (Fuel + Toll + EMI)</div>
              <div className="text-3xl font-black text-amber-400 font-mono">₹24,180</div>
              <div className="text-[11px] text-slate-400">CNG: ₹12,800 • FASTag: ₹4,100</div>
            </div>
          </div>
        </div>
      )}

      {/* SUB-VIEW 2: DAILY TARGET */}
      {activeSubItem === 'daily-target' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-5">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white">Daily Target: ₹3,500 Net Profit</h3>
            <span className="text-xs font-mono font-bold text-emerald-400 bg-emerald-500/20 px-3 py-1 rounded-full">
              81% Complete
            </span>
          </div>

          <div className="w-full bg-slate-950 rounded-full h-4 p-0.5 border border-slate-800">
            <div className="bg-gradient-to-r from-emerald-500 to-teal-400 h-full rounded-full transition-all duration-500" style={{ width: '81%' }} />
          </div>

          <div className="grid grid-cols-3 gap-3 text-xs text-center">
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
              <div className="text-slate-400 text-[10px]">Earned Today</div>
              <div className="font-bold text-white font-mono mt-0.5">₹2,840</div>
            </div>
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
              <div className="text-slate-400 text-[10px]">Remaining Gap</div>
              <div className="font-bold text-amber-400 font-mono mt-0.5">₹660</div>
            </div>
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
              <div className="text-slate-400 text-[10px]">Rides Needed</div>
              <div className="font-bold text-emerald-400 font-mono mt-0.5">1 Airport Run</div>
            </div>
          </div>
        </div>
      )}

      {/* SUB-VIEW 3: MONTHLY P&L */}
      {activeSubItem === 'monthly-pnl' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-4">
          <h3 className="text-base font-bold text-white">Monthly Commercial Profit & Loss Statement</h3>
          <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 font-mono text-xs space-y-2">
            <div className="flex justify-between text-slate-300 py-1">
              <span>Total Commercial Gross Receipts:</span>
              <span className="font-bold text-white">₹78,450.00</span>
            </div>
            <div className="flex justify-between text-rose-400 py-1">
              <span>Less: Aggregator Commission (Ola/Uber):</span>
              <span>-₹11,280.00</span>
            </div>
            <div className="flex justify-between text-amber-400 py-1">
              <span>Less: Fuel (CNG + Petrol):</span>
              <span>-₹14,200.00</span>
            </div>
            <div className="flex justify-between text-amber-300 py-1">
              <span>Less: FASTag Tolls & Commercial Parking:</span>
              <span>-₹3,840.00</span>
            </div>
            <div className="flex justify-between text-purple-400 py-1">
              <span>Less: Preventive Garage Maintenance:</span>
              <span>-₹4,200.00</span>
            </div>
            <div className="flex justify-between text-blue-400 py-1">
              <span>Less: Commercial Vehicle Insurance EMI:</span>
              <span>-₹2,100.00</span>
            </div>
            <div className="pt-2 border-t-2 border-slate-700 flex justify-between text-sm font-black text-emerald-400">
              <span>NET TAKE-HOME OPERATING PROFIT:</span>
              <span>₹42,830.00</span>
            </div>
          </div>
        </div>
      )}

      {/* SUB-VIEW 4: TAX REPORTS SECTION 44AD */}
      {activeSubItem === 'tax-reports' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-white">Section 44AD / 44AE Presumptive Taxation</h3>
              <p className="text-xs text-slate-400">Government presumptive tax for commercial passenger transport vehicles. No CA audit required!</p>
            </div>
            <button className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center gap-1.5">
              <Download className="w-3.5 h-3.5" />
              <span>Download ITR-4 Summary</span>
            </button>
          </div>

          <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-2 text-xs">
            <div className="text-emerald-400 font-bold">Presumptive Income Calculation (FY 2026-27):</div>
            <p className="text-slate-300 leading-relaxed">
              Under Section 44AE, light goods/passenger carriage vehicles are taxed at a flat rate of ₹7,500 per vehicle per month. For commercial cabs on UPI receipts, 6% turnover taxation yields minimum taxable liability, resulting in ZERO net income tax after Section 87A rebate!
            </p>
          </div>
        </div>
      )}

      {/* SUB-VIEW 5: CUSTOMER CRM */}
      {activeSubItem === 'customer-crm' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white">VIP Direct Customer Directory</h3>
            <span className="text-xs text-slate-400">{clients.length} Registered VIPs</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {clients.map((c) => (
              <div key={c.id} className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white text-sm">{c.name}</span>
                  <span className="text-xs bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-full font-bold">
                    0% Cut VIP
                  </span>
                </div>
                <div className="text-slate-400">{c.preferredRoute || 'Airport Regular'}</div>
                <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-[11px]">
                  <span className="text-slate-400">Rate: ₹{c.agreedRate || 1650}</span>
                  <div className="flex items-center gap-2">
                    <a href={`tel:${c.phone}`} className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-400">
                      <Phone className="w-3.5 h-3.5" />
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SUB-VIEW 6: DIRECT CUSTOMERS GENERATOR */}
      {activeSubItem === 'direct-customers' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-5">
          <div>
            <h3 className="text-base font-bold text-white">Direct Customer Onboarding (0% Aggregator Commission)</h3>
            <p className="text-xs text-slate-400">Every passenger you convert from Ola/Uber to direct booking adds +₹400 to your pocket per airport trip.</p>
          </div>

          <form onSubmit={handleCreateClient} className="bg-slate-950 border border-slate-800 rounded-2xl p-5 space-y-4 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Passenger Name</label>
                <input
                  type="text"
                  value={newClientName}
                  onChange={(e) => setNewClientName(e.target.value)}
                  placeholder="e.g. Vikramaditya Reddy"
                  required
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                />
              </div>
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Phone Number</label>
                <input
                  type="text"
                  value={newClientPhone}
                  onChange={(e) => setNewClientPhone(e.target.value)}
                  placeholder="e.g. 9845012345"
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Preferred Regular Route</label>
                <input
                  type="text"
                  value={newClientRoute}
                  onChange={(e) => setNewClientRoute(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white"
                />
              </div>
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Agreed Direct Fixed Fare (₹)</label>
                <input
                  type="number"
                  value={newClientRate}
                  onChange={(e) => setNewClientRate(Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono"
                />
              </div>
            </div>

            <button
              type="submit"
              className="py-2.5 px-6 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center gap-2"
            >
              <UserPlus className="w-4 h-4" />
              <span>Save VIP Direct Client</span>
            </button>
          </form>
        </div>
      )}

      {/* SUB-VIEW 7: BUSINESS REPORTS */}
      {activeSubItem === 'business-reports' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-4 text-xs">
          <h3 className="text-base font-bold text-white">Commercial Audit & Fleet Reports</h3>
          <div className="space-y-2">
            {[
              { title: 'September 2026 Monthly Earnings Ledger (PDF)', size: '1.4 MB' },
              { title: 'Commercial FASTag & Toll Deduction Statement (CSV)', size: '340 KB' },
              { title: 'Vehicle Odometer & Fuel Mileage Efficiency Audit (PDF)', size: '820 KB' },
            ].map((r, i) => (
              <div key={i} className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                <div>
                  <div className="font-bold text-white">{r.title}</div>
                  <div className="text-slate-500 text-[11px]">{r.size}</div>
                </div>
                <button className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300">
                  <Download className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
