import React, { useState } from 'react';
import { 
  Receipt, 
  FileText, 
  Search, 
  Filter, 
  Download, 
  Share2, 
  Plus, 
  Clock, 
  DollarSign, 
  CheckCircle2, 
  ExternalLink, 
  Sparkles,
  QrCode,
  Calendar,
  Layers,
  ArrowDownToLine,
  Eye,
  Trash2
} from 'lucide-react';
import { DriverProfile, TripRecord, ExpenseRecord } from '../../types';
import { exportProfitLossPDF, exportCustomerReceiptPDF } from '../../utils/exportUtils';

interface DocumentBillEngineViewProps {
  driver: DriverProfile;
  trips: TripRecord[];
  expenses: ExpenseRecord[];
  onOpenScanReceipt: () => void;
  onOpenCustomerPayment: (trip?: TripRecord | null) => void;
  onOpenNewTrip?: () => void;
}

export const DocumentBillEngineView: React.FC<DocumentBillEngineViewProps> = ({
  driver,
  trips,
  expenses,
  onOpenScanReceipt,
  onOpenCustomerPayment,
  onOpenNewTrip,
}) => {
  const [activeTab, setActiveTab] = useState<'ALL' | 'RECEIPTS' | 'EXPENSE_BILLS' | 'TAX_INVOICES'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');

  // Filter bills & receipts
  const filteredTrips = trips.filter(t => {
    if (activeTab === 'EXPENSE_BILLS') return false;
    const matchesSearch = 
      t.pickupLocation.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.dropoffLocation.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (t.passengerName && t.passengerName.toLowerCase().includes(searchQuery.toLowerCase())) ||
      t.id.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesSearch;
  });

  const filteredExpenses = expenses.filter(e => {
    if (activeTab === 'RECEIPTS') return false;
    const matchesCategory = selectedCategory === 'ALL' || e.category === selectedCategory;
    const matchesSearch = 
      e.merchantName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      e.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (e.notes && e.notes.toLowerCase().includes(searchQuery.toLowerCase())) ||
      e.id.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const handleDownloadPLPDF = () => {
    exportProfitLossPDF(driver, trips, expenses, 'Daily Operations P&L Ledger');
  };

  const handleDownloadTripReceipt = (trip: TripRecord) => {
    exportCustomerReceiptPDF({
      receiptNumber: `REC-${trip.id.slice(-6).toUpperCase()}`,
      date: new Date(trip.timestamp).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }),
      driver: driver,
      customerName: trip.passengerName || 'Valued Passenger',
      customerPhone: '+91 98450 XXXXX',
      pickupLocation: trip.pickupLocation,
      dropoffLocation: trip.dropoffLocation,
      distanceKm: trip.distanceKm,
      durationMinutes: trip.durationMinutes,
      baseFare: 80,
      distanceFare: Math.max(0, trip.grossFare - 80 - trip.tollCost),
      tollCost: trip.tollCost,
      waitingOrSurgeFare: 0,
      discount: 0,
      totalPaid: trip.grossFare,
      paymentMode: trip.paymentMode || 'UPI',
      notes: `Booking Ref: ${trip.id}`
    });
  };

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-emerald-950/60 border border-slate-800 rounded-3xl p-5 shadow-2xl relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 uppercase">
                🧾 PILLAR 9 • DOCUMENT & BILL ENGINE
              </span>
              <span className="text-xs text-slate-400 font-mono">
                Zero Permanent Server Duplication • Ephemeral On-Demand PDFs
              </span>
            </div>
            <h1 className="text-xl font-black text-white flex items-center gap-2">
              <span>DIGITAL RECEIPTS & EXPENSE INVOICES</span>
              <Sparkles className="w-4 h-4 text-emerald-400" />
            </h1>
            <p className="text-xs text-slate-300 max-w-2xl">
              Instant generation of GST commercial customer invoices, OCR receipt scanner history, and tax-ready P&L audit reports. All PDFs are generated on-demand in the browser without server storage clutter.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={onOpenScanReceipt}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-100 text-xs font-bold transition flex items-center gap-2 border border-slate-700 cursor-pointer"
            >
              <Receipt className="w-3.5 h-3.5 text-amber-400" />
              <span>Scan Bill OCR</span>
            </button>

            <button
              onClick={() => onOpenCustomerPayment()}
              className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-slate-950 text-xs font-black transition flex items-center gap-2 shadow-lg shadow-emerald-600/20 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Generate Customer Bill</span>
            </button>

            <button
              onClick={handleDownloadPLPDF}
              className="px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition flex items-center gap-2 shadow-lg shadow-indigo-600/20 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export P&L PDF</span>
            </button>
          </div>
        </div>

        {/* 6 Capabilities Strip */}
        <div className="mt-4 pt-3 border-t border-slate-800/80 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 text-center text-[10px] font-bold">
          <div className="p-2 rounded-xl bg-slate-950/70 border border-slate-800 text-slate-300">
            1. 📄 Digital Receipts
          </div>
          <div className="p-2 rounded-xl bg-slate-950/70 border border-slate-800 text-emerald-400">
            2. ⚡ PDF on Demand
          </div>
          <div className="p-2 rounded-xl bg-slate-950/70 border border-slate-800 text-indigo-400">
            3. ☁️ Cloud Bill History
          </div>
          <div className="p-2 rounded-xl bg-slate-950/70 border border-slate-800 text-teal-400">
            4. 🔍 Invoice Search
          </div>
          <div className="p-2 rounded-xl bg-slate-950/70 border border-slate-800 text-amber-400">
            5. 💳 Expense Records
          </div>
          <div className="p-2 rounded-xl bg-slate-950/70 border border-slate-800 text-emerald-300">
            6. 🛡️ 0% PDF Duplication
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-lg">
        {/* Tabs */}
        <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs font-bold w-full sm:w-auto">
          {(['ALL', 'RECEIPTS', 'EXPENSE_BILLS', 'TAX_INVOICES'] as const).map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`flex-1 sm:flex-none px-3 py-1.5 rounded-lg transition cursor-pointer ${
                activeTab === tab ? 'bg-emerald-600 text-white shadow' : 'text-slate-400 hover:text-white'
              }`}
            >
              {tab.replace('_', ' ')}
            </button>
          ))}
        </div>

        {/* Search */}
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by passenger, station, merchant..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
          />
        </div>
      </div>

      {/* Main Content Grid: Customer Receipts & Expense Invoices */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        
        {/* Left Col: Customer Trip Invoices & Digital Receipts */}
        {(activeTab === 'ALL' || activeTab === 'RECEIPTS' || activeTab === 'TAX_INVOICES') && (
          <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
                  <FileText className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">Passenger Trip Receipts ({filteredTrips.length})</h3>
                  <p className="text-[11px] text-slate-400">GST-compliant digital invoices for passengers</p>
                </div>
              </div>

              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                1-Click PDF
              </span>
            </div>

            <div className="space-y-3 max-h-[500px] overflow-y-auto pr-1">
              {filteredTrips.length === 0 ? (
                <div className="p-8 text-center text-xs text-slate-500 bg-slate-950/50 rounded-2xl border border-slate-800/60">
                  No passenger trip receipts matching query.
                </div>
              ) : (
                filteredTrips.map(trip => (
                  <div 
                    key={trip.id}
                    className="p-4 rounded-2xl bg-slate-950 border border-slate-800 hover:border-emerald-500/50 transition flex flex-col justify-between space-y-2.5 group"
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="text-xs font-bold text-white group-hover:text-emerald-300 transition-colors">
                          {trip.passengerName || 'Direct Passenger'}
                        </span>
                        <div className="text-[10px] text-slate-400 font-mono">
                          ID: {trip.id} • {new Date(trip.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </div>
                      </div>

                      <div className="text-right">
                        <div className="text-sm font-black text-emerald-400 font-mono">
                          ₹{trip.grossFare}
                        </div>
                        <span className="text-[9px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 font-bold">
                          {trip.paymentMode || 'UPI'}
                        </span>
                      </div>
                    </div>

                    <div className="text-xs text-slate-300 space-y-0.5">
                      <div className="truncate">🟢 {trip.pickupLocation}</div>
                      <div className="truncate">🔴 {trip.dropoffLocation}</div>
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 text-[11px]">
                      <span className="text-slate-400 font-mono">
                        {trip.distanceKm} km • {trip.durationMinutes} mins • Toll: ₹{trip.tollCost}
                      </span>

                      <button
                        onClick={() => handleDownloadTripReceipt(trip)}
                        className="px-2.5 py-1 rounded-lg bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 font-bold transition flex items-center gap-1 cursor-pointer"
                        title="Download ephemeral customer PDF"
                      >
                        <Download className="w-3 h-3" />
                        <span>PDF</span>
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* Right Col: Expense Records & OCR Scanned Fuel/Toll Bills */}
        {(activeTab === 'ALL' || activeTab === 'EXPENSE_BILLS' || activeTab === 'TAX_INVOICES') && (
          <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30">
                  <Receipt className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">Expense Records & OCR Invoices ({filteredExpenses.length})</h3>
                  <p className="text-[11px] text-slate-400">CNG, FASTag toll, repairs & chai logs</p>
                </div>
              </div>

              <button
                onClick={onOpenScanReceipt}
                className="text-[10px] font-bold px-2.5 py-1 rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1 hover:bg-amber-500/30 cursor-pointer"
              >
                <Plus className="w-3 h-3" />
                <span>Add Bill</span>
              </button>
            </div>

            <div className="space-y-3 max-h-[500px] overflow-y-auto pr-1">
              {filteredExpenses.length === 0 ? (
                <div className="p-8 text-center text-xs text-slate-500 bg-slate-950/50 rounded-2xl border border-slate-800/60">
                  No expense bills matching search criteria.
                </div>
              ) : (
                filteredExpenses.map(expense => (
                  <div 
                    key={expense.id}
                    className="p-4 rounded-2xl bg-slate-950 border border-slate-800 hover:border-amber-500/50 transition flex flex-col justify-between space-y-2.5 group"
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="text-xs font-bold text-white group-hover:text-amber-300 transition-colors">
                          {expense.merchantName}
                        </span>
                        <div className="text-[10px] text-slate-400 font-mono">
                          {new Date(expense.date).toLocaleDateString('en-IN')} • Category: {expense.category}
                        </div>
                      </div>

                      <div className="text-right">
                        <div className="text-sm font-black text-rose-400 font-mono">
                          - ₹{expense.amount}
                        </div>
                        <span className="text-[9px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 font-bold">
                          {expense.paymentMethod}
                        </span>
                      </div>
                    </div>

                    <div className="text-xs text-slate-300 italic">
                      "{expense.notes || 'Routine business running expense'}"
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 text-[11px]">
                      <span className="text-emerald-400 font-medium">
                        {expense.isTaxDeductible ? '✓ 44AD Tax Deductible' : 'Non-deductible'}
                      </span>

                      <span className="text-[10px] font-mono text-slate-500">
                        Encrypted Hash: {expense.id.slice(-8)}
                      </span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

      </div>

    </div>
  );
};
