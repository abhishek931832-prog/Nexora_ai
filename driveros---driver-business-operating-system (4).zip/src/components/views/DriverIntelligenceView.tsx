import React, { useState } from 'react';
import { 
  Brain, 
  TrendingUp, 
  Zap, 
  MapPin, 
  AlertCircle, 
  Gauge, 
  Clock, 
  Calendar, 
  Compass, 
  DollarSign, 
  ArrowUpRight, 
  ChevronRight, 
  Target, 
  Sparkles,
  Info,
  CheckCircle2,
  RefreshCw
} from 'lucide-react';
import { DriverProfile, TripRecord } from '../../types';

interface DriverIntelligenceViewProps {
  driver: DriverProfile;
  trips: TripRecord[];
  activeSubItem?: string;
  onSelectSubItem?: (sub: string) => void;
  onNavigateMap?: () => void;
}

export const DriverIntelligenceView: React.FC<DriverIntelligenceViewProps> = ({
  driver,
  trips,
  activeSubItem = 'earnings-prediction',
  onSelectSubItem,
  onNavigateMap,
}) => {
  const [selectedTimeframe, setSelectedTimeframe] = useState<'2H' | '4H' | 'TODAY' | 'WEEK'>('4H');
  const [activeZoneFilter, setActiveZoneFilter] = useState<'ALL' | 'AIRPORT' | 'TECH' | 'NIGHT'>('ALL');
  const [isRefreshing, setIsRefreshing] = useState(false);

  const handleRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => setIsRefreshing(false), 800);
  };

  // Hourly Earning Prediction Curve Data
  const hourlyCurve = [
    { hour: '06:00', estHourly: 320, demand: 'Medium', label: 'Airport Shift Start' },
    { hour: '08:00', estHourly: 540, demand: 'High Surge 1.8x', label: 'Tech Park Commute' },
    { hour: '10:00', estHourly: 420, demand: 'High', label: 'Meeting Rush' },
    { hour: '12:00', estHourly: 280, demand: 'Low', label: 'Midday Slump' },
    { hour: '14:00', estHourly: 310, demand: 'Medium', label: 'Intercity Dispatches' },
    { hour: '16:00', estHourly: 480, demand: 'High Surge 1.6x', label: 'School & Hospital' },
    { hour: '18:00', estHourly: 620, demand: 'Peak Surge 2.2x', label: 'Evening Peak Outbound' },
    { hour: '20:00', estHourly: 590, demand: 'High Surge 1.9x', label: 'Dinner & Social' },
    { hour: '22:00', estHourly: 450, demand: 'Medium', label: 'Airport Red-Eye Waves' },
  ];

  // Best-Zone Recommendations
  const recommendedZones = [
    {
      id: 'airport',
      name: 'Kempegowda Airport T2 Corridor',
      corridor: 'Hebbal ➔ NH44 Elevated ➔ KIA T2',
      surge: '2.3x',
      predictedHourly: 680,
      confidenceScore: '96%',
      deadheadRisk: 'Very Low (Return Bookings 91%)',
      reason: '22 Flight arrivals between 18:30–21:00. Average ticket ₹950–₹1,400.',
      status: 'TOP PICK',
      type: 'AIRPORT',
    },
    {
      id: 'bellandur',
      name: 'Outer Ring Road (Bellandur to Mahadevapura)',
      corridor: 'Ecospace ➔ Marathahalli ➔ Bagmane Tech',
      surge: '1.9x',
      predictedHourly: 540,
      confidenceScore: '92%',
      deadheadRisk: 'Low (Heavy Tech Commuter Flow)',
      reason: 'Tech corporate outbound traffic peaking. High short-trip surge.',
      status: 'SURGE ACTIVE',
      type: 'TECH',
    },
    {
      id: 'indiranagar',
      name: 'Indiranagar 100ft Road & Koramangala 80ft',
      corridor: 'Domlur ➔ Sony World ➔ Koramangala 4th Block',
      surge: '1.7x',
      predictedHourly: 490,
      confidenceScore: '89%',
      deadheadRisk: 'Medium (Dense short hops)',
      reason: 'High dining and entertainment traffic. High tip propensity.',
      status: 'HIGH DENSITY',
      type: 'NIGHT',
    },
  ];

  // Dead-Mile Detection & Recovery
  const deadheadMetrics = {
    totalKmToday: 142,
    paidKmToday: 118,
    deadheadKm: 24,
    deadheadPercent: 16.9, // optimal is < 20%
    wastedFuelCost: 144, // ₹6/km CNG
    recoveryAction: 'AI Backhaul matching enabled: Return trips automatically queued 15 mins before drop-off.',
  };

  // Profit-Per-KM Analysis
  const profitPerKmData = {
    grossRatePerKm: 20.0,
    fuelCostPerKm: 4.8,
    tollWearPerKm: 1.2,
    platformFeePerKm: 0.0, // direct / optimal
    netProfitPerKm: 14.0,
    hourlyRunRate: 495,
  };

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950/60 to-slate-900 border border-slate-800 rounded-3xl p-5 shadow-2xl relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 uppercase">
                🧠 PILLAR 2 • REVENUE AI
              </span>
              <span className="text-xs text-slate-400 font-mono">
                Predictive Optimization Engine
              </span>
            </div>
            <h1 className="text-xl font-black text-white flex items-center gap-2">
              <span>DRIVER INTELLIGENCE ENGINE</span>
              <Sparkles className="w-4 h-4 text-indigo-400" />
            </h1>
            <p className="text-xs text-slate-300 max-w-2xl">
              Real-time algorithms predicting earnings velocity, demand spikes, high-margin corridors, dead-mile elimination, and profit-per-kilometer optimization.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleRefresh}
              className={`p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                isRefreshing ? 'animate-spin' : ''
              }`}
              title="Refresh intelligence models"
            >
              <RefreshCw className="w-4 h-4" />
            </button>

            <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs font-bold">
              {(['2H', '4H', 'TODAY', 'WEEK'] as const).map(tf => (
                <button
                  key={tf}
                  onClick={() => setSelectedTimeframe(tf)}
                  className={`px-3 py-1 rounded-lg transition cursor-pointer ${
                    selectedTimeframe === tf
                      ? 'bg-indigo-600 text-white shadow-md'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {tf}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* 6 Engine Pillars Mini Bar */}
        <div className="mt-4 pt-3 border-t border-slate-800/80 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 text-xs">
          <div className="p-2 rounded-xl bg-slate-950/70 border border-slate-800/80">
            <div className="text-[10px] text-slate-400 font-medium">1. Earnings Prediction</div>
            <div className="text-sm font-black text-emerald-400 font-mono">₹1,850–₹2,300</div>
            <div className="text-[9px] text-slate-500">Next 4 hours</div>
          </div>

          <div className="p-2 rounded-xl bg-slate-950/70 border border-slate-800/80">
            <div className="text-[10px] text-slate-400 font-medium">2. Demand Forecast</div>
            <div className="text-sm font-black text-rose-400 font-mono">2.3x Surge Wave</div>
            <div className="text-[9px] text-slate-500">Flight + Tech Outbound</div>
          </div>

          <div className="p-2 rounded-xl bg-slate-950/70 border border-slate-800/80">
            <div className="text-[10px] text-slate-400 font-medium">3. Best-Zone Pick</div>
            <div className="text-sm font-black text-indigo-400">Airport T2 Corridor</div>
            <div className="text-[9px] text-slate-500">96% confidence score</div>
          </div>

          <div className="p-2 rounded-xl bg-slate-950/70 border border-slate-800/80">
            <div className="text-[10px] text-slate-400 font-medium">4. Dead-Mile Ratio</div>
            <div className="text-sm font-black text-teal-400 font-mono">16.9% (Low)</div>
            <div className="text-[9px] text-slate-500">Target: &lt;20%</div>
          </div>

          <div className="p-2 rounded-xl bg-slate-950/70 border border-slate-800/80">
            <div className="text-[10px] text-slate-400 font-medium">5. Profit Per KM</div>
            <div className="text-sm font-black text-emerald-300 font-mono">₹14.0 net/km</div>
            <div className="text-[9px] text-slate-500">Gross: ₹20.0 • Fuel: ₹4.8</div>
          </div>

          <div className="p-2 rounded-xl bg-slate-950/70 border border-slate-800/80">
            <div className="text-[10px] text-slate-400 font-medium">6. Hourly Run Rate</div>
            <div className="text-sm font-black text-amber-400 font-mono">₹495 / hour</div>
            <div className="text-[9px] text-slate-500">Peak expected: ₹620/h</div>
          </div>
        </div>
      </div>

      {/* Grid: Hourly Prediction Curve & Dead-Mile Detection */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        
        {/* Left 7 Cols: Hourly Earning Prediction Curve */}
        <div className="lg:col-span-7 bg-slate-900/90 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center border border-indigo-500/30">
                <Clock className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">Hourly Earnings Forecast & Surge Clock</h3>
                <p className="text-[11px] text-slate-400">Predicted earning velocity per hour across the active shift</p>
              </div>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              Peak: 18:00–21:00
            </span>
          </div>

          {/* Interactive Chart Bars */}
          <div className="space-y-2 pt-2">
            {hourlyCurve.map((h, idx) => {
              const maxVal = 650;
              const percent = Math.round((h.estHourly / maxVal) * 100);
              const isPeak = h.estHourly >= 540;

              return (
                <div key={idx} className="group p-2 rounded-xl hover:bg-slate-800/50 transition border border-transparent hover:border-slate-700/50">
                  <div className="flex items-center justify-between text-xs mb-1">
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-slate-300 w-12">{h.hour}</span>
                      <span className="text-slate-400 font-medium">{h.label}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className={`text-[10px] px-1.5 py-0.5 rounded font-bold ${
                        isPeak ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30' : 'bg-slate-800 text-slate-400'
                      }`}>
                        {h.demand}
                      </span>
                      <span className="font-mono font-black text-white">₹{h.estHourly}/h</span>
                    </div>
                  </div>

                  <div className="w-full h-2.5 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                    <div 
                      className={`h-full rounded-full transition-all duration-500 ${
                        isPeak 
                          ? 'bg-gradient-to-r from-indigo-500 to-rose-500' 
                          : 'bg-gradient-to-r from-emerald-500 to-teal-400'
                      }`}
                      style={{ width: `${percent}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>

          <div className="p-3 rounded-2xl bg-indigo-950/40 border border-indigo-500/30 flex items-start gap-2.5 text-xs text-slate-300">
            <Sparkles className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
            <div>
              <strong className="text-indigo-300">AI Shift Advice:</strong> Stay active between 18:00 and 21:00 on the Hebbal-Airport or ORR tech belt to unlock maximum hourly velocity of ₹620/h. Take a 25-minute break at 15:30.
            </div>
          </div>
        </div>

        {/* Right 5 Cols: Dead-Mile Detection & Profit-Per-KM */}
        <div className="lg:col-span-5 space-y-5">
          
          {/* Dead-Mile Detection Card */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-teal-500/20 text-teal-400 flex items-center justify-center border border-teal-500/30">
                  <Gauge className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">Dead-Mile Detection</h3>
                  <p className="text-[11px] text-slate-400">Empty return vs earning distance</p>
                </div>
              </div>
              <span className="text-xs font-mono font-bold text-teal-400">
                16.9% Ratio
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-center text-xs">
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                <div className="text-[10px] text-slate-400">Paid Earning KM</div>
                <div className="text-lg font-black text-emerald-400 font-mono">118 km</div>
                <div className="text-[10px] text-slate-500">83.1% of shift</div>
              </div>
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
                <div className="text-[10px] text-slate-400">Deadhead KM</div>
                <div className="text-lg font-black text-amber-400 font-mono">24 km</div>
                <div className="text-[10px] text-slate-500">₹144 fuel cost</div>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-slate-950 border border-teal-500/30 space-y-1.5">
              <div className="text-xs font-bold text-teal-300 flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Smart Backhaul Protection Active</span>
              </div>
              <p className="text-[11px] text-slate-300 leading-relaxed">
                When you drop off at Kempegowda Airport or Electronic City, Saathi queues return city trips 10 minutes before destination arrival to eliminate empty return dead miles.
              </p>
            </div>
          </div>

          {/* Profit-Per-KM Breakdown Card */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
                  <DollarSign className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">Profit-Per-KM Ledger</h3>
                  <p className="text-[11px] text-slate-400">Net in-pocket margin per kilometer</p>
                </div>
              </div>
              <span className="text-sm font-black text-emerald-400 font-mono">
                ₹14.0/km
              </span>
            </div>

            <div className="space-y-2 text-xs">
              <div className="flex justify-between items-center py-1 border-b border-slate-800">
                <span className="text-slate-400">Average Gross Fare:</span>
                <span className="font-mono text-white font-bold">₹20.00 / km</span>
              </div>
              <div className="flex justify-between items-center py-1 border-b border-slate-800">
                <span className="text-slate-400">CNG Fuel Expense:</span>
                <span className="font-mono text-rose-400 font-bold">- ₹4.80 / km</span>
              </div>
              <div className="flex justify-between items-center py-1 border-b border-slate-800">
                <span className="text-slate-400">Tyre & Maintenance Wear:</span>
                <span className="font-mono text-amber-400 font-bold">- ₹1.20 / km</span>
              </div>
              <div className="flex justify-between items-center py-1.5 bg-emerald-500/10 px-2.5 rounded-lg border border-emerald-500/20">
                <span className="font-bold text-emerald-300">True Net Take-Home:</span>
                <span className="font-mono font-black text-emerald-400 text-sm">₹14.00 / km</span>
              </div>
            </div>
          </div>

        </div>
      </div>

      {/* Best-Zone Recommendations List */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <MapPin className="w-4 h-4 text-indigo-400" />
              <span>Best-Zone High-Margin Recommendations</span>
            </h2>
            <p className="text-xs text-slate-400">AI-ranked geographical corridors based on surge, arrival waves, and backhaul probability</p>
          </div>

          <div className="flex items-center gap-1.5 bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs font-bold">
            {(['ALL', 'AIRPORT', 'TECH', 'NIGHT'] as const).map(f => (
              <button
                key={f}
                onClick={() => setActiveZoneFilter(f)}
                className={`px-3 py-1 rounded-lg transition cursor-pointer ${
                  activeZoneFilter === f ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white'
                }`}
              >
                {f}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {recommendedZones
            .filter(z => activeZoneFilter === 'ALL' || z.type === activeZoneFilter)
            .map(zone => (
              <div 
                key={zone.id}
                className="p-4 rounded-2xl bg-slate-950 border border-slate-800 hover:border-indigo-500/50 transition-all flex flex-col justify-between space-y-3 relative group"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                      {zone.status}
                    </span>
                    <span className="text-xs font-black text-rose-400 font-mono">
                      {zone.surge} Surge
                    </span>
                  </div>

                  <h4 className="text-sm font-bold text-white group-hover:text-indigo-300 transition-colors">
                    {zone.name}
                  </h4>
                  <div className="text-[11px] font-mono text-slate-400 mb-2">
                    📍 {zone.corridor}
                  </div>
                  <p className="text-xs text-slate-300 leading-relaxed mb-3">
                    {zone.reason}
                  </p>
                </div>

                <div className="space-y-2 pt-2 border-t border-slate-800/80">
                  <div className="flex items-center justify-between text-xs font-mono">
                    <span className="text-slate-400">Est. Hourly:</span>
                    <span className="text-emerald-400 font-bold">₹{zone.predictedHourly} / hr</span>
                  </div>
                  <div className="flex items-center justify-between text-xs font-mono">
                    <span className="text-slate-400">Confidence:</span>
                    <span className="text-slate-200">{zone.confidenceScore}</span>
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-slate-400">
                    <span>Backhaul Risk:</span>
                    <span className="text-teal-400">{zone.deadheadRisk}</span>
                  </div>

                  <button
                    onClick={onNavigateMap}
                    className="w-full mt-2 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer shadow-md shadow-indigo-950"
                  >
                    <span>Navigate to Zone</span>
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
        </div>
      </div>

    </div>
  );
};
