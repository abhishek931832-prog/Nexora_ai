import React, { useState } from 'react';
import { 
  AlertCircle, 
  CreditCard, 
  Car, 
  Headphones, 
  Phone, 
  MessageSquare, 
  CheckCircle2, 
  Clock, 
  FileText, 
  Send, 
  HelpCircle, 
  ShieldAlert, 
  ChevronRight, 
  ExternalLink,
  LifeBuoy
} from 'lucide-react';
import { DriverProfile } from '../../types';

interface DriverProblemCenterProps {
  driver: DriverProfile;
  initialCategory?: 'PAYMENT' | 'RIDE' | 'SUPPORT';
}

export const DriverProblemCenter: React.FC<DriverProblemCenterProps> = ({
  driver,
  initialCategory = 'PAYMENT',
}) => {
  const [activeCategory, setActiveCategory] = useState<'PAYMENT' | 'RIDE' | 'SUPPORT'>(initialCategory);
  const [selectedIssue, setSelectedIssue] = useState<string>('Wrong fare calculation');
  const [issueDescription, setIssueDescription] = useState<string>('');
  const [ticketSubmitted, setTicketSubmitted] = useState<boolean>(false);
  const [generatedTicketId, setGeneratedTicketId] = useState<string>('');

  const SUPPORT_NUMBER = '9318320977';

  const ISSUES_CONFIG = {
    PAYMENT: [
      { id: 'wrong-fare', title: 'Wrong fare calculation', desc: 'Distance or time recorded lower than actual GPS track. Dispute missing amount.' },
      { id: 'missing-payment', title: 'Missing payment from rider', desc: 'Rider showed fake UPI screenshot or promised to pay later. Recover full fare.' },
      { id: 'fee-dispute', title: 'Platform fee dispute', desc: 'Aggregator deducted more than agreed commission rate (>28%). Request refund.' },
      { id: 'payout-delay', title: 'Payout delay / Bank hold', desc: 'Daily bank transfer delayed or held in pending state. Expedite IMPS release.' },
    ],
    RIDE: [
      { id: 'cancellation', title: 'Rider cancellation after reaching', desc: 'Passenger cancelled after driver arrived within pickup zone. Claim ₹50-₹100 cancellation fee.' },
      { id: 'wrong-pickup', title: 'Wrong pickup location pin', desc: 'Passenger pinned wrong location >1.5 km away. Void any driver cancellation strike.' },
      { id: 'extra-charge', title: 'Extra luggage / Passenger charge', desc: 'Commercial luggage, oversized freight, or extra passengers without additional fare.' },
      { id: 'route-issue', title: 'Route issue / Toll deviation', desc: 'Police diversion or road closure required detour. Surcharge fare adjustment.' },
    ],
    SUPPORT: [
      { id: 'driver-complaint', title: 'Driver formal complaint', desc: 'Lodge formal grievance against unfair aggregator platform policy or dispatch bias.' },
      { id: 'customer-issue', title: 'Customer verbal abuse / Misconduct', desc: 'Unruly or abusive passenger report with blacklisting and legal protection.' },
      { id: 'app-problem', title: 'App glitch / GPS freeze', desc: 'Application crashed during active ride or failed to submit trip end confirmation.' },
      { id: 'account-issue', title: 'Account issue / Rating strike', desc: 'Unfair retaliatory 1-star rating appeal or false passenger complaint scrub.' },
    ],
  };

  const handleRaiseTicket = (e: React.FormEvent) => {
    e.preventDefault();
    const tid = `DS-9318-${Math.floor(100000 + Math.random() * 900000)}`;
    setGeneratedTicketId(tid);
    setTicketSubmitted(true);
  };

  const whatsappMessage = encodeURIComponent(
    `Hello DriveSmart Priority Desk, I am ${driver.name} (Vehicle: ${driver.vehiclePlate}, Phone: ${driver.phone}). I need urgent assistance with: ${selectedIssue}. Ticket ID: ${generatedTicketId || 'PENDING'}.`
  );

  return (
    <div className="space-y-6 pb-12">
      {/* 24x7 DRIVE SMART DEDICATED SUPPORT HERO BANNER */}
      <div className="bg-gradient-to-r from-red-950/60 via-slate-900 to-amber-950/40 border-2 border-red-500/50 rounded-2xl p-5 sm:p-6 shadow-2xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-5 relative z-10">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="p-2 rounded-xl bg-red-500/20 text-red-400">
                <LifeBuoy className="w-6 h-6 animate-spin" />
              </span>
              <span className="text-xs font-mono font-bold uppercase tracking-widest text-red-400 bg-red-500/20 px-3 py-1 rounded-full border border-red-500/30">
                24x7 Priority Driver Desk
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              DRIVE SMART SUPPORT: <span className="text-emerald-400 font-mono tracking-wider">{SUPPORT_NUMBER}</span>
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
              Facing wrong fare deductions, delayed bank payouts, or passenger disputes? Connect directly with our dedicated driver dispute resolution cell.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
            <a
              href={`tel:${SUPPORT_NUMBER}`}
              className="flex-1 md:flex-initial py-3 px-5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-950 transition-transform active:scale-95"
            >
              <Phone className="w-4 h-4" />
              <span>CALL {SUPPORT_NUMBER}</span>
            </a>

            <a
              href={`https://wa.me/91${SUPPORT_NUMBER}?text=${whatsappMessage}`}
              target="_blank"
              rel="noreferrer"
              className="flex-1 md:flex-initial py-3 px-5 rounded-xl bg-slate-800 hover:bg-slate-700 text-emerald-400 hover:text-emerald-300 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 border border-emerald-500/30 transition-colors"
            >
              <MessageSquare className="w-4 h-4" />
              <span>WhatsApp Desk</span>
            </a>
          </div>
        </div>
      </div>

      {/* 3 CORE PILLARS OF PROBLEM RESOLUTION */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* PAYMENT PILLAR */}
        <button
          onClick={() => {
            setActiveCategory('PAYMENT');
            setSelectedIssue('Wrong fare calculation');
          }}
          className={`p-5 rounded-2xl border text-left transition-all ${
            activeCategory === 'PAYMENT'
              ? 'bg-slate-900 border-emerald-500 shadow-xl shadow-emerald-950/40 ring-2 ring-emerald-500/20'
              : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="flex items-center justify-between mb-3">
            <span className="p-2.5 rounded-xl bg-emerald-500/20 text-emerald-400">
              <CreditCard className="w-6 h-6" />
            </span>
            <span className="text-[11px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full">
              4 Solutions
            </span>
          </div>
          <h3 className="text-base font-bold text-white">💳 PAYMENT ISSUES</h3>
          <p className="text-xs text-slate-400 mt-1">Wrong fare, missing payments, fee disputes, and payout delays.</p>
        </button>

        {/* RIDE PILLAR */}
        <button
          onClick={() => {
            setActiveCategory('RIDE');
            setSelectedIssue('Rider cancellation after reaching');
          }}
          className={`p-5 rounded-2xl border text-left transition-all ${
            activeCategory === 'RIDE'
              ? 'bg-slate-900 border-amber-500 shadow-xl shadow-amber-950/40 ring-2 ring-amber-500/20'
              : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="flex items-center justify-between mb-3">
            <span className="p-2.5 rounded-xl bg-amber-500/20 text-amber-400">
              <Car className="w-6 h-6" />
            </span>
            <span className="text-[11px] font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-full">
              4 Solutions
            </span>
          </div>
          <h3 className="text-base font-bold text-white">🚕 RIDE ISSUES</h3>
          <p className="text-xs text-slate-400 mt-1">Cancellations, wrong pickup pins, extra luggage, and route detours.</p>
        </button>

        {/* SUPPORT PILLAR */}
        <button
          onClick={() => {
            setActiveCategory('SUPPORT');
            setSelectedIssue('Driver formal complaint');
          }}
          className={`p-5 rounded-2xl border text-left transition-all ${
            activeCategory === 'SUPPORT'
              ? 'bg-slate-900 border-purple-500 shadow-xl shadow-purple-950/40 ring-2 ring-purple-500/20'
              : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="flex items-center justify-between mb-3">
            <span className="p-2.5 rounded-xl bg-purple-500/20 text-purple-400">
              <Headphones className="w-6 h-6" />
            </span>
            <span className="text-[11px] font-bold text-purple-400 bg-purple-500/10 px-2 py-0.5 rounded-full">
              4 Solutions
            </span>
          </div>
          <h3 className="text-base font-bold text-white">👨💼 DRIVER SUPPORT</h3>
          <p className="text-xs text-slate-400 mt-1">Grievance filing, customer abuse, app crashes, and rating scrub.</p>
        </button>
      </div>

      {/* DETAILED WORKFLOW & DISPUTE GENERATOR */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Columns: Issue Selector & Claim Form */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-5">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-base font-bold text-white">
              Select Specific {activeCategory} Problem
            </h3>
            <span className="text-xs text-slate-400 font-mono">
              Vehicle: {driver.vehiclePlate}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {ISSUES_CONFIG[activeCategory].map((item) => (
              <div
                key={item.id}
                onClick={() => setSelectedIssue(item.title)}
                className={`p-4 rounded-xl border cursor-pointer transition-all ${
                  selectedIssue === item.title
                    ? 'bg-slate-950 border-emerald-500 ring-1 ring-emerald-500/30'
                    : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="font-bold text-white text-xs flex items-center justify-between">
                  <span>{item.title}</span>
                  {selectedIssue === item.title && (
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  )}
                </div>
                <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>

          {/* Ticket Submission Form */}
          <form onSubmit={handleRaiseTicket} className="space-y-4 pt-3 border-t border-slate-800">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300 block">
                Additional Details / Trip ID / Screenshot Notes
              </label>
              <textarea
                value={issueDescription}
                onChange={(e) => setIssueDescription(e.target.value)}
                placeholder="Explain the incident (e.g. Passenger booked trip to Airport but fare calculated only till Hebbal, difference amount ₹220)..."
                rows={3}
                required
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div className="flex items-center justify-between flex-wrap gap-3">
              <div className="text-[11px] text-slate-400">
                Guaranteed response within <strong>15 minutes</strong> by DriveSmart Support Cell.
              </div>

              <button
                type="submit"
                className="py-2.5 px-6 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs flex items-center gap-2 shadow-lg shadow-emerald-950 transition-all"
              >
                <Send className="w-3.5 h-3.5" />
                <span>SUBMIT DISPUTE TICKET</span>
              </button>
            </div>
          </form>

          {ticketSubmitted && (
            <div className="p-4 bg-emerald-950/40 border border-emerald-500 rounded-xl text-xs text-emerald-300 space-y-2">
              <div className="flex items-center gap-2 font-bold text-sm text-emerald-400">
                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                <span>Ticket Generated: #{generatedTicketId}</span>
              </div>
              <p className="leading-relaxed">
                Your dispute for <strong>"{selectedIssue}"</strong> has been logged into our escalation queue. Priority agent assigned. You will receive an SMS and WhatsApp callback at <strong>{driver.phone}</strong> shortly.
              </p>
              <div className="flex items-center gap-3 pt-2">
                <a
                  href={`tel:${SUPPORT_NUMBER}`}
                  className="px-3 py-1.5 bg-emerald-500 text-slate-950 font-bold rounded-lg text-[11px] flex items-center gap-1"
                >
                  <Phone className="w-3 h-3" /> Call Priority Officer
                </a>
              </div>
            </div>
          )}
        </div>

        {/* Right Column: Support Status & Direct Contacts */}
        <div className="space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-3">
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-emerald-400" /> Driver Protection Charter
            </h4>
            <p className="text-xs text-slate-300 leading-relaxed">
              DriveSmart OS acts as the independent legal advocate for cab drivers across India. We ensure zero unauthorized deductions and protect your yellow board license.
            </p>
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs space-y-2">
              <div className="flex justify-between text-slate-400">
                <span>Direct Support Line:</span>
                <span className="text-emerald-400 font-bold font-mono">9318320977</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Working Hours:</span>
                <span className="text-white font-medium">24 Hours / 7 Days</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Average Resolution:</span>
                <span className="text-emerald-400 font-medium">&lt; 35 mins</span>
              </div>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-3 text-xs">
            <h4 className="font-bold text-white">Recent Dispute History</h4>
            <div className="space-y-2">
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-1">
                <div className="flex justify-between font-semibold text-slate-200">
                  <span>Ola Airport Toll Deduction</span>
                  <span className="text-emerald-400 font-bold">Resolved (₹115 Refunded)</span>
                </div>
                <div className="text-[10px] text-slate-500">Ticket #DS-841920 • 2 days ago</div>
              </div>

              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-1">
                <div className="flex justify-between font-semibold text-slate-200">
                  <span>Passenger Cancellation Claim</span>
                  <span className="text-emerald-400 font-bold">Approved (₹75 Credited)</span>
                </div>
                <div className="text-[10px] text-slate-500">Ticket #DS-819201 • 5 days ago</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
