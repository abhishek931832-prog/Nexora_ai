import React, { useState } from 'react';
import { 
  Gift, 
  Award, 
  Target, 
  Zap, 
  Trophy, 
  CheckCircle2, 
  Sparkles, 
  Flame, 
  Clock, 
  ChevronRight 
} from 'lucide-react';
import { DriverProfile } from '../../types';

interface IncentivesViewProps {
  driver: DriverProfile;
  activeSubItem: string;
  onSelectSubItem: (sub: string) => void;
}

export const IncentivesView: React.FC<IncentivesViewProps> = ({
  driver,
  activeSubItem,
  onSelectSubItem,
}) => {
  return (
    <div className="space-y-6 pb-12">
      {/* Header & Sub-items */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 sm:p-4 shadow-lg">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-pink-500/20 text-pink-400">
              <Gift className="w-5 h-5" />
            </span>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                Driver Incentives & Rewards Club
              </h2>
              <p className="text-xs text-slate-400">Unlock cash bonuses, zero-cancellation streaks, peak-hour multipliers, and garage discounts.</p>
            </div>
          </div>
        </div>

        {/* Sub-item Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pt-3 border-t border-slate-800/80 mt-3 scrollbar-none">
          {[
            { id: 'daily-target', label: 'Daily Target' },
            { id: 'weekly-goals', label: 'Weekly Goals' },
            { id: 'bonuses', label: 'Bonuses' },
            { id: 'challenges', label: 'Challenges' },
            { id: 'rewards', label: 'Rewards' },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => onSelectSubItem(tab.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-1.5 ${
                activeSubItem === tab.id
                  ? 'bg-pink-500 text-slate-950 font-bold shadow'
                  : 'bg-slate-800/60 text-slate-300 hover:bg-slate-800 hover:text-white border border-slate-700/50'
              }`}
            >
              <span>{tab.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* SUB-VIEW 1: DAILY TARGET INCENTIVES */}
      {activeSubItem === 'daily-target' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-4 text-xs">
          <h3 className="text-base font-bold text-white">Daily Ride Milestone Tiers</h3>

          <div className="space-y-3">
            <div className="p-4 rounded-xl bg-slate-950 border border-emerald-500/40 flex items-center justify-between">
              <div>
                <div className="font-bold text-white text-sm flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" /> Tier 1: Complete 6 Rides
                </div>
                <div className="text-emerald-400 text-[11px] mt-0.5">COMPLETED! ₹150 Bonus Credited</div>
              </div>
              <span className="text-base font-black text-emerald-400 font-mono">+₹150</span>
            </div>

            <div className="p-4 rounded-xl bg-slate-950 border border-amber-500/40 flex items-center justify-between">
              <div>
                <div className="font-bold text-white text-sm flex items-center gap-2">
                  <Clock className="w-4 h-4 text-amber-400" /> Tier 2: Complete 10 Rides (8/10 done)
                </div>
                <div className="text-amber-400 text-[11px] mt-0.5">Just 2 more rides to unlock!</div>
              </div>
              <span className="text-base font-black text-amber-400 font-mono">+₹350</span>
            </div>

            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between opacity-70">
              <div>
                <div className="font-bold text-white text-sm">Tier 3: Complete 14 Rides (Power Driver)</div>
                <div className="text-slate-400 text-[11px] mt-0.5">Unlock top tier daily payout</div>
              </div>
              <span className="text-base font-black text-slate-300 font-mono">+₹600</span>
            </div>
          </div>
        </div>
      )}

      {/* SUB-VIEW 2: WEEKLY GOALS */}
      {activeSubItem === 'weekly-goals' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-4 text-xs">
          <h3 className="text-base font-bold text-white">Weekly Commercial Challenge: ₹22,000 Net</h3>

          <div className="p-5 bg-slate-950 border border-slate-800 rounded-2xl space-y-3">
            <div className="flex justify-between text-xs">
              <span className="text-slate-300">Progress: 44 / 65 Rides Completed</span>
              <span className="font-bold text-pink-400 font-mono">67%</span>
            </div>
            <div className="w-full bg-slate-900 rounded-full h-3">
              <div className="bg-gradient-to-r from-pink-500 to-rose-400 h-full rounded-full" style={{ width: '67%' }} />
            </div>
            <div className="flex justify-between text-[11px] text-slate-400 pt-1">
              <span>Earned: ₹15,420</span>
              <span className="text-emerald-400 font-bold">₹2,500 Mega Bonus on completion!</span>
            </div>
          </div>
        </div>
      )}

      {/* SUB-VIEW 3: BONUSES */}
      {activeSubItem === 'bonuses' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-4 text-xs">
          <h3 className="text-base font-bold text-white">Peak Hour Unlockable Multipliers</h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-4 bg-slate-950 border border-emerald-500/30 rounded-xl space-y-2">
              <div className="font-bold text-emerald-400 flex items-center gap-1.5 text-sm">
                <Zap className="w-4 h-4" /> Airport Morning Rush Bonus
              </div>
              <p className="text-slate-300">Complete any airport trip between 04:30 AM and 08:30 AM to receive a flat +₹150 instant bonus.</p>
            </div>

            <div className="p-4 bg-slate-950 border border-pink-500/30 rounded-xl space-y-2">
              <div className="font-bold text-pink-400 flex items-center gap-1.5 text-sm">
                <Flame className="w-4 h-4" /> Friday Night Rain Surge
              </div>
              <p className="text-slate-300">+₹80 extra per ride during rainy weather when safety telemetry remains in green zone.</p>
            </div>
          </div>
        </div>
      )}

      {/* SUB-VIEW 4: CHALLENGES */}
      {activeSubItem === 'challenges' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-4 text-xs">
          <h3 className="text-base font-bold text-white">Active Driver Badges & Quests</h3>

          <div className="space-y-3">
            <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl flex items-center justify-between">
              <div>
                <div className="font-bold text-white text-sm">Zero Cancellation Streak (5 Days)</div>
                <div className="text-slate-400 text-[11px]">4 of 5 days completed • ₹500 cash reward</div>
              </div>
              <span className="text-xs bg-amber-500/20 text-amber-300 font-bold px-2 py-1 rounded-full">In Progress</span>
            </div>

            <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl flex items-center justify-between">
              <div>
                <div className="font-bold text-white text-sm">Direct Customer Master (10 VIPs)</div>
                <div className="text-slate-400 text-[11px]">7 of 10 clients onboarded • Free Castrol oil kit</div>
              </div>
              <span className="text-xs bg-emerald-500/20 text-emerald-300 font-bold px-2 py-1 rounded-full">Almost There</span>
            </div>
          </div>
        </div>
      )}

      {/* SUB-VIEW 5: REWARDS */}
      {activeSubItem === 'rewards' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-4 text-xs">
          <h3 className="text-base font-bold text-white">Driver Partner Perks & Vouchers</h3>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-2">
              <div className="font-bold text-white">Castrol Engine Oil Kit</div>
              <p className="text-slate-400 text-[11px]">100% Free 3.5L synthetic oil voucher for completing 200 monthly rides.</p>
              <button className="w-full py-1.5 rounded-lg bg-pink-600 hover:bg-pink-500 text-white font-bold">
                Redeem Voucher
              </button>
            </div>

            <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-2">
              <div className="font-bold text-white">Apollo Tyre 25% Off</div>
              <p className="text-slate-400 text-[11px]">Discounted replacement for high-mileage commercial taxi drivers.</p>
              <button className="w-full py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold">
                View Deal
              </button>
            </div>

            <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-2">
              <div className="font-bold text-white">Health & Eye Checkup</div>
              <p className="text-slate-400 text-[11px]">Free optometrist consultation at Manipal Hospitals for driver fatigue prevention.</p>
              <button className="w-full py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold">
                Book Slot
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
