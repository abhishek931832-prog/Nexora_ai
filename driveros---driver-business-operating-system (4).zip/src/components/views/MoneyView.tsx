import React, { useState } from 'react';
import { 
  DollarSign, 
  TrendingUp, 
  Fuel, 
  CreditCard, 
  Wrench, 
  Percent, 
  Wallet, 
  ArrowDownToLine, 
  Receipt, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  PlusCircle, 
  Building,
  RefreshCw,
  Zap,
  PiggyBank
} from 'lucide-react';
import { DriverProfile, TripRecord, ExpenseRecord } from '../../types';

interface MoneyViewProps {
  driver: DriverProfile;
  trips: TripRecord[];
  expenses: ExpenseRecord[];
  activeSubItem: string;
  onSelectSubItem: (sub: string) => void;
  onOpenScanReceipt: () => void;
  onAddExpense: (exp: ExpenseRecord) => void;
}

export const MoneyView: React.FC<MoneyViewProps> = ({
  driver,
  trips,
  expenses,
  activeSubItem,
  onSelectSubItem,
  onOpenScanReceipt,
  onAddExpense,
}) => {
  const [withdrawalPending, setWithdrawalPending] = useState(false);
  const [withdrawalSuccess, setWithdrawalSuccess] = useState(false);

  // Financial calculations
  const totalGrossToday = trips.reduce((acc, t) => acc + t.grossFare, 0);
  const totalCommissionLost = trips.reduce((acc, t) => acc + (t.platformCommission || 0), 0);
  const totalFuelCost = expenses
    .filter(e => e.category === 'CNG_FUEL' || e.category === 'PETROL_DIESEL' || e.category === 'EV_CHARGE')
    .reduce((acc, e) => acc + e.amount, 0);
  const totalTolls = expenses
    .filter(e => e.category === 'TOLL' || e.category === 'PARKING')
    .reduce((acc, e) => acc + e.amount, 0);
  
  // ₹3/km wear and tear reserve fund
  const totalKmDriven = trips.reduce((acc, t) => acc + t.distanceKm, 0);
  const maintenanceReserveFund = Math.round(totalKmDriven * 2.8);

  const realNetProfit = totalGrossToday - totalCommissionLost - totalFuelCost - totalTolls - maintenanceReserveFund;

  const cashCollected = trips.filter(t => t.paymentMode === 'CASH').reduce((acc, t) => acc + t.grossFare, 0);
  const upiCollected = trips.filter(t => t.paymentMode === 'UPI' || t.paymentMode === 'DIRECT_TRANSFER').reduce((acc, t) => acc + t.grossFare, 0);

  const handleInstantPayout = () => {
    setWithdrawalPending(true);
    setTimeout(() => {
      setWithdrawalPending(false);
      setWithdrawalSuccess(true);
    }, 1500);
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Pillar Header & Sub-item Selector */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 sm:p-4 shadow-lg">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400">
              <DollarSign className="w-5 h-5" />
            </span>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                Money & Financial Operations
                <span className="text-xs font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-bold">
                  Net: ₹{realNetProfit > 0 ? realNetProfit.toLocaleString() : '3,240'}
                </span>
              </h2>
              <p className="text-xs text-slate-400">Track real take-home cash, fuel burn, FASTag deductions, maintenance fund, and instant payouts.</p>
            </div>
          </div>

          <button
            onClick={onOpenScanReceipt}
            className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1.5 border border-slate-700"
          >
            <Receipt className="w-3.5 h-3.5 text-amber-400" />
            <span>Scan Fuel / Toll Bill</span>
          </button>
        </div>

        {/* Sub-item Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pt-3 border-t border-slate-800/80 mt-3 scrollbar-none">
          {[
            { id: 'today-earnings', label: "Today's Earnings" },
            { id: 'real-profit', label: 'Real Profit' },
            { id: 'fuel-cost', label: 'Fuel Cost' },
            { id: 'toll-parking', label: 'Toll / Parking' },
            { id: 'maintenance', label: 'Maintenance Reserve' },
            { id: 'platform-fees', label: 'Platform Fees' },
            { id: 'cash-upi', label: 'Cash / UPI Split' },
            { id: 'payouts', label: 'Payouts & Transfers' },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => onSelectSubItem(tab.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-1.5 ${
                activeSubItem === tab.id
                  ? 'bg-emerald-500 text-slate-950 font-bold shadow'
                  : 'bg-slate-800/60 text-slate-300 hover:bg-slate-800 hover:text-white border border-slate-700/50'
              }`}
            >
              <span>{tab.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* SUB-VIEW 1: TODAY'S EARNINGS */}
      {activeSubItem === 'today-earnings' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-lg">
              <div className="text-xs text-slate-400 font-medium">Gross Fare Total</div>
              <div className="text-2xl font-black text-white font-mono mt-1">₹{totalGrossToday.toLocaleString()}</div>
              <div className="text-[11px] text-emerald-400 mt-1">{trips.length} completed trips</div>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-lg">
              <div className="text-xs text-slate-400 font-medium">Platform Deductions (Ola/Uber)</div>
              <div className="text-2xl font-black text-rose-400 font-mono mt-1">-₹{totalCommissionLost.toLocaleString()}</div>
              <div className="text-[11px] text-slate-400 mt-1">Average 26.4% commission</div>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-lg">
              <div className="text-xs text-slate-400 font-medium">Operating Fuel & Tolls</div>
              <div className="text-2xl font-black text-amber-400 font-mono mt-1">-₹{(totalFuelCost + totalTolls).toLocaleString()}</div>
              <div className="text-[11px] text-slate-400 mt-1">FASTag + CNG expenditure</div>
            </div>

            <div className="bg-slate-900 border border-emerald-500/40 rounded-2xl p-4 shadow-lg bg-emerald-950/20">
              <div className="text-xs text-emerald-400 font-bold">Real Take-Home Cash</div>
              <div className="text-2xl font-black text-emerald-400 font-mono mt-1">₹{realNetProfit.toLocaleString()}</div>
              <div className="text-[11px] text-emerald-300 font-semibold mt-1">Pure profit in your pocket</div>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-3">
            <h3 className="text-sm font-bold text-white">Today's Aggregator Breakdown</h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                <div className="flex justify-between font-bold text-white">
                  <span>Direct Bookings</span>
                  <span className="text-emerald-400 font-mono">₹1,650</span>
                </div>
                <div className="text-[11px] text-emerald-300">0% Cut • ₹0 Commission paid</div>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                <div className="flex justify-between font-bold text-white">
                  <span>Ola Cabs</span>
                  <span className="text-slate-300 font-mono">₹1,840</span>
                </div>
                <div className="text-[11px] text-rose-400">28% Cut • ₹515 lost in fees</div>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                <div className="flex justify-between font-bold text-white">
                  <span>Uber Driver</span>
                  <span className="text-slate-300 font-mono">₹1,210</span>
                </div>
                <div className="text-[11px] text-rose-400">25% Cut • ₹302 lost in fees</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SUB-VIEW 2: REAL PROFIT CALCULATOR */}
      {activeSubItem === 'real-profit' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-6">
          <div>
            <h3 className="text-base font-bold text-white">True In-Pocket Profit Waterfall</h3>
            <p className="text-xs text-slate-400">Never get fooled by aggregator gross amounts. Here is your authentic net profit equation.</p>
          </div>

          <div className="bg-slate-950 border border-slate-800 rounded-2xl p-5 space-y-3 font-mono text-xs">
            <div className="flex justify-between py-2 border-b border-slate-800 text-sm">
              <span className="text-slate-300">Gross Passenger Receipts</span>
              <span className="font-bold text-white">₹{totalGrossToday.toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-rose-400">
              <span>(-) Aggregator Commission Cuts (Ola/Uber)</span>
              <span>-₹{totalCommissionLost.toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-amber-400">
              <span>(-) Fuel Consumed (CNG/EV)</span>
              <span>-₹{totalFuelCost.toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-amber-300">
              <span>(-) FASTag Tolls & Parking Plazas</span>
              <span>-₹{totalTolls.toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-purple-400">
              <span>(-) Vehicle Wear & Tear Reserve (₹2.8/km)</span>
              <span>-₹{maintenanceReserveFund.toLocaleString()}</span>
            </div>
            <div className="flex justify-between py-3 border-t-2 border-slate-700 text-base font-black text-emerald-400">
              <span>(=) AUTHENTIC NET PROFIT</span>
              <span>₹{realNetProfit.toLocaleString()}</span>
            </div>
          </div>
        </div>
      )}

      {/* SUB-VIEW 3: FUEL COST TRACKER */}
      {activeSubItem === 'fuel-cost' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-5">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-white">Fuel & Energy Expenditure</h3>
              <p className="text-xs text-slate-400">WagonR CNG • Mileage: 26.5 km/kg • Current Fuel Rate: ₹83.50/kg</p>
            </div>
            <span className="text-xs font-bold text-amber-400 bg-amber-500/20 px-3 py-1 rounded-full">
              ₹3.15 per km run
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-center">
              <div className="text-xs text-slate-400">Total Fuel Spent Today</div>
              <div className="text-2xl font-black text-amber-400 font-mono mt-1">₹{totalFuelCost || 450}</div>
              <div className="text-[10px] text-slate-500 mt-1">5.4 kg CNG pumped</div>
            </div>
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-center">
              <div className="text-xs text-slate-400">Total Kilometers Logged</div>
              <div className="text-2xl font-black text-white font-mono mt-1">{totalKmDriven || 142} km</div>
              <div className="text-[10px] text-slate-500 mt-1">Empty deadhead: 8.2 km (5.7%)</div>
            </div>
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-center">
              <div className="text-xs text-slate-400">Fuel Efficiency Rating</div>
              <div className="text-2xl font-black text-emerald-400 font-mono mt-1">94% Optimal</div>
              <div className="text-[10px] text-emerald-300 mt-1">Low AC idle loss</div>
            </div>
          </div>
        </div>
      )}

      {/* SUB-VIEW 4: TOLL & PARKING TRACKER */}
      {activeSubItem === 'toll-parking' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-5">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-white">FASTag Tolls & Parking Plazas</h3>
              <p className="text-xs text-slate-400">All electronic toll deductions synced automatically with passenger invoices.</p>
            </div>
            <div className="text-right">
              <div className="text-[10px] text-slate-400">FASTag Balance</div>
              <div className="text-sm font-black text-emerald-400 font-mono">₹840.00</div>
            </div>
          </div>

          <div className="space-y-2">
            {[
              { plaza: 'Kempegowda Airport NH44 Plaza', amount: 115, time: 'Today, 08:45 AM', status: 'Reimbursed from Passenger' },
              { plaza: 'NICE Road Expressway Toll (Bannerghatta)', amount: 95, time: 'Yesterday, 06:15 PM', status: 'Reimbursed from Passenger' },
              { plaza: 'Forum South Bangalore Mall Parking', amount: 40, time: 'Yesterday, 02:30 PM', status: 'Driver Operating Expense' },
            ].map((item, idx) => (
              <div key={idx} className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs">
                <div>
                  <div className="font-bold text-white">{item.plaza}</div>
                  <div className="text-slate-400 text-[11px]">{item.time}</div>
                </div>
                <div className="text-right">
                  <div className="font-black text-amber-400 font-mono">₹{item.amount}</div>
                  <div className="text-[10px] text-emerald-400">{item.status}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SUB-VIEW 5: MAINTENANCE RESERVE */}
      {activeSubItem === 'maintenance' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-5">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-white">Vehicle Wear & Tear Maintenance Fund</h3>
              <p className="text-xs text-slate-400">Rule of Thumb: Set aside ₹2.80 per km so unexpected tyre punctures or oil service never breaks your wallet.</p>
            </div>
            <span className="p-2 rounded-xl bg-purple-500/20 text-purple-400">
              <PiggyBank className="w-5 h-5" />
            </span>
          </div>

          <div className="bg-slate-950 border border-purple-500/30 rounded-2xl p-5 space-y-4">
            <div className="flex justify-between items-center">
              <div>
                <div className="text-xs text-slate-400">Accumulated Maintenance Vault</div>
                <div className="text-3xl font-black text-purple-300 font-mono mt-0.5">₹14,280</div>
              </div>
              <button className="px-3.5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold shadow-lg">
                Log Garage Expense
              </button>
            </div>

            <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-800 text-xs text-center">
              <div className="p-2.5 rounded-xl bg-slate-900">
                <div className="text-slate-400 text-[10px]">Tyre Life</div>
                <div className="font-bold text-slate-200 mt-0.5">18,500 km left</div>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-900">
                <div className="text-slate-400 text-[10px]">Engine Oil Service</div>
                <div className="font-bold text-amber-400 mt-0.5">Due in 1,240 km</div>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-900">
                <div className="text-slate-400 text-[10px]">Brake Shoe Health</div>
                <div className="font-bold text-emerald-400 mt-0.5">72% Good</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SUB-VIEW 6: PLATFORM FEES BREAKDOWN */}
      {activeSubItem === 'platform-fees' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-5">
          <div>
            <h3 className="text-base font-bold text-white">Aggregator Fee & Commission Audit</h3>
            <p className="text-xs text-slate-400">Real-time tracker of money surrendered to Ola, Uber, and Rapido.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 rounded-xl bg-slate-950 border border-rose-500/30 space-y-2">
              <div className="flex justify-between items-center text-xs">
                <span className="font-bold text-white">Ola Cabs</span>
                <span className="text-rose-400 font-bold font-mono">28% Cut</span>
              </div>
              <div className="text-2xl font-black text-rose-400 font-mono">₹515</div>
              <div className="text-[11px] text-slate-400">Includes 5% GST on platform fee + ride access surcharge.</div>
            </div>

            <div className="p-4 rounded-xl bg-slate-950 border border-rose-500/30 space-y-2">
              <div className="flex justify-between items-center text-xs">
                <span className="font-bold text-white">Uber Driver</span>
                <span className="text-rose-400 font-bold font-mono">25% Cut</span>
              </div>
              <div className="text-2xl font-black text-rose-400 font-mono">₹302</div>
              <div className="text-[11px] text-slate-400">Service fee deducted before bank payout.</div>
            </div>

            <div className="p-4 rounded-xl bg-slate-950 border border-emerald-500/40 space-y-2">
              <div className="flex justify-between items-center text-xs">
                <span className="font-bold text-white">DriveSmart Direct</span>
                <span className="text-emerald-400 font-bold font-mono">0% Cut</span>
              </div>
              <div className="text-2xl font-black text-emerald-400 font-mono">₹0.00</div>
              <div className="text-[11px] text-emerald-300">Driver keeps 100% of the customer fare!</div>
            </div>
          </div>
        </div>
      )}

      {/* SUB-VIEW 7: CASH VS UPI SPLIT */}
      {activeSubItem === 'cash-upi' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-5">
          <div>
            <h3 className="text-base font-bold text-white">Cash in Hand vs. Digital UPI Balance</h3>
            <p className="text-xs text-slate-400">Reconcile cash collected with your online bank account.</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="bg-slate-950 border border-slate-800 rounded-2xl p-5 space-y-2">
              <div className="flex items-center gap-2 text-xs text-slate-400">
                <Wallet className="w-4 h-4 text-amber-400" />
                <span>Physical Cash in Hand</span>
              </div>
              <div className="text-3xl font-black text-amber-400 font-mono">₹{cashCollected || 1200}</div>
              <div className="text-xs text-slate-400">Keep ready for cash toll and CNG refills.</div>
            </div>

            <div className="bg-slate-950 border border-slate-800 rounded-2xl p-5 space-y-2">
              <div className="flex items-center gap-2 text-xs text-slate-400">
                <CreditCard className="w-4 h-4 text-emerald-400" />
                <span>UPI / Bank Balance</span>
              </div>
              <div className="text-3xl font-black text-emerald-400 font-mono">₹{upiCollected || 2220}</div>
              <div className="text-xs text-slate-400">Directly settled into Axis Bank A/C ...8921.</div>
            </div>
          </div>
        </div>
      )}

      {/* SUB-VIEW 8: PAYOUTS & BANK TRANSFERS */}
      {activeSubItem === 'payouts' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-5">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-white">Instant Bank Payouts</h3>
              <p className="text-xs text-slate-400">Direct IMPS settlement to your registered bank account.</p>
            </div>
            <span className="text-xs font-bold text-emerald-400 bg-emerald-500/20 px-3 py-1 rounded-full">
              KYC Verified
            </span>
          </div>

          <div className="bg-slate-950 border border-slate-800 rounded-2xl p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-xs text-slate-400">Settlement Account</div>
                <div className="text-sm font-bold text-white font-mono mt-0.5">Axis Bank • A/C #91802008472910</div>
                <div className="text-[11px] text-slate-500 font-mono">IFSC: UTIB0001248 • Shivaraj Gowda</div>
              </div>
              <div className="text-right">
                <div className="text-xs text-slate-400">Available to Withdraw</div>
                <div className="text-2xl font-black text-emerald-400 font-mono">₹2,840.00</div>
              </div>
            </div>

            <button
              onClick={handleInstantPayout}
              disabled={withdrawalPending || withdrawalSuccess}
              className={`w-full py-3 px-4 rounded-xl font-black text-xs flex items-center justify-center gap-2 shadow-lg transition-all ${
                withdrawalSuccess
                  ? 'bg-emerald-600 text-white'
                  : 'bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950'
              }`}
            >
              {withdrawalPending ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Processing IMPS Bank Transfer...</span>
                </>
              ) : withdrawalSuccess ? (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span>₹2,840 Transferred to Axis Bank! Ref #IMPS98214</span>
                </>
              ) : (
                <>
                  <ArrowDownToLine className="w-4 h-4" />
                  <span>WITHDRAW ₹2,840 TO BANK NOW</span>
                </>
              )}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
