import React, { useState } from 'react';
import { 
  Smartphone, 
  Layers, 
  TrendingUp, 
  Percent, 
  Award, 
  CheckCircle2, 
  DollarSign, 
  BarChart3, 
  ArrowRight,
  Zap,
  Sparkles
} from 'lucide-react';
import { DriverProfile, TripRecord } from '../../types';

interface PlatformHubViewProps {
  driver: DriverProfile;
  trips: TripRecord[];
  activeSubItem: string;
  onSelectSubItem: (sub: string) => void;
}

export const PlatformHubView: React.FC<PlatformHubViewProps> = ({
  driver,
  trips,
  activeSubItem,
  onSelectSubItem,
}) => {
  return (
    <div className="space-y-6 pb-12">
      {/* Header & Sub-items */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 sm:p-4 shadow-lg">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-orange-500/20 text-orange-400">
              <Smartphone className="w-5 h-5" />
            </span>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                Multi-Platform Aggregator Hub
              </h2>
              <p className="text-xs text-slate-400">
                Compare net earnings across Ola, Uber, Rapido, and Namma Yatri. AI advises which platform pays the highest right now.
              </p>
            </div>
          </div>
        </div>

        {/* Sub-item Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pt-3 border-t border-slate-800/80 mt-3 scrollbar-none">
          {[
            { id: 'ola-earnings', label: 'Ola Earnings' },
            { id: 'uber-earnings', label: 'Uber Earnings' },
            { id: 'rapido-earnings', label: 'Rapido Earnings' },
            { id: 'other-apps', label: 'Other Apps (Namma Yatri)' },
            { id: 'compare-earnings', label: 'Compare Earnings' },
            { id: 'best-app-today', label: 'Best App Today' },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => onSelectSubItem(tab.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-1.5 ${
                activeSubItem === tab.id
                  ? 'bg-orange-500 text-slate-950 font-bold shadow'
                  : 'bg-slate-800/60 text-slate-300 hover:bg-slate-800 hover:text-white border border-slate-700/50'
              }`}
            >
              <span>{tab.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* SUB-VIEW 1: OLA EARNINGS */}
      {activeSubItem === 'ola-earnings' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-4 text-xs">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white">Ola Partner Earnings & Cut</h3>
            <span className="bg-rose-500/20 text-rose-400 font-bold px-2.5 py-1 rounded-full">28% Commission Cut</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-center">
            <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl">
              <div className="text-slate-400 text-[10px]">Ola Gross Total</div>
              <div className="text-2xl font-black text-white font-mono mt-1">₹1,840</div>
              <div className="text-[10px] text-slate-500 mt-1">6 rides completed</div>
            </div>
            <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl">
              <div className="text-slate-400 text-[10px]">Ola Commission Lost</div>
              <div className="text-2xl font-black text-rose-400 font-mono mt-1">-₹515</div>
              <div className="text-[10px] text-slate-500 mt-1">28% standard cut</div>
            </div>
            <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl">
              <div className="text-slate-400 text-[10px]">Net Payout to Bank</div>
              <div className="text-2xl font-black text-emerald-400 font-mono mt-1">₹1,325</div>
              <div className="text-[10px] text-emerald-300 mt-1">After platform fee</div>
            </div>
          </div>
        </div>
      )}

      {/* SUB-VIEW 2: UBER EARNINGS */}
      {activeSubItem === 'uber-earnings' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-4 text-xs">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white">Uber Driver Earnings & Service Fee</h3>
            <span className="bg-rose-500/20 text-rose-400 font-bold px-2.5 py-1 rounded-full">25% Service Fee</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-center">
            <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl">
              <div className="text-slate-400 text-[10px]">Uber Gross Total</div>
              <div className="text-2xl font-black text-white font-mono mt-1">₹1,210</div>
              <div className="text-[10px] text-slate-500 mt-1">4 rides completed</div>
            </div>
            <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl">
              <div className="text-slate-400 text-[10px]">Uber Cut</div>
              <div className="text-2xl font-black text-rose-400 font-mono mt-1">-₹302</div>
              <div className="text-[10px] text-slate-500 mt-1">25% service fee</div>
            </div>
            <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl">
              <div className="text-slate-400 text-[10px]">Net Uber Bank Payout</div>
              <div className="text-2xl font-black text-emerald-400 font-mono mt-1">₹908</div>
              <div className="text-[10px] text-emerald-300 mt-1">Instant cashout ready</div>
            </div>
          </div>
        </div>
      )}

      {/* SUB-VIEW 3: RAPIDO EARNINGS */}
      {activeSubItem === 'rapido-earnings' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-4 text-xs">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white">Rapido Captain Earnings</h3>
            <span className="bg-amber-500/20 text-amber-300 font-bold px-2.5 py-1 rounded-full">20% Cut</span>
          </div>

          <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-2">
            <div className="flex justify-between">
              <span className="text-slate-400">Total Rapido Auto/Cab Rides:</span>
              <span className="font-bold text-white font-mono">2 Trips (₹340 Gross)</span>
            </div>
            <div className="flex justify-between text-rose-400">
              <span>Rapido Commission (20%):</span>
              <span className="font-mono">-₹68</span>
            </div>
            <div className="flex justify-between font-bold text-emerald-400 pt-2 border-t border-slate-800">
              <span>Net Take-Home:</span>
              <span className="font-mono">₹272</span>
            </div>
          </div>
        </div>
      )}

      {/* SUB-VIEW 4: OTHER APPS (NAMMA YATRI / INDRIVE) */}
      {activeSubItem === 'other-apps' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-4 text-xs">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white">Namma Yatri & Open Mobility Apps</h3>
            <span className="bg-emerald-500/20 text-emerald-300 font-bold px-2.5 py-1 rounded-full">0% Commission</span>
          </div>

          <div className="p-4 bg-slate-950 border border-emerald-500/30 rounded-xl space-y-2">
            <div className="flex justify-between">
              <span className="text-slate-300 font-bold">Namma Yatri (Direct UPI from Passenger):</span>
              <span className="font-bold text-emerald-400 font-mono">₹950 (100% In-Pocket)</span>
            </div>
            <p className="text-slate-400 leading-relaxed">
              Open Network for Digital Commerce (ONDC) model. Drivers pay a small flat daily subscription of ₹25 and keep 100% of all ride fares directly into their UPI!
            </p>
          </div>
        </div>
      )}

      {/* SUB-VIEW 5: COMPARE EARNINGS TABLE */}
      {activeSubItem === 'compare-earnings' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-4 text-xs">
          <h3 className="text-base font-bold text-white">Platform Profitability Comparison Matrix</h3>

          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400">
                  <th className="py-2.5">Platform</th>
                  <th className="py-2.5">Commission Cut</th>
                  <th className="py-2.5">Driver Net / ₹1,000</th>
                  <th className="py-2.5">Payout Speed</th>
                  <th className="py-2.5">Driver Rating Protection</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 text-slate-200">
                <tr>
                  <td className="py-2.5 font-bold text-emerald-400">Direct Client (DriveSmart)</td>
                  <td className="py-2.5 font-bold text-emerald-400">0%</td>
                  <td className="py-2.5 font-bold font-mono text-emerald-400">₹1,000 (100%)</td>
                  <td className="py-2.5">Instant UPI</td>
                  <td className="py-2.5 text-emerald-400">100% Guaranteed</td>
                </tr>
                <tr>
                  <td className="py-2.5 font-bold text-sky-400">Namma Yatri</td>
                  <td className="py-2.5 font-bold text-emerald-400">0% (+₹25/day sub)</td>
                  <td className="py-2.5 font-bold font-mono text-sky-300">₹975 (97.5%)</td>
                  <td className="py-2.5">Instant UPI</td>
                  <td className="py-2.5 text-emerald-400">Community Moderated</td>
                </tr>
                <tr>
                  <td className="py-2.5 font-bold text-slate-300">Uber Driver</td>
                  <td className="py-2.5 text-rose-400 font-bold">25%</td>
                  <td className="py-2.5 font-mono text-slate-300">₹750 (75%)</td>
                  <td className="py-2.5">Daily / Weekly</td>
                  <td className="py-2.5 text-amber-400">Algorithmic Review</td>
                </tr>
                <tr>
                  <td className="py-2.5 font-bold text-slate-300">Ola Cabs</td>
                  <td className="py-2.5 text-rose-400 font-bold">28%</td>
                  <td className="py-2.5 font-mono text-slate-300">₹720 (72%)</td>
                  <td className="py-2.5">Daily</td>
                  <td className="py-2.5 text-rose-400">Strict Penalties</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* SUB-VIEW 6: BEST APP TODAY */}
      {activeSubItem === 'best-app-today' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-4 text-xs">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-orange-400" /> AI Real-Time Platform Recommendation
          </h3>

          <div className="p-5 bg-gradient-to-br from-emerald-950/40 to-slate-950 border border-emerald-500/40 rounded-2xl space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm font-bold text-white">Recommended Right Now:</span>
              <span className="bg-emerald-500 text-slate-950 font-black px-3 py-1 rounded-full text-xs">
                NAMMA YATRI + DIRECT BOOKINGS
              </span>
            </div>

            <p className="text-slate-200 leading-relaxed">
              Koramangala and Indiranagar are seeing peak tech commuter demand. Turn OFF Ola and Uber to stop losing 28% in commissions. Run Namma Yatri for local city runs and reserve your airport slots for Direct VIP clients at ₹1,650 flat fare!
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
