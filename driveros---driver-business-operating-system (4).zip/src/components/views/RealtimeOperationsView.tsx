import React, { useState, useEffect } from 'react';
import { 
  Zap, 
  Activity, 
  Radio, 
  Wifi, 
  WifiOff, 
  Server, 
  MapPin, 
  Navigation, 
  Car, 
  ShieldCheck, 
  RefreshCw, 
  CheckCircle2, 
  AlertCircle, 
  Clock, 
  Gauge, 
  Cpu, 
  Layers
} from 'lucide-react';
import { DriverProfile, TripRecord } from '../../types';

interface RealtimeOperationsViewProps {
  driver: DriverProfile;
  activeRide?: any;
  onOpenBookingFlow?: () => void;
  onOpenMap?: () => void;
}

export const RealtimeOperationsView: React.FC<RealtimeOperationsViewProps> = ({
  driver,
  activeRide,
  onOpenBookingFlow,
  onOpenMap,
}) => {
  const [wsStatus, setWsStatus] = useState<'CONNECTED' | 'RECONNECTING' | 'OFFLINE'>('CONNECTED');
  const [latencyMs, setLatencyMs] = useState(24);
  const [gpsAccuracyMeters, setGpsAccuracyMeters] = useState(2.8);
  const [satellitesLocked, setSatellitesLocked] = useState(14);
  const [syncQueueCount, setSyncQueueCount] = useState(0);
  const [isSimulatingDisconnect, setIsSimulatingDisconnect] = useState(false);

  // Periodic heartbeat & latency jitter simulation
  useEffect(() => {
    if (wsStatus !== 'CONNECTED') return;
    const interval = setInterval(() => {
      setLatencyMs(prev => Math.max(16, Math.min(48, prev + Math.floor(Math.random() * 7) - 3)));
    }, 2500);
    return () => clearInterval(interval);
  }, [wsStatus]);

  const handleTestRecovery = () => {
    setIsSimulatingDisconnect(true);
    setWsStatus('RECONNECTING');
    setSyncQueueCount(3);
    setTimeout(() => {
      setWsStatus('CONNECTED');
      setSyncQueueCount(0);
      setIsSimulatingDisconnect(false);
    }, 1800);
  };

  const nearbyFleet = [
    { id: 'CAB-841', model: 'Maruti Dzire CNG', plate: 'KA-04-ME-4412', distance: '380m', status: 'ON_TRIP', speed: '42 km/h' },
    { id: 'CAB-920', model: 'Tata Tigor EV', plate: 'KA-05-EV-1920', distance: '650m', status: 'SEARCHING', speed: '18 km/h' },
    { id: 'CAB-108', model: 'Hyundai Aura CNG', plate: 'KA-01-AJ-8812', distance: '1.1km', status: 'ON_TRIP', speed: '55 km/h' },
    { id: 'CAB-312', model: 'Toyota Innova Crysta', plate: 'KA-51-B-3120', distance: '1.4km', status: 'RESTING', speed: '0 km/h' },
  ];

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-amber-950/50 border border-slate-800 rounded-3xl p-5 shadow-2xl relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-amber-500/20 text-amber-400 border border-amber-500/30 uppercase">
                ⚡ PILLAR 11 • REAL-TIME OPERATIONS
              </span>
              <span className="text-xs text-slate-400 font-mono">
                WebSocket Sync • GPS Telemetry • Offline Recovery
              </span>
            </div>
            <h1 className="text-xl font-black text-white flex items-center gap-2">
              <span>REAL-TIME FLEET TELEMETRY & NETWORK SYNC</span>
              <Activity className="w-5 h-5 text-amber-400" />
            </h1>
            <p className="text-xs text-slate-300 max-w-2xl">
              High-throughput bidirectional state synchronization connecting passenger booking events, live driver GPS coordinates, fleet peer monitoring, and zero-data-loss offline caching.
            </p>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              onClick={handleTestRecovery}
              disabled={isSimulatingDisconnect}
              className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition flex items-center gap-2 border border-slate-700 cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 text-amber-400 ${isSimulatingDisconnect ? 'animate-spin' : ''}`} />
              <span>Test Offline Recovery</span>
            </button>

            <div className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-xs font-mono font-bold text-emerald-300">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
              <span>WS: {wsStatus} ({latencyMs}ms)</span>
            </div>
          </div>
        </div>

        {/* 6 Capabilities Strip */}
        <div className="mt-4 pt-3 border-t border-slate-800/80 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 text-center text-[10px] font-bold">
          <div className="p-2 rounded-xl bg-slate-950/70 border border-slate-800 text-emerald-400">
            1. ⚡ WebSocket Live
          </div>
          <div className="p-2 rounded-xl bg-slate-950/70 border border-slate-800 text-slate-300">
            2. 📍 Driver GPS Lock
          </div>
          <div className="p-2 rounded-xl bg-slate-950/70 border border-slate-800 text-amber-400">
            3. 🔄 Ride State Sync
          </div>
          <div className="p-2 rounded-xl bg-slate-950/70 border border-slate-800 text-indigo-400">
            4. 🚕 Fleet Monitoring
          </div>
          <div className="p-2 rounded-xl bg-slate-950/70 border border-slate-800 text-teal-400">
            5. 💚 System Health
          </div>
          <div className="p-2 rounded-xl bg-slate-950/70 border border-slate-800 text-rose-400">
            6. 📴 Offline Auto-Recovery
          </div>
        </div>
      </div>

      {/* Grid: Live Telemetry Telemetry & System Health */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        
        {/* Card 1: GPS & Driver Location Telemetry */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
                <MapPin className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">Live Driver Telemetry</h3>
                <p className="text-[11px] text-slate-400">Hardware GPS & Inertial Sensors</p>
              </div>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300">
              ±{gpsAccuracyMeters}m Accuracy
            </span>
          </div>

          <div className="space-y-2 text-xs font-mono bg-slate-950 p-3.5 rounded-2xl border border-slate-800">
            <div className="flex justify-between">
              <span className="text-slate-400">Latitude:</span>
              <span className="text-white">12.9716° N</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Longitude:</span>
              <span className="text-white">77.5946° E</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Heading & Speed:</span>
              <span className="text-emerald-400 font-bold">42° NNE • 56 km/h</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Satellites Locked:</span>
              <span className="text-amber-400 font-bold">{satellitesLocked} GNSS (NavIC/GPS)</span>
            </div>
          </div>

          <button
            onClick={onOpenMap}
            className="w-full py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer border border-slate-700"
          >
            <Navigation className="w-3.5 h-3.5 text-emerald-400" />
            <span>Open Map Radar</span>
          </button>
        </div>

        {/* Card 2: Ride Status Synchronization */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30">
                <Radio className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">Ride State Sync</h3>
                <p className="text-[11px] text-slate-400">Passenger App Bidirectional Sync</p>
              </div>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-500/20 text-amber-300">
              Live Channel
            </span>
          </div>

          <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800 space-y-2 text-xs">
            <div className="flex justify-between items-center">
              <span className="text-slate-400">Active Ride Status:</span>
              <span className="font-bold text-emerald-400 uppercase font-mono">
                {activeRide?.status || 'ACCEPTED (IN TRANSIT)'}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-400">Passenger:</span>
              <span className="text-white font-medium">{activeRide?.customerName || 'Ananya Sharma'}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-400">Sync Ping Cadence:</span>
              <span className="text-slate-300 font-mono">Every 1000ms</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-400">Queue Buffer:</span>
              <span className="text-teal-400 font-mono">{syncQueueCount} pending items</span>
            </div>
          </div>

          <button
            onClick={onOpenBookingFlow}
            className="w-full py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-slate-950 text-xs font-black transition flex items-center justify-center gap-1.5 cursor-pointer shadow-md shadow-amber-950"
          >
            <Car className="w-3.5 h-3.5" />
            <span>Open Ride State Machine</span>
          </button>
        </div>

        {/* Card 3: System Health & Offline Recovery */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center border border-indigo-500/30">
                <Cpu className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">System Diagnostics</h3>
                <p className="text-[11px] text-slate-400">Engine Vitals & Storage Cache</p>
              </div>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300">
              100% HEALTHY
            </span>
          </div>

          <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800 space-y-2 text-xs">
            <div className="flex justify-between items-center">
              <span className="text-slate-400">API Gateway:</span>
              <span className="text-emerald-400 font-bold">200 OK (Node/Express)</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-400">Local Cache:</span>
              <span className="text-slate-200">IndexedDB Storage Synced</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-400">Battery Level:</span>
              <span className="text-emerald-300 font-mono">84% (Charging)</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-400">Offline Fallback:</span>
              <span className="text-indigo-300 font-bold">Auto-Replay Ready</span>
            </div>
          </div>

          <div className="p-2 rounded-xl bg-slate-950 border border-slate-800/80 text-[11px] text-slate-400 text-center">
            Zero data loss guaranteed even in low-connectivity underground tunnels.
          </div>
        </div>

      </div>

      {/* Fleet Monitoring Section */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Car className="w-4 h-4 text-amber-400" />
              <span>Nearby Fleet Peer Monitoring (Buddy Network)</span>
            </h3>
            <p className="text-xs text-slate-400">Live positions of peer drivers within 2 km perimeter for safety and crowd-sourced traffic</p>
          </div>
          <span className="text-xs font-mono text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-lg border border-emerald-500/20">
            4 Peers Active Nearby
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {nearbyFleet.map(peer => (
            <div key={peer.id} className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-white">{peer.id}</span>
                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-slate-300">
                  {peer.distance}
                </span>
              </div>
              <div className="text-xs text-slate-300 font-medium truncate">{peer.model}</div>
              <div className="text-[11px] font-mono text-slate-400">{peer.plate}</div>
              <div className="flex items-center justify-between pt-1 border-t border-slate-800/80 text-[10px]">
                <span className="text-emerald-400 font-bold">{peer.status}</span>
                <span className="text-slate-400">{peer.speed}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
