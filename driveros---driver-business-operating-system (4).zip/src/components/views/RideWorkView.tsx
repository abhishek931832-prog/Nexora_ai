import React, { useState, useEffect } from 'react';
import { 
  Car, 
  Navigation, 
  MapPin, 
  Play, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  AlertTriangle, 
  DollarSign, 
  Fuel, 
  Route, 
  ShieldCheck, 
  QrCode, 
  Send, 
  Phone, 
  MessageSquare, 
  Sparkles,
  Search,
  Filter,
  Download,
  Share2,
  ChevronRight,
  ArrowRight,
  Info
} from 'lucide-react';
import { TripRecord, DriverProfile } from '../../types';

interface RideWorkViewProps {
  driver: DriverProfile;
  trips: TripRecord[];
  activeSubItem: string;
  onSelectSubItem: (sub: string) => void;
  onOpenNewTrip: () => void;
  onOpenCustomerPayment: (trip?: TripRecord | null) => void;
  onSaveTrip: (trip: TripRecord) => void;
  onOpenMap?: () => void;
}

export const RideWorkView: React.FC<RideWorkViewProps> = ({
  driver,
  trips,
  activeSubItem,
  onSelectSubItem,
  onOpenNewTrip,
  onOpenCustomerPayment,
  onSaveTrip,
  onOpenMap,
}) => {
  // Simulator State for Incoming New Ride
  const [hasIncomingRide, setHasIncomingRide] = useState(true);
  const [countdown, setCountdown] = useState(15);
  const [incomingRide, setIncomingRide] = useState({
    id: `RIDE-${Date.now()}`,
    passengerName: 'Ananya Sharma',
    passengerPhone: '+91 98451 22910',
    rating: 4.9,
    pickup: 'Koramangala Sony World Signal',
    pickupDistance: '1.4 km (4 mins away)',
    dropoff: 'Kempegowda Airport T2 Departure',
    tripDistance: 41.5,
    estDuration: 62,
    platform: 'DIRECT_CLIENT' as const,
    grossFare: 1650,
    fuelCostEst: 142,
    tollCostEst: 115,
    surge: 1.8,
  });

  // Active Ride Lifecycle State
  const [rideStatus, setRideStatus] = useState<'IDLE' | 'PICKUP' | 'IN_TRANSIT' | 'COMPLETED'>('PICKUP');
  const [meterSeconds, setMeterSeconds] = useState(745);
  const [distanceCoveredKm, setDistanceCoveredKm] = useState(14.2);
  const [otpInput, setOtpInput] = useState('');
  const [otpVerified, setOtpVerified] = useState(false);
  const [isNavigating, setIsNavigating] = useState(true);

  // Cancellation State
  const [cancellationReason, setCancellationReason] = useState('PASSENGER_NO_SHOW');
  const [cancellationNotes, setCancellationNotes] = useState('');
  const [cancellationDisputeSubmitted, setCancellationDisputeSubmitted] = useState(false);

  // Trip History search & filter
  const [searchQuery, setSearchQuery] = useState('');
  const [platformFilter, setPlatformFilter] = useState('ALL');

  // Countdown timer for incoming ride
  useEffect(() => {
    if (!hasIncomingRide) return;
    const timer = setInterval(() => {
      setCountdown(c => {
        if (c <= 1) {
          setCountdown(15);
          return 15;
        }
        return c - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [hasIncomingRide]);

  // Active meter running effect
  useEffect(() => {
    if (rideStatus !== 'IN_TRANSIT') return;
    const interval = setInterval(() => {
      setMeterSeconds(s => s + 1);
      setDistanceCoveredKm(d => +(d + 0.02).toFixed(2));
    }, 1000);
    return () => clearInterval(interval);
  }, [rideStatus]);

  const handleAcceptRide = () => {
    setRideStatus('PICKUP');
    setHasIncomingRide(false);
    onSelectSubItem('pickup');
  };

  const handleRejectRide = () => {
    setHasIncomingRide(false);
    setTimeout(() => {
      setHasIncomingRide(true);
      setCountdown(15);
    }, 4000);
  };

  const handleStartTrip = () => {
    if (!otpVerified && otpInput !== '4821') {
      alert('Please enter correct OTP: 4821');
      return;
    }
    setRideStatus('IN_TRANSIT');
    onSelectSubItem('start-trip');
  };

  const handleEndTrip = () => {
    setRideStatus('COMPLETED');
    const completedTrip: TripRecord = {
      id: `trip_${Date.now()}`,
      timestamp: new Date().toISOString(),
      platform: incomingRide.platform,
      pickupLocation: incomingRide.pickup,
      dropoffLocation: incomingRide.dropoff,
      distanceKm: incomingRide.tripDistance,
      durationMinutes: Math.round(meterSeconds / 60),
      grossFare: incomingRide.grossFare,
      platformCommission: 0,
      fuelCost: incomingRide.fuelCostEst,
      tollCost: incomingRide.tollCostEst,
      tips: 50,
      netProfit: incomingRide.grossFare - incomingRide.fuelCostEst - incomingRide.tollCostEst + 50,
      deadheadKm: 0,
      passengerName: incomingRide.passengerName,
      paymentMode: 'UPI',
    };
    onSaveTrip(completedTrip);
    onSelectSubItem('end-trip');
  };

  const filteredTrips = trips.filter(t => {
    const matchesSearch = t.pickupLocation.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          t.dropoffLocation.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          (t.passengerName && t.passengerName.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesPlatform = platformFilter === 'ALL' || t.platform === platformFilter;
    return matchesSearch && matchesPlatform;
  });

  return (
    <div className="space-y-6 pb-12">
      {/* Sub-item Navigation Tabs matching the user's diagram */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-2 sm:p-3 shadow-lg">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-amber-500/20 text-amber-400">
              <Car className="w-5 h-5" />
            </span>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                Ride Work Lifecycle
                <span className="text-xs font-mono font-normal px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  {rideStatus === 'IN_TRANSIT' ? 'Trip Running' : 'Ready for Dispatch'}
                </span>
              </h2>
              <p className="text-xs text-slate-400">Manage incoming rides, turn-by-turn navigation, running fare meter, and trip history.</p>
            </div>
          </div>

          <button
            onClick={onOpenNewTrip}
            className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-lg shadow-emerald-950 transition-all"
          >
            <Play className="w-3.5 h-3.5" />
            <span>Manual Trip Log</span>
          </button>
        </div>

        {/* Horizontal Sub-tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pt-3 border-t border-slate-800/80 mt-3 scrollbar-none">
          {[
            { id: 'new-ride', label: 'New Ride' },
            { id: 'accept-reject', label: 'Accept / Reject' },
            { id: 'pickup', label: 'Pickup' },
            { id: 'navigation', label: 'Navigation' },
            { id: 'start-trip', label: 'Start Trip' },
            { id: 'end-trip', label: 'End Trip' },
            { id: 'cancellation', label: 'Cancellation' },
            { id: 'trip-history', label: 'Trip History' },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => onSelectSubItem(tab.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-1.5 ${
                activeSubItem === tab.id
                  ? 'bg-emerald-500 text-slate-950 font-bold shadow'
                  : 'bg-slate-800/60 text-slate-300 hover:bg-slate-800 hover:text-white border border-slate-700/50'
              }`}
            >
              <span>{tab.label}</span>
              {tab.id === 'new-ride' && hasIncomingRide && (
                <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
              )}
            </button>
          ))}
        </div>
      </div>

      {/* SUB-VIEW 1: NEW RIDE DISPATCH SIMULATOR */}
      {activeSubItem === 'new-ride' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="p-2 rounded-xl bg-amber-500/20 text-amber-400">
                  <Car className="w-5 h-5" />
                </span>
                <div>
                  <h3 className="text-base font-bold text-white">Incoming Ride Broadcast</h3>
                  <p className="text-xs text-slate-400">Direct VIP Corporate Ride with 0% Platform Commission</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-400">Expires in:</span>
                <span className="w-8 h-8 rounded-full bg-amber-500/20 border border-amber-400/40 text-amber-300 font-mono font-bold flex items-center justify-center text-sm animate-pulse">
                  {countdown}s
                </span>
              </div>
            </div>

            {/* Passenger & Fare Card */}
            <div className="bg-slate-950 border border-emerald-500/30 rounded-2xl p-5 space-y-4">
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-base font-bold text-white">{incomingRide.passengerName}</span>
                    <span className="text-xs bg-emerald-500/20 text-emerald-300 font-bold px-2 py-0.5 rounded-full">
                      ★ {incomingRide.rating} VIP
                    </span>
                  </div>
                  <div className="text-xs text-slate-400 mt-0.5">Corporate Airport Regular • Verified Commuter</div>
                </div>

                <div className="text-right">
                  <div className="text-2xl font-black text-emerald-400 font-mono">₹{incomingRide.grossFare}</div>
                  <div className="text-[11px] text-emerald-300 font-bold">100% In-Pocket (0% Cut)</div>
                </div>
              </div>

              {/* Route points */}
              <div className="space-y-3 pt-2 border-t border-slate-800">
                <div className="flex items-start gap-3">
                  <span className="w-3 h-3 rounded-full bg-emerald-400 mt-1 shrink-0 ring-4 ring-emerald-500/20" />
                  <div>
                    <div className="text-xs text-slate-400">PICKUP (1.4 km • 4 mins away)</div>
                    <div className="text-sm font-semibold text-slate-100">{incomingRide.pickup}</div>
                  </div>
                </div>

                <div className="h-6 w-0.5 bg-slate-700 ml-1.5" />

                <div className="flex items-start gap-3">
                  <span className="w-3 h-3 rounded-full bg-rose-500 mt-1 shrink-0 ring-4 ring-rose-500/20" />
                  <div>
                    <div className="text-xs text-slate-400">DROPOFF (41.5 km • 62 mins)</div>
                    <div className="text-sm font-semibold text-slate-100">{incomingRide.dropoff}</div>
                  </div>
                </div>
              </div>

              {/* Cost & Profit Breakdown */}
              <div className="grid grid-cols-3 gap-2 bg-slate-900/90 p-3 rounded-xl border border-slate-800 text-center">
                <div>
                  <div className="text-[10px] text-slate-400">Est. CNG Fuel</div>
                  <div className="text-xs font-bold text-amber-400 font-mono mt-0.5">₹{incomingRide.fuelCostEst}</div>
                </div>
                <div>
                  <div className="text-[10px] text-slate-400">NH44 Toll</div>
                  <div className="text-xs font-bold text-amber-300 font-mono mt-0.5">₹{incomingRide.tollCostEst}</div>
                </div>
                <div>
                  <div className="text-[10px] text-emerald-400 font-bold">Net In-Pocket</div>
                  <div className="text-sm font-black text-emerald-400 font-mono mt-0.5">
                    ₹{incomingRide.grossFare - incomingRide.fuelCostEst - incomingRide.tollCostEst}
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-2 gap-3 pt-2">
                <button
                  onClick={handleRejectRide}
                  className="py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-white font-bold text-xs flex items-center justify-center gap-2 border border-slate-700 transition-colors"
                >
                  <XCircle className="w-4 h-4 text-rose-400" />
                  <span>Pass / Next Ride</span>
                </button>

                <button
                  onClick={handleAcceptRide}
                  className="py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-950 transition-transform active:scale-95"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>ACCEPT RIDE (₹1,650)</span>
                </button>
              </div>
            </div>
          </div>

          {/* Right Column: AI Trip Intelligence */}
          <div className="space-y-4">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-3">
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-emerald-400" /> AI Trip Intelligence
              </h4>
              <p className="text-xs text-slate-300 leading-relaxed">
                This trip to <strong>Kempegowda Airport T2</strong> gives you <strong>₹22.4 net profit per minute</strong>. Highly recommended over city crawls.
              </p>
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-xs space-y-1.5">
                <div className="flex justify-between text-slate-400">
                  <span>Return Return Probability:</span>
                  <span className="text-emerald-400 font-bold">92% High</span>
                </div>
                <div className="text-[11px] text-slate-400">Airport Taxi staging queue has under 12 mins wait for return corporate bookings.</div>
              </div>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-2 text-xs">
              <div className="font-bold text-white flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-400" /> Driver Security Note
              </div>
              <p className="text-slate-400 leading-relaxed">
                This client has completed 14 rides with 5-star ratings. Automatic emergency OTP and location sharing enabled.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* SUB-VIEW 2: ACCEPT / REJECT COMPARISON ENGINE */}
      {activeSubItem === 'accept-reject' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-6">
          <div>
            <h3 className="text-base font-bold text-white">Ride Acceptance Profitability Engine</h3>
            <p className="text-xs text-slate-400">Side-by-side comparison: Aggregator (Ola/Uber 28% cut) vs Direct Booking (0% cut).</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Aggregator Booking */}
            <div className="bg-slate-950 border border-rose-500/30 rounded-2xl p-5 space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-rose-400 bg-rose-500/20 px-2 py-0.5 rounded-full">
                  Aggregator Trip (Ola Prime)
                </span>
                <span className="text-xs text-slate-400">28% Commission Cut</span>
              </div>

              <div className="space-y-2 text-xs text-slate-300">
                <div className="flex justify-between">
                  <span>Gross Fare:</span>
                  <span className="font-bold text-white font-mono">₹1,650</span>
                </div>
                <div className="flex justify-between text-rose-400">
                  <span>Ola 28% Commission Lost:</span>
                  <span className="font-bold font-mono">-₹462</span>
                </div>
                <div className="flex justify-between">
                  <span>Fuel (CNG 41km):</span>
                  <span className="font-mono">-₹142</span>
                </div>
                <div className="flex justify-between">
                  <span>FASTag Toll:</span>
                  <span className="font-mono">-₹115</span>
                </div>
                <div className="pt-2 border-t border-slate-800 flex justify-between text-sm font-bold text-slate-200">
                  <span>True Driver In-Pocket:</span>
                  <span className="font-mono text-rose-300">₹931 (56.4%)</span>
                </div>
              </div>
            </div>

            {/* Direct Booking */}
            <div className="bg-slate-950 border border-emerald-500/40 rounded-2xl p-5 space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-emerald-300 bg-emerald-500/20 px-2 py-0.5 rounded-full">
                  Direct Booking (DriveSmart)
                </span>
                <span className="text-xs text-emerald-400 font-bold">0% Commission Cut</span>
              </div>

              <div className="space-y-2 text-xs text-slate-300">
                <div className="flex justify-between">
                  <span>Gross Fare:</span>
                  <span className="font-bold text-white font-mono">₹1,650</span>
                </div>
                <div className="flex justify-between text-emerald-400 font-bold">
                  <span>Platform Commission:</span>
                  <span className="font-mono">₹0 (ZERO)</span>
                </div>
                <div className="flex justify-between">
                  <span>Fuel (CNG 41km):</span>
                  <span className="font-mono">-₹142</span>
                </div>
                <div className="flex justify-between">
                  <span>FASTag Toll:</span>
                  <span className="font-mono">-₹115</span>
                </div>
                <div className="pt-2 border-t border-slate-800 flex justify-between text-sm font-bold text-emerald-400">
                  <span>True Driver In-Pocket:</span>
                  <span className="font-mono text-emerald-400 text-base">₹1,393 (84.4%)</span>
                </div>
              </div>

              <div className="p-3 bg-emerald-950/40 border border-emerald-500/30 rounded-xl text-xs text-emerald-200 font-semibold text-center">
                +₹462 EXTRA pure profit earned on this single ride!
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SUB-VIEW 3: PICKUP MANAGEMENT & OTP */}
      {activeSubItem === 'pickup' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-5">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-white">Active Passenger Pickup</h3>
              <p className="text-xs text-slate-400">Driving to pickup point • Arriving in ~4 mins</p>
            </div>
            <span className="text-xs px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold">
              En Route to Pickup
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-slate-950 border border-slate-800 rounded-2xl p-5 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-bold text-white">{incomingRide.passengerName}</h4>
                  <div className="text-xs text-slate-400">{incomingRide.passengerPhone}</div>
                </div>
                <div className="flex items-center gap-2">
                  <a
                    href={`tel:${incomingRide.passengerPhone}`}
                    className="p-2.5 rounded-xl bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30 transition-colors"
                    title="Call Passenger"
                  >
                    <Phone className="w-4 h-4" />
                  </a>
                  <a
                    href={`https://wa.me/919845122910?text=Hello%20Ananya,%20your%20cab%20is%202%20mins%20away.`}
                    target="_blank"
                    rel="noreferrer"
                    className="p-2.5 rounded-xl bg-sky-500/20 text-sky-400 hover:bg-sky-500/30 transition-colors"
                    title="WhatsApp Passenger"
                  >
                    <MessageSquare className="w-4 h-4" />
                  </a>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-xs space-y-1">
                <span className="text-slate-400 block text-[10px]">Pickup Location:</span>
                <span className="font-semibold text-slate-200">{incomingRide.pickup}</span>
                <span className="text-emerald-400 block text-[11px] font-mono mt-1">Passenger Landmark: Near Fabindia showroom entrance</span>
              </div>

              {/* 4-digit Ride Start OTP */}
              <div className="space-y-2 pt-2">
                <label className="text-xs text-slate-300 font-semibold block">Enter Passenger Start Ride OTP (Demo: 4821)</label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    maxLength={4}
                    value={otpInput}
                    onChange={(e) => {
                      setOtpInput(e.target.value);
                      if (e.target.value === '4821') {
                        setOtpVerified(true);
                      }
                    }}
                    placeholder="4821"
                    className="w-32 bg-slate-900 border border-slate-700 rounded-xl px-4 py-2.5 text-center text-lg font-mono font-bold tracking-widest text-white focus:outline-none focus:border-emerald-500"
                  />
                  {otpVerified ? (
                    <span className="text-xs text-emerald-400 font-bold flex items-center gap-1">
                      <CheckCircle2 className="w-4 h-4" /> OTP Verified!
                    </span>
                  ) : (
                    <button
                      onClick={() => {
                        setOtpInput('4821');
                        setOtpVerified(true);
                      }}
                      className="text-xs px-3 py-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white"
                    >
                      Fill Demo OTP
                    </button>
                  )}
                </div>
              </div>

              <button
                onClick={handleStartTrip}
                className="w-full py-3 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs flex items-center justify-center gap-2 shadow-lg transition-all"
              >
                <Play className="w-4 h-4" />
                <span>START TRIP & ENGAGE METER</span>
              </button>
            </div>

            <div className="bg-slate-950 border border-slate-800 rounded-2xl p-5 space-y-3 text-xs text-slate-300">
              <h4 className="font-bold text-white flex items-center gap-1.5">
                <Navigation className="w-4 h-4 text-emerald-400" /> Route & Live Guidance
              </h4>
              <p className="text-slate-400">Take intermediate 80ft road to avoid Koramangala 6th block water-logging construction.</p>
              <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 space-y-1">
                <div className="text-slate-400 text-[10px]">Estimated Toll:</div>
                <div className="font-bold text-amber-400 font-mono">₹115 (Airport Express)</div>
                <div className="text-[10px] text-slate-500">Will be billed directly on dropoff checkout.</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SUB-VIEW 4: LIVE NAVIGATION HUD WITH CAR MARKER */}
      {activeSubItem === 'navigation' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400">
                <Navigation className="w-5 h-5" />
              </span>
              <div>
                <h3 className="text-base font-bold text-white">Live Navigation HUD (Windshield Mode)</h3>
                <p className="text-xs text-slate-400">Real-time GPS turn-by-turn guidance with speed telemetry.</p>
              </div>
            </div>
            <div className="bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800 text-right">
              <div className="text-[10px] text-slate-400">Current Speed</div>
              <div className="text-base font-black text-emerald-400 font-mono">56 km/h</div>
            </div>
          </div>

          {/* Turn-by-Turn Instruction Banner */}
          <div className="bg-slate-950 border border-emerald-500/40 rounded-2xl p-4 sm:p-5 flex items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl bg-emerald-500 text-slate-950 flex items-center justify-center font-bold text-2xl shadow-lg">
                ↰
              </div>
              <div>
                <div className="text-xs text-emerald-400 font-bold uppercase tracking-wider">In 200 Meters</div>
                <div className="text-base sm:text-lg font-bold text-white">Turn Left onto Indiranagar 100ft Road</div>
                <div className="text-xs text-slate-400 mt-0.5">Follow NH44 toward Hebbal Flyover & Airport</div>
              </div>
            </div>

            <div className="text-right shrink-0">
              <div className="text-xs text-slate-400">ETA to Destination</div>
              <div className="text-lg font-black text-white font-mono">48 mins</div>
              <div className="text-xs text-emerald-400 font-mono">31.2 km left</div>
            </div>
          </div>

          {/* Speed Limit & Alert Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center text-xs">
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
              <div className="text-slate-400 text-[10px]">Speed Limit</div>
              <div className="text-sm font-bold text-slate-100 font-mono mt-0.5">80 km/h (Safe)</div>
            </div>
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
              <div className="text-slate-400 text-[10px]">Traffic Condition</div>
              <div className="text-sm font-bold text-emerald-400 font-mono mt-0.5">Clear Green Flow</div>
            </div>
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
              <div className="text-slate-400 text-[10px]">Next Fuel / Rest</div>
              <div className="text-sm font-bold text-amber-400 font-mono mt-0.5">GAIL CNG 4.2 km</div>
            </div>
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800">
              <div className="text-slate-400 text-[10px]">Passenger Safety</div>
              <div className="text-sm font-bold text-emerald-400 font-mono mt-0.5">Smooth Braking</div>
            </div>
          </div>

          {/* Open Full GPS Map with Moving Car Action */}
          {onOpenMap && (
            <div className="pt-2">
              <button
                onClick={onOpenMap}
                className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-xs flex items-center justify-center gap-2 shadow-xl shadow-emerald-950/50 transition-all cursor-pointer"
              >
                <Car className="w-4 h-4" />
                <span>OPEN LIVE MAP WITH MOVING CAR & FLEET GPS</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      )}

      {/* SUB-VIEW 5: START TRIP METER */}
      {activeSubItem === 'start-trip' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-emerald-400 animate-ping" />
              <h3 className="text-base font-bold text-white">Active Digital Fare Meter</h3>
            </div>
            <span className="text-xs px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 font-mono font-bold">
              Meter Running
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-5 rounded-2xl bg-slate-950 border border-emerald-500/40 text-center space-y-1">
              <div className="text-xs text-slate-400 font-medium">Running Fare (Direct VIP)</div>
              <div className="text-3xl font-black text-emerald-400 font-mono">₹{incomingRide.grossFare}</div>
              <div className="text-[11px] text-emerald-300 font-semibold">+₹115 Toll included</div>
            </div>

            <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 text-center space-y-1">
              <div className="text-xs text-slate-400 font-medium">Trip Distance Covered</div>
              <div className="text-3xl font-black text-white font-mono">{distanceCoveredKm} km</div>
              <div className="text-[11px] text-slate-400">Target: {incomingRide.tripDistance} km</div>
            </div>

            <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 text-center space-y-1">
              <div className="text-xs text-slate-400 font-medium">Trip Duration Elapsed</div>
              <div className="text-3xl font-black text-amber-400 font-mono">
                {Math.floor(meterSeconds / 60)}m {meterSeconds % 60}s
              </div>
              <div className="text-[11px] text-slate-400">Avg Speed: 52 km/h</div>
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              onClick={() => onSelectSubItem('navigation')}
              className="py-2.5 px-4 rounded-xl bg-slate-800 text-slate-300 hover:text-white text-xs font-semibold"
            >
              Open Turn Navigation
            </button>
            <button
              onClick={handleEndTrip}
              className="py-2.5 px-6 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-rose-950"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>REACHED DESTINATION - END TRIP</span>
            </button>
          </div>
        </div>
      )}

      {/* SUB-VIEW 6: END TRIP CHECKOUT & DYNAMIC UPI QR */}
      {activeSubItem === 'end-trip' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-white">Trip Completed • Payment Checkout</h3>
              <p className="text-xs text-slate-400">Collect fare via dynamic UPI QR code or cash, then issue receipt.</p>
            </div>
            <span className="text-xs px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 font-bold">
              Ready for Settlement
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Invoice Breakdown */}
            <div className="bg-slate-950 border border-slate-800 rounded-2xl p-5 space-y-3 text-xs">
              <div className="font-bold text-white text-sm pb-2 border-b border-slate-800 flex justify-between">
                <span>Trip Invoice #DS-{Date.now().toString().slice(-6)}</span>
                <span className="text-emerald-400 font-mono">0% Commission</span>
              </div>

              <div className="space-y-1.5 text-slate-300">
                <div className="flex justify-between">
                  <span>Base Distance Fare (41.5 km):</span>
                  <span className="font-mono">₹1,485</span>
                </div>
                <div className="flex justify-between">
                  <span>Airport Toll Plaza (FASTag):</span>
                  <span className="font-mono text-amber-400">₹115</span>
                </div>
                <div className="flex justify-between">
                  <span>Direct Booking Convenience:</span>
                  <span className="font-mono text-emerald-400">₹50 (0% cut)</span>
                </div>
                <div className="pt-2 border-t border-slate-800 flex justify-between text-base font-black text-white">
                  <span>TOTAL FARE COLLECTIBLE:</span>
                  <span className="font-mono text-emerald-400">₹1,650</span>
                </div>
              </div>

              <div className="pt-3 space-y-2">
                <button
                  onClick={() => onOpenCustomerPayment()}
                  className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-200 text-xs font-bold flex items-center justify-center gap-2 border border-slate-700"
                >
                  <Share2 className="w-4 h-4 text-emerald-400" />
                  <span>Send PDF Receipt to Customer WhatsApp</span>
                </button>
              </div>
            </div>

            {/* Dynamic UPI QR Code */}
            <div className="bg-slate-950 border border-emerald-500/40 rounded-2xl p-5 text-center space-y-3">
              <div className="text-xs font-bold text-emerald-400 uppercase tracking-wider">
                Scan & Pay via any UPI App
              </div>
              <div className="w-40 h-40 mx-auto bg-white p-2 rounded-2xl shadow-xl flex items-center justify-center border-4 border-emerald-500/30">
                {/* SVG mock QR */}
                <div className="w-full h-full bg-slate-950 rounded-lg p-2 flex flex-col items-center justify-center text-emerald-400">
                  <QrCode className="w-24 h-24 text-white" />
                  <span className="text-[9px] font-mono text-slate-400 mt-1">UPI ID: shivaraj@okaxis</span>
                </div>
              </div>

              <div className="text-xs text-slate-400 font-mono">
                Amount: <strong className="text-emerald-400 text-sm">₹1,650</strong>
              </div>

              <div className="grid grid-cols-2 gap-2 pt-1">
                <button
                  onClick={() => alert('Cash payment marked as collected!')}
                  className="py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-300"
                >
                  Cash Received
                </button>
                <button
                  onClick={() => alert('UPI payment verified instantly!')}
                  className="py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-black"
                >
                  UPI Verified
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SUB-VIEW 7: CANCELLATION RESOLUTION & DISPUTE */}
      {activeSubItem === 'cancellation' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-5">
          <div>
            <h3 className="text-base font-bold text-white">Cancellation Dispute & Compensation Recovery</h3>
            <p className="text-xs text-slate-400">
              Recover ₹50 - ₹100 cancellation fees when riders cancel after you have driven toward pickup.
            </p>
          </div>

          <div className="bg-slate-950 border border-slate-800 rounded-2xl p-5 space-y-4">
            <div className="space-y-2">
              <label className="text-xs font-semibold text-slate-300 block">Select Cancellation Reason</label>
              <select
                value={cancellationReason}
                onChange={(e) => setCancellationReason(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-500"
              >
                <option value="PASSENGER_NO_SHOW">Passenger did not show up after 5 minutes at pickup location</option>
                <option value="WRONG_PICKUP">Passenger entered wrong pickup pin (&gt;1.5 km away)</option>
                <option value="RIDER_CANCELLED_LATE">Passenger cancelled after driver reached within 500m</option>
                <option value="EXCESS_LUGGAGE">Passenger carried excessive commercial freight without prior notice</option>
                <option value="UNRULY_BEHAVIOR">Passenger refused to follow basic safety or sobriety norms</option>
              </select>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-semibold text-slate-300 block">Driver Notes & Proof</label>
              <textarea
                value={cancellationNotes}
                onChange={(e) => setCancellationNotes(e.target.value)}
                placeholder="Waited at Sony World signal for 7 minutes, called passenger twice but no answer..."
                rows={3}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div className="p-3 bg-emerald-950/40 border border-emerald-500/30 rounded-xl text-xs text-emerald-200">
              <strong>Section 65 Driver Protection Guarantee:</strong> DriveSmart logs your GPS track as proof. Cancellation fee of ₹75 will be credited automatically.
            </div>

            <button
              onClick={() => setCancellationDisputeSubmitted(true)}
              className="py-2.5 px-6 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center gap-2"
            >
              <Send className="w-4 h-4" />
              <span>Submit Cancellation Claim</span>
            </button>

            {cancellationDisputeSubmitted && (
              <div className="p-3 bg-slate-900 border border-emerald-500 rounded-xl text-xs text-emerald-400 flex items-center gap-2 font-semibold">
                <CheckCircle2 className="w-4 h-4" /> Claim #CAN-8910 verified. ₹75 credited to driver wallet.
              </div>
            )}
          </div>
        </div>
      )}

      {/* SUB-VIEW 8: TRIP HISTORY LEDGER */}
      {activeSubItem === 'trip-history' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-base font-bold text-white">Trip History Ledger</h3>
              <p className="text-xs text-slate-400">Total {trips.length} commercial trips logged this cycle.</p>
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <div className="relative flex-1 sm:w-48">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search trips..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-8 pr-3 py-1.5 text-xs text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <select
                value={platformFilter}
                onChange={(e) => setPlatformFilter(e.target.value)}
                className="bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-1.5 text-xs text-slate-300"
              >
                <option value="ALL">All Platforms</option>
                <option value="DIRECT_CLIENT">Direct (0% cut)</option>
                <option value="OLA">Ola</option>
                <option value="UBER">Uber</option>
                <option value="RAPIDO">Rapido</option>
              </select>
            </div>
          </div>

          <div className="space-y-2.5">
            {filteredTrips.slice(0, 8).map((trip) => (
              <div
                key={trip.id}
                className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/80 hover:border-slate-700 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-white text-sm">{trip.pickupLocation.split(',')[0]}</span>
                    <ArrowRight className="w-3 h-3 text-slate-500" />
                    <span className="font-bold text-slate-200 text-sm">{trip.dropoffLocation.split(',')[0]}</span>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      trip.platform === 'DIRECT_CLIENT' 
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' 
                        : 'bg-slate-800 text-slate-400'
                    }`}>
                      {trip.platform}
                    </span>
                  </div>
                  <div className="text-slate-400 text-[11px] flex items-center gap-3">
                    <span>{trip.distanceKm} km</span>
                    <span>•</span>
                    <span>{trip.durationMinutes} mins</span>
                    <span>•</span>
                    <span>Passenger: {trip.passengerName || 'Regular Rider'}</span>
                  </div>
                </div>

                <div className="flex items-center justify-between sm:justify-end gap-4 border-t sm:border-t-0 pt-2 sm:pt-0 border-slate-800">
                  <div className="text-right">
                    <div className="text-slate-400 text-[10px]">Gross Fare</div>
                    <div className="font-bold text-slate-200 font-mono">₹{trip.grossFare}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-emerald-400 font-bold text-[10px]">Net In-Pocket</div>
                    <div className="font-black text-emerald-400 font-mono text-sm">₹{trip.netProfit}</div>
                  </div>
                  <button
                    onClick={() => onOpenCustomerPayment(trip)}
                    className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white"
                    title="View Receipt"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
