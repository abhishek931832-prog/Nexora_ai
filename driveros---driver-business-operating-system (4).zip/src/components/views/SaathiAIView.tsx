import React, { useState } from 'react';
import { 
  Bot, 
  Mic, 
  MicOff, 
  Send, 
  Sparkles, 
  TrendingUp, 
  Compass, 
  Receipt, 
  AlertTriangle, 
  Volume2, 
  Calendar, 
  CheckCircle2, 
  HelpCircle,
  Clock,
  Car
} from 'lucide-react';
import { DriverProfile, TripRecord, ExpenseRecord } from '../../types';

interface SaathiAIViewProps {
  driver: DriverProfile;
  trips: TripRecord[];
  expenses: ExpenseRecord[];
  activeSubItem: string;
  onSelectSubItem: (sub: string) => void;
  onAddExpenseFromVoice?: (amount: number, category: string, notes: string) => void;
}

interface ChatMessage {
  id: string;
  sender: 'DRIVER' | 'SAATHI';
  text: string;
  timestamp: string;
  audioAction?: boolean;
}

export const SaathiAIView: React.FC<SaathiAIViewProps> = ({
  driver,
  trips,
  expenses,
  activeSubItem,
  onSelectSubItem,
  onAddExpenseFromVoice,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      sender: 'SAATHI',
      text: `Namaste ${driver.name} ji! Main aapka DriveSmart Saathi hoon. Aaj aapne ₹3,420 gross kamaya hai. Koramangala aur Indiranagar mein abhi 1.9x surge hai. Aapko koi route, earnings ya dispute mein help chahiye?`,
      timestamp: 'Just now',
    },
  ]);

  const [inputQuery, setInputQuery] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);

  const handleSendMessage = (textToSend?: string) => {
    const q = textToSend || inputQuery;
    if (!q.trim()) return;

    const userMsg: ChatMessage = {
      id: `user_${Date.now()}`,
      sender: 'DRIVER',
      text: q,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages(prev => [...prev, userMsg]);
    setInputQuery('');

    // Generate intelligent driver-tailored answer
    setTimeout(() => {
      let reply = '';
      const lower = q.toLowerCase();

      if (lower.includes('earning') || lower.includes('kamai') || lower.includes('target')) {
        reply = `Aapka daily target ₹3,500 hai aur aap abhi ₹2,840 par hain. Sirf 1 Airport trip ya 2 Indiranagar rides lene se aapka ₹3,500 target complete ho jayega aur ₹300 ka daily bonus unlock hoga!`;
      } else if (lower.includes('route') || lower.includes('jam') || lower.includes('silk board')) {
        reply = `Silk Board signal par abhi 35 mins ka heavy delay hai. Agur lake road se HSR Layout 27th Main bypass lijiye. 18 minutes bachenge aur ₹35 ka fuel save hoga.`;
      } else if (lower.includes('cng') || lower.includes('fuel') || lower.includes('pump')) {
        reply = `GAIL Gas CNG Pump (Bellandur Ring Road) par abhi ZERO queue hai (wait time < 2 mins). Agle 4 km mein CNG bharva lijiye.`;
      } else if (lower.includes('dispute') || lower.includes('cancel') || lower.includes('penalty')) {
        reply = `Ola ya Uber cancellation penalty ko dispute karne ke liye Driver Problem Center mein "Cancellation" select karein. Hamara automated claim Section 65 proof generate karta hai.`;
      } else {
        reply = `Ji Shivaraj ji, maine aapki query analyze ki hai. DriveSmart AI driver OS aapke 100% margin protection ke liye active hai. Kya aap iska voice summary sunna chahte hain?`;
      }

      const saathiMsg: ChatMessage = {
        id: `saathi_${Date.now()}`,
        sender: 'SAATHI',
        text: reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages(prev => [...prev, saathiMsg]);
    }, 800);
  };

  const handleVoiceToggle = () => {
    if (isRecording) {
      setIsRecording(false);
      handleSendMessage('Agle ghante mein sabse zyada surge kahan milega?');
    } else {
      setIsRecording(true);
      setTimeout(() => {
        setIsRecording(false);
        handleSendMessage('Agle ghante mein sabse zyada surge kahan milega?');
      }, 2500);
    }
  };

  const handleSpeakText = (txt: string) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(txt);
      utterance.rate = 0.95;
      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => setIsSpeaking(false);
      window.speechSynthesis.speak(utterance);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header & Sub-items */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 sm:p-4 shadow-lg">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-purple-500/20 text-purple-400">
              <Bot className="w-5 h-5" />
            </span>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                Saathi AI • Driver Co-Pilot
                <span className="text-xs font-mono px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 font-bold">
                  Multilingual AI
                </span>
              </h2>
              <p className="text-xs text-slate-400">Voice-first intelligence for surge timing, route traffic avoidance, expense leak checks, and daily debriefs.</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => handleSpeakText('Namaste driver bhai. Saathi AI active hai.')}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white"
              title="Test Audio Readout"
            >
              <Volume2 className="w-4 h-4 text-purple-400" />
            </button>
          </div>
        </div>

        {/* Sub-item Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pt-3 border-t border-slate-800/80 mt-3 scrollbar-none">
          {[
            { id: 'ask-anything', label: 'Ask Anything' },
            { id: 'earnings-advice', label: 'Earnings Advice' },
            { id: 'route-advice', label: 'Route Advice' },
            { id: 'expense-analysis', label: 'Expense Analysis' },
            { id: 'problem-solver', label: 'Problem Solver' },
            { id: 'voice-assistant', label: 'Voice Assistant' },
            { id: 'daily-summary', label: 'Daily Summary' },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => onSelectSubItem(tab.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-1.5 ${
                activeSubItem === tab.id
                  ? 'bg-purple-500 text-slate-950 font-bold shadow'
                  : 'bg-slate-800/60 text-slate-300 hover:bg-slate-800 hover:text-white border border-slate-700/50'
              }`}
            >
              <span>{tab.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* SUB-VIEW 1: ASK ANYTHING CHAT */}
      {activeSubItem === 'ask-anything' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between text-xs text-slate-400 border-b border-slate-800 pb-2">
            <span>Conversing in Hinglish / Kannada / English</span>
            <span className="text-emerald-400 font-bold flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" /> Online
            </span>
          </div>

          {/* Chat Stream */}
          <div className="space-y-3 min-h-[280px] max-h-[380px] overflow-y-auto p-2 scrollbar-none">
            {messages.map((m) => (
              <div
                key={m.id}
                className={`flex gap-3 text-xs leading-relaxed ${
                  m.sender === 'DRIVER' ? 'justify-end' : 'justify-start'
                }`}
              >
                {m.sender === 'SAATHI' && (
                  <span className="w-7 h-7 rounded-xl bg-purple-500/20 text-purple-300 flex items-center justify-center shrink-0 mt-0.5">
                    <Bot className="w-4 h-4" />
                  </span>
                )}

                <div
                  className={`max-w-[82%] sm:max-w-[70%] p-3.5 rounded-2xl ${
                    m.sender === 'DRIVER'
                      ? 'bg-emerald-600 text-white rounded-br-none'
                      : 'bg-slate-950 text-slate-200 border border-slate-800 rounded-bl-none shadow'
                  }`}
                >
                  <p>{m.text}</p>
                  <div className="flex items-center justify-between gap-3 mt-1.5 pt-1 border-t border-white/10 text-[10px] text-slate-400">
                    <span>{m.timestamp}</span>
                    {m.sender === 'SAATHI' && (
                      <button
                        onClick={() => handleSpeakText(m.text)}
                        className="text-purple-400 hover:text-purple-300 flex items-center gap-1"
                      >
                        <Volume2 className="w-3 h-3" /> Speak
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Quick Prompt Chips */}
          <div className="flex items-center gap-2 overflow-x-auto py-1 scrollbar-none text-[11px]">
            {[
              'Aaj ₹3,500 target kaise complete karoon?',
              'Airport route pe toll vs interior road profit?',
              'Ola 28% commission dispute kaise daalein?',
              'Near CNG pump without queue?',
            ].map((chip, idx) => (
              <button
                key={idx}
                onClick={() => handleSendMessage(chip)}
                className="px-2.5 py-1 rounded-full bg-slate-950 text-slate-300 hover:text-white border border-slate-800 hover:border-purple-500 whitespace-nowrap transition-colors"
              >
                {chip}
              </button>
            ))}
          </div>

          {/* Input Box with Mic */}
          <div className="flex items-center gap-2 pt-2 border-t border-slate-800">
            <button
              onClick={handleVoiceToggle}
              className={`p-3 rounded-xl transition-all ${
                isRecording
                  ? 'bg-rose-600 text-white animate-pulse'
                  : 'bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700'
              }`}
              title={isRecording ? 'Listening...' : 'Hold to Speak'}
            >
              {isRecording ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4 text-purple-400" />}
            </button>

            <input
              type="text"
              value={inputQuery}
              onChange={(e) => setInputQuery(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
              placeholder="Ask Saathi AI anything (Hindi / English / Kannada)..."
              className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
            />

            <button
              onClick={() => handleSendMessage()}
              className="p-3 rounded-xl bg-purple-600 hover:bg-purple-500 text-white transition-colors"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* SUB-VIEW 2: EARNINGS ADVICE */}
      {activeSubItem === 'earnings-advice' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-emerald-400" /> Daily Target Maximizer
          </h3>
          <p className="text-xs text-slate-300 leading-relaxed">
            Based on current city booking frequency and weather forecast, here is your playbook to hit ₹4,000+ today:
          </p>

          <div className="space-y-2.5 text-xs">
            <div className="p-3.5 rounded-xl bg-slate-950 border border-emerald-500/30 space-y-1">
              <div className="font-bold text-emerald-400">1. Peak Rush Strategy (08:30 AM - 11:30 AM)</div>
              <div className="text-slate-300">Target Electronic City elevated corridor. IT parks have high demand for direct airport runs with ₹0 commission.</div>
            </div>
            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
              <div className="font-bold text-amber-400">2. Lunch Slump Preservation (01:30 PM - 03:30 PM)</div>
              <div className="text-slate-300">Do NOT cruise empty. Park at HSR Sector 2 tree canopy rest stop. Save ₹180 in idle CNG fuel.</div>
            </div>
            <div className="p-3.5 rounded-xl bg-slate-950 border border-purple-500/30 space-y-1">
              <div className="font-bold text-purple-300">3. Night Surge Play (08:00 PM - 12:00 AM)</div>
              <div className="text-slate-300">Indiranagar 100ft Rd and Koramangala 5th Block surge hits 2.2x. Accept short hops to maximize ride count bonus.</div>
            </div>
          </div>
        </div>
      )}

      {/* SUB-VIEW 3: ROUTE ADVICE */}
      {activeSubItem === 'route-advice' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Compass className="w-5 h-5 text-sky-400" /> Profit-Maximizing Route Intelligence
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div className="p-4 rounded-xl bg-slate-950 border border-rose-500/30 space-y-2">
              <div className="font-bold text-rose-400 flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4" /> Avoid: Silk Board Flyover Junction
              </div>
              <p className="text-slate-300">Current average delay is 38 minutes due to metro construction. Fuel idle loss: ~₹45.</p>
              <div className="text-[11px] text-emerald-400 font-semibold">Take Madiwala interior lake road bypass.</div>
            </div>

            <div className="p-4 rounded-xl bg-slate-950 border border-emerald-500/30 space-y-2">
              <div className="font-bold text-emerald-400 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4" /> Recommend: NH44 Airport Express Toll
              </div>
              <p className="text-slate-300">Toll is ₹115, but you save 35 minutes and ₹90 in stop-and-go clutch wear. Passenger pays toll.</p>
              <div className="text-[11px] text-emerald-300 font-semibold">Highest net profit per minute.</div>
            </div>
          </div>
        </div>
      )}

      {/* SUB-VIEW 4: EXPENSE ANALYSIS */}
      {activeSubItem === 'expense-analysis' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Receipt className="w-5 h-5 text-amber-400" /> AI Expense Leak Detector
          </h3>
          <p className="text-xs text-slate-300">
            Saathi analyzed your last 10 expense records and found ₹420 in avoidable weekly expenses:
          </p>

          <div className="space-y-2.5 text-xs">
            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
              <div>
                <div className="font-bold text-white">AC Idling During Passenger Wait Time</div>
                <div className="text-slate-400 text-[11px]">Idled 42 minutes with AC on high. Burned ~₹95 in CNG.</div>
              </div>
              <span className="font-bold text-amber-400 font-mono">-₹95</span>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
              <div>
                <div className="font-bold text-white">Chai & Snack Spending</div>
                <div className="text-slate-400 text-[11px]">₹160 spent at commercial highway stall. Carry water flask.</div>
              </div>
              <span className="font-bold text-slate-400 font-mono">-₹160</span>
            </div>
          </div>
        </div>
      )}

      {/* SUB-VIEW 5: PROBLEM SOLVER */}
      {activeSubItem === 'problem-solver' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <HelpCircle className="w-5 h-5 text-purple-400" /> Instant Dispute & Problem Resolution
          </h3>

          <div className="space-y-3 text-xs">
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="font-bold text-white">Passenger refuses to pay Toll Plaza fee</div>
              <p className="text-slate-400">Section 12 of RTO fare rules state that all bridge, tunnel, and highway expressway tolls are strictly payable by the passenger. Use the DriveSmart digital invoice with integrated FASTag timestamp.</p>
            </div>

            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
              <div className="font-bold text-white">Ola/Uber unfair 1-star retaliation review</div>
              <p className="text-slate-400">If a passenger leaves a retaliatory review after being asked not to smoke or damage seats, open Driver Problem Center &gt; Support &gt; Account issue to trigger an AI rating scrub request.</p>
            </div>
          </div>
        </div>
      )}

      {/* SUB-VIEW 6: VOICE ASSISTANT */}
      {activeSubItem === 'voice-assistant' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 text-center space-y-5">
          <div className="w-20 h-20 mx-auto rounded-full bg-purple-500/20 text-purple-400 border border-purple-500/40 flex items-center justify-center animate-pulse">
            <Mic className="w-10 h-10" />
          </div>

          <div>
            <h3 className="text-lg font-bold text-white">Hands-Free Steering Wheel Voice Co-Pilot</h3>
            <p className="text-xs text-slate-400 max-w-md mx-auto mt-1">
              Never take your eyes off the highway. Tap and speak in your mother tongue: "Saathi, log 500 rupees CNG", "Next fuel stop", or "End trip".
            </p>
          </div>

          <button
            onClick={handleVoiceToggle}
            className={`py-3.5 px-8 rounded-2xl font-black text-sm transition-all shadow-xl ${
              isRecording
                ? 'bg-rose-600 text-white animate-ping'
                : 'bg-gradient-to-r from-purple-500 to-indigo-500 hover:from-purple-400 text-slate-950'
            }`}
          >
            {isRecording ? 'Listening to voice command...' : 'TAP TO ACTIVATE VOICE NOW'}
          </button>
        </div>
      )}

      {/* SUB-VIEW 7: DAILY SUMMARY */}
      {activeSubItem === 'daily-summary' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-purple-400" />
              <h3 className="text-base font-bold text-white">Today's Debriefing Summary</h3>
            </div>
            <button
              onClick={() => handleSpeakText('Shivaraj ji, aaj aapka shift bohot accha raha. Total net in-pocket profit teen hazaar do sau rupaye hai.')}
              className="px-3 py-1.5 rounded-xl bg-purple-500/20 text-purple-300 hover:bg-purple-500/30 text-xs font-bold flex items-center gap-1.5"
            >
              <Volume2 className="w-3.5 h-3.5" /> Read Aloud
            </button>
          </div>

          <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-3 text-xs">
            <p className="text-slate-200 text-sm font-semibold leading-relaxed">
              "Shivaraj ji, great work today! You completed <strong>{trips.length} rides</strong> covering <strong>142 km</strong> across Bengaluru. Your direct client conversion saved you <strong>₹462 in platform cuts</strong>. Total real in-pocket profit is <strong>₹3,240</strong>."
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 border-t border-slate-800 text-center">
              <div className="p-2.5 rounded-xl bg-slate-900">
                <div className="text-slate-400 text-[10px]">Total Hours</div>
                <div className="font-bold text-white font-mono mt-0.5">7.4 hrs</div>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-900">
                <div className="text-slate-400 text-[10px]">Hourly Rate</div>
                <div className="font-bold text-emerald-400 font-mono mt-0.5">₹437/hr</div>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-900">
                <div className="text-slate-400 text-[10px]">Safety Score</div>
                <div className="font-bold text-emerald-400 font-mono mt-0.5">98/100</div>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-900">
                <div className="text-slate-400 text-[10px]">Target Achieved</div>
                <div className="font-bold text-purple-400 font-mono mt-0.5">92%</div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
