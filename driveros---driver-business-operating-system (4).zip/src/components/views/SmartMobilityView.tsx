import React, { useState } from 'react';
import { 
  Navigation, 
  MapPin, 
  Flame, 
  Fuel, 
  Zap, 
  ParkingCircle, 
  Layers, 
  Route, 
  AlertTriangle, 
  Clock, 
  Sparkles, 
  Compass, 
  CheckCircle2, 
  ExternalLink,
  ShieldCheck,
  BatteryCharging,
  Car
} from 'lucide-react';
import { ProfitMap } from '../ProfitMap';

export const SmartMobilityView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'MAP' | 'ROUTING_ANALYZER' | 'EV_CHARGING' | 'PARKING'>('MAP');
  
  // Fuel vs Toll Routing Analysis state
  const [selectedRoute, setSelectedRoute] = useState<'AIRPORT_TOLL' | 'AIRPORT_SERVICE' | 'ORR_TECH'>('AIRPORT_TOLL');

  // EV Station Data
  const evStations = [
    {
      id: 'zeon_hebbal',
      name: 'Zeon EV Fast Hub — Hebbal Flyover',
      power: '60 kW Dual Gun (CCS2)',
      price: '₹18.50 / kWh',
      availableGuns: '3 / 4 Available',
      distance: '2.4 km (6 mins)',
      waitTime: '0 mins',
      amenities: 'Washroom • Chai Point • 24x7 Security',
    },
    {
      id: 'tatapower_airport',
      name: 'Tata Power EZ Charge — KIA Staging Lot',
      power: '120 kW Ultra Fast',
      price: '₹21.00 / kWh',
      availableGuns: '6 / 8 Available',
      distance: '14.2 km (18 mins)',
      waitTime: '5 mins',
      amenities: 'Driver Canteen • Rest Area • Tyre Air',
    },
    {
      id: 'jio_bp_koramangala',
      name: 'Jio-bp pulse — Koramangala 80ft',
      power: '30 kW DC Fast',
      price: '₹19.00 / kWh',
      availableGuns: '1 / 2 Available',
      distance: '5.1 km (14 mins)',
      waitTime: '12 mins',
      amenities: 'ATM • 24x7 Convenience Store',
    },
  ];

  // Parking Intelligence Data
  const parkingHubs = [
    {
      id: 'airport_staging',
      name: 'KIA Commercial Taxi Holding Staging Area',
      totalSlots: 450,
      occupiedSlots: 310,
      vacancyPercent: 31,
      fee: '₹50 for 4 hours (FASTag auto-debit)',
      security: 'CCTV Monitored • Karnataka Police Post',
      driverFacilities: 'Subsidized Canteen, Prayer Hall, Bathrooms',
      surgeStatus: 'High Inflow (22 flights arriving)',
    },
    {
      id: 'majestic_railway',
      name: 'Majestic KSR Railway Station Cab Staging',
      totalSlots: 120,
      occupiedSlots: 98,
      vacancyPercent: 18,
      fee: '₹40 for 2 hours',
      security: 'RPF Guarded',
      driverFacilities: 'Water Purifier & Tea Stall',
      surgeStatus: 'Train arrival: Shatabdi Express 19:45',
    },
    {
      id: 'ecity_elevated',
      name: 'Electronic City Toll Plaza Driver Rest Bay',
      totalSlots: 60,
      occupiedSlots: 22,
      vacancyPercent: 63,
      fee: 'Free for Commercial Cabs',
      security: 'BETL Highway Patrol',
      driverFacilities: 'Clean Washrooms, Tyre Pressure Point',
      surgeStatus: 'Moderate',
    },
  ];

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      
      {/* Smart Mobility Header Strip */}
      <div className="bg-gradient-to-r from-slate-900 via-emerald-950/60 to-slate-900 border border-slate-800 rounded-3xl p-5 shadow-2xl relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 uppercase">
                🗺️ PILLAR 3 • SMART MOBILITY ENGINE
              </span>
              <span className="text-xs text-slate-400 font-mono">
                Real-Time Traffic • Heatmap • EV & Parking AI
              </span>
            </div>
            <h1 className="text-xl font-black text-white flex items-center gap-2">
              <span>DYNAMIC MOBILITY & ROUTE INTELLIGENCE</span>
              <Compass className="w-4 h-4 text-emerald-400" />
            </h1>
            <p className="text-xs text-slate-300 max-w-2xl">
              High-velocity fleet telemetry combining live traffic, demand heatmaps, fuel/toll optimized routing, EV charger availability, and verified airport/city parking staging areas.
            </p>
          </div>

          {/* Navigation Pills */}
          <div className="flex items-center bg-slate-950 p-1.5 rounded-2xl border border-slate-800 text-xs font-bold shrink-0">
            <button
              onClick={() => setActiveTab('MAP')}
              className={`px-3 py-1.5 rounded-xl transition cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'MAP' ? 'bg-emerald-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Navigation className="w-3.5 h-3.5" />
              <span>Live Map & Fleet</span>
            </button>
            <button
              onClick={() => setActiveTab('ROUTING_ANALYZER')}
              className={`px-3 py-1.5 rounded-xl transition cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'ROUTING_ANALYZER' ? 'bg-emerald-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Route className="w-3.5 h-3.5" />
              <span>Fuel & Toll Routing</span>
            </button>
            <button
              onClick={() => setActiveTab('EV_CHARGING')}
              className={`px-3 py-1.5 rounded-xl transition cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'EV_CHARGING' ? 'bg-emerald-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              <span>EV Charging</span>
            </button>
            <button
              onClick={() => setActiveTab('PARKING')}
              className={`px-3 py-1.5 rounded-xl transition cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'PARKING' ? 'bg-emerald-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
              }`}
            >
              <ParkingCircle className="w-3.5 h-3.5 text-sky-400" />
              <span>Parking Staging</span>
            </button>
          </div>
        </div>

        {/* 7 Sub-capabilities strip */}
        <div className="mt-4 pt-3 border-t border-slate-800/80 grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2 text-center text-[10px] font-bold">
          <div className="p-2 rounded-xl bg-slate-950/70 border border-slate-800 text-slate-300">
            1. 🟢 Real-Time Traffic
          </div>
          <div className="p-2 rounded-xl bg-slate-950/70 border border-slate-800 text-emerald-400">
            2. 🧭 Dynamic Route Opt
          </div>
          <div className="p-2 rounded-xl bg-slate-950/70 border border-slate-800 text-rose-400">
            3. 🔥 Demand Heatmap
          </div>
          <div className="p-2 rounded-xl bg-slate-950/70 border border-slate-800 text-amber-400">
            4. ⛽ Fuel-Aware Routing
          </div>
          <div className="p-2 rounded-xl bg-slate-950/70 border border-slate-800 text-indigo-400">
            5. 💳 Toll-Aware (FASTag)
          </div>
          <div className="p-2 rounded-xl bg-slate-950/70 border border-slate-800 text-teal-400">
            6. ⚡ EV Optimization
          </div>
          <div className="p-2 rounded-xl bg-slate-950/70 border border-slate-800 text-sky-400">
            7. 🅿️ Parking Intelligence
          </div>
        </div>
      </div>

      {/* VIEW CONTENT BASED ON TAB */}

      {activeTab === 'MAP' && (
        <ProfitMap />
      )}

      {activeTab === 'ROUTING_ANALYZER' && (
        <div className="space-y-5">
          <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Route className="w-4 h-4 text-emerald-400" />
                  <span>Fuel vs. Toll Dynamic Route Optimizer</span>
                </h3>
                <p className="text-xs text-slate-400">
                  Calculates true financial trade-offs: toll cost vs distance detour vs traffic fuel burn
                </p>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs font-mono text-emerald-400 bg-emerald-500/10 px-3 py-1 rounded-lg border border-emerald-500/30">
                  CNG Price: ₹88.50/kg • Toll: FASTag Auto
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Option 1: Airport Express Elevated */}
              <div 
                onClick={() => setSelectedRoute('AIRPORT_TOLL')}
                className={`p-4 rounded-2xl border transition cursor-pointer ${
                  selectedRoute === 'AIRPORT_TOLL'
                    ? 'bg-emerald-950/40 border-emerald-500/70 shadow-lg shadow-emerald-950/40'
                    : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-emerald-400 flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>RECOMMENDED (FASTEST)</span>
                  </span>
                  <span className="text-xs font-mono font-bold text-white">38 mins</span>
                </div>
                <h4 className="text-sm font-bold text-white mb-1">NH44 Elevated Toll Highway</h4>
                <p className="text-xs text-slate-400 mb-3">Hebbal ➔ Elevated Flyover ➔ Airport T2</p>

                <div className="space-y-1.5 text-xs font-mono pt-2 border-t border-slate-800">
                  <div className="flex justify-between text-slate-400">
                    <span>Distance:</span>
                    <span className="text-white">34.2 km</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>FASTag Toll:</span>
                    <span className="text-amber-400">₹115.00</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>CNG Fuel Burn:</span>
                    <span className="text-slate-200">1.4 kg (₹124)</span>
                  </div>
                  <div className="flex justify-between font-bold pt-1 border-t border-slate-800/80">
                    <span className="text-emerald-300">Total Route Cost:</span>
                    <span className="text-emerald-400 text-sm">₹239.00</span>
                  </div>
                </div>
              </div>

              {/* Option 2: Service Road (Toll Bypass) */}
              <div 
                onClick={() => setSelectedRoute('AIRPORT_SERVICE')}
                className={`p-4 rounded-2xl border transition cursor-pointer ${
                  selectedRoute === 'AIRPORT_SERVICE'
                    ? 'bg-emerald-950/40 border-emerald-500/70 shadow-lg shadow-emerald-950/40'
                    : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-amber-400">
                    <span>TOLL-FREE (DETOUR)</span>
                  </span>
                  <span className="text-xs font-mono font-bold text-slate-300">58 mins</span>
                </div>
                <h4 className="text-sm font-bold text-white mb-1">NH44 Service Road Bypass</h4>
                <p className="text-xs text-slate-400 mb-3">Yelahanka ➔ Bagalur ➔ Airport Backgate</p>

                <div className="space-y-1.5 text-xs font-mono pt-2 border-t border-slate-800">
                  <div className="flex justify-between text-slate-400">
                    <span>Distance:</span>
                    <span className="text-white">42.8 km (+8.6 km)</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>FASTag Toll:</span>
                    <span className="text-emerald-400 font-bold">₹0.00 (Saved ₹115)</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>CNG Fuel Burn:</span>
                    <span className="text-rose-400">2.1 kg (₹186)</span>
                  </div>
                  <div className="flex justify-between font-bold pt-1 border-t border-slate-800/80">
                    <span className="text-slate-300">Total Route Cost:</span>
                    <span className="text-amber-400 text-sm">₹186.00</span>
                  </div>
                </div>
              </div>

              {/* Option 3: Tech Park Outer Ring Road */}
              <div 
                onClick={() => setSelectedRoute('ORR_TECH')}
                className={`p-4 rounded-2xl border transition cursor-pointer ${
                  selectedRoute === 'ORR_TECH'
                    ? 'bg-emerald-950/40 border-emerald-500/70 shadow-lg shadow-emerald-950/40'
                    : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-indigo-400">
                    <span>SURGE CORRIDOR</span>
                  </span>
                  <span className="text-xs font-mono font-bold text-slate-300">46 mins</span>
                </div>
                <h4 className="text-sm font-bold text-white mb-1">ORR via Budigere Cross</h4>
                <p className="text-xs text-slate-400 mb-3">Whitefield ➔ Budigere ➔ Airport South Gate</p>

                <div className="space-y-1.5 text-xs font-mono pt-2 border-t border-slate-800">
                  <div className="flex justify-between text-slate-400">
                    <span>Distance:</span>
                    <span className="text-white">38.5 km</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>FASTag Toll:</span>
                    <span className="text-amber-400">₹60.00</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>CNG Fuel Burn:</span>
                    <span className="text-slate-200">1.6 kg (₹142)</span>
                  </div>
                  <div className="flex justify-between font-bold pt-1 border-t border-slate-800/80">
                    <span className="text-indigo-300">Total Route Cost:</span>
                    <span className="text-indigo-400 text-sm">₹202.00</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-3.5 rounded-2xl bg-emerald-950/30 border border-emerald-500/30 flex items-start gap-2 text-xs text-slate-200">
              <Sparkles className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <strong>AI Route Verdict:</strong> Taking the NH44 Elevated Highway costs ₹53 more overall (due to ₹115 toll vs extra fuel), but saves <strong>20 minutes</strong>. At an hourly rate of ₹495/hr, that 20 minutes is worth <strong>₹165 in earning opportunity</strong>. The toll route delivers higher net income.
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'EV_CHARGING' && (
        <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <BatteryCharging className="w-5 h-5 text-amber-400" />
                <span>EV Charging Optimization Network</span>
              </h3>
              <p className="text-xs text-slate-400">
                Live telemetry of high-speed DC commercial cab chargers with queue status and pricing
              </p>
            </div>

            <div className="flex items-center gap-2">
              <span className="px-3 py-1 rounded-xl bg-slate-950 border border-slate-800 text-xs text-emerald-400 font-mono font-bold">
                EV Battery: 68% • 138 km Range
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {evStations.map(station => (
              <div key={station.id} className="p-4 rounded-2xl bg-slate-950 border border-slate-800 hover:border-amber-500/50 transition space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                    {station.power}
                  </span>
                  <span className="text-xs font-black text-emerald-400 font-mono">
                    {station.waitTime} wait
                  </span>
                </div>

                <div>
                  <h4 className="text-sm font-bold text-white">{station.name}</h4>
                  <div className="text-xs text-slate-400 font-mono mt-0.5">
                    📍 {station.distance}
                  </div>
                </div>

                <div className="space-y-1.5 text-xs pt-2 border-t border-slate-800">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Guns:</span>
                    <span className="text-emerald-400 font-bold">{station.availableGuns}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Tariff:</span>
                    <span className="text-white font-mono">{station.price}</span>
                  </div>
                  <div className="text-[11px] text-slate-400 pt-1">
                    ☕ {station.amenities}
                  </div>
                </div>

                <button 
                  onClick={() => setActiveTab('MAP')}
                  className="w-full py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-slate-950 text-xs font-black transition flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Navigation className="w-3.5 h-3.5" />
                  <span>Navigate & Reserve Gun</span>
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeTab === 'PARKING' && (
        <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <ParkingCircle className="w-5 h-5 text-sky-400" />
                <span>Verified Cab Staging & Rest Bays</span>
              </h3>
              <p className="text-xs text-slate-400">
                Safe waiting parking lots, airport holding zones, and subsidized driver rest amenities
              </p>
            </div>

            <span className="text-xs font-mono text-sky-300 bg-sky-500/10 px-3 py-1 rounded-xl border border-sky-500/30">
              Karnataka Transport Department Approved
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {parkingHubs.map(hub => (
              <div key={hub.id} className="p-4 rounded-2xl bg-slate-950 border border-slate-800 hover:border-sky-500/50 transition space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-sky-400">
                    {hub.vacancyPercent}% Available
                  </span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                    {hub.occupiedSlots}/{hub.totalSlots} Full
                  </span>
                </div>

                <div>
                  <h4 className="text-sm font-bold text-white">{hub.name}</h4>
                  <div className="text-[11px] text-amber-400 mt-0.5">
                    ⚡ {hub.surgeStatus}
                  </div>
                </div>

                <div className="space-y-1.5 text-xs pt-2 border-t border-slate-800">
                  <div className="flex justify-between text-slate-400">
                    <span>Fee:</span>
                    <span className="text-white font-mono">{hub.fee}</span>
                  </div>
                  <div className="text-[11px] text-slate-400">
                    🛡️ {hub.security}
                  </div>
                  <div className="text-[11px] text-slate-300 pt-1">
                    ☕ {hub.driverFacilities}
                  </div>
                </div>

                <button 
                  onClick={() => setActiveTab('MAP')}
                  className="w-full py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer shadow-md shadow-sky-950"
                >
                  <Navigation className="w-3.5 h-3.5" />
                  <span>Navigate to Staging Bay</span>
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
};
