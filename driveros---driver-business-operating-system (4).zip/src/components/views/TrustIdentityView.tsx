import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Lock, 
  Key, 
  Smartphone, 
  UserCheck, 
  FileCheck, 
  History, 
  EyeOff, 
  Eye, 
  CheckCircle2, 
  AlertTriangle, 
  Sparkles, 
  Fingerprint, 
  Server, 
  RefreshCw,
  Award,
  ChevronRight
} from 'lucide-react';
import { DriverProfile } from '../../types';

interface TrustIdentityViewProps {
  driver: DriverProfile;
  privacyBlurActive?: boolean;
  onTogglePrivacyBlur?: () => void;
  onOpenDriverAuth?: () => void;
}

export const TrustIdentityView: React.FC<TrustIdentityViewProps> = ({
  driver,
  privacyBlurActive = false,
  onTogglePrivacyBlur,
  onOpenDriverAuth,
}) => {
  const [activeRole, setActiveRole] = useState<'OWNER_OPERATOR' | 'FLEET_LESSEE' | 'SUPER_ADMIN'>('OWNER_OPERATOR');
  const [isRefreshingVerification, setIsRefreshingVerification] = useState(false);
  const [maskedPhoneEnabled, setMaskedPhoneEnabled] = useState(true);

  const handleVerifyNow = () => {
    setIsRefreshingVerification(true);
    setTimeout(() => {
      setIsRefreshingVerification(false);
    }, 1000);
  };

  const auditEvents = [
    {
      id: 'AUD-9021',
      timestamp: 'Today, 18:24',
      action: 'Biometric Session Verified',
      device: 'Samsung Galaxy F54 (IMEI: 86493206718****)',
      location: 'Bengaluru NH44 Toll Plaza',
      status: 'VERIFIED',
    },
    {
      id: 'AUD-9020',
      timestamp: 'Today, 14:15',
      action: 'DigiLocker Parivahan RC Sync',
      device: 'DriverOS Secure Android Container',
      location: 'KA-05-AB-9821 Commercial Tourist Permit',
      status: 'VERIFIED',
    },
    {
      id: 'AUD-9019',
      timestamp: 'Today, 08:30',
      action: 'Duty Start & Alcohol / Fatigue Check',
      device: 'Front Camera IR Blink Sensor',
      location: 'Koramangala 4th Block',
      status: 'PASSED',
    },
    {
      id: 'AUD-9018',
      timestamp: 'Yesterday, 22:40',
      action: 'Direct Passenger Payment Cleared',
      device: 'NPCI UPI Dynamic QR Terminal',
      location: 'Kempegowda Airport T2',
      status: 'SETTLED',
    },
  ];

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-indigo-950/70 border border-slate-800 rounded-3xl p-5 shadow-2xl relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 uppercase">
                🔐 PILLAR 10 • TRUST & IDENTITY
              </span>
              <span className="text-xs text-slate-400 font-mono">
                DigiLocker • Parivahan • Zero-Trust Security
              </span>
            </div>
            <h1 className="text-xl font-black text-white flex items-center gap-2">
              <span>DRIVER VERIFICATION & PRIVACY SHIELD</span>
              <ShieldCheck className="w-5 h-5 text-indigo-400" />
            </h1>
            <p className="text-xs text-slate-300 max-w-2xl">
              Cryptographically verified driver credentials, government transport registry synchronization, biometric session management, and strict passenger privacy controls.
            </p>
          </div>

          <div className="flex items-center gap-2.5">
            {onTogglePrivacyBlur && (
              <button
                onClick={onTogglePrivacyBlur}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer border ${
                  privacyBlurActive
                    ? 'bg-rose-500/20 text-rose-300 border-rose-500/40 animate-pulse'
                    : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700'
                }`}
              >
                {privacyBlurActive ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                <span>{privacyBlurActive ? 'Privacy Blur ON' : 'Privacy Blur OFF'}</span>
              </button>
            )}

            <button
              onClick={onOpenDriverAuth}
              className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition flex items-center gap-2 shadow-lg shadow-indigo-600/20 cursor-pointer"
            >
              <Key className="w-3.5 h-3.5" />
              <span>Switch Driver Profile</span>
            </button>
          </div>
        </div>

        {/* 6 Capabilities Strip */}
        <div className="mt-4 pt-3 border-t border-slate-800/80 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 text-center text-[10px] font-bold">
          <div className="p-2 rounded-xl bg-slate-950/70 border border-slate-800 text-slate-300">
            1. 🪪 Driver Verification
          </div>
          <div className="p-2 rounded-xl bg-slate-950/70 border border-slate-800 text-indigo-400">
            2. 🚗 Vehicle Verification
          </div>
          <div className="p-2 rounded-xl bg-slate-950/70 border border-slate-800 text-emerald-400">
            3. 📱 Session / Device
          </div>
          <div className="p-2 rounded-xl bg-slate-950/70 border border-slate-800 text-teal-400">
            4. 👥 Role-Based Access
          </div>
          <div className="p-2 rounded-xl bg-slate-950/70 border border-slate-800 text-amber-400">
            5. 📜 Audit History
          </div>
          <div className="p-2 rounded-xl bg-slate-950/70 border border-slate-800 text-rose-400">
            6. 👁️ Privacy Controls
          </div>
        </div>
      </div>

      {/* Grid: Driver Verification Box & Vehicle Registry */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        
        {/* Left Col: Driver Identity & DigiLocker Badges */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center border border-indigo-500/30">
                <UserCheck className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">Government Driver Verification</h3>
                <p className="text-[11px] text-slate-400">Ministry of Road Transport & Highways (MoRTH)</p>
              </div>
            </div>

            <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3" />
              <span>DigiLocker Verified</span>
            </span>
          </div>

          <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-2.5 text-xs">
            <div className="flex justify-between items-center py-1 border-b border-slate-800/80">
              <span className="text-slate-400">Driver Full Name:</span>
              <span className="text-white font-bold">{driver.name}</span>
            </div>
            <div className="flex justify-between items-center py-1 border-b border-slate-800/80">
              <span className="text-slate-400">Commercial DL Number:</span>
              <span className="font-mono text-indigo-300 font-bold">{driver.commercialDlNumber}</span>
            </div>
            <div className="flex justify-between items-center py-1 border-b border-slate-800/80">
              <span className="text-slate-400">Karnataka RTO Badge:</span>
              <span className="font-mono text-emerald-400 font-bold">{driver.rtoBadgeNumber}</span>
            </div>
            <div className="flex justify-between items-center py-1 border-b border-slate-800/80">
              <span className="text-slate-400">Police Clearance Certificate:</span>
              <span className="text-emerald-300 font-bold">✓ Clear (Bengaluru City Police)</span>
            </div>
            <div className="flex justify-between items-center py-1">
              <span className="text-slate-400">Biometric Public Key Hash:</span>
              <span className="font-mono text-slate-400 text-[10px] truncate max-w-[200px]">
                {driver.biometricKeyFingerprint}
              </span>
            </div>
          </div>

          <div className="flex items-center justify-between pt-1">
            <div className="flex items-center gap-2">
              <Fingerprint className="w-4 h-4 text-emerald-400" />
              <span className="text-xs text-slate-300 font-medium">Hardware Biometrics Enabled</span>
            </div>
            <button
              onClick={handleVerifyNow}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
            >
              <RefreshCw className={`w-3 h-3 ${isRefreshingVerification ? 'animate-spin' : ''}`} />
              <span>Re-Sync DigiLocker</span>
            </button>
          </div>
        </div>

        {/* Right Col: Vehicle Verification & Parivahan RC Registry */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-teal-500/20 text-teal-400 flex items-center justify-center border border-teal-500/30">
                <FileCheck className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">Commercial Vehicle Parivahan RC</h3>
                <p className="text-[11px] text-slate-400">Vahan 4.0 Central Registry Integration</p>
              </div>
            </div>

            <span className="px-2.5 py-0.5 rounded-full bg-teal-500/20 text-teal-300 border border-teal-500/30 text-[10px] font-bold flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3" />
              <span>Commercial Active</span>
            </span>
          </div>

          <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-2.5 text-xs">
            <div className="flex justify-between items-center py-1 border-b border-slate-800/80">
              <span className="text-slate-400">Registration Plate:</span>
              <span className="font-mono text-white font-black text-sm">{driver.vehiclePlate}</span>
            </div>
            <div className="flex justify-between items-center py-1 border-b border-slate-800/80">
              <span className="text-slate-400">Vehicle Model & Fuel:</span>
              <span className="text-slate-200 font-bold">{driver.vehicleModel} ({driver.fuelType})</span>
            </div>
            <div className="flex justify-between items-center py-1 border-b border-slate-800/80">
              <span className="text-slate-400">Commercial Tourist Permit:</span>
              <span className="text-emerald-400 font-bold">Valid All-Karnataka (Till Nov 2027)</span>
            </div>
            <div className="flex justify-between items-center py-1 border-b border-slate-800/80">
              <span className="text-slate-400">Fitness Certificate (FC):</span>
              <span className="text-slate-200">Valid till 14 Dec 2026 (KA-05 RTO)</span>
            </div>
            <div className="flex justify-between items-center py-1">
              <span className="text-slate-400">FASTag NPCI ID:</span>
              <span className="font-mono text-amber-400 font-bold">34161FA0299104821</span>
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-teal-950/30 border border-teal-500/30 flex items-center justify-between text-xs">
            <span className="text-teal-300 font-medium">PUC Emission & Third Party Insurance Active</span>
            <span className="font-mono text-slate-400">ICICI Lombard</span>
          </div>
        </div>

      </div>

      {/* Role-Based Access & Session Security Controls */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        
        {/* Left 6 Cols: Role-Based Access & Privacy Controls */}
        <div className="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-4">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Lock className="w-4 h-4 text-indigo-400" />
            <span>Role-Based Access & Privacy Controls</span>
          </h3>

          <div className="space-y-3">
            {/* Roles selector */}
            <div className="space-y-1.5">
              <div className="text-xs text-slate-400 font-medium">Select Operational Role:</div>
              <div className="grid grid-cols-3 gap-2">
                {(['OWNER_OPERATOR', 'FLEET_LESSEE', 'SUPER_ADMIN'] as const).map(role => (
                  <button
                    key={role}
                    onClick={() => setActiveRole(role)}
                    className={`p-2.5 rounded-xl border text-xs font-bold transition cursor-pointer text-center ${
                      activeRole === role
                        ? 'bg-indigo-600 text-white border-indigo-500 shadow-md'
                        : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
                    }`}
                  >
                    {role.replace('_', ' ')}
                  </button>
                ))}
              </div>
            </div>

            {/* Privacy toggles */}
            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-bold text-white">Passenger Phone Number Masking</div>
                  <div className="text-[11px] text-slate-400">Virtual VoIP relay to prevent passenger harassment</div>
                </div>
                <button
                  onClick={() => setMaskedPhoneEnabled(!maskedPhoneEnabled)}
                  className={`w-11 h-6 rounded-full transition-colors flex items-center px-0.5 cursor-pointer ${
                    maskedPhoneEnabled ? 'bg-indigo-600 justify-end' : 'bg-slate-800 justify-start'
                  }`}
                >
                  <div className="w-5 h-5 rounded-full bg-white shadow-md" />
                </button>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-slate-800/80">
                <div>
                  <div className="font-bold text-white">Financial Screen Privacy Blur</div>
                  <div className="text-[11px] text-slate-400">Blurs rupee balances when passengers view screen</div>
                </div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                  {privacyBlurActive ? 'Active' : 'Disabled'}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Right 6 Cols: Audit History Trail */}
        <div className="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-3xl p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <History className="w-4 h-4 text-amber-400" />
              <span>Tamper-Proof Audit History</span>
            </h3>
            <span className="text-[10px] font-mono text-slate-500">
              SHA-256 Hash Chain
            </span>
          </div>

          <div className="space-y-2.5 max-h-[220px] overflow-y-auto pr-1">
            {auditEvents.map(event => (
              <div key={event.id} className="p-2.5 rounded-xl bg-slate-950 border border-slate-800/90 flex items-center justify-between text-xs">
                <div className="space-y-0.5">
                  <div className="font-bold text-white flex items-center gap-2">
                    <span>{event.action}</span>
                    <span className="text-[9px] font-mono px-1 rounded bg-slate-800 text-slate-400">{event.id}</span>
                  </div>
                  <div className="text-[11px] text-slate-400">
                    {event.device} • {event.location}
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-[10px] px-1.5 py-0.5 rounded font-mono font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                    {event.status}
                  </span>
                  <div className="text-[10px] text-slate-500 font-mono mt-0.5">
                    {event.timestamp}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

    </div>
  );
};
