import React, { useState } from 'react';
import { 
  Car, 
  Wrench, 
  ShieldCheck, 
  Wind, 
  FileText, 
  Fuel, 
  Clock, 
  CheckCircle2, 
  AlertTriangle, 
  Calendar, 
  Zap, 
  Upload,
  PlusCircle
} from 'lucide-react';
import { DriverProfile, DocumentRecord } from '../../types';

interface VehicleViewProps {
  driver: DriverProfile;
  documents: DocumentRecord[];
  activeSubItem: string;
  onSelectSubItem: (sub: string) => void;
  onUploadDocument?: (doc: DocumentRecord) => void;
}

export const VehicleView: React.FC<VehicleViewProps> = ({
  driver,
  documents,
  activeSubItem,
  onSelectSubItem,
}) => {
  return (
    <div className="space-y-6 pb-12">
      {/* Header & Sub-items */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 sm:p-4 shadow-lg">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-cyan-500/20 text-cyan-400">
              <Car className="w-5 h-5" />
            </span>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                Vehicle Compliance & Health
                <span className="text-xs font-mono px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 font-bold">
                  {driver.vehiclePlate}
                </span>
              </h2>
              <p className="text-xs text-slate-400">Commercial fitness, service reminders, insurance validity, PUC emissions, and garage logs.</p>
            </div>
          </div>
        </div>

        {/* Sub-item Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pt-3 border-t border-slate-800/80 mt-3 scrollbar-none">
          {[
            { id: 'profile', label: 'Vehicle Profile' },
            { id: 'service-reminder', label: 'Service Reminder' },
            { id: 'insurance', label: 'Insurance' },
            { id: 'pollution', label: 'Pollution (PUC)' },
            { id: 'documents', label: 'Documents' },
            { id: 'fuel-ev', label: 'Fuel/EV Tracking' },
            { id: 'maintenance-history', label: 'Maintenance History' },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => onSelectSubItem(tab.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-1.5 ${
                activeSubItem === tab.id
                  ? 'bg-cyan-500 text-slate-950 font-bold shadow'
                  : 'bg-slate-800/60 text-slate-300 hover:bg-slate-800 hover:text-white border border-slate-700/50'
              }`}
            >
              <span>{tab.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* SUB-VIEW 1: VEHICLE PROFILE */}
      {activeSubItem === 'profile' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-5">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white">Commercial Taxi Profile</h3>
            <span className="text-xs font-bold text-emerald-400 bg-emerald-500/20 px-2.5 py-1 rounded-full">
              RTO Active Commercial Cab
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
              <div className="text-slate-400 text-[10px]">Model & Spec</div>
              <div className="text-sm font-bold text-white mt-1">{driver.vehicleModel}</div>
              <div className="text-slate-500 text-[11px] mt-0.5">Commercial Tour Edition</div>
            </div>

            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
              <div className="text-slate-400 text-[10px]">Registration Plate</div>
              <div className="text-sm font-bold text-amber-400 font-mono mt-1">{driver.vehiclePlate}</div>
              <div className="text-slate-500 text-[11px] mt-0.5">Yellow Board Commercial</div>
            </div>

            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
              <div className="text-slate-400 text-[10px]">Fuel Propulsion</div>
              <div className="text-sm font-bold text-emerald-400 mt-1">{driver.fuelType} (Factory Fitted)</div>
              <div className="text-slate-500 text-[11px] mt-0.5">60L CNG Tank Capacity</div>
            </div>

            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
              <div className="text-slate-400 text-[10px]">RTO Badge Number</div>
              <div className="text-sm font-bold text-slate-200 font-mono mt-1">{driver.rtoBadgeNumber}</div>
              <div className="text-emerald-400 text-[11px] mt-0.5">Verified Commercial Driver</div>
            </div>

            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
              <div className="text-slate-400 text-[10px]">Commercial DL Number</div>
              <div className="text-sm font-bold text-slate-200 font-mono mt-1">{driver.commercialDlNumber}</div>
              <div className="text-slate-500 text-[11px] mt-0.5">LMV-TR Transport Valid</div>
            </div>

            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
              <div className="text-slate-400 text-[10px]">Chassis / VIN</div>
              <div className="text-sm font-bold text-slate-200 font-mono mt-1">MA3EWB41S00982142</div>
              <div className="text-slate-500 text-[11px] mt-0.5">BS-VI Phase 2 Compliant</div>
            </div>
          </div>
        </div>
      )}

      {/* SUB-VIEW 2: SERVICE REMINDER */}
      {activeSubItem === 'service-reminder' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Wrench className="w-5 h-5 text-amber-400" /> Predictive Maintenance Countdown
          </h3>

          <div className="space-y-3 text-xs">
            <div className="p-4 rounded-xl bg-slate-950 border border-amber-500/30 flex items-center justify-between">
              <div>
                <div className="font-bold text-white text-sm">Engine Oil & Oil Filter Replacement</div>
                <div className="text-slate-400 text-[11px]">Castrol Magnatec 5W-30 • Recommended interval: 10,000 km</div>
              </div>
              <div className="text-right">
                <div className="text-base font-black text-amber-400 font-mono">Due in 1,240 km</div>
                <div className="text-[10px] text-slate-400">~6 days driving</div>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
              <div>
                <div className="font-bold text-white text-sm">Front Brake Pads & Rotor Inspection</div>
                <div className="text-slate-400 text-[11px]">Brembo Commercial Grade • Wear remaining: 68%</div>
              </div>
              <div className="text-right">
                <div className="text-base font-black text-emerald-400 font-mono">Due in 4,800 km</div>
                <div className="text-[10px] text-slate-400">Safe for highway</div>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
              <div>
                <div className="font-bold text-white text-sm">Spark Plugs & CNG Injector Cleaning</div>
                <div className="text-slate-400 text-[11px]">NGK Iridium plugs for optimal fuel mileage</div>
              </div>
              <div className="text-right">
                <div className="text-base font-black text-emerald-400 font-mono">Due in 8,200 km</div>
                <div className="text-[10px] text-slate-400">Optimal status</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SUB-VIEW 3: INSURANCE VALIDITY */}
      {activeSubItem === 'insurance' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white">Commercial Taxi Comprehensive Insurance</h3>
            <span className="text-xs font-bold text-emerald-400 bg-emerald-500/20 px-2.5 py-1 rounded-full">
              Active Policy
            </span>
          </div>

          <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-3 text-xs">
            <div className="flex justify-between border-b border-slate-800 pb-2">
              <span className="text-slate-400">Insurer:</span>
              <span className="font-bold text-white">ICICI Lombard Commercial Motor</span>
            </div>
            <div className="flex justify-between border-b border-slate-800 pb-2">
              <span className="text-slate-400">Policy Number:</span>
              <span className="font-mono text-emerald-400 font-bold">3001/2026/98214201</span>
            </div>
            <div className="flex justify-between border-b border-slate-800 pb-2">
              <span className="text-slate-400">Insured Declared Value (IDV):</span>
              <span className="font-mono font-bold text-white">₹4,80,000</span>
            </div>
            <div className="flex justify-between border-b border-slate-800 pb-2">
              <span className="text-slate-400">Passenger Legal Liability:</span>
              <span className="font-mono font-bold text-white">Unlimited / Full Cover</span>
            </div>
            <div className="flex justify-between text-amber-400 font-bold pt-1">
              <span>Policy Expiry Date:</span>
              <span>18 Nov 2026 (64 days remaining)</span>
            </div>
          </div>
        </div>
      )}

      {/* SUB-VIEW 4: POLLUTION PUC */}
      {activeSubItem === 'pollution' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white">Pollution Under Control (PUC) Certificate</h3>
            <span className="text-xs font-bold text-emerald-400 bg-emerald-500/20 px-2.5 py-1 rounded-full">
              Valid & Compliant
            </span>
          </div>

          <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-2 text-xs">
            <div className="flex justify-between">
              <span className="text-slate-400">PUC Certificate No:</span>
              <span className="font-mono text-slate-200">KA050098210042</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">CO Level (Carbon Monoxide):</span>
              <span className="font-mono text-emerald-400">0.08% (Permitted: &lt;0.5%)</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Hydrocarbon (HC):</span>
              <span className="font-mono text-emerald-400">42 ppm (Permitted: &lt;750 ppm)</span>
            </div>
            <div className="flex justify-between font-bold text-amber-400 pt-2 border-t border-slate-800">
              <span>Next Renewal Date:</span>
              <span>24 Dec 2026</span>
            </div>
          </div>
        </div>
      )}

      {/* SUB-VIEW 5: DOCUMENTS ENCLAVE */}
      {activeSubItem === 'documents' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white">Encrypted Commercial Documents Vault</h3>
            <span className="text-xs text-slate-400">Traffic Police & RTO Inspection Ready</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            {documents.map((doc) => (
              <div key={doc.id} className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white">{doc.title}</span>
                  <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/20 px-2 py-0.5 rounded-full">
                    {doc.status}
                  </span>
                </div>
                <div className="text-slate-400 font-mono text-[11px]">{doc.documentNumber}</div>
                <div className="text-[10px] text-slate-500">Exp: {doc.expiryDate} ({doc.daysRemaining} days left)</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SUB-VIEW 6: FUEL/EV TRACKING */}
      {activeSubItem === 'fuel-ev' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Fuel className="w-5 h-5 text-amber-400" /> Fuel & Mileage Efficiency Tracking
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-center text-xs">
            <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl">
              <div className="text-slate-400 text-[10px]">Real-World Mileage</div>
              <div className="text-2xl font-black text-emerald-400 font-mono mt-1">26.4 km/kg</div>
              <div className="text-[10px] text-slate-500 mt-1">CNG with AC 50% on</div>
            </div>

            <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl">
              <div className="text-slate-400 text-[10px]">Cost Per Kilometer</div>
              <div className="text-2xl font-black text-amber-400 font-mono mt-1">₹3.16 / km</div>
              <div className="text-[10px] text-slate-500 mt-1">Based on ₹83.50/kg rate</div>
            </div>

            <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl">
              <div className="text-slate-400 text-[10px]">Fuel Tank Range</div>
              <div className="text-2xl font-black text-white font-mono mt-1">220 km</div>
              <div className="text-[10px] text-slate-500 mt-1">Full cylinder capacity</div>
            </div>
          </div>
        </div>
      )}

      {/* SUB-VIEW 7: MAINTENANCE HISTORY */}
      {activeSubItem === 'maintenance-history' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl space-y-4 text-xs">
          <h3 className="text-base font-bold text-white">Garage Invoices & Service History</h3>
          <div className="space-y-2">
            {[
              { service: '50,000 km Major Service (Synthetic Oil + Plugs + Filters)', cost: 3850, date: '12 Aug 2026', garage: 'Maruti Authorized Service, Koramangala' },
              { service: 'Front 2 Tyres Replacement (Bridgestone B290)', cost: 8400, date: '04 Jun 2026', garage: 'Apollo Tyre Zone, HSR' },
              { service: 'AC Gas Refill & Compressor Servicing', cost: 1650, date: '22 Apr 2026', garage: 'CoolCar Hub, BTM' },
            ].map((s, idx) => (
              <div key={idx} className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                <div>
                  <div className="font-bold text-white">{s.service}</div>
                  <div className="text-slate-400 text-[11px]">{s.garage} • {s.date}</div>
                </div>
                <div className="text-right">
                  <div className="font-black text-amber-400 font-mono">₹{s.cost.toLocaleString()}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
