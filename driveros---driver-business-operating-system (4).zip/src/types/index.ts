export type PlatformType = 'OLA' | 'UBER' | 'RAPIDO' | 'NAMMA_YATRI' | 'DIRECT_CLIENT';

export type ExpenseCategory = 
  | 'CNG_FUEL'
  | 'PETROL_DIESEL'
  | 'EV_CHARGE'
  | 'TOLL'
  | 'MAINTENANCE'
  | 'CAR_WASH'
  | 'INSURANCE_EMI'
  | 'VEHICLE_LOAN_EMI'
  | 'CHAI_SNACKS'
  | 'CHALLAN_RTO'
  | 'PARKING'
  | 'OTHER';

export interface DriverProfile {
  id: string;
  name: string;
  phone: string;
  email: string;
  city: string;
  vehicleModel: string;
  vehiclePlate: string;
  fuelType: 'CNG' | 'PETROL' | 'DIESEL' | 'EV';
  fuelMileageKmPerUnit: number;
  fuelPricePerUnit: number;
  rtoBadgeNumber: string;
  commercialDlNumber: string;
  yearsExperience: number;
  biometricKeyFingerprint: string;
  encryptionKeyHash: string;
  rating: number;
  totalTripsCount: number;
  isIdentityVerified: boolean;
  activeLanguage: 'en' | 'hi' | 'kn' | 'ta' | 'te' | 'mr';
}

export interface TripRecord {
  id: string;
  timestamp: string;
  platform: PlatformType;
  pickupLocation: string;
  dropoffLocation: string;
  distanceKm: number;
  durationMinutes: number;
  grossFare: number;
  platformCommission: number;
  platformCommissionRate?: number; // e.g. 0.28 for Ola
  fuelCost: number;
  tollCost: number;
  tips: number;
  netProfit: number;
  deadheadKm: number;
  passengerName?: string;
  passengerRating?: number;
  isPassengerVerified?: boolean;
  passengerSafetyBadge?: 'VERIFIED_CORP' | 'VERIFIED_STUDENT' | 'TOP_RATED' | 'STANDARD' | string;
  paymentMode: 'CASH' | 'UPI' | 'PLATFORM_WALLET' | 'DIRECT_TRANSFER' | 'WALLET' | 'CORP_ACCOUNT' | string;
  isSyncedToVault?: boolean;
  isEncrypted?: boolean;
  notes?: string;
}

export interface ExpenseRecord {
  id: string;
  date: string;
  category: ExpenseCategory;
  amount: number;
  merchantName: string;
  litresOrUnits?: string;
  paymentMethod: 'UPI' | 'FASTAG' | 'CASH' | 'CARD';
  isTaxDeductible: boolean;
  gstNumber?: string;
  receiptImageUrl?: string;
  ocrConfidence?: number;
  notes?: string;
  isEncrypted: boolean;
}

export interface DirectClient {
  id: string;
  name: string;
  phone: string;
  companyOrLocality?: string;
  clientType?: string;
  defaultPickup?: string;
  defaultDropoff?: string;
  preferredRoute?: string;
  agreedRate?: number; // ₹ per trip or ₹/km
  totalRidesCompleted?: number;
  totalTripsCompleted?: number;
  totalRevenueGenerated: number;
  preferredTiming?: string;
  notes: string;
  rating: number;
  isVip?: boolean;
  lastTripDate?: string;
  customRateCard?: string;
}

export type DirectClientRecord = DirectClient;

export interface RateCardItem {
  title: string;
  fixedPrice?: number;
  pricePerKm?: number;
  minimumFare?: number;
  description: string;
  badge: string;
}

export interface AuditLogRecord {
  id: string;
  timestamp: string;
  action: string;
  resource: string;
  performedBy: string;
  ipAddress: string;
  signature: string;
  verified: boolean;
}

export interface DocumentRecord {
  id: string;
  type: 'COMMERCIAL_DL' | 'RC_BOOK' | 'INSURANCE_POLICY' | 'PUC_CERTIFICATE' | 'ALL_INDIA_PERMIT' | 'FITNESS_CERTIFICATE' | 'RTO_BADGE';
  title: string;
  documentNumber: string;
  issueDate: string;
  expiryDate: string;
  daysRemaining: number;
  status: 'VALID' | 'EXPIRING_SOON' | 'EXPIRED';
  fileEncryptedHash: string;
  issuerAuthority: string;
}

export interface DemandSurgeCluster {
  id: string;
  zoneName: string;
  city: string;
  coordinates: { x: number; y: number }; // Relative map positioning
  lat?: number;
  lng?: number;
  surgeMultiplier: number;
  estimatedDemandScore: number; // 1-100
  avgWaitTimeMin: number;
  avgFarePerTrip: number;
  peakHourWindow: string;
  highValueRouteTarget: string;
  activeOlaDriverDensity: 'HIGH_COMPETITION' | 'MEDIUM' | 'LOW_HIGH_OPPORTUNITY';
}

export interface VerifiedRestAndFuelHub {
  id: string;
  name: string;
  type: 'VERIFIED_PARKING' | 'CNG_PUMP' | 'EV_FAST_CHARGER' | 'CHAI_REST_STOP' | 'CLEAN_WASHROOM';
  address: string;
  priceInfo: string;
  queueStatus: 'NO_QUEUE' | 'SHORT_QUEUE (5-10m)' | 'LONG_QUEUE (20m+)';
  rating: number;
  coordinates: { x: number; y: number };
  lat?: number;
  lng?: number;
  amenities: string[];
}

export interface SecurityAuditItem {
  id: string;
  timestamp: string;
  action: string;
  actor: string;
  ipHash: string;
  signature: string;
  status: 'AUTHORIZED' | 'BLOCKED' | 'VERIFIED';
  details: string;
}

export interface MicroInsuranceState {
  policyNumber: string;
  provider: string; // e.g., 'ICICI Lombard x DriverOS MicroShield'
  status: 'ACTIVE_ON_DUTY' | 'PAUSED';
  accidentalCoverAmount: number; // ₹5,00,000
  hospitalCashPerDay: number; // ₹1,500/day
  perTripCost: number; // ₹1.50 per trip
  totalCoveredTrips: number;
  lastClaimStatus: 'NONE' | 'PROCESSING' | 'APPROVED';
}

export interface FatigueMonitoringState {
  continuousDrivingMinutes: number;
  restBreakCountdownMinutes: number;
  fatigueScore: number; // 0 (Well Rested) to 100 (Critical Fatigue)
  isWarningTriggered: boolean;
  eyeClosureDetectedCount: number;
  lastBreakTimestamp: string;
  statusMessage: string;
}

export interface ShiftState {
  isOnDuty: boolean;
  shiftStartTime: string | null;
  currentOdometerKm: number;
  dailyGoalAmount: number;
}

export type MainPillar = 
  | 'HOME'
  | 'TODAY'
  | 'RIDE_WORK' 
  | 'DRIVER_INTELLIGENCE'
  | 'SMART_MOBILITY'
  | 'SMART_MAP'
  | 'SAATHI_AI' 
  | 'MONEY' 
  | 'VEHICLE' 
  | 'SAFETY' 
  | 'BUSINESS' 
  | 'DOCUMENT_BILL_ENGINE'
  | 'TRUST_IDENTITY'
  | 'REALTIME_OPERATIONS'
  | 'PLATFORM_HUB' 
  | 'INCENTIVES' 
  | 'PROBLEM_CENTER'
  | 'WORK' 
  | 'INSIGHTS'
  | 'CUSTOMER_BOOKING';

export type RideBookingStatus = 
  | 'pending'
  | 'searching'
  | 'accepted'
  | 'arriving'
  | 'started'
  | 'completed'
  | 'paid'
  | 'declined';

export type RideVehicleType = 'Mini' | 'Sedan' | 'XL' | 'Auto';

export interface RideBooking {
  id: string;
  createdAt: string;
  pickup: string;
  destination: string;
  distanceKm: number;
  estimatedDurationMin: number;
  fareEstimate: number; // e.g. 650
  rideType: RideVehicleType;
  customerName: string;
  customerPhone: string;
  status: RideBookingStatus;
  otp: string;
  driver: {
    name: string;
    phone: string;
    vehiclePlate: string;
    vehicleModel: string;
    rating: number;
    currentLocation?: { lat: number; lng: number };
  };
  breakdown: {
    baseFare: number;
    distanceFare: number;
    tollCost: number;
    platformTaxGst: number;
    driverEstimatedEarning: number;
  };
  liveTracking?: {
    driverLat: number;
    driverLng: number;
    etaMinutes: number;
    progressPercentage: number;
    currentSpeedKmH: number;
    bearing: number;
    nextStepText: string;
  };
  payment?: {
    mode: 'UPI' | 'CASH' | 'CARD';
    amount: number;
    paidAt: string;
    transactionRef: string;
    invoiceNumber: string;
    upiId?: string;
  };
}

