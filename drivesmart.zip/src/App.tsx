import { useState, useEffect } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { Navigation } from 'lucide-react';
import { RidePhase, RideTier, ActiveBooking, RideHistoryItem, UserProfile, SavedLocation, DriverStatus } from './types';
import {
  RIDE_TIERS,
  SAMPLE_DRIVERS,
  INITIAL_RIDE_HISTORY,
  SAVED_LOCATIONS,
  DEFAULT_USER_PROFILE,
  calculateRouteEstimate,
} from './data/mockData';
import LiveMap from './components/LiveMap';
import HomeScreen from './components/HomeScreen';
import RideOptionsSheet from './components/RideOptionsSheet';
import ConfirmBookingSheet from './components/ConfirmBookingSheet';
import DriverMatchingView from './components/DriverMatchingView';
import DriverFoundView from './components/DriverFoundView';
import LiveRideView from './components/LiveRideView';
import RideCompletedView from './components/RideCompletedView';
import MyRidesView from './components/MyRidesView';
import ProfileView from './components/ProfileView';
import BottomNav, { TabId } from './components/BottomNav';

const DEFAULT_CURRENT_LOCATION = 'Current location (Connaught Place, Central Delhi)';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabId>('home');
  const [ridePhase, setRidePhase] = useState<RidePhase>('idle');

  // Persistent User Profile
  const [userProfile, setUserProfile] = useState<UserProfile>(() => {
    try {
      const saved = localStorage.getItem('drivesmart_profile');
      return saved ? JSON.parse(saved) : DEFAULT_USER_PROFILE;
    } catch {
      return DEFAULT_USER_PROFILE;
    }
  });

  // Persistent Saved Locations
  const [savedLocations, setSavedLocations] = useState<SavedLocation[]>(() => {
    try {
      const saved = localStorage.getItem('drivesmart_saved_locs');
      return saved ? JSON.parse(saved) : SAVED_LOCATIONS;
    } catch {
      return SAVED_LOCATIONS;
    }
  });

  // Input states (Auto-fills pickup with current location)
  const [pickup, setPickup] = useState(DEFAULT_CURRENT_LOCATION);
  const [destination, setDestination] = useState('');
  const [selectedTier, setSelectedTier] = useState<RideTier>(RIDE_TIERS[0]);

  // Active ride state
  const [activeBooking, setActiveBooking] = useState<ActiveBooking | null>(null);

  // Persistent Ride History
  const [ridesHistory, setRidesHistory] = useState<RideHistoryItem[]>(() => {
    try {
      const saved = localStorage.getItem('drivesmart_history');
      return saved ? JSON.parse(saved) : INITIAL_RIDE_HISTORY;
    } catch {
      return INITIAL_RIDE_HISTORY;
    }
  });

  // Sync profile to localStorage
  const handleUpdateProfile = (updated: UserProfile) => {
    setUserProfile(updated);
    try {
      localStorage.setItem('drivesmart_profile', JSON.stringify(updated));
    } catch {}
  };

  // Sync saved locations to localStorage
  const handleUpdateLocation = (id: string, newAddress: string) => {
    setSavedLocations((prev) => {
      const next = prev.map((l) => (l.id === id ? { ...l, address: newAddress } : l));
      try {
        localStorage.setItem('drivesmart_saved_locs', JSON.stringify(next));
      } catch {}
      return next;
    });
  };

  // Sync history to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('drivesmart_history', JSON.stringify(ridesHistory));
    } catch {}
  }, [ridesHistory]);

  // Handlers for Ride Flow
  const handleFindRide = () => {
    setRidePhase('selecting_tier');
  };

  const handleBookRide = () => {
    setRidePhase('confirming');
  };

  // FAST BOOKING (QUICK BOOK): Skips typing and tier selection, goes directly to Confirmation!
  const handleQuickBook = (quickDest: string) => {
    setDestination(quickDest);
    setSelectedTier(RIDE_TIERS[0]); // Default to Smart for fast daily commute
    setActiveTab('home');
    setRidePhase('confirming');
  };

  // 1-TAP RIDE AGAIN: Reuses previous route & tier and jumps directly to Confirmation!
  const handleBookAgain = (ride: RideHistoryItem) => {
    setPickup(ride.pickup);
    setDestination(ride.destination);
    const matchedTier = RIDE_TIERS.find((t) => t.name === ride.tierName) || RIDE_TIERS[0];
    setSelectedTier(matchedTier);
    setActiveTab('home');
    setRidePhase('confirming');
  };

  // Confirm ride -> Initiates Smart Driver Matching radar
  const handleConfirmRide = () => {
    setRidePhase('matching');
  };

  // When smart driver matching completes: Assign driver and transition to driver_found
  const handleDriverMatched = () => {
    const driverIndex = selectedTier.id === 'smart' ? 1 : selectedTier.id === 'comfort' ? 0 : 2;
    const assignedDriver = SAMPLE_DRIVERS[driverIndex] || SAMPLE_DRIVERS[0];
    const estimate = calculateRouteEstimate(destination);

    const newBooking: ActiveBooking = {
      id: `DS-${Math.floor(1000 + Math.random() * 9000)}`,
      pickup,
      pickupCoords: { x: 340, y: 520 },
      destination,
      destinationCoords: { x: 740, y: 240 },
      tier: selectedTier,
      fare: selectedTier.fare,
      paymentMethod: userProfile.defaultPayment || 'DriveSmart UPI (•••4829)',
      driver: assignedDriver,
      createdAt: 'Just now',
      status: 'driver_en_route',
      distanceKm: estimate.distanceKm,
      durationMins: estimate.durationMins,
    };

    setActiveBooking(newBooking);
    setRidePhase('driver_found');
  };

  const handleUpdateDriverStatus = (status: DriverStatus) => {
    if (activeBooking) {
      setActiveBooking({
        ...activeBooking,
        status,
      });
    }
  };

  const handleCancelRide = () => {
    if (activeBooking) {
      const cancelledItem: RideHistoryItem = {
        id: activeBooking.id,
        pickup: activeBooking.pickup,
        destination: activeBooking.destination,
        date: 'Just now',
        fare: activeBooking.fare,
        tierName: activeBooking.tier.name,
        vehicleName: `${activeBooking.driver.vehicle} • ${activeBooking.driver.vehicleNumber}`,
        status: 'Cancelled',
        paymentMethod: 'UPI (Refunded)',
      };
      setRidesHistory((prev) => [cancelledItem, ...prev]);
    }
    setActiveBooking(null);
    setRidePhase('idle');
  };

  const handleStartTrip = () => {
    if (activeBooking) {
      setActiveBooking({
        ...activeBooking,
        status: 'on_trip',
      });
    }
    setRidePhase('in_progress');
  };

  const handleCompleteTrip = () => {
    if (activeBooking) {
      setActiveBooking({
        ...activeBooking,
        status: 'completed',
      });
    }
    setRidePhase('completed');
  };

  const handleFinishRating = (rating: number, feedbackTags: string[]) => {
    if (activeBooking) {
      const completedItem: RideHistoryItem = {
        id: activeBooking.id,
        pickup: activeBooking.pickup,
        destination: activeBooking.destination,
        date: 'Today, Just now',
        fare: activeBooking.fare,
        tierName: activeBooking.tier.name,
        vehicleName: `${activeBooking.driver.vehicle} • ${activeBooking.driver.vehicleNumber}`,
        status: 'Completed',
        rating,
        duration: `${activeBooking.durationMins || 18} mins`,
        distance: `${activeBooking.distanceKm || 8.4} km`,
        paymentMethod: activeBooking.paymentMethod,
      };
      setRidesHistory((prev) => [completedItem, ...prev]);
    }

    setActiveBooking(null);
    setRidePhase('idle');
    setDestination('');
  };

  const isRideActive =
    ridePhase === 'matching' ||
    ridePhase === 'driver_found' ||
    ridePhase === 'in_progress' ||
    ridePhase === 'completed';

  return (
    <div className="min-h-screen w-full bg-[#06080B] text-slate-100 flex items-center justify-center p-0 md:p-6 overflow-hidden">
      {/* Mobile Device Frame Container */}
      <div className="relative w-full h-screen md:h-[844px] md:max-w-[420px] md:rounded-[44px] bg-[#090C12] md:border-4 md:border-[#1E2533] md:shadow-[0_25px_70px_rgba(0,0,0,0.8),0_0_30px_rgba(0,240,255,0.08)] flex flex-col overflow-hidden">
        {/* App Top Bar */}
        <header
          id="app-top-header"
          className="w-full bg-[#0A0D14]/90 border-b border-white/[0.06] backdrop-blur-xl px-5 py-3.5 flex items-center justify-between z-30 shrink-0 select-none"
        >
          {/* DriveSmart Brand Logo */}
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-cyan-400 to-cyan-600 flex items-center justify-center shadow-[0_0_15px_rgba(0,240,255,0.4)]">
              <Navigation className="w-4 h-4 text-slate-950 stroke-[2.5] rotate-45" />
            </div>
            <div className="flex items-baseline gap-1">
              <span className="font-extrabold text-lg tracking-tight text-white font-sans">
                Drive<span className="text-cyan-400">Smart</span>
              </span>
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 shadow-[0_0_8px_rgba(0,240,255,0.9)]" />
            </div>
          </div>

          {/* Quick Status / Reset shortcut */}
          <div className="flex items-center gap-2">
            {ridePhase !== 'idle' && (
              <button
                id="reset-to-home-btn"
                onClick={() => {
                  setRidePhase('idle');
                  setActiveBooking(null);
                }}
                className="text-[11px] font-semibold text-slate-400 hover:text-cyan-300 px-2.5 py-1 rounded-full bg-white/5 border border-white/10 transition-colors cursor-pointer"
                title="Reset to clean Home"
              >
                Reset
              </button>
            )}

            <div className="flex items-center gap-1 text-[11px] font-medium text-cyan-300 bg-cyan-500/10 px-2.5 py-1 rounded-full border border-cyan-500/20">
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
              <span>Customer</span>
            </div>
          </div>
        </header>

        {/* Main Content Body */}
        <main id="main-content-area" className="flex-1 relative flex flex-col overflow-hidden">
          {/* TAB 1: HOME (Hosts the Ride Booking Lifecycle + Vector Live Map) */}
          {activeTab === 'home' && (
            <div className="relative w-full h-full flex flex-col overflow-hidden">
              {/* UPPER SECTION: Vector Live Map */}
              <div
                id="map-viewport-section"
                className={`relative w-full transition-all duration-500 ease-in-out ${
                  ridePhase === 'idle'
                    ? 'h-[40%]'
                    : ridePhase === 'driver_found' || ridePhase === 'in_progress'
                    ? 'h-[50%]'
                    : ridePhase === 'matching'
                    ? 'h-[36%]'
                    : 'h-[34%]'
                }`}
              >
                <LiveMap
                  phase={ridePhase}
                  pickupLabel={pickup}
                  destinationLabel={destination || 'Select Destination'}
                />

                {/* Subtle map gradient fade overlay at bottom */}
                <div className="absolute bottom-0 inset-x-0 h-10 bg-gradient-to-t from-[#090C12] to-transparent pointer-events-none" />
              </div>

              {/* LOWER SECTION: Interactive Card / Sheet */}
              <div
                id="booking-flow-card-section"
                className="flex-1 overflow-y-auto px-4 py-2 scrollbar-none z-10 -mt-3"
              >
                <AnimatePresence mode="wait">
                  {/* 1. HOME: Search, Smart Auto-Pickup, Suggestions & Quick Book */}
                  {ridePhase === 'idle' && (
                    <motion.div
                      key="home-step"
                      initial={{ opacity: 0, y: 15 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      transition={{ duration: 0.25 }}
                    >
                      <HomeScreen
                        pickup={pickup}
                        destination={destination}
                        setPickup={setPickup}
                        setDestination={setDestination}
                        onFindRide={handleFindRide}
                        onQuickBook={handleQuickBook}
                        savedLocations={savedLocations}
                      />
                    </motion.div>
                  )}

                  {/* 2. RIDE OPTIONS: Smart, Comfort, XL with Automated Route Calculation */}
                  {ridePhase === 'selecting_tier' && (
                    <motion.div
                      key="options-step"
                      initial={{ opacity: 0, y: 15 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      transition={{ duration: 0.25 }}
                    >
                      <RideOptionsSheet
                        pickup={pickup}
                        destination={destination}
                        selectedTier={selectedTier}
                        onSelectTier={setSelectedTier}
                        onBookRide={handleBookRide}
                        onBack={() => setRidePhase('idle')}
                      />
                    </motion.div>
                  )}

                  {/* 3. CONFIRM BOOKING: Summary with Pre-filled Profile & Saved Payment */}
                  {ridePhase === 'confirming' && (
                    <motion.div
                      key="confirm-step"
                      initial={{ opacity: 0, y: 15 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      transition={{ duration: 0.25 }}
                    >
                      <ConfirmBookingSheet
                        pickup={pickup}
                        destination={destination}
                        tier={selectedTier}
                        userProfile={userProfile}
                        onConfirmRide={handleConfirmRide}
                        onBack={() => setRidePhase('selecting_tier')}
                      />
                    </motion.div>
                  )}

                  {/* 3.5 SMART DRIVER MATCHING: Concentric radar animation and instant dispatch */}
                  {ridePhase === 'matching' && (
                    <motion.div
                      key="matching-step"
                      initial={{ opacity: 0, scale: 0.96 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.96 }}
                      transition={{ duration: 0.25 }}
                    >
                      <DriverMatchingView
                        tier={selectedTier}
                        destination={destination}
                        onMatched={handleDriverMatched}
                      />
                    </motion.div>
                  )}

                  {/* 4. DRIVER FOUND: Driver details, live countdown, Call Driver, Cancel, Arrival status */}
                  {ridePhase === 'driver_found' && activeBooking && (
                    <motion.div
                      key="driver-found-step"
                      initial={{ opacity: 0, y: 15 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      transition={{ duration: 0.25 }}
                    >
                      <DriverFoundView
                        driver={activeBooking.driver}
                        tier={activeBooking.tier}
                        pickup={activeBooking.pickup}
                        destination={activeBooking.destination}
                        driverStatus={activeBooking.status}
                        onUpdateDriverStatus={handleUpdateDriverStatus}
                        onCancelRide={handleCancelRide}
                        onStartRide={handleStartTrip}
                      />
                    </motion.div>
                  )}

                  {/* 5. LIVE RIDE: Ride in progress, progress bar, minimal SAFETY button (SOS 112, Share), auto-arrival */}
                  {ridePhase === 'in_progress' && activeBooking && (
                    <motion.div
                      key="live-ride-step"
                      initial={{ opacity: 0, y: 15 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      transition={{ duration: 0.25 }}
                    >
                      <LiveRideView
                        destination={activeBooking.destination}
                        driver={activeBooking.driver}
                        tier={activeBooking.tier}
                        fare={activeBooking.fare}
                        initialDistanceKm={activeBooking.distanceKm}
                        initialDurationMins={activeBooking.durationMins}
                        onCompleteRide={handleCompleteTrip}
                      />
                    </motion.div>
                  )}

                  {/* 6. RIDE COMPLETED: Journey Complete, fare, distance, duration, payment status, rate ride */}
                  {ridePhase === 'completed' && activeBooking && (
                    <motion.div
                      key="completed-step"
                      initial={{ opacity: 0, y: 15 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      transition={{ duration: 0.25 }}
                    >
                      <RideCompletedView
                        destination={activeBooking.destination}
                        driver={activeBooking.driver}
                        tier={activeBooking.tier}
                        fare={activeBooking.fare}
                        paymentMethod={activeBooking.paymentMethod}
                        distanceKm={activeBooking.distanceKm}
                        durationMins={activeBooking.durationMins}
                        onFinishRating={handleFinishRating}
                      />
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>
          )}

          {/* TAB 2: MY RIDES (History list with 1-Tap 'RIDE AGAIN' and receipt modal) */}
          {activeTab === 'rides' && (
            <div className="flex-1 overflow-y-auto p-4 scrollbar-none">
              <MyRidesView
                rides={ridesHistory}
                onBookAgain={handleBookAgain}
              />
            </div>
          )}

          {/* TAB 3: PROFILE (Clean customer profile: Name, Phone, Saved Places, Payment, Support) */}
          {activeTab === 'profile' && (
            <div className="flex-1 overflow-y-auto p-4 scrollbar-none">
              <ProfileView
                profile={userProfile}
                onUpdateProfile={handleUpdateProfile}
                savedLocations={savedLocations}
                onUpdateLocation={handleUpdateLocation}
              />
            </div>
          )}
        </main>

        {/* BOTTOM NAVIGATION: HOME | MY RIDES | PROFILE */}
        <BottomNav
          activeTab={activeTab}
          onTabChange={(tab) => setActiveTab(tab)}
          hasActiveRide={isRideActive}
        />
      </div>
    </div>
  );
}
