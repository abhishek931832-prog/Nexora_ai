import { Home, Clock, User } from 'lucide-react';

export type TabId = 'home' | 'rides' | 'profile';

interface BottomNavProps {
  activeTab: TabId;
  onTabChange: (tab: TabId) => void;
  hasActiveRide?: boolean;
}

export default function BottomNav({
  activeTab,
  onTabChange,
  hasActiveRide = false,
}: BottomNavProps) {
  const tabs: { id: TabId; label: string; icon: typeof Home }[] = [
    { id: 'home', label: 'HOME', icon: Home },
    { id: 'rides', label: 'MY RIDES', icon: Clock },
    { id: 'profile', label: 'PROFILE', icon: User },
  ];

  return (
    <nav
      id="bottom-navigation-bar"
      aria-label="Main Navigation"
      className="w-full bg-[#0D1118]/95 border-t border-white/[0.08] backdrop-blur-2xl px-6 py-2 shadow-2xl shrink-0"
    >
      <div className="max-w-md mx-auto flex items-center justify-around">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          const Icon = tab.icon;

          return (
            <button
              key={tab.id}
              id={`nav-tab-${tab.id}`}
              onClick={() => onTabChange(tab.id)}
              className={`flex flex-col items-center justify-center py-1.5 px-4 rounded-2xl transition-all relative select-none cursor-pointer ${
                isActive
                  ? 'text-cyan-400 font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <div className="relative">
                <Icon
                  className={`w-5 h-5 transition-transform duration-200 ${
                    isActive ? 'scale-110 stroke-[2.4]' : 'stroke-[1.8]'
                  }`}
                />
                {/* Active Ride indicator dot on HOME */}
                {tab.id === 'home' && hasActiveRide && (
                  <span className="absolute -top-0.5 -right-1 flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-cyan-400"></span>
                  </span>
                )}
              </div>

              <span className="text-[10px] tracking-wider mt-1 font-semibold">
                {tab.label}
              </span>

              {/* Active Tab Cyan underline indicator */}
              {isActive && (
                <div className="w-4 h-0.5 rounded-full bg-cyan-400 mt-0.5 shadow-[0_0_8px_rgba(0,240,255,0.8)]" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
}
