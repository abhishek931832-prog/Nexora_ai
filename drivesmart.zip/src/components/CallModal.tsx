import { useState, useEffect } from 'react';
import { PhoneOff, Mic, MicOff, Volume2, VolumeX, ShieldCheck } from 'lucide-react';
import { DriverInfo } from '../types';

interface CallModalProps {
  driver: DriverInfo;
  onClose: () => void;
}

export default function CallModal({ driver, onClose }: CallModalProps) {
  const [seconds, setSeconds] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [isSpeaker, setIsSpeaker] = useState(true);

  useEffect(() => {
    const timer = setInterval(() => {
      setSeconds((s) => s + 1);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTime = (totalSec: number) => {
    const m = Math.floor(totalSec / 60);
    const s = totalSec % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-sm rounded-3xl bg-[#0F141E] border border-cyan-500/30 p-6 text-center shadow-2xl flex flex-col items-center">
        {/* DriveSmart VoIP Masking Badge */}
        <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-[11px] font-semibold text-cyan-300 mb-6">
          <ShieldCheck className="w-3.5 h-3.5" />
          <span>DriveSmart Number Masking Active</span>
        </div>

        {/* Driver Photo Avatar */}
        <div className="relative mb-4">
          <div className="w-24 h-24 rounded-full overflow-hidden border-2 border-cyan-400 p-0.5 shadow-[0_0_20px_rgba(0,240,255,0.3)]">
            <img
              src={driver.photoUrl}
              alt={driver.name}
              className="w-full h-full object-cover rounded-full"
            />
          </div>
          <div className="absolute bottom-0 right-0 w-6 h-6 rounded-full bg-emerald-500 border-2 border-[#0F141E] flex items-center justify-center">
            <span className="w-2 h-2 rounded-full bg-white animate-pulse" />
          </div>
        </div>

        <h3 className="text-xl font-bold text-white mb-0.5">
          {driver.name}
        </h3>
        <p className="text-xs text-slate-400 mb-2">
          {driver.vehicle} • {driver.vehicleNumber}
        </p>
        <p className="text-sm font-mono text-cyan-400 font-bold mb-8">
          {seconds === 0 ? 'Connecting...' : formatTime(seconds)}
        </p>

        {/* In-Call Controls */}
        <div className="flex items-center justify-center gap-5 mb-8">
          <button
            id="call-mute-toggle"
            onClick={() => setIsMuted(!isMuted)}
            className={`w-12 h-12 rounded-full flex items-center justify-center border transition-all ${
              isMuted
                ? 'bg-rose-500/20 border-rose-400 text-rose-300'
                : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10'
            }`}
          >
            {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>

          <button
            id="call-speaker-toggle"
            onClick={() => setIsSpeaker(!isSpeaker)}
            className={`w-12 h-12 rounded-full flex items-center justify-center border transition-all ${
              isSpeaker
                ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300'
                : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10'
            }`}
          >
            {isSpeaker ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
          </button>
        </div>

        {/* End Call Button */}
        <button
          id="end-call-btn"
          onClick={onClose}
          className="w-full py-3.5 rounded-2xl bg-rose-600 hover:bg-rose-500 active:scale-[0.99] text-white font-bold text-sm tracking-wide flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(225,29,72,0.4)] cursor-pointer"
        >
          <PhoneOff className="w-5 h-5" />
          <span>END CALL</span>
        </button>
      </div>
    </div>
  );
}
