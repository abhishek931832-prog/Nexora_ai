import { useState } from 'react';
import { ArrowLeft, Clock, CreditCard, CheckCircle2, ShieldCheck, Car, ArrowRight, UserCheck } from 'lucide-react';
import { RideTier, UserProfile } from '../types';

interface ConfirmBookingSheetProps {
  pickup: string;
  destination: string;
  tier: RideTier;
  userProfile: UserProfile;
  onConfirmRide: () => void;
  onBack: () => void;
}

export default function ConfirmBookingSheet({
  pickup,
  destination,
  tier,
  userProfile,
  onConfirmRide,
  onBack,
}: ConfirmBookingSheetProps) {
  const [paymentMethod, setPaymentMethod] = useState<string>(userProfile.defaultPayment || 'DriveSmart UPI (•••4829)');
  const [showPaymentPicker, setShowPaymentPicker] = useState(false);

  const paymentOptions = [
    'DriveSmart UPI (•••4829)',
    'Credit Card (•••9012)',
    'Cash on Arrival',
  ];

  return (
    <div className="w-full flex flex-col gap-3">
      {/* Header with back navigation */}
      <div className="flex items-center justify-between px-1">
        <button
          id="back-to-options-btn"
          onClick={onBack}
          className="flex items-center gap-1.5 text-xs font-semibold text-slate-400 hover:text-white px-3 py-1.5 rounded-full bg-[#141822]/80 border border-white/10 active:scale-95 transition-all cursor-pointer"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Change Option</span>
        </button>

        <span className="text-xs font-semibold tracking-wide text-cyan-400">
          Booking Summary
        </span>
      </div>

      {/* Main Confirmation Glass Card */}
      <div className="rounded-3xl bg-[#10141C]/95 border border-white/[0.08] p-5 shadow-2xl backdrop-blur-xl">
        {/* Route Summary: Pickup ↓ Destination */}
        <div className="relative pl-6 pb-4 border-b border-white/[0.08]">
          {/* Visual Route Indicator */}
          <div className="absolute left-0 top-1.5 bottom-2 flex flex-col items-center">
            <div className="w-2.5 h-2.5 rounded-full bg-cyan-400 ring-2 ring-cyan-400/25" />
            <div className="w-0.5 flex-1 bg-gradient-to-b from-cyan-400 to-rose-400 my-1 opacity-70" />
            <div className="w-2.5 h-2.5 rounded-full bg-rose-400 ring-2 ring-rose-400/25" />
          </div>

          {/* Pickup Node */}
          <div className="mb-3">
            <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              Pickup
            </div>
            <div className="text-sm font-semibold text-white truncate">
              {pickup}
            </div>
          </div>

          {/* Destination Node */}
          <div>
            <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              Destination
            </div>
            <div className="text-sm font-semibold text-white truncate">
              {destination}
            </div>
          </div>
        </div>

        {/* Vehicle & ETA Details */}
        <div className="grid grid-cols-2 gap-2.5 py-3.5 border-b border-white/[0.08]">
          <div className="p-3 rounded-2xl bg-[#151A25] border border-white/5">
            <div className="text-[11px] text-slate-400 flex items-center gap-1 mb-1">
              <Car className="w-3.5 h-3.5 text-cyan-400" />
              <span>Vehicle</span>
            </div>
            <div className="text-sm font-bold text-white">
              {tier.name}
            </div>
            <div className="text-[11px] text-slate-400 truncate">
              {tier.vehicleModel} • {tier.seats} seats
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-[#151A25] border border-white/5">
            <div className="text-[11px] text-slate-400 flex items-center gap-1 mb-1">
              <Clock className="w-3.5 h-3.5 text-cyan-400" />
              <span>Driver ETA</span>
            </div>
            <div className="text-sm font-bold text-white font-mono">
              {tier.etaMinutes} mins
            </div>
            <div className="text-[11px] text-emerald-400">
              Immediate pickup
            </div>
          </div>
        </div>

        {/* Fare & Payment method */}
        <div className="py-3.5 space-y-3 border-b border-white/[0.08]">
          {/* Fare line */}
          <div className="flex items-center justify-between">
            <div>
              <span className="text-xs text-slate-400 block font-medium">
                Estimated Fare
              </span>
              <span className="text-[11px] text-slate-500">
                Guaranteed upfront price
              </span>
            </div>
            <span className="text-2xl font-black font-mono text-cyan-300">
              ₹{tier.fare}
            </span>
          </div>

          {/* Pre-filled Payment Method */}
          <div className="p-3 rounded-2xl bg-[#141924] border border-white/5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400">
                  <CreditCard className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-[10px] text-slate-400 uppercase font-semibold">
                    Payment Method
                  </div>
                  <div className="text-xs font-bold text-white">
                    {paymentMethod}
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setShowPaymentPicker(!showPaymentPicker)}
                className="text-xs font-semibold text-cyan-400 hover:text-cyan-300 px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 transition-colors"
              >
                {showPaymentPicker ? 'Done' : 'Change'}
              </button>
            </div>

            {/* Quick dropdown if customer wants to switch */}
            {showPaymentPicker && (
              <div className="mt-3 pt-2 border-t border-white/10 space-y-1.5">
                {paymentOptions.map((opt) => (
                  <button
                    key={opt}
                    onClick={() => {
                      setPaymentMethod(opt);
                      setShowPaymentPicker(false);
                    }}
                    className={`w-full text-left px-3 py-2 rounded-xl text-xs flex items-center justify-between transition-colors ${
                      paymentMethod === opt
                        ? 'bg-cyan-500/20 text-cyan-300 font-bold border border-cyan-500/30'
                        : 'text-slate-300 hover:bg-white/5'
                    }`}
                  >
                    <span>{opt}</span>
                    {paymentMethod === opt && <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Pre-filled Profile Notice */}
          <div className="flex items-center gap-2 px-1 text-[11px] text-slate-400">
            <UserCheck className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
            <span className="truncate">
              Booking for <strong className="text-white">{userProfile.name}</strong> ({userProfile.phone})
            </span>
          </div>
        </div>

        {/* Main Action: CONFIRM RIDE */}
        <button
          id="confirm-ride-btn"
          onClick={onConfirmRide}
          className="mt-4 w-full py-4 px-6 rounded-2xl bg-cyan-400 hover:bg-cyan-300 active:scale-[0.99] text-slate-950 font-bold text-base tracking-wide flex items-center justify-center gap-2 shadow-[0_0_25px_rgba(0,240,255,0.35)] transition-all cursor-pointer"
        >
          <span>CONFIRM RIDE</span>
          <ArrowRight className="w-5 h-5 stroke-[2.5]" />
        </button>
      </div>
    </div>
  );
}
