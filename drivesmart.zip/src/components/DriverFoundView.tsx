import { useState, useEffect } from 'react';
import { Phone, X, Star, Shield, Car, Check, ArrowRight, Clock, AlertTriangle } from 'lucide-react';
import { DriverInfo, RideTier, DriverStatus } from '../types';
import CallModal from './CallModal';

interface DriverFoundViewProps {
  driver: DriverInfo;
  tier: RideTier;
  pickup: string;
  destination: string;
  driverStatus: DriverStatus;
  onUpdateDriverStatus: (status: DriverStatus) => void;
  onCancelRide: () => void;
  onStartRide: () => void;
}

export default function DriverFoundView({
  driver,
  tier,
  pickup,
  destination,
  driverStatus,
  onUpdateDriverStatus,
  onCancelRide,
  onStartRide,
}: DriverFoundViewProps) {
  const [etaSeconds, setEtaSeconds] = useState(120); // 2 mins countdown
  const [isCalling, setIsCalling] = useState(false);
  const [showCancelConfirm, setShowCancelConfirm] = useState(false);

  const isArrived = driverStatus === 'driver_arrived';

  // Countdown timer for realistic ETA and automatic arrival detection
  useEffect(() => {
    if (isArrived) return;

    const interval = setInterval(() => {
      setEtaSeconds((prev) => {
        if (prev <= 1) {
          onUpdateDriverStatus('driver_arrived');
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isArrived, onUpdateDriverStatus]);

  const minutes = Math.floor(etaSeconds / 60);
  const seconds = etaSeconds % 60;

  return (
    <div className="w-full flex flex-col gap-3">
      {/* Driver Card */}
      <div className="rounded-3xl bg-[#10141C]/95 border border-white/[0.08] p-5 shadow-2xl backdrop-blur-xl">
        {/* Status header banner */}
        <div className="flex items-center justify-between pb-3.5 border-b border-white/[0.08]">
          <div className="flex items-center gap-2">
            <span className="relative flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-cyan-400"></span>
            </span>
            <span className="text-base font-extrabold text-white tracking-tight">
              {isArrived ? 'Driver has arrived!' : 'Driver is on the way'}
            </span>
          </div>

          <div className="text-right">
            {isArrived ? (
              <span className="text-xs font-bold text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-full border border-emerald-500/30">
                At Pickup Point
              </span>
            ) : (
              <div className="text-xs font-mono font-bold text-cyan-300">
                ETA {minutes}m {seconds < 10 ? `0${seconds}` : seconds}s
              </div>
            )}
          </div>
        </div>

        {/* Driver Photo, Name, Vehicle & Plate Number */}
        <div className="py-4 flex items-center justify-between">
          <div className="flex items-center gap-3.5">
            {/* Driver Photo */}
            <div className="relative">
              <div className="w-14 h-14 rounded-2xl overflow-hidden border-2 border-cyan-400/80 shadow-[0_0_15px_rgba(0,240,255,0.25)]">
                <img
                  src={driver.photoUrl}
                  alt={driver.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute -bottom-1 -right-1 px-1.5 py-0.5 rounded-full bg-[#0A0D14] border border-cyan-500/40 text-[10px] text-cyan-300 font-bold flex items-center gap-0.5">
                <Star className="w-2.5 h-2.5 fill-cyan-400 text-cyan-400" />
                <span>{driver.rating}</span>
              </div>
            </div>

            {/* Driver & Car Details */}
            <div>
              <h3 className="text-base font-bold text-white leading-tight">
                {driver.name}
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                {driver.vehicle}
              </p>
              <div className="inline-block mt-1 px-2.5 py-0.5 rounded-lg bg-white/10 border border-white/10 font-mono font-bold text-xs tracking-wider text-white">
                {driver.vehicleNumber}
              </div>
            </div>
          </div>

          {/* Verification OTP / Safety PIN */}
          <div className="p-2.5 rounded-2xl bg-[#141924] border border-cyan-500/20 text-center shrink-0">
            <div className="text-[10px] text-cyan-400 uppercase font-semibold">
              START PIN
            </div>
            <div className="font-mono text-base font-extrabold text-white tracking-widest">
              {driver.safetyPin}
            </div>
          </div>
        </div>

        {/* Pickup Location Reminder */}
        <div className="p-3 rounded-2xl bg-[#141A25] border border-white/5 text-xs text-slate-300 flex items-center justify-between">
          <span className="text-slate-400 truncate mr-2">
            Meet at: <strong className="text-white">{pickup}</strong>
          </span>
          {!isArrived && (
            <button
              onClick={() => onUpdateDriverStatus('driver_arrived')}
              className="text-[10px] text-cyan-400 hover:underline font-semibold shrink-0 cursor-pointer"
            >
              Simulate Arrival
            </button>
          )}
        </div>

        {/* Action Buttons: Call Driver, Cancel Ride, or Start Trip */}
        <div className="mt-4 flex gap-2.5">
          {/* Call Driver Button */}
          <button
            id="call-driver-btn"
            onClick={() => setIsCalling(true)}
            className="flex-1 py-3.5 px-4 rounded-2xl bg-[#171D28] hover:bg-[#1E2535] border border-white/10 text-white font-bold text-xs tracking-wide flex items-center justify-center gap-2 active:scale-95 transition-all cursor-pointer"
          >
            <Phone className="w-4 h-4 text-cyan-400" />
            <span>CALL DRIVER</span>
          </button>

          {/* Cancel Ride Button */}
          <button
            id="cancel-ride-btn"
            onClick={() => setShowCancelConfirm(true)}
            className="py-3.5 px-4 rounded-2xl bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/20 text-rose-300 font-bold text-xs tracking-wide flex items-center justify-center gap-1.5 active:scale-95 transition-all cursor-pointer"
          >
            <X className="w-4 h-4" />
            <span>CANCEL</span>
          </button>
        </div>

        {/* Big Start Trip Button when driver has arrived */}
        {isArrived && (
          <button
            id="start-ride-btn"
            onClick={onStartRide}
            className="mt-3 w-full py-3.5 px-4 rounded-2xl bg-cyan-400 hover:bg-cyan-300 active:scale-[0.99] text-slate-950 font-bold text-sm tracking-wide flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(0,240,255,0.35)] transition-all cursor-pointer animate-pulse"
          >
            <span>START JOURNEY NOW</span>
            <ArrowRight className="w-4 h-4 stroke-[2.5]" />
          </button>
        )}
      </div>

      {/* Call Driver Modal */}
      {isCalling && (
        <CallModal
          driver={driver}
          onClose={() => setIsCalling(false)}
        />
      )}

      {/* Cancel Confirmation Dialog */}
      {showCancelConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-sm rounded-3xl bg-[#10141C] border border-white/10 p-5 shadow-2xl space-y-4">
            <div className="flex items-center gap-3 text-rose-400">
              <div className="w-10 h-10 rounded-2xl bg-rose-500/15 flex items-center justify-center">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-bold text-white text-base">
                  Cancel Booking?
                </h4>
                <p className="text-xs text-slate-400">
                  No cancellation fee applies.
                </p>
              </div>
            </div>

            <div className="flex gap-3 pt-2">
              <button
                onClick={() => {
                  setShowCancelConfirm(false);
                  onCancelRide();
                }}
                className="flex-1 py-3 rounded-xl bg-rose-500 hover:bg-rose-600 text-white font-bold text-xs tracking-wider transition-colors cursor-pointer"
              >
                YES, CANCEL
              </button>
              <button
                onClick={() => setShowCancelConfirm(false)}
                className="flex-1 py-3 rounded-xl bg-white/10 hover:bg-white/15 text-slate-200 font-bold text-xs tracking-wider transition-colors cursor-pointer"
              >
                KEEP RIDE
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
