import { useEffect, useState } from 'react';
import { Shield, Sparkles, Navigation, CheckCircle } from 'lucide-react';
import { RideTier } from '../types';

interface DriverMatchingViewProps {
  tier: RideTier;
  destination: string;
  onMatched: () => void;
}

export default function DriverMatchingView({
  tier,
  destination,
  onMatched,
}: DriverMatchingViewProps) {
  const [matchStep, setMatchStep] = useState(0);

  const steps = [
    'Scanning nearby verified drivers...',
    `Locating nearest ${tier.name} vehicle...`,
    'Locking in guaranteed fare...',
    'Driver connected!',
  ];

  useEffect(() => {
    const timer1 = setTimeout(() => setMatchStep(1), 600);
    const timer2 = setTimeout(() => setMatchStep(2), 1200);
    const timer3 = setTimeout(() => {
      setMatchStep(3);
      setTimeout(onMatched, 400);
    }, 1800);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
    };
  }, [onMatched]);

  return (
    <div className="w-full flex flex-col items-center justify-center p-6 rounded-3xl bg-[#10141C]/95 border border-cyan-500/20 shadow-2xl backdrop-blur-xl relative overflow-hidden text-center">
      {/* Subtle Radial Glow */}
      <div className="absolute inset-0 bg-gradient-to-b from-cyan-500/10 via-transparent to-transparent pointer-events-none" />

      {/* Animated Radar Pulse */}
      <div className="relative w-36 h-36 flex items-center justify-center mb-5">
        <div className="absolute inset-0 rounded-full border border-cyan-400/20 animate-ping" />
        <div className="absolute inset-3 rounded-full border border-cyan-400/30 animate-pulse" />
        <div className="absolute inset-7 rounded-full border border-cyan-400/40" />

        <div className="w-16 h-16 rounded-2xl bg-cyan-500/20 border-2 border-cyan-400 flex items-center justify-center text-cyan-300 shadow-[0_0_25px_rgba(0,240,255,0.4)] z-10">
          <Navigation className="w-8 h-8 text-cyan-400 rotate-45 animate-bounce" />
        </div>
      </div>

      {/* Status Headings */}
      <div className="space-y-1 z-10">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs font-semibold mb-1">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Smart Dispatch</span>
        </div>

        <h3 className="text-xl font-extrabold text-white tracking-tight">
          Finding your DriveSmart
        </h3>

        <p className="text-xs text-cyan-300/90 font-medium h-5">
          {steps[matchStep]}
        </p>
      </div>

      {/* Destination & Tier Tag */}
      <div className="mt-5 w-full p-3 rounded-2xl bg-[#141A25] border border-white/5 flex items-center justify-between text-xs z-10">
        <span className="text-slate-400">
          Destination: <strong className="text-white truncate max-w-[150px] inline-block align-bottom">{destination}</strong>
        </span>
        <span className="font-bold text-cyan-400 font-mono">
          {tier.name} • ₹{tier.fare}
        </span>
      </div>

      {/* Quick Skip button for immediate manual progression */}
      <button
        type="button"
        onClick={onMatched}
        className="mt-4 text-[11px] text-slate-500 hover:text-cyan-400 transition-colors z-10 cursor-pointer"
      >
        Tap to connect instantly
      </button>
    </div>
  );
}
