import { useState, useMemo } from 'react';
import {
  MapPin,
  Clock,
  Home,
  Briefcase,
  ArrowRight,
  Navigation,
  Zap,
  RotateCcw,
  Sparkles,
  Check,
  Search,
  X,
} from 'lucide-react';
import { SavedLocation, DestinationSuggestion } from '../types';
import { SMART_DESTINATIONS } from '../data/mockData';

interface HomeScreenProps {
  pickup: string;
  destination: string;
  setPickup: (val: string) => void;
  setDestination: (val: string) => void;
  onFindRide: () => void;
  onQuickBook: (destination: string) => void;
  savedLocations: SavedLocation[];
}

const DEFAULT_CURRENT_LOCATION = 'Current location (Connaught Place, Central Delhi)';

export default function HomeScreen({
  pickup,
  destination,
  setPickup,
  setDestination,
  onFindRide,
  onQuickBook,
  savedLocations,
}: HomeScreenProps) {
  const [errorMsg, setErrorMsg] = useState('');
  const [isEditingPickup, setIsEditingPickup] = useState(false);
  const [isDestFocused, setIsDestFocused] = useState(false);
  const [gpsStatus, setGpsStatus] = useState<'active' | 'detecting'>('active');

  const isAutoLocation = pickup === DEFAULT_CURRENT_LOCATION;

  // Filter destination suggestions matching query or popular if empty
  const suggestions = useMemo(() => {
    const query = destination.trim().toLowerCase();
    if (!query) {
      return SMART_DESTINATIONS.slice(0, 4);
    }
    return SMART_DESTINATIONS.filter(
      (d) =>
        d.label.toLowerCase().includes(query) ||
        d.address.toLowerCase().includes(query) ||
        d.area.toLowerCase().includes(query)
    );
  }, [destination]);

  const handleSelectSuggestion = (sug: DestinationSuggestion) => {
    setDestination(sug.label);
    setIsDestFocused(false);
    setErrorMsg('');
  };

  const handleSelectSaved = (loc: SavedLocation) => {
    setDestination(loc.label);
    setIsDestFocused(false);
    setErrorMsg('');
  };

  const handleDetectGps = () => {
    setGpsStatus('detecting');
    setTimeout(() => {
      setPickup(DEFAULT_CURRENT_LOCATION);
      setGpsStatus('active');
      setIsEditingPickup(false);
    }, 400);
  };

  const handleFindRide = () => {
    if (!destination.trim()) {
      setErrorMsg('Please select or enter a destination');
      return;
    }
    setErrorMsg('');
    onFindRide();
  };

  // Find "Work" or first saved location for Quick Book
  const workLocation = savedLocations.find((l) => l.type === 'work') || savedLocations[0];

  return (
    <div className="w-full flex flex-col gap-3.5 pb-2">
      {/* 1. Quick Book Banner: One-Tap to Confirmation for frequent route */}
      {workLocation && (
        <div
          id="quick-book-card"
          className="rounded-3xl bg-gradient-to-r from-cyan-950/60 via-[#101926]/90 to-[#0F1722]/90 border border-cyan-500/30 p-4 shadow-xl backdrop-blur-xl relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-500/10 rounded-full blur-2xl pointer-events-none" />

          <div className="flex items-center justify-between gap-3 relative z-10">
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-1.5 text-[11px] font-bold text-cyan-400 uppercase tracking-wider mb-0.5">
                <Zap className="w-3.5 h-3.5 fill-cyan-400 text-cyan-400" />
                <span>Fast Booking</span>
              </div>
              <h3 className="text-sm font-extrabold text-white truncate">
                Go to {workLocation.label}
              </h3>
              <p className="text-xs text-slate-300 mt-0.5 font-medium">
                18 min · ₹250 estimated · Smart
              </p>
            </div>

            <button
              id="quick-book-continue-btn"
              onClick={() => onQuickBook(workLocation.label)}
              className="px-4 py-2.5 rounded-xl bg-cyan-400 hover:bg-cyan-300 active:scale-95 text-slate-950 font-bold text-xs tracking-wider uppercase flex items-center gap-1.5 shadow-[0_0_15px_rgba(0,240,255,0.35)] shrink-0 transition-all cursor-pointer"
            >
              <span>CONTINUE</span>
              <ArrowRight className="w-3.5 h-3.5 stroke-[2.5]" />
            </button>
          </div>
        </div>
      )}

      {/* 2. Main Search & Location Booking Card */}
      <div className="rounded-3xl bg-[#10141C]/95 border border-white/[0.08] p-5 shadow-2xl backdrop-blur-xl">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-extrabold text-white tracking-tight">
            Where do you want to go?
          </h2>

          {/* Location Status Pill */}
          <div className="flex items-center gap-1.5 text-[10px] font-semibold px-2.5 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/25 text-cyan-300">
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
            <span>{gpsStatus === 'detecting' ? 'Locating...' : 'GPS Active'}</span>
          </div>
        </div>

        {/* Input Fields */}
        <div className="space-y-3 relative">
          {/* Pickup Field */}
          <div className="relative">
            <div className="relative flex items-center">
              <div className="absolute left-3.5 flex items-center justify-center">
                <div className="w-3.5 h-3.5 rounded-full bg-cyan-400 ring-4 ring-cyan-400/20" />
              </div>

              <input
                id="pickup-input"
                type="text"
                value={pickup}
                onChange={(e) => {
                  setPickup(e.target.value);
                  setIsEditingPickup(true);
                }}
                placeholder="Pickup location"
                className="w-full bg-[#0A0D14] border border-white/10 rounded-2xl py-3.5 pl-11 pr-24 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400/50 transition-all font-medium"
              />

              {/* Action Button inside Pickup Field */}
              <div className="absolute right-2.5 flex items-center">
                {isAutoLocation ? (
                  <button
                    type="button"
                    onClick={() => setIsEditingPickup(true)}
                    className="text-[11px] font-semibold text-slate-400 hover:text-cyan-300 px-2 py-1 rounded-lg bg-white/5 border border-white/10 transition-colors"
                  >
                    Change
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={handleDetectGps}
                    className="text-[11px] font-semibold text-cyan-400 hover:text-cyan-300 px-2 py-1 rounded-lg bg-cyan-500/10 border border-cyan-500/20 flex items-center gap-1 transition-colors"
                    title="Auto-detect current location"
                  >
                    <Navigation className="w-3 h-3" />
                    <span>Auto</span>
                  </button>
                )}
              </div>
            </div>

            {/* Quick Auto-Detect Hint if modified */}
            {!isAutoLocation && (
              <div className="flex items-center justify-between px-1 mt-1 text-[11px] text-slate-400">
                <span>Manual pickup selected</span>
                <button
                  type="button"
                  onClick={handleDetectGps}
                  className="text-cyan-400 hover:underline flex items-center gap-1 font-medium"
                >
                  <RotateCcw className="w-2.5 h-2.5" />
                  <span>Reset to current location</span>
                </button>
              </div>
            )}
          </div>

          {/* Dashed connector line */}
          <div className="absolute left-5 top-[40px] bottom-[38px] w-0.5 border-l-2 border-dashed border-slate-700 pointer-events-none z-0" />

          {/* Destination Field */}
          <div className="relative">
            <div className="relative flex items-center">
              <div className="absolute left-3.5 flex items-center justify-center">
                <MapPin className="w-4 h-4 text-rose-400" />
              </div>

              <input
                id="destination-input"
                type="text"
                value={destination}
                onFocus={() => setIsDestFocused(true)}
                onChange={(e) => {
                  setDestination(e.target.value);
                  if (errorMsg) setErrorMsg('');
                }}
                placeholder="Enter or select destination..."
                className="w-full bg-[#0A0D14] border border-white/10 rounded-2xl py-3.5 pl-11 pr-10 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400/50 transition-all font-medium"
              />

              {destination && (
                <button
                  type="button"
                  onClick={() => setDestination('')}
                  className="absolute right-3 p-1 rounded-full text-slate-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>
        </div>

        {errorMsg && (
          <p className="text-xs text-rose-400 mt-2 font-medium pl-1">{errorMsg}</p>
        )}

        {/* 3. Quick Saved Shortcuts: Home, Work, Recent (Under Destination Field) */}
        {savedLocations.length > 0 && (
          <div className="mt-3.5 pt-3.5 border-t border-white/[0.06]">
            <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-2 flex items-center justify-between">
              <span>Quick Destinations</span>
              <span className="text-[10px] text-cyan-400 font-mono">1-TAP SELECT</span>
            </div>

            <div className="grid grid-cols-3 gap-2">
              {savedLocations.map((loc) => {
                const isHome = loc.type === 'home';
                const isWork = loc.type === 'work';
                const isSelected = destination.includes(loc.label);

                return (
                  <button
                    key={loc.id}
                    id={`shortcut-${loc.id}`}
                    type="button"
                    onClick={() => handleSelectSaved(loc)}
                    className={`flex flex-col items-center justify-center p-2.5 rounded-2xl border transition-all text-center group cursor-pointer ${
                      isSelected
                        ? 'bg-cyan-500/15 border-cyan-400 text-white shadow-[0_0_12px_rgba(0,240,255,0.2)]'
                        : 'bg-[#141A25] border-white/5 hover:border-white/15 text-slate-300'
                    }`}
                  >
                    <div
                      className={`w-8 h-8 rounded-xl flex items-center justify-center mb-1.5 transition-all ${
                        isSelected
                          ? 'bg-cyan-400 text-slate-950'
                          : 'bg-white/5 text-cyan-400 group-hover:bg-cyan-500/10'
                      }`}
                    >
                      {isHome && <Home className="w-4 h-4" />}
                      {isWork && <Briefcase className="w-4 h-4" />}
                      {!isHome && !isWork && <Clock className="w-4 h-4" />}
                    </div>
                    <span className="text-xs font-bold truncate w-full">
                      {loc.label}
                    </span>
                    <span className="text-[10px] text-slate-400 truncate w-full font-medium">
                      {isHome ? '16m · 7km' : isWork ? '18m · 8km' : '22m · 10km'}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Main Action: FIND RIDE */}
        <button
          id="find-ride-btn"
          onClick={handleFindRide}
          className="mt-4 w-full py-4 px-6 rounded-2xl bg-cyan-400 hover:bg-cyan-300 active:scale-[0.99] text-slate-950 font-bold text-base tracking-wide flex items-center justify-center gap-2 shadow-[0_0_25px_rgba(0,240,255,0.35)] transition-all cursor-pointer"
        >
          <span>FIND RIDE</span>
          <ArrowRight className="w-5 h-5 stroke-[2.5]" />
        </button>
      </div>

      {/* 4. Smart Destination Suggestions List with travel time and distance */}
      <div className="rounded-3xl bg-[#10141C]/90 border border-white/[0.08] p-4 shadow-xl backdrop-blur-xl">
        <div className="flex items-center justify-between px-2 mb-2.5">
          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
            <Sparkles className="w-3 h-3 text-cyan-400" />
            <span>Suggested Destinations</span>
          </span>
          <span className="text-[10px] text-slate-500">Tap to choose</span>
        </div>

        <div className="space-y-1">
          {suggestions.map((sug) => {
            const isSelected = destination === sug.label;

            return (
              <button
                key={sug.id}
                id={`suggestion-${sug.id}`}
                onClick={() => handleSelectSuggestion(sug)}
                className={`w-full flex items-center justify-between p-3 rounded-2xl border transition-all text-left group cursor-pointer ${
                  isSelected
                    ? 'bg-cyan-500/10 border-cyan-500/30'
                    : 'hover:bg-white/[0.04] active:bg-white/[0.07] border-transparent hover:border-white/5'
                }`}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-9 h-9 rounded-xl bg-[#171D27] border border-white/10 flex items-center justify-center text-cyan-400 group-hover:border-cyan-500/40 group-hover:bg-cyan-500/10 transition-all shrink-0">
                    <MapPin className="w-4 h-4" />
                  </div>
                  <div className="min-w-0">
                    <div className="text-sm font-semibold text-white group-hover:text-cyan-300 transition-colors truncate">
                      {sug.label}
                    </div>
                    <div className="text-xs text-slate-400 truncate">
                      {sug.address}
                    </div>
                  </div>
                </div>

                <div className="text-right pl-2 shrink-0">
                  <div className="text-xs font-mono font-bold text-cyan-300">
                    {sug.timeMins} mins
                  </div>
                  <div className="text-[10px] text-slate-400 font-medium">
                    {sug.distanceKm} km
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
