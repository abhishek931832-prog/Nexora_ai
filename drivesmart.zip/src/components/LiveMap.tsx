import { useEffect, useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Navigation, Compass, Layers, Plus, Minus, Car } from 'lucide-react';
import { RidePhase } from '../types';

interface LiveMapProps {
  phase: RidePhase;
  pickupLabel?: string;
  destinationLabel?: string;
  isDriverArrived?: boolean;
  onTripSimulatedStep?: (progress: number) => void;
  className?: string;
}

// Fixed coordinate anchors in our vector map space (0-1000 x 0-800)
const PICKUP_POINT = { x: 340, y: 520 };
const DESTINATION_POINT = { x: 740, y: 240 };
const DRIVER_START_POINT = { x: 180, y: 700 };

// Bezier-like waypoint routes
const ROUTE_DRIVER_TO_PICKUP = [
  { x: 180, y: 700 },
  { x: 220, y: 640 },
  { x: 280, y: 600 },
  { x: 340, y: 520 },
];

const ROUTE_PICKUP_TO_DEST = [
  { x: 340, y: 520 },
  { x: 390, y: 460 },
  { x: 450, y: 440 },
  { x: 530, y: 390 },
  { x: 610, y: 360 },
  { x: 660, y: 300 },
  { x: 740, y: 240 },
];

function interpolatePath(points: { x: number; y: number }[], t: number) {
  const clampedT = Math.max(0, Math.min(1, t));
  const segments = points.length - 1;
  const scaledT = clampedT * segments;
  const index = Math.floor(scaledT);
  const localT = scaledT - index;

  if (index >= segments) {
    const last = points[points.length - 1];
    const prev = points[points.length - 2];
    const angle = Math.atan2(last.y - prev.y, last.x - prev.x) * (180 / Math.PI);
    return { x: last.x, y: last.y, angle };
  }

  const p0 = points[index];
  const p1 = points[index + 1];

  const x = p0.x + (p1.x - p0.x) * localT;
  const y = p0.y + (p1.y - p0.y) * localT;
  const angle = Math.atan2(p1.y - p0.y, p1.x - p0.x) * (180 / Math.PI);

  return { x, y, angle };
}

export default function LiveMap({
  phase,
  pickupLabel = 'Current Location',
  destinationLabel = 'Destination',
  onTripSimulatedStep,
  className = '',
}: LiveMapProps) {
  const [zoom, setZoom] = useState(1);
  const [is3D, setIs3D] = useState(false);
  const [driverProgress, setDriverProgress] = useState(0.2); // for driver_found
  const [tripProgress, setTripProgress] = useState(0.05); // for in_progress
  const animRef = useRef<number | null>(null);

  // Background idle cars
  const [ambientCars] = useState([
    { id: 1, x: 260, y: 480, angle: 45, type: 'Smart' },
    { id: 2, x: 410, y: 560, angle: -30, type: 'Comfort' },
    { id: 3, x: 480, y: 380, angle: 110, type: 'XL' },
    { id: 4, x: 620, y: 290, angle: -65, type: 'Smart' },
    { id: 5, x: 190, y: 340, angle: 15, type: 'Comfort' },
  ]);

  // Handle live vehicle movement animation
  useEffect(() => {
    let lastTime = performance.now();

    const updateMovement = (time: number) => {
      const delta = (time - lastTime) / 1000;
      lastTime = time;

      if (phase === 'driver_found') {
        setDriverProgress((prev) => {
          const next = prev + delta * 0.04;
          return next > 0.98 ? 0.98 : next;
        });
      } else if (phase === 'in_progress') {
        setTripProgress((prev) => {
          const next = prev + delta * 0.035;
          if (onTripSimulatedStep) {
            onTripSimulatedStep(Math.min(1, next));
          }
          return next > 1 ? 1 : next;
        });
      }

      animRef.current = requestAnimationFrame(updateMovement);
    };

    animRef.current = requestAnimationFrame(updateMovement);
    return () => {
      if (animRef.current) cancelAnimationFrame(animRef.current);
    };
  }, [phase, onTripSimulatedStep]);

  // Reset progress when phase changes
  useEffect(() => {
    if (phase === 'driver_found') {
      setDriverProgress(0.15);
    } else if (phase === 'in_progress') {
      setTripProgress(0.02);
    }
  }, [phase]);

  // Calculate moving car coordinates
  const driverPos = interpolatePath(ROUTE_DRIVER_TO_PICKUP, driverProgress);
  const tripPos = interpolatePath(ROUTE_PICKUP_TO_DEST, tripProgress);

  // Active car position based on phase
  const activeCar = phase === 'driver_found' ? driverPos : tripPos;

  // Path SVG string
  const mainRoutePathD = ROUTE_PICKUP_TO_DEST.reduce(
    (acc, p, i) => (i === 0 ? `M ${p.x} ${p.y}` : `${acc} L ${p.x} ${p.y}`),
    ''
  );

  const driverRoutePathD = ROUTE_DRIVER_TO_PICKUP.reduce(
    (acc, p, i) => (i === 0 ? `M ${p.x} ${p.y}` : `${acc} L ${p.x} ${p.y}`),
    ''
  );

  return (
    <div
      id="live-map-container"
      className={`relative w-full h-full overflow-hidden select-none bg-[#07090D] ${className}`}
      style={{
        perspective: is3D ? '850px' : 'none',
      }}
    >
      {/* Map Surface with optional 3D Tilt */}
      <div
        className="w-full h-full transition-transform duration-700 ease-out origin-center"
        style={{
          transform: is3D
            ? `rotateX(26deg) scale(${zoom * 1.08}) translateY(-4%)`
            : `scale(${zoom})`,
        }}
      >
        <svg
          className="w-full h-full object-cover"
          viewBox="0 0 1000 800"
          preserveAspectRatio="xMidYMid slice"
        >
          <defs>
            {/* Dark Map Radial Gradient */}
            <radialGradient id="mapVignette" cx="50%" cy="50%" r="65%">
              <stop offset="0%" stopColor="#0E131C" />
              <stop offset="70%" stopColor="#080A0E" />
              <stop offset="100%" stopColor="#040507" />
            </radialGradient>

            {/* Neon Cyan Glow for Active Route */}
            <filter id="cyanGlow" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="6" result="blur" />
              <feMerge>
                <feMergeNode in="blur" />
                <feMergeNode in="blur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>

            {/* Soft Glow for Vehicle Headlights */}
            <linearGradient id="headlightBeam" x1="0%" y1="50%" x2="100%" y2="50%">
              <stop offset="0%" stopColor="rgba(0, 240, 255, 0.45)" />
              <stop offset="60%" stopColor="rgba(0, 240, 255, 0.12)" />
              <stop offset="100%" stopColor="rgba(0, 240, 255, 0)" />
            </linearGradient>

            <linearGradient id="routeGradient" x1="0%" y1="100%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#00E5FF" />
              <stop offset="50%" stopColor="#00B4D8" />
              <stop offset="100%" stopColor="#38BDF8" />
            </linearGradient>

            <pattern id="gridSubtle" width="60" height="60" patternUnits="userSpaceOnUse">
              <path d="M 60 0 L 0 0 0 60" fill="none" stroke="#161B26" strokeWidth="0.8" />
            </pattern>
          </defs>

          {/* Background Canvas */}
          <rect width="1000" height="800" fill="url(#mapVignette)" />
          <rect width="1000" height="800" fill="url(#gridSubtle)" opacity="0.6" />

          {/* Ambient River / Water feature */}
          <path
            d="M -50 480 Q 250 450, 480 560 T 1050 510"
            fill="none"
            stroke="#0B1A24"
            strokeWidth="38"
            strokeLinecap="round"
            opacity="0.8"
          />
          <path
            d="M -50 480 Q 250 450, 480 560 T 1050 510"
            fill="none"
            stroke="#082333"
            strokeWidth="20"
            strokeLinecap="round"
            opacity="0.9"
          />

          {/* Secondary Street Grid (Graphite) */}
          <g stroke="#131924" strokeWidth="10" strokeLinecap="round" opacity="0.8">
            <line x1="80" y1="120" x2="920" y2="120" />
            <line x1="120" y1="280" x2="880" y2="280" />
            <line x1="60" y1="420" x2="940" y2="420" />
            <line x1="90" y1="620" x2="900" y2="620" />
            <line x1="150" y1="740" x2="850" y2="740" />

            <line x1="140" y1="80" x2="140" y2="720" />
            <line x1="280" y1="60" x2="280" y2="750" />
            <line x1="460" y1="50" x2="460" y2="750" />
            <line x1="640" y1="70" x2="640" y2="740" />
            <line x1="820" y1="90" x2="820" y2="720" />
          </g>

          {/* Primary Arterial Roads (Lighter Graphite) */}
          <g stroke="#1C2433" strokeWidth="16" strokeLinecap="round" strokeLinejoin="round">
            {/* Diagonal Expressways */}
            <path d="M 40 760 L 320 540 L 760 220 L 980 140" />
            <path d="M 80 200 L 420 230 L 720 580 L 940 720" />
            <path d="M 320 60 L 330 380 L 340 520 L 380 760" />
            <path d="M 720 70 L 740 240 L 710 500 L 690 750" />
          </g>

          {/* Road centerlines */}
          <g stroke="#263145" strokeWidth="1.5" strokeDasharray="6,8" opacity="0.7">
            <path d="M 40 760 L 320 540 L 760 220 L 980 140" fill="none" />
            <path d="M 80 200 L 420 230 L 720 580 L 940 720" fill="none" />
            <path d="M 320 60 L 330 380 L 340 520 L 380 760" fill="none" />
            <path d="M 720 70 L 740 240 L 710 500 L 690 750" fill="none" />
          </g>

          {/* Subtle Landmarks/Zones */}
          <g opacity="0.4">
            <rect x="230" y="180" width="70" height="60" rx="6" fill="#141C28" stroke="#1F2A3D" strokeWidth="1" />
            <text x="265" y="215" fill="#4B5B75" fontSize="11" textAnchor="middle" fontFamily="sans-serif">Tech Park</text>

            <rect x="520" y="240" width="90" height="50" rx="6" fill="#141C28" stroke="#1F2A3D" strokeWidth="1" />
            <text x="565" y="270" fill="#4B5B75" fontSize="11" textAnchor="middle" fontFamily="sans-serif">Central Mall</text>

            <rect x="370" y="580" width="80" height="50" rx="6" fill="#141C28" stroke="#1F2A3D" strokeWidth="1" />
            <text x="410" y="610" fill="#4B5B75" fontSize="11" textAnchor="middle" fontFamily="sans-serif">Aerocity</text>
          </g>

          {/* AMBIENT CARS when idle or selecting */}
          {phase === 'idle' || phase === 'selecting_tier' || phase === 'confirming' ? (
            <g id="ambient-cars">
              {ambientCars.map((car) => (
                <g key={car.id} transform={`translate(${car.x}, ${car.y}) rotate(${car.angle})`}>
                  {/* Subtle car shadow */}
                  <rect x="-9" y="-5" width="18" height="10" rx="3" fill="rgba(0,0,0,0.6)" />
                  {/* Vehicle Body */}
                  <rect
                    x="-8"
                    y="-4.5"
                    width="16"
                    height="9"
                    rx="2.5"
                    fill="#1E2738"
                    stroke="#00F0FF"
                    strokeWidth="0.75"
                  />
                  {/* Windshield */}
                  <rect x="-1" y="-3.5" width="3" height="7" rx="1" fill="#00E5FF" opacity="0.8" />
                  {/* Tiny Cyan Ping */}
                  <circle cx="0" cy="0" r="1.5" fill="#00F0FF" />
                </g>
              ))}
            </g>
          ) : null}

          {/* ACTIVE ROUTE LINE */}
          {phase !== 'idle' && (
            <>
              {/* Route underlay dark glow */}
              <path
                d={mainRoutePathD}
                fill="none"
                stroke="#00F0FF"
                strokeWidth="10"
                strokeLinecap="round"
                strokeLinejoin="round"
                opacity="0.25"
                filter="url(#cyanGlow)"
              />
              {/* Main vibrant neon cyan route */}
              <path
                d={mainRoutePathD}
                fill="none"
                stroke="url(#routeGradient)"
                strokeWidth="5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              {/* Animated pulsating dash */}
              <path
                d={mainRoutePathD}
                fill="none"
                stroke="#FFFFFF"
                strokeWidth="2.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeDasharray="8, 14"
                className="animate-[dash_1.2s_linear_infinite]"
              />
            </>
          )}

          {/* DRIVER ROUTE (Driver is on the way) */}
          {phase === 'driver_found' && (
            <>
              <path
                d={driverRoutePathD}
                fill="none"
                stroke="#00E5FF"
                strokeWidth="6"
                strokeLinecap="round"
                strokeLinejoin="round"
                opacity="0.3"
                filter="url(#cyanGlow)"
              />
              <path
                d={driverRoutePathD}
                fill="none"
                stroke="#00F0FF"
                strokeWidth="4"
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeDasharray="6, 8"
              />
            </>
          )}

          {/* PICKUP PIN (Current Location) */}
          <g transform={`translate(${PICKUP_POINT.x}, ${PICKUP_POINT.y})`}>
            {/* Ripple Wave */}
            <circle cx="0" cy="0" r="28" fill="none" stroke="#00F0FF" strokeWidth="1.5" opacity="0.3">
              <animate attributeName="r" values="8;32" dur="2s" repeatCount="indefinite" />
              <animate attributeName="opacity" values="0.8;0" dur="2s" repeatCount="indefinite" />
            </circle>
            {/* Inner glow halo */}
            <circle cx="0" cy="0" r="14" fill="rgba(0, 240, 255, 0.2)" />
            {/* Center dot */}
            <circle cx="0" cy="0" r="7" fill="#00F0FF" stroke="#FFFFFF" strokeWidth="2.5" />

            {/* Pickup Tooltip */}
            <g transform="translate(0, -26)">
              <rect
                x="-58"
                y="-20"
                width="116"
                height="22"
                rx="6"
                fill="#0F141E"
                stroke="#00F0FF"
                strokeWidth="1"
              />
              <text
                x="0"
                y="-6"
                fill="#E2E8F0"
                fontSize="10"
                fontWeight="600"
                textAnchor="middle"
                fontFamily="sans-serif"
              >
                📍 {pickupLabel.length > 14 ? pickupLabel.slice(0, 14) + '...' : pickupLabel}
              </text>
            </g>
          </g>

          {/* DESTINATION PIN */}
          {phase !== 'idle' && (
            <g transform={`translate(${DESTINATION_POINT.x}, ${DESTINATION_POINT.y})`}>
              {/* Pulse rings */}
              <circle cx="0" cy="0" r="24" fill="none" stroke="#38BDF8" strokeWidth="1.2" opacity="0.4">
                <animate attributeName="r" values="6;26" dur="2.4s" repeatCount="indefinite" />
                <animate attributeName="opacity" values="0.7;0" dur="2.4s" repeatCount="indefinite" />
              </circle>

              {/* Pin body */}
              <path
                d="M 0 0 L -8 -22 A 10 10 0 1 1 8 -22 Z"
                fill="#0F172A"
                stroke="#00E5FF"
                strokeWidth="2"
              />
              <circle cx="0" cy="-22" r="4.5" fill="#00F0FF" />

              {/* Destination Tag */}
              <g transform="translate(0, -42)">
                <rect
                  x="-62"
                  y="-18"
                  width="124"
                  height="22"
                  rx="6"
                  fill="#0B0E14"
                  stroke="#38BDF8"
                  strokeWidth="1"
                />
                <text
                  x="0"
                  y="-4"
                  fill="#F8FAFC"
                  fontSize="10"
                  fontWeight="600"
                  textAnchor="middle"
                  fontFamily="sans-serif"
                >
                  🏁 {destinationLabel.length > 15 ? destinationLabel.slice(0, 15) + '...' : destinationLabel}
                </text>
              </g>
            </g>
          )}

          {/* LIVE MOVING DRIVESMART VEHICLE (Driver found or Trip in progress) */}
          {(phase === 'driver_found' || phase === 'in_progress') && (
            <g
              transform={`translate(${activeCar.x}, ${activeCar.y}) rotate(${activeCar.angle})`}
              className="transition-transform duration-75 ease-linear"
            >
              {/* Headlight beam projection */}
              <polygon
                points="12,-6 56,-16 56,16 12,6"
                fill="url(#headlightBeam)"
              />

              {/* Vehicle drop shadow */}
              <ellipse cx="0" cy="0" rx="16" ry="9" fill="rgba(0,0,0,0.85)" />

              {/* Car Body */}
              <rect
                x="-14"
                y="-7.5"
                width="28"
                height="15"
                rx="4"
                fill="#0A0E17"
                stroke="#00F0FF"
                strokeWidth="1.6"
              />

              {/* Roof cockpit */}
              <rect
                x="-6"
                y="-5"
                width="14"
                height="10"
                rx="2"
                fill="#162030"
              />

              {/* Windshield */}
              <rect
                x="4"
                y="-4"
                width="3"
                height="8"
                rx="1"
                fill="#00F0FF"
                opacity="0.9"
              />

              {/* Cyan DriveSmart Glow on Roof */}
              <circle cx="1" cy="0" r="2.5" fill="#00F0FF" filter="url(#cyanGlow)" />

              {/* Headlight bulbs */}
              <circle cx="13" cy="-5" r="1" fill="#FFFFFF" />
              <circle cx="13" cy="5" r="1" fill="#FFFFFF" />
              {/* Taillights */}
              <circle cx="-13" cy="-5" r="1" fill="#FF3366" />
              <circle cx="-13" cy="5" r="1" fill="#FF3366" />
            </g>
          )}
        </svg>
      </div>

      {/* Floating Map Controls (Top-Right / Minimalist Glass) */}
      <div className="absolute top-4 right-4 flex flex-col gap-2 z-20">
        <button
          id="map-tilt-toggle"
          onClick={() => setIs3D(!is3D)}
          title={is3D ? 'Switch to 2D Top View' : 'Switch to 3D Perspective'}
          className={`p-2.5 rounded-xl border backdrop-blur-md transition-all ${
            is3D
              ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300 shadow-[0_0_15px_rgba(0,240,255,0.3)]'
              : 'bg-[#12161F]/80 border-white/10 text-slate-300 hover:text-white hover:border-white/20'
          }`}
        >
          <Layers className="w-4 h-4" />
        </button>

        <button
          id="map-zoom-in"
          onClick={() => setZoom((z) => Math.min(1.4, z + 0.15))}
          title="Zoom In"
          className="p-2.5 rounded-xl bg-[#12161F]/80 border border-white/10 text-slate-300 hover:text-white hover:border-white/20 backdrop-blur-md active:scale-95 transition-all"
        >
          <Plus className="w-4 h-4" />
        </button>

        <button
          id="map-zoom-out"
          onClick={() => setZoom((z) => Math.max(0.85, z - 0.15))}
          title="Zoom Out"
          className="p-2.5 rounded-xl bg-[#12161F]/80 border border-white/10 text-slate-300 hover:text-white hover:border-white/20 backdrop-blur-md active:scale-95 transition-all"
        >
          <Minus className="w-4 h-4" />
        </button>

        <button
          id="map-recenter"
          onClick={() => {
            setZoom(1);
            setIs3D(false);
          }}
          title="Recenter Map"
          className="p-2.5 rounded-xl bg-[#12161F]/80 border border-white/10 text-slate-300 hover:text-white hover:border-white/20 backdrop-blur-md active:scale-95 transition-all"
        >
          <Compass className="w-4 h-4" />
        </button>
      </div>

      {/* Real-time Telemetry Bar for "in_progress" (Clean & Minimal) */}
      {phase === 'in_progress' && (
        <div className="absolute top-4 left-4 z-20">
          <div className="flex items-center gap-3 px-3.5 py-1.5 rounded-full bg-[#0E121A]/85 border border-cyan-500/30 backdrop-blur-md shadow-lg">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-cyan-400"></span>
            </span>
            <div className="text-[12px] font-mono tracking-wide text-cyan-300">
              SPEED: <span className="font-bold text-white">44 km/h</span>
            </div>
            <div className="h-3 w-px bg-white/15" />
            <div className="text-[12px] font-mono text-slate-300">
              GPS: <span className="text-cyan-400 font-semibold">LOCKED</span>
            </div>
          </div>
        </div>
      )}

      {/* Driver Arrived indicator in driver_found phase */}
      {phase === 'driver_found' && (
        <div className="absolute top-4 left-4 z-20">
          <div className="flex items-center gap-2.5 px-3.5 py-1.5 rounded-full bg-[#0E121A]/85 border border-cyan-500/30 backdrop-blur-md shadow-lg">
            <div className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
            <span className="text-xs font-medium text-slate-200">
              Driver 0.4 km away
            </span>
          </div>
        </div>
      )}
    </div>
  );
}
