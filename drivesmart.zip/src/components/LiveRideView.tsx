import { useState, useEffect } from 'react';
import {
  ShieldCheck,
  MapPin,
  Clock,
  Navigation,
  CheckCircle2,
  Shield,
  PhoneCall,
  Share2,
  X,
  Copy,
  Check,
} from 'lucide-react';
import { DriverInfo, RideTier } from '../types';

interface LiveRideViewProps {
  destination: string;
  driver: DriverInfo;
  tier: RideTier;
  fare: number;
  initialDistanceKm?: number;
  initialDurationMins?: number;
  onCompleteRide: () => void;
}

export default function LiveRideView({
  destination,
  driver,
  tier,
  fare,
  initialDistanceKm = 8.4,
  initialDurationMins = 18,
  onCompleteRide,
}: LiveRideViewProps) {
  const [etaRemainingMins, setEtaRemainingMins] = useState(initialDurationMins);
  const [distanceRemainingKm, setDistanceRemainingKm] = useState(initialDistanceKm);
  const [progressPercent, setProgressPercent] = useState(15);
  const [showSafetySheet, setShowSafetySheet] = useState(false);
  const [sosTriggered, setSosTriggered] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  // Progressive automated journey countdown & arrival
  useEffect(() => {
    const timer = setInterval(() => {
      setProgressPercent((p) => {
        if (p >= 98) {
          // Auto complete ride upon arrival!
          onCompleteRide();
          return 100;
        }
        return p + 3;
      });

      setEtaRemainingMins((m) => (m > 1 ? m - 1 : 1));
      setDistanceRemainingKm((d) => (d > 0.4 ? +(d - 0.3).toFixed(1) : 0.1));
    }, 2500);

    return () => clearInterval(timer);
  }, [onCompleteRide]);

  const handleCopyShare = () => {
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleTriggerSOS = () => {
    setSosTriggered(true);
    setTimeout(() => setSosTriggered(false), 5000);
  };

  return (
    <div className="w-full flex flex-col gap-3">
      {/* Clean Glass Panel for Ride In Progress */}
      <div className="rounded-3xl bg-[#10141C]/95 border border-white/[0.08] p-5 shadow-2xl backdrop-blur-xl">
        {/* Status indicator & Minimal SAFETY Button */}
        <div className="flex items-center justify-between pb-3.5 border-b border-white/[0.08]">
          <div className="flex items-center gap-2.5">
            <span className="relative flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-cyan-400"></span>
            </span>
            <span className="text-base font-extrabold text-white tracking-tight">
              Journey in progress
            </span>
          </div>

          {/* Minimal Smart Safety Button */}
          <button
            id="safety-modal-trigger-btn"
            onClick={() => setShowSafetySheet(true)}
            className="flex items-center gap-1.5 text-xs text-rose-300 font-bold bg-rose-500/10 hover:bg-rose-500/20 px-3 py-1.5 rounded-full border border-rose-500/30 active:scale-95 transition-all cursor-pointer"
          >
            <Shield className="w-3.5 h-3.5 text-rose-400 fill-rose-400/20" />
            <span>SAFETY</span>
          </button>
        </div>

        {/* Live Trip Progress Bar */}
        <div className="pt-3 pb-1">
          <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1.5">
            <span>Trip Progress</span>
            <span className="font-mono text-cyan-400 font-bold">{progressPercent}%</span>
          </div>
          <div className="w-full h-2 rounded-full bg-[#1A2230] overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-cyan-500 to-cyan-300 rounded-full transition-all duration-700 shadow-[0_0_10px_rgba(0,240,255,0.6)]"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>

        {/* Destination & ETA Display */}
        <div className="py-3 space-y-3">
          {/* Destination */}
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-xl bg-rose-500/10 border border-rose-500/20 flex items-center justify-center text-rose-400 shrink-0 mt-0.5">
              <MapPin className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                Destination
              </div>
              <div className="text-sm font-bold text-white truncate">
                {destination}
              </div>
            </div>
          </div>

          {/* ETA & Distance */}
          <div className="grid grid-cols-2 gap-2.5 pt-1">
            <div className="p-3 rounded-2xl bg-[#151B27] border border-white/5">
              <div className="text-[11px] text-slate-400 flex items-center gap-1.5 mb-0.5">
                <Clock className="w-3.5 h-3.5 text-cyan-400" />
                <span>ETA</span>
              </div>
              <div className="text-xl font-black font-mono text-white">
                {etaRemainingMins} mins
              </div>
              <div className="text-[10px] text-cyan-300 font-medium">
                Fastest corridor
              </div>
            </div>

            <div className="p-3 rounded-2xl bg-[#151B27] border border-white/5">
              <div className="text-[11px] text-slate-400 flex items-center gap-1.5 mb-0.5">
                <Navigation className="w-3.5 h-3.5 text-cyan-400" />
                <span>Distance</span>
              </div>
              <div className="text-xl font-black font-mono text-white">
                {distanceRemainingKm} km
              </div>
              <div className="text-[10px] text-slate-400 font-medium">
                Speed ~42 km/h
              </div>
            </div>
          </div>

          {/* Driver & Vehicle micro-badge */}
          <div className="flex items-center justify-between p-3 rounded-2xl bg-[#131823] border border-white/5 text-xs">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-full overflow-hidden border border-cyan-400/50">
                <img
                  src={driver.photoUrl}
                  alt={driver.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <div>
                <span className="font-semibold text-white block">{driver.name}</span>
                <span className="text-[11px] text-slate-400">{driver.vehicle}</span>
              </div>
            </div>

            <div className="font-mono text-xs font-bold text-slate-300 bg-white/5 px-2.5 py-1 rounded-lg border border-white/5">
              {driver.vehicleNumber}
            </div>
          </div>
        </div>

        {/* Complete Ride Trigger Button (for quick demo jump or automatic arrival) */}
        <button
          id="complete-ride-simulation-btn"
          onClick={onCompleteRide}
          className="w-full py-3.5 px-4 rounded-2xl bg-cyan-400 hover:bg-cyan-300 active:scale-[0.99] text-slate-950 font-bold text-xs tracking-wider uppercase flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(0,240,255,0.3)] transition-all cursor-pointer"
        >
          <CheckCircle2 className="w-4 h-4 stroke-[2.5]" />
          <span>ARRIVE AT DESTINATION</span>
        </button>
      </div>

      {/* SMART SAFETY MINIMAL BOTTOM SHEET */}
      {showSafetySheet && (
        <div className="fixed inset-0 z-50 flex items-end justify-center p-0 sm:p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-md rounded-t-3xl sm:rounded-3xl bg-[#10141C] border border-white/15 p-5 shadow-2xl space-y-4 animate-in slide-in-from-bottom-6">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <div className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-cyan-400" />
                <h4 className="text-base font-extrabold text-white">
                  DriveSmart Safety Shield
                </h4>
              </div>
              <button
                onClick={() => setShowSafetySheet(false)}
                className="w-8 h-8 rounded-full bg-white/5 border border-white/10 text-slate-300 hover:text-white flex items-center justify-center cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* 1. Emergency SOS Button */}
            <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30">
              <div className="flex items-center justify-between">
                <div>
                  <h5 className="font-bold text-white text-sm">Emergency Assistance</h5>
                  <p className="text-xs text-rose-300/90 mt-0.5">
                    Connect immediately with Police (112) & DriveSmart Safety Team
                  </p>
                </div>
                <button
                  id="trigger-emergency-sos-btn"
                  onClick={handleTriggerSOS}
                  className="px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-extrabold text-xs tracking-wider uppercase flex items-center gap-1.5 shadow-lg shadow-rose-600/30 shrink-0 cursor-pointer active:scale-95"
                >
                  <PhoneCall className="w-3.5 h-3.5" />
                  <span>SOS 112</span>
                </button>
              </div>

              {sosTriggered && (
                <div className="mt-3 p-2.5 rounded-xl bg-rose-500/20 border border-rose-500/40 text-xs text-rose-200 font-semibold flex items-center gap-2 animate-pulse">
                  <span>🚨 Emergency SOS Alert Broadcasted. GPS coordinates transmitted to Central Dispatch.</span>
                </div>
              )}
            </div>

            {/* 2. Share Live Journey */}
            <div className="p-3.5 rounded-2xl bg-[#141A25] border border-white/5 flex items-center justify-between">
              <div>
                <div className="text-xs font-bold text-white">Share Live Journey</div>
                <div className="text-[11px] text-slate-400">Share real-time tracking link with family</div>
              </div>

              <button
                id="share-live-journey-btn"
                onClick={handleCopyShare}
                className="px-3 py-2 rounded-xl bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 text-xs font-bold flex items-center gap-1.5 cursor-pointer active:scale-95 transition-all"
              >
                {copiedLink ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span>LINK COPIED</span>
                  </>
                ) : (
                  <>
                    <Share2 className="w-3.5 h-3.5" />
                    <span>SHARE LINK</span>
                  </>
                )}
              </button>
            </div>

            {/* 3. Verified Driver & Vehicle Credentials */}
            <div className="p-3.5 rounded-2xl bg-[#141A25] border border-white/5 text-xs space-y-2">
              <div className="text-slate-400 uppercase font-semibold text-[10px] tracking-wider">
                Driver Background Verified
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Driver: <strong className="text-white">{driver.name}</strong></span>
                <span className="text-cyan-400 font-bold">{driver.rating} ★ Rated</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Vehicle: <strong className="text-white">{driver.vehicle}</strong></span>
                <span className="font-mono text-white">{driver.vehicleNumber}</span>
              </div>
            </div>

            <button
              onClick={() => setShowSafetySheet(false)}
              className="w-full py-3 rounded-2xl bg-white/10 hover:bg-white/15 text-slate-200 font-bold text-xs tracking-wider cursor-pointer"
            >
              CLOSE SAFETY SHIELD
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
