import { useState } from 'react';
import { Clock, MapPin, CheckCircle, XCircle, ChevronRight, X, Star, Calendar, ShieldCheck, Car, RotateCcw, ArrowRight } from 'lucide-react';
import { RideHistoryItem } from '../types';

interface MyRidesViewProps {
  rides: RideHistoryItem[];
  onBookAgain: (ride: RideHistoryItem) => void;
}

export default function MyRidesView({ rides, onBookAgain }: MyRidesViewProps) {
  const [selectedRide, setSelectedRide] = useState<RideHistoryItem | null>(null);

  return (
    <div className="w-full flex flex-col gap-3.5 pb-4">
      {/* Header */}
      <div className="flex items-center justify-between px-1">
        <div>
          <h2 className="text-xl font-black text-white tracking-tight">
            My Rides
          </h2>
          <p className="text-xs text-slate-400">
            {rides.length} recorded {rides.length === 1 ? 'trip' : 'trips'} · 1-Tap Re-booking
          </p>
        </div>

        <div className="text-xs font-mono text-cyan-400 bg-cyan-500/10 px-2.5 py-1 rounded-full border border-cyan-500/20">
          DriveSmart Verified
        </div>
      </div>

      {/* Rides List */}
      <div className="space-y-3">
        {rides.map((ride) => {
          const isCompleted = ride.status === 'Completed';

          return (
            <div
              key={ride.id}
              id={`history-item-${ride.id}`}
              className="w-full p-4 rounded-3xl bg-[#10141C]/90 border border-white/[0.08] hover:border-cyan-500/40 transition-all shadow-lg backdrop-blur-xl group"
            >
              <div className="flex items-start justify-between gap-2 mb-2">
                <div className="min-w-0 flex-1">
                  {/* Status & Date */}
                  <div className="flex items-center gap-2 mb-1">
                    <span
                      className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        isCompleted
                          ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                          : 'bg-rose-500/15 text-rose-300 border border-rose-500/30'
                      }`}
                    >
                      {isCompleted ? (
                        <CheckCircle className="w-3 h-3 text-emerald-400" />
                      ) : (
                        <XCircle className="w-3 h-3 text-rose-400" />
                      )}
                      <span>{ride.status}</span>
                    </span>

                    <span className="text-[11px] text-slate-400 flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      <span>{ride.date}</span>
                    </span>
                  </div>

                  {/* Destination */}
                  <h3
                    onClick={() => setSelectedRide(ride)}
                    className="text-sm font-bold text-white group-hover:text-cyan-300 transition-colors truncate cursor-pointer"
                  >
                    {ride.destination}
                  </h3>

                  {/* Vehicle Tag */}
                  <div className="text-xs text-slate-400 mt-0.5 truncate flex items-center gap-1">
                    <Car className="w-3 h-3 text-cyan-400" />
                    <span>{ride.tierName} • {ride.vehicleName}</span>
                  </div>
                </div>

                {/* Fare & Rating */}
                <div className="text-right shrink-0 pl-2">
                  <div className="text-base font-extrabold font-mono text-white">
                    ₹{ride.fare}
                  </div>
                  {ride.rating && (
                    <div className="flex items-center justify-end gap-0.5 text-[11px] text-cyan-400 mt-0.5">
                      <Star className="w-3 h-3 fill-cyan-400 text-cyan-400" />
                      <span>{ride.rating}.0</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Bottom Actions Row: 1-Tap "RIDE AGAIN" + View Receipt */}
              <div className="pt-2.5 mt-2 border-t border-white/5 flex items-center justify-between gap-2">
                <button
                  id={`ride-again-card-${ride.id}`}
                  onClick={() => onBookAgain(ride)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-extrabold text-xs tracking-wide uppercase transition-all shadow-[0_0_12px_rgba(0,240,255,0.25)] active:scale-95 cursor-pointer"
                >
                  <RotateCcw className="w-3 h-3 stroke-[2.5]" />
                  <span>RIDE AGAIN</span>
                </button>

                <button
                  id={`view-receipt-btn-${ride.id}`}
                  onClick={() => setSelectedRide(ride)}
                  className="text-xs text-slate-400 hover:text-white flex items-center gap-1 transition-colors cursor-pointer"
                >
                  <span>Receipt details</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Ride Details Modal / Sheet */}
      {selectedRide && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-md rounded-t-3xl sm:rounded-3xl bg-[#10141C] border border-white/15 p-6 shadow-2xl animate-in slide-in-from-bottom-6 duration-200">
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-4 border-b border-white/10">
              <div>
                <span className="text-xs font-mono text-slate-400 uppercase">
                  Trip Receipt
                </span>
                <h4 className="text-lg font-bold text-white">
                  {selectedRide.id}
                </h4>
              </div>
              <button
                id="close-ride-modal-btn"
                onClick={() => setSelectedRide(null)}
                className="w-8 h-8 rounded-full bg-white/5 border border-white/10 text-slate-300 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Route Points */}
            <div className="py-4 space-y-3 border-b border-white/10">
              <div className="flex items-start gap-2.5">
                <div className="w-2.5 h-2.5 rounded-full bg-cyan-400 ring-2 ring-cyan-400/25 mt-1 shrink-0" />
                <div>
                  <div className="text-[10px] text-slate-400 uppercase">Pickup</div>
                  <div className="text-xs font-semibold text-white">
                    {selectedRide.pickup}
                  </div>
                </div>
              </div>

              <div className="flex items-start gap-2.5">
                <div className="w-2.5 h-2.5 rounded-full bg-rose-400 ring-2 ring-rose-400/25 mt-1 shrink-0" />
                <div>
                  <div className="text-[10px] text-slate-400 uppercase">Destination</div>
                  <div className="text-xs font-semibold text-white">
                    {selectedRide.destination}
                  </div>
                </div>
              </div>
            </div>

            {/* Fare Breakdown */}
            <div className="py-4 space-y-2 border-b border-white/10 text-xs">
              <div className="flex items-center justify-between text-slate-300">
                <span>Vehicle Tier</span>
                <span className="font-semibold text-white">{selectedRide.tierName}</span>
              </div>
              <div className="flex items-center justify-between text-slate-300">
                <span>Vehicle & Driver</span>
                <span className="font-semibold text-white">{selectedRide.vehicleName}</span>
              </div>
              <div className="flex items-center justify-between text-slate-300">
                <span>Date & Time</span>
                <span className="text-slate-400">{selectedRide.date}</span>
              </div>
              <div className="flex items-center justify-between text-slate-300">
                <span>Payment</span>
                <span className="text-cyan-400">{selectedRide.paymentMethod}</span>
              </div>
              <div className="flex items-center justify-between pt-2 text-sm font-bold text-white border-t border-white/5">
                <span>Total Paid</span>
                <span className="font-mono text-base text-cyan-300">₹{selectedRide.fare}</span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="mt-5 flex gap-3">
              <button
                id="book-again-modal-btn"
                onClick={() => {
                  const r = selectedRide;
                  setSelectedRide(null);
                  onBookAgain(r);
                }}
                className="flex-1 py-3.5 rounded-2xl bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-bold text-xs tracking-wide uppercase transition-all shadow-[0_0_15px_rgba(0,240,255,0.3)] flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>RIDE AGAIN NOW</span>
              </button>

              <button
                id="dismiss-modal-btn"
                onClick={() => setSelectedRide(null)}
                className="py-3.5 px-5 rounded-2xl bg-white/10 hover:bg-white/15 text-slate-200 font-bold text-xs transition-all cursor-pointer"
              >
                CLOSE
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
