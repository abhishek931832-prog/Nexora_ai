import { useState } from 'react';
import {
  User,
  Phone,
  Mail,
  CreditCard,
  Shield,
  ShieldCheck,
  Check,
  Home,
  Briefcase,
  Bell,
  HelpCircle,
  LogOut,
  ExternalLink,
} from 'lucide-react';
import { UserProfile, SavedLocation } from '../types';

interface ProfileViewProps {
  profile: UserProfile;
  onUpdateProfile: (p: UserProfile) => void;
  savedLocations: SavedLocation[];
  onUpdateLocation: (id: string, newAddress: string) => void;
}

export default function ProfileView({
  profile,
  onUpdateProfile,
  savedLocations,
  onUpdateLocation,
}: ProfileViewProps) {
  const [name, setName] = useState(profile.name);
  const [phone, setPhone] = useState(profile.phone);
  const [defaultPayment, setDefaultPayment] = useState(profile.defaultPayment);
  const [notifications, setNotifications] = useState(profile.notificationsEnabled);
  const [savedMsg, setSavedMsg] = useState(false);
  const [showSupportModal, setShowSupportModal] = useState(false);

  const homeLocation = savedLocations.find((l) => l.type === 'home');
  const workLocation = savedLocations.find((l) => l.type === 'work');

  const [homeAddr, setHomeAddr] = useState(homeLocation?.address || 'B-4/12, Vasant Kunj');
  const [workAddr, setWorkAddr] = useState(workLocation?.address || 'DLF Cyber Hub, Tower 10');

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateProfile({
      ...profile,
      name,
      phone,
      defaultPayment,
      notificationsEnabled: notifications,
    });

    if (homeLocation) onUpdateLocation(homeLocation.id, homeAddr);
    if (workLocation) onUpdateLocation(workLocation.id, workAddr);

    setSavedMsg(true);
    setTimeout(() => setSavedMsg(false), 2000);
  };

  return (
    <div className="w-full flex flex-col gap-4 pb-4">
      {/* Header */}
      <div className="px-1">
        <h2 className="text-xl font-black text-white tracking-tight">
          Customer Profile
        </h2>
        <p className="text-xs text-slate-400">
          Saved once, automatically re-used for all rides
        </p>
      </div>

      {/* Main Profile Card */}
      <div className="rounded-3xl bg-[#10141C]/90 border border-white/[0.08] p-5 shadow-2xl backdrop-blur-xl">
        {/* User Avatar & Badge */}
        <div className="flex items-center gap-4 pb-4 border-b border-white/10">
          <div className="relative">
            <div className="w-14 h-14 rounded-2xl bg-cyan-500/10 border-2 border-cyan-400 flex items-center justify-center text-cyan-400 font-extrabold text-xl shadow-[0_0_15px_rgba(0,240,255,0.25)]">
              {name.slice(0, 2).toUpperCase()}
            </div>
            <div className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-cyan-400 flex items-center justify-center text-slate-950">
              <Check className="w-2.5 h-2.5 stroke-[3]" />
            </div>
          </div>

          <div>
            <h3 className="text-base font-bold text-white">
              {name}
            </h3>
            <span className="inline-flex items-center gap-1 text-[11px] text-cyan-300 font-medium">
              <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
              <span>DriveSmart Priority Customer</span>
            </span>
          </div>
        </div>

        {/* Profile Form */}
        <form onSubmit={handleSaveProfile} className="py-4 space-y-3.5">
          {/* 1. Name */}
          <div>
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
              Full Name
            </label>
            <div className="relative flex items-center">
              <User className="absolute left-3.5 w-4 h-4 text-slate-500" />
              <input
                id="profile-name-input"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-[#0A0D14] border border-white/10 rounded-2xl py-3 pl-10 pr-4 text-xs text-slate-100 focus:outline-none focus:border-cyan-400 font-medium"
              />
            </div>
          </div>

          {/* 2. Phone */}
          <div>
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
              Mobile Number
            </label>
            <div className="relative flex items-center">
              <Phone className="absolute left-3.5 w-4 h-4 text-slate-500" />
              <input
                id="profile-phone-input"
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full bg-[#0A0D14] border border-white/10 rounded-2xl py-3 pl-10 pr-4 text-xs text-slate-100 focus:outline-none focus:border-cyan-400 font-mono"
              />
            </div>
          </div>

          {/* 3. Preferred Payment Method */}
          <div>
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
              Default Payment Method
            </label>
            <div className="relative flex items-center">
              <CreditCard className="absolute left-3.5 w-4 h-4 text-slate-500" />
              <input
                id="profile-payment-input"
                type="text"
                value={defaultPayment}
                onChange={(e) => setDefaultPayment(e.target.value)}
                className="w-full bg-[#0A0D14] border border-white/10 rounded-2xl py-3 pl-10 pr-4 text-xs text-slate-100 focus:outline-none focus:border-cyan-400 font-mono"
              />
            </div>
          </div>

          {/* 4. Saved Places: Home & Work */}
          <div className="pt-2 border-t border-white/10">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-2">
              Saved Places
            </label>

            <div className="space-y-2">
              {/* Home */}
              <div className="p-2.5 rounded-2xl bg-[#141A25] border border-white/5 flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-cyan-500/10 flex items-center justify-center text-cyan-400 shrink-0">
                  <Home className="w-4 h-4" />
                </div>
                <div className="min-w-0 flex-1">
                  <span className="text-[10px] font-bold text-slate-400 block uppercase">Home</span>
                  <input
                    type="text"
                    value={homeAddr}
                    onChange={(e) => setHomeAddr(e.target.value)}
                    className="w-full bg-transparent border-none p-0 text-xs text-white font-medium focus:outline-none focus:underline"
                  />
                </div>
              </div>

              {/* Work */}
              <div className="p-2.5 rounded-2xl bg-[#141A25] border border-white/5 flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-cyan-500/10 flex items-center justify-center text-cyan-400 shrink-0">
                  <Briefcase className="w-4 h-4" />
                </div>
                <div className="min-w-0 flex-1">
                  <span className="text-[10px] font-bold text-slate-400 block uppercase">Work</span>
                  <input
                    type="text"
                    value={workAddr}
                    onChange={(e) => setWorkAddr(e.target.value)}
                    className="w-full bg-transparent border-none p-0 text-xs text-white font-medium focus:outline-none focus:underline"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* 5. Notifications Toggle */}
          <div className="p-3 rounded-2xl bg-[#141A25] border border-white/5 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Bell className="w-4 h-4 text-cyan-400" />
              <div>
                <div className="text-xs font-bold text-white">Ride Notifications</div>
                <div className="text-[10px] text-slate-400">Driver arrival & trip updates</div>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setNotifications(!notifications)}
              className={`w-10 h-6 rounded-full transition-colors p-0.5 cursor-pointer ${
                notifications ? 'bg-cyan-400' : 'bg-slate-700'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-slate-950 transition-transform ${
                  notifications ? 'translate-x-4' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Save Button */}
          <button
            id="save-profile-btn"
            type="submit"
            className="w-full py-3.5 px-4 rounded-2xl bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-bold text-xs tracking-wider uppercase transition-all shadow-[0_0_15px_rgba(0,240,255,0.25)] flex items-center justify-center gap-1.5 cursor-pointer active:scale-95"
          >
            {savedMsg ? (
              <>
                <Check className="w-4 h-4 stroke-[3]" />
                <span>SAVED SUCCESSFULLY</span>
              </>
            ) : (
              <span>SAVE PREFERENCES</span>
            )}
          </button>
        </form>
      </div>

      {/* 6. Support & Help Center Shortcut */}
      <div className="rounded-3xl bg-[#10141C]/80 border border-white/[0.06] p-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400 shrink-0">
            <HelpCircle className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-white">24×7 DriveSmart Support</h4>
            <p className="text-[11px] text-slate-400">Instant ride dispute & lost item help</p>
          </div>
        </div>

        <button
          onClick={() => setShowSupportModal(true)}
          className="text-xs font-bold text-cyan-400 hover:text-cyan-300 px-3 py-1.5 rounded-xl bg-white/5 border border-white/10 cursor-pointer"
        >
          Contact
        </button>
      </div>

      {/* Support Modal */}
      {showSupportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-sm rounded-3xl bg-[#10141C] border border-white/15 p-5 shadow-2xl space-y-4">
            <div className="flex items-center gap-3 text-cyan-400">
              <div className="w-10 h-10 rounded-2xl bg-cyan-500/15 flex items-center justify-center">
                <HelpCircle className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-bold text-white text-base">Support & Help</h4>
                <p className="text-xs text-slate-400">Toll-Free Priority Line: 1800-DRIVESMART</p>
              </div>
            </div>

            <div className="space-y-2 text-xs text-slate-300 pt-1">
              <div className="p-3 rounded-2xl bg-[#141A25] border border-white/5">
                <div className="font-bold text-white">Lost and Found</div>
                <div className="text-[11px] text-slate-400 mt-0.5">We immediately connect you with your previous driver</div>
              </div>
              <div className="p-3 rounded-2xl bg-[#141A25] border border-white/5">
                <div className="font-bold text-white">Fare Correction Guarantee</div>
                <div className="text-[11px] text-slate-400 mt-0.5">Automated refund within 1 hour for route discrepancies</div>
              </div>
            </div>

            <button
              onClick={() => setShowSupportModal(false)}
              className="w-full py-3 rounded-2xl bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-bold text-xs tracking-wider uppercase cursor-pointer"
            >
              CLOSE
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
