import { useState } from 'react';
import { Star, CheckCircle2, Navigation, Clock, CreditCard, ArrowRight, ThumbsUp } from 'lucide-react';
import { DriverInfo, RideTier } from '../types';

interface RideCompletedViewProps {
  destination: string;
  driver: DriverInfo;
  tier: RideTier;
  fare: number;
  paymentMethod: string;
  distanceKm?: number;
  durationMins?: number;
  onFinishRating: (rating: number, tags: string[]) => void;
}

export default function RideCompletedView({
  destination,
  driver,
  tier,
  fare,
  paymentMethod,
  distanceKm = 8.4,
  durationMins = 18,
  onFinishRating,
}: RideCompletedViewProps) {
  const [rating, setRating] = useState(5);
  const [hoverRating, setHoverRating] = useState<number | null>(null);
  const [selectedTags, setSelectedTags] = useState<string[]>(['Clean Car', 'Smooth Drive']);

  const quickFeedbackTags = [
    'Clean Car',
    'Smooth Drive',
    'Polite Driver',
    'Great Route',
    'Quiet Ride',
  ];

  const toggleTag = (tag: string) => {
    setSelectedTags((prev) =>
      prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]
    );
  };

  const handleDone = () => {
    onFinishRating(rating, selectedTags);
  };

  return (
    <div className="w-full flex flex-col gap-3 animate-in fade-in zoom-in-95 duration-300">
      {/* Main Glass Receipt & Rating Card */}
      <div className="rounded-3xl bg-[#10141C]/95 border border-white/[0.08] p-5 shadow-2xl backdrop-blur-xl text-center">
        {/* Success Icon */}
        <div className="w-12 h-12 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 mx-auto flex items-center justify-center mb-3 shadow-[0_0_20px_rgba(0,240,255,0.25)]">
          <CheckCircle2 className="w-7 h-7 stroke-[2.2]" />
        </div>

        {/* Journey Complete */}
        <h2 className="text-xl font-black text-white tracking-tight mb-0.5">
          Journey Complete
        </h2>
        <p className="text-xs text-slate-400 truncate max-w-[280px] mx-auto mb-4">
          {destination}
        </p>

        {/* Automatic Ride Summary Matrix */}
        <div className="p-4 rounded-2xl bg-[#141A25] border border-white/5 mb-4 text-left">
          {/* Final Fare */}
          <div className="flex items-center justify-between pb-3 border-b border-white/5">
            <div>
              <span className="text-[11px] text-slate-400 uppercase font-semibold">
                Final Fare
              </span>
              <div className="text-xs text-slate-400">
                {tier.name} • Guaranteed rate
              </div>
            </div>
            <span className="text-2xl font-black font-mono text-cyan-300">
              ₹{fare}
            </span>
          </div>

          {/* Distance & Duration Grid */}
          <div className="grid grid-cols-2 gap-2 py-3 border-b border-white/5">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-cyan-500/10 flex items-center justify-center text-cyan-400">
                <Navigation className="w-3.5 h-3.5" />
              </div>
              <div>
                <div className="text-[10px] text-slate-400 uppercase">Distance</div>
                <div className="text-xs font-bold text-white font-mono">{distanceKm} km</div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-cyan-500/10 flex items-center justify-center text-cyan-400">
                <Clock className="w-3.5 h-3.5" />
              </div>
              <div>
                <div className="text-[10px] text-slate-400 uppercase">Duration</div>
                <div className="text-xs font-bold text-white font-mono">{durationMins} mins</div>
              </div>
            </div>
          </div>

          {/* Payment Status */}
          <div className="flex items-center justify-between pt-3 text-xs">
            <span className="text-slate-400 flex items-center gap-1.5">
              <CreditCard className="w-3.5 h-3.5 text-slate-400" />
              <span>Payment status</span>
            </span>
            <div className="flex items-center gap-1.5 text-emerald-400 font-semibold">
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
              <span>Paid via {paymentMethod}</span>
            </div>
          </div>
        </div>

        {/* ⭐ Rate Your Ride */}
        <div className="mb-4">
          <div className="text-xs font-bold uppercase tracking-wider text-slate-300 mb-2.5">
            Rate your ride with {driver.name}
          </div>

          {/* Interactive Star Row */}
          <div className="flex items-center justify-center gap-2 mb-3">
            {[1, 2, 3, 4, 5].map((star) => {
              const active = (hoverRating ?? rating) >= star;
              return (
                <button
                  key={star}
                  id={`rate-star-${star}`}
                  type="button"
                  onMouseEnter={() => setHoverRating(star)}
                  onMouseLeave={() => setHoverRating(null)}
                  onClick={() => setRating(star)}
                  className="p-1 text-slate-600 hover:scale-110 active:scale-95 transition-all cursor-pointer"
                >
                  <Star
                    className={`w-7 h-7 transition-colors ${
                      active
                        ? 'fill-cyan-400 text-cyan-400 drop-shadow-[0_0_8px_rgba(0,240,255,0.6)]'
                        : 'text-slate-700'
                    }`}
                  />
                </button>
              );
            })}
          </div>

          {/* Quick Feedback Tags */}
          <div className="flex flex-wrap items-center justify-center gap-1.5">
            {quickFeedbackTags.map((tag) => {
              const isSelected = selectedTags.includes(tag);
              return (
                <button
                  key={tag}
                  id={`feedback-tag-${tag.replace(/\s+/g, '-').toLowerCase()}`}
                  type="button"
                  onClick={() => toggleTag(tag)}
                  className={`text-xs px-3 py-1.5 rounded-full border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300 font-semibold'
                      : 'bg-white/5 border-white/5 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {tag}
                </button>
              );
            })}
          </div>
        </div>

        {/* Done / Return to Home Button */}
        <button
          id="finish-ride-rating-btn"
          onClick={handleDone}
          className="w-full py-4 px-6 rounded-2xl bg-cyan-400 hover:bg-cyan-300 active:scale-[0.99] text-slate-950 font-bold text-sm tracking-wide flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(0,240,255,0.35)] transition-all cursor-pointer"
        >
          <span>DONE & RETURN TO HOME</span>
          <ArrowRight className="w-4 h-4 stroke-[2.5]" />
        </button>
      </div>
    </div>
  );
}
