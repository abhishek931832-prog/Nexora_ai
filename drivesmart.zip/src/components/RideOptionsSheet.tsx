import { Users, Clock, ArrowLeft, ArrowRight, ShieldCheck, Car, Navigation } from 'lucide-react';
import { RideTier, RouteEstimate } from '../types';
import { RIDE_TIERS, calculateRouteEstimate } from '../data/mockData';

interface RideOptionsSheetProps {
  pickup: string;
  destination: string;
  selectedTier: RideTier;
  onSelectTier: (tier: RideTier) => void;
  onBookRide: () => void;
  onBack: () => void;
}

export default function RideOptionsSheet({
  pickup,
  destination,
  selectedTier,
  onSelectTier,
  onBookRide,
  onBack,
}: RideOptionsSheetProps) {
  const estimate: RouteEstimate = calculateRouteEstimate(destination);

  return (
    <div className="w-full flex flex-col gap-3">
      {/* Route Badge & Back Navigation */}
      <div className="flex items-center justify-between px-1">
        <button
          id="back-to-home-btn"
          onClick={onBack}
          className="flex items-center gap-1.5 text-xs font-semibold text-slate-400 hover:text-white px-3 py-1.5 rounded-full bg-[#141822]/80 border border-white/10 active:scale-95 transition-all"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Change Destination</span>
        </button>

        <div className="text-xs text-cyan-400 font-mono flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
          <span>Instant Estimates</span>
        </div>
      </div>

      {/* Ride Options Card Container */}
      <div className="rounded-3xl bg-[#10141C]/95 border border-white/[0.08] p-4 shadow-2xl backdrop-blur-xl">
        {/* Automatic Ride Calculation Summary Banner */}
        <div className="p-3 mb-3 rounded-2xl bg-[#141A25] border border-white/5 flex items-center justify-between text-xs">
          <div className="min-w-0 pr-2">
            <div className="text-[10px] uppercase font-bold text-cyan-400 tracking-wider flex items-center gap-1">
              <Navigation className="w-3 h-3" />
              <span>Route Calculated</span>
            </div>
            <div className="text-white font-bold truncate mt-0.5">
              {destination}
            </div>
          </div>

          <div className="text-right shrink-0">
            <div className="text-white font-bold font-mono text-sm">
              {estimate.distanceKm} km
            </div>
            <div className="text-[11px] text-slate-400 font-medium">
              ~{estimate.durationMins} min trip
            </div>
          </div>
        </div>

        {/* Tier Cards: Smart, Comfort, XL */}
        <div className="space-y-2.5">
          {RIDE_TIERS.map((tier) => {
            const isSelected = selectedTier.id === tier.id;

            return (
              <div
                key={tier.id}
                id={`tier-card-${tier.id}`}
                onClick={() => onSelectTier(tier)}
                className={`relative w-full p-4 rounded-2xl border transition-all cursor-pointer select-none flex items-center justify-between ${
                  isSelected
                    ? 'bg-cyan-950/35 border-cyan-400 shadow-[0_0_20px_rgba(0,240,255,0.2)] ring-1 ring-cyan-400/40'
                    : 'bg-[#141924]/60 border-white/[0.06] hover:border-white/15 hover:bg-[#161C28]'
                }`}
              >
                {/* Left side: Vehicle icon & Details */}
                <div className="flex items-center gap-3.5">
                  <div
                    className={`w-12 h-12 rounded-xl flex items-center justify-center border transition-all shrink-0 ${
                      isSelected
                        ? 'bg-cyan-500/20 border-cyan-400/60 text-cyan-300'
                        : 'bg-[#1B2230] border-white/10 text-slate-400'
                    }`}
                  >
                    <Car className="w-6 h-6" />
                  </div>

                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-base font-bold text-white">
                        {tier.name}
                      </span>
                      <span className="flex items-center gap-1 text-xs text-slate-400 bg-white/5 px-2 py-0.5 rounded-full font-medium">
                        <Users className="w-3 h-3" />
                        <span>{tier.seats} seats</span>
                      </span>
                    </div>

                    <div className="flex items-center gap-2 mt-0.5 text-xs text-slate-400">
                      <span className="flex items-center gap-1 text-cyan-300 font-medium">
                        <Clock className="w-3 h-3 text-cyan-400" />
                        <span>{tier.etaMinutes} min away</span>
                      </span>
                      <span>•</span>
                      <span className="text-slate-400 truncate max-w-[120px]">
                        {tier.vehicleModel}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Right side: Fare */}
                <div className="text-right pl-2 shrink-0">
                  <div className="text-lg font-extrabold font-mono text-white tracking-tight">
                    ₹{tier.fare}
                  </div>
                  <div className="text-[11px] text-emerald-400 font-medium">
                    Estimated fare
                  </div>
                </div>

                {/* Selected Indicator dot */}
                {isSelected && (
                  <div className="absolute -top-1.5 -right-1.5 w-4 h-4 rounded-full bg-cyan-400 border-2 border-[#10141C] flex items-center justify-center">
                    <div className="w-1.5 h-1.5 rounded-full bg-slate-950" />
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Selected Tier Summary */}
        <div className="mt-3.5 p-3 rounded-2xl bg-white/[0.03] border border-white/5 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2 text-slate-300">
            <ShieldCheck className="w-4 h-4 text-cyan-400" />
            <span>
              Selected: <strong className="text-white">{selectedTier.name}</strong> ({selectedTier.seats} seats)
            </span>
          </div>
          <span className="text-cyan-400 font-mono font-bold text-sm">
            ₹{selectedTier.fare}
          </span>
        </div>

        {/* Main Action: BOOK DRIVESMART */}
        <button
          id="book-drivesmart-btn"
          onClick={onBookRide}
          className="mt-4 w-full py-4 px-6 rounded-2xl bg-cyan-400 hover:bg-cyan-300 active:scale-[0.99] text-slate-950 font-bold text-base tracking-wide flex items-center justify-center gap-2 shadow-[0_0_25px_rgba(0,240,255,0.35)] transition-all cursor-pointer"
        >
          <span>BOOK DRIVESMART</span>
          <ArrowRight className="w-5 h-5 stroke-[2.5]" />
        </button>
      </div>
    </div>
  );
}
