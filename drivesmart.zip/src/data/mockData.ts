import { RideTier, SavedLocation, DriverInfo, RideHistoryItem, UserProfile, DestinationSuggestion, RouteEstimate } from '../types';

export const DEFAULT_USER_PROFILE: UserProfile = {
  name: 'Abhishek Sharma',
  phone: '+91 98765 43210',
  email: 'abhishek.sharma@example.com',
  defaultPayment: 'DriveSmart UPI (•••4829)',
  notificationsEnabled: true,
};

export const RIDE_TIERS: RideTier[] = [
  {
    id: 'smart',
    name: 'Smart',
    tagline: 'Affordable, compact daily commute',
    seats: 4,
    etaMinutes: 5,
    fare: 250,
    vehicleModel: 'Hyundai Aura / Swift',
    imageIcon: 'car',
  },
  {
    id: 'comfort',
    name: 'Comfort',
    tagline: 'Spacious sedans with top-rated drivers',
    seats: 4,
    etaMinutes: 7,
    fare: 350,
    vehicleModel: 'Honda City / Škoda Slavia',
    imageIcon: 'car-front',
  },
  {
    id: 'xl',
    name: 'XL',
    tagline: 'Premium 6-seater for groups & luggage',
    seats: 6,
    etaMinutes: 8,
    fare: 450,
    vehicleModel: 'Toyota Innova / Ertiga',
    imageIcon: 'truck',
  },
];

export const SAVED_LOCATIONS: SavedLocation[] = [
  {
    id: 'loc-home',
    type: 'home',
    label: 'Home',
    address: 'B-4/12, Vasant Kunj',
    area: 'South New Delhi',
    lat: 28.5244,
    lng: 77.1588,
  },
  {
    id: 'loc-work',
    type: 'work',
    label: 'Work',
    address: 'DLF Cyber Hub, Tower 10',
    area: 'Cyber City, Gurugram',
    lat: 28.4986,
    lng: 77.0878,
  },
  {
    id: 'loc-recent',
    type: 'recent',
    label: 'Aerocity Metro Station',
    address: 'Hospitality District, Aerocity',
    area: 'IGI Airport Corridor',
    lat: 28.5495,
    lng: 77.1215,
  },
];

export const SMART_DESTINATIONS: DestinationSuggestion[] = [
  {
    id: 'dest-work',
    label: 'DLF Cyber Hub, Tower 10',
    address: 'Cyber City, Gurugram',
    area: 'Gurugram IT Corridor',
    timeMins: 18,
    distanceKm: 8.4,
    isPopular: true,
  },
  {
    id: 'dest-home',
    label: 'B-4/12, Vasant Kunj',
    address: 'Sector B, Vasant Kunj',
    area: 'South New Delhi',
    timeMins: 16,
    distanceKm: 7.2,
    isPopular: true,
  },
  {
    id: 'dest-airport',
    label: 'Indira Gandhi Int’l Airport (T3)',
    address: 'Terminal 3 Departures',
    area: 'Airport Zone',
    timeMins: 28,
    distanceKm: 14.2,
    isPopular: true,
  },
  {
    id: 'dest-mall',
    label: 'Select CITYWALK Mall',
    address: 'A-3, District Centre, Saket',
    area: 'Saket, New Delhi',
    timeMins: 22,
    distanceKm: 9.8,
    isPopular: true,
  },
  {
    id: 'dest-cp',
    label: 'Connaught Place (Inner Circle)',
    address: 'Block A, Connaught Place',
    area: 'Central Delhi',
    timeMins: 12,
    distanceKm: 5.5,
    isPopular: false,
  },
  {
    id: 'dest-aerocity',
    label: 'Aerocity Worldmark',
    address: 'Hospitality District, Aerocity',
    area: 'IGI Airport Corridor',
    timeMins: 20,
    distanceKm: 11.0,
    isPopular: false,
  },
  {
    id: 'dest-noida',
    label: 'Mall of India, Sector 18',
    address: 'Sector 18, Noida',
    area: 'Noida Center',
    timeMins: 34,
    distanceKm: 17.6,
    isPopular: false,
  },
];

export function calculateRouteEstimate(destination: string): RouteEstimate {
  const match = SMART_DESTINATIONS.find((d) =>
    destination.toLowerCase().includes(d.label.toLowerCase()) ||
    d.label.toLowerCase().includes(destination.toLowerCase())
  );

  if (match) {
    return {
      distanceKm: match.distanceKm,
      durationMins: match.timeMins,
      routeSummary: `Via ${match.area} (Fastest)`,
    };
  }

  // Consistent hash for any custom typed destination
  let hash = 0;
  for (let i = 0; i < destination.length; i++) {
    hash = (hash << 5) - hash + destination.charCodeAt(i);
    hash |= 0;
  }
  const positiveHash = Math.abs(hash);
  const distance = Number((6 + (positiveHash % 120) / 10).toFixed(1));
  const duration = Math.round(distance * 2.1 + 4);

  return {
    distanceKm: distance,
    durationMins: duration,
    routeSummary: 'Via Express Corridor (Traffic Normal)',
  };
}

export const POPULAR_DESTINATIONS = [
  {
    label: 'Indira Gandhi Int’l Airport (T3)',
    address: 'Terminal 3, New Delhi',
    area: 'Airport Zone',
    distance: '14.2 km',
  },
  {
    label: 'Select CITYWALK Mall',
    address: 'A-3, District Centre, Saket',
    area: 'Saket, New Delhi',
    distance: '9.8 km',
  },
  {
    label: 'Connaught Place (Inner Circle)',
    address: 'Block A, Connaught Place',
    area: 'Central Delhi',
    distance: '16.5 km',
  },
];

export const SAMPLE_DRIVERS: DriverInfo[] = [
  {
    name: 'Rajesh Kumar',
    photoUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=240&h=240&q=80',
    rating: 4.94,
    totalTrips: '3,420 trips',
    vehicle: 'Honda City (Pearl White)',
    vehicleNumber: 'DL 01 CA 9824',
    color: 'White',
    phoneNumber: '+91 98112 34567',
    safetyPin: '4821',
  },
  {
    name: 'Arjun Verma',
    photoUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=240&h=240&q=80',
    rating: 4.89,
    totalTrips: '2,180 trips',
    vehicle: 'Hyundai Aura (Titan Grey)',
    vehicleNumber: 'DL 03 BR 7109',
    color: 'Grey',
    phoneNumber: '+91 98711 65432',
    safetyPin: '6390',
  },
  {
    name: 'Vikram Singh',
    photoUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=240&h=240&q=80',
    rating: 4.96,
    totalTrips: '4,510 trips',
    vehicle: 'Toyota Innova Crysta (Silver)',
    vehicleNumber: 'HR 26 DQ 5512',
    color: 'Silver',
    phoneNumber: '+91 99990 88211',
    safetyPin: '8215',
  },
];

export const INITIAL_RIDE_HISTORY: RideHistoryItem[] = [
  {
    id: 'DS-9082',
    pickup: 'Current Location (Connaught Place)',
    destination: 'Select CITYWALK Mall, Saket',
    date: 'Yesterday, 8:45 PM',
    fare: 350,
    tierName: 'Comfort',
    vehicleName: 'Honda City • DL 01 CA 9824',
    status: 'Completed',
    rating: 5,
    duration: '26 mins',
    distance: '12.4 km',
    paymentMethod: 'UPI (•••4829)',
  },
  {
    id: 'DS-8941',
    pickup: 'DLF Cyber Hub, Tower 10',
    destination: 'B-4/12, Vasant Kunj, New Delhi',
    date: '16 Sep 2026, 6:15 PM',
    fare: 250,
    tierName: 'Smart',
    vehicleName: 'Hyundai Aura • DL 03 BR 7109',
    status: 'Completed',
    rating: 5,
    duration: '32 mins',
    distance: '15.1 km',
    paymentMethod: 'UPI (•••4829)',
  },
  {
    id: 'DS-8710',
    pickup: 'Aerocity Metro Station',
    destination: 'Cyber City Building 9',
    date: '14 Sep 2026, 11:30 AM',
    fare: 250,
    tierName: 'Smart',
    vehicleName: 'Swift Dzire • DL 02 CZ 4410',
    status: 'Cancelled',
    duration: '0 mins',
    distance: '0 km',
    paymentMethod: 'UPI (Refunded)',
  },
];
