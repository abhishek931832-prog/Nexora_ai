export type RideTierId = 'smart' | 'comfort' | 'xl';

export interface RideTier {
  id: RideTierId;
  name: string;
  tagline: string;
  seats: number;
  etaMinutes: number;
  fare: number;
  vehicleModel: string;
  imageIcon: string;
}

export interface SavedLocation {
  id: string;
  type: 'home' | 'work' | 'recent';
  label: string;
  address: string;
  area: string;
  lat: number;
  lng: number;
}

export interface DriverInfo {
  name: string;
  photoUrl: string;
  rating: number;
  totalTrips: string;
  vehicle: string;
  vehicleNumber: string;
  color: string;
  phoneNumber: string;
  safetyPin: string;
}

export type RidePhase = 
  | 'idle'            // Screen 1: Home
  | 'selecting_tier'  // Screen 2: Ride Options
  | 'confirming'      // Screen 3: Confirm Booking
  | 'matching'        // Screen 3.5: Smart Driver Matching radar
  | 'driver_found'    // Screen 4: Driver Found (on the way / arrived)
  | 'in_progress'     // Screen 5: Live Ride
  | 'completed';      // Screen 6: Ride Completed

export type DriverStatus = 'driver_en_route' | 'driver_arrived' | 'on_trip' | 'completed' | 'cancelled';

export interface DestinationSuggestion {
  id: string;
  label: string;
  address: string;
  area: string;
  timeMins: number;
  distanceKm: number;
  isPopular?: boolean;
}

export interface RouteEstimate {
  distanceKm: number;
  durationMins: number;
  routeSummary: string;
}

export interface UserProfile {
  name: string;
  phone: string;
  email: string;
  defaultPayment: string;
  notificationsEnabled: boolean;
}

export interface ActiveBooking {
  id: string;
  pickup: string;
  pickupCoords: { x: number; y: number };
  destination: string;
  destinationCoords: { x: number; y: number };
  tier: RideTier;
  fare: number;
  paymentMethod: string;
  driver: DriverInfo;
  createdAt: string;
  status: DriverStatus;
  distanceKm: number;
  durationMins: number;
  rating?: number;
  feedbackTags?: string[];
}

export interface RideHistoryItem {
  id: string;
  pickup: string;
  destination: string;
  date: string;
  fare: number;
  tierName: string;
  vehicleName: string;
  status: 'Completed' | 'Cancelled';
  rating?: number;
  duration?: string;
  distance?: string;
  paymentMethod: string;
}
